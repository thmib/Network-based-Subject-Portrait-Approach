#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 4g
#SBATCH -t 1:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_121000-121999.data NLCRC_13000-13999.data > NLCRC_121000-121999.data+NLCRC_13000-13999.data.ig


