#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 4g
#SBATCH -t 1:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_51000-51999.data NLCRC_71000-71999.data > NLCRC_51000-51999.data+NLCRC_71000-71999.data.ig


