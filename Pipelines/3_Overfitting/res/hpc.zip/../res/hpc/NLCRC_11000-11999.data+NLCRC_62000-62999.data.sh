#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 4g
#SBATCH -t 1:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_11000-11999.data NLCRC_62000-62999.data > NLCRC_11000-11999.data+NLCRC_62000-62999.data.ig


