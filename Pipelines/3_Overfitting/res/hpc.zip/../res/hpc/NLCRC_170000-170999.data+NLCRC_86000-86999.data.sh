#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 4g
#SBATCH -t 1:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_170000-170999.data NLCRC_86000-86999.data > NLCRC_170000-170999.data+NLCRC_86000-86999.data.ig


