#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 4g
#SBATCH -t 1:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_125000-125999.data NLCRC_201000-201999.data > NLCRC_125000-125999.data+NLCRC_201000-201999.data.ig


