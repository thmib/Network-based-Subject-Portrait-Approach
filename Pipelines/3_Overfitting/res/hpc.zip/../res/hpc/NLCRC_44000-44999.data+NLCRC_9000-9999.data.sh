#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 4g
#SBATCH -t 1:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_44000-44999.data NLCRC_9000-9999.data > NLCRC_44000-44999.data+NLCRC_9000-9999.data.ig


