#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 4g
#SBATCH -t 1:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_182000-182999.data NLCRC_238000-238195.data > NLCRC_182000-182999.data+NLCRC_238000-238195.data.ig


