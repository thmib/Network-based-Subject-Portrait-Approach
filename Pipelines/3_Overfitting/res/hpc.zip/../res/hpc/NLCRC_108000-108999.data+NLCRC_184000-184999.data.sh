#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 4g
#SBATCH -t 1:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_108000-108999.data NLCRC_184000-184999.data > NLCRC_108000-108999.data+NLCRC_184000-184999.data.ig


