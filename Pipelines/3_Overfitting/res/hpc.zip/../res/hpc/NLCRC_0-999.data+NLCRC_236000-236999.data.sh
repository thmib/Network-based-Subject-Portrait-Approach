#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 4g
#SBATCH -t 1:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_0-999.data NLCRC_236000-236999.data > NLCRC_0-999.data+NLCRC_236000-236999.data.ig


