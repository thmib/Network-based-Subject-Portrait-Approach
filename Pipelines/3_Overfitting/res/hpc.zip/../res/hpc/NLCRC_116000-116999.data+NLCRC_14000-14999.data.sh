#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 4g
#SBATCH -t 1:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_116000-116999.data NLCRC_14000-14999.data > NLCRC_116000-116999.data+NLCRC_14000-14999.data.ig


