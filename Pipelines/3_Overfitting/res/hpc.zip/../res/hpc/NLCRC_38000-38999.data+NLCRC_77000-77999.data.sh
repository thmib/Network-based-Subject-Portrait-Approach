#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 4g
#SBATCH -t 1:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_38000-38999.data NLCRC_77000-77999.data > NLCRC_38000-38999.data+NLCRC_77000-77999.data.ig


