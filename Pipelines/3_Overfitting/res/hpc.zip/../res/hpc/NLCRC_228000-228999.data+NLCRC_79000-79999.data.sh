#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 4g
#SBATCH -t 1:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_228000-228999.data NLCRC_79000-79999.data > NLCRC_228000-228999.data+NLCRC_79000-79999.data.ig


