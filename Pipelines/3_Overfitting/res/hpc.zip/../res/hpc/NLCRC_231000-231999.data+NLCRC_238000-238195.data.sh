#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 4g
#SBATCH -t 1:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_231000-231999.data NLCRC_238000-238195.data > NLCRC_231000-231999.data+NLCRC_238000-238195.data.ig


