#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 4g
#SBATCH -t 1:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_35000-35999.data NLCRC_91000-91999.data > NLCRC_35000-35999.data+NLCRC_91000-91999.data.ig


