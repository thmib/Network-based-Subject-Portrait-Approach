#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 4g
#SBATCH -t 1:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_16000-16999.data NLCRC_63000-63999.data > NLCRC_16000-16999.data+NLCRC_63000-63999.data.ig


