#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 4g
#SBATCH -t 1:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_109000-109999.data NLCRC_212000-212999.data > NLCRC_109000-109999.data+NLCRC_212000-212999.data.ig


