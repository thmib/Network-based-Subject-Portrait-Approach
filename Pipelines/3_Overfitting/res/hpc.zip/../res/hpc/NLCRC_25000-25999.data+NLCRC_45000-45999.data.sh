#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 4g
#SBATCH -t 1:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_25000-25999.data NLCRC_45000-45999.data > NLCRC_25000-25999.data+NLCRC_45000-45999.data.ig


