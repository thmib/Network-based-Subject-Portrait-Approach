#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 4g
#SBATCH -t 1:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_137000-137999.data NLCRC_46000-46999.data > NLCRC_137000-137999.data+NLCRC_46000-46999.data.ig


