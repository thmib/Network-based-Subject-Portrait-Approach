#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 4g
#SBATCH -t 1:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_26000-26999.data NLCRC_95000-95999.data > NLCRC_26000-26999.data+NLCRC_95000-95999.data.ig


