#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 4g
#SBATCH -t 1:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_132000-132999.data NLCRC_75000-75999.data > NLCRC_132000-132999.data+NLCRC_75000-75999.data.ig


