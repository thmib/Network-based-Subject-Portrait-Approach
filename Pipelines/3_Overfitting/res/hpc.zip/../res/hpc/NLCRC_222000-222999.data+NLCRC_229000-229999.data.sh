#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 4g
#SBATCH -t 1:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_222000-222999.data NLCRC_229000-229999.data > NLCRC_222000-222999.data+NLCRC_229000-229999.data.ig


