#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 4g
#SBATCH -t 1:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_12000-12999.data NLCRC_183000-183999.data > NLCRC_12000-12999.data+NLCRC_183000-183999.data.ig


