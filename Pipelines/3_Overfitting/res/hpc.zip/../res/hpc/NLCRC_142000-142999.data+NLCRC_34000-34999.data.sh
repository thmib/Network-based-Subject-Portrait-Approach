#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 4g
#SBATCH -t 1:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_142000-142999.data NLCRC_34000-34999.data > NLCRC_142000-142999.data+NLCRC_34000-34999.data.ig


