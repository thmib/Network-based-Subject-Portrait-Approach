#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 4g
#SBATCH -t 1:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_122000-122999.data NLCRC_162000-162999.data > NLCRC_122000-122999.data+NLCRC_162000-162999.data.ig


