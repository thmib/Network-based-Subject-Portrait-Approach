#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 4g
#SBATCH -t 1:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_144000-144999.data NLCRC_174000-174999.data > NLCRC_144000-144999.data+NLCRC_174000-174999.data.ig


