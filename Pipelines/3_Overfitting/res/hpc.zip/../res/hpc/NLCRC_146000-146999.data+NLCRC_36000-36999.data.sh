#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 4g
#SBATCH -t 1:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_146000-146999.data NLCRC_36000-36999.data > NLCRC_146000-146999.data+NLCRC_36000-36999.data.ig


