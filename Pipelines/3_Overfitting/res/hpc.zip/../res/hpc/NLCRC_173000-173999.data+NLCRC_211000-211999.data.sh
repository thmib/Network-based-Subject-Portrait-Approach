#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 4g
#SBATCH -t 1:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_173000-173999.data NLCRC_211000-211999.data > NLCRC_173000-173999.data+NLCRC_211000-211999.data.ig


