#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 4g
#SBATCH -t 1:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_126000-126999.data NLCRC_21000-21999.data > NLCRC_126000-126999.data+NLCRC_21000-21999.data.ig


