#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 4g
#SBATCH -t 1:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_61000-61999.data NLCRC_87000-87999.data > NLCRC_61000-61999.data+NLCRC_87000-87999.data.ig


