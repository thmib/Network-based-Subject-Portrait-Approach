#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 4g
#SBATCH -t 1:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_147000-147999.data NLCRC_81000-81999.data > NLCRC_147000-147999.data+NLCRC_81000-81999.data.ig


