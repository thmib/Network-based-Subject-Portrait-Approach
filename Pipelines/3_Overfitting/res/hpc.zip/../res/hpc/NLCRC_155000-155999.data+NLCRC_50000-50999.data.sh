#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 4g
#SBATCH -t 1:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_155000-155999.data NLCRC_50000-50999.data > NLCRC_155000-155999.data+NLCRC_50000-50999.data.ig


