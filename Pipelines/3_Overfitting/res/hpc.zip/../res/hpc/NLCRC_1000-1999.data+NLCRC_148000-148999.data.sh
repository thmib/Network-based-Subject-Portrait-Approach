#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 4g
#SBATCH -t 1:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_1000-1999.data NLCRC_148000-148999.data > NLCRC_1000-1999.data+NLCRC_148000-148999.data.ig


