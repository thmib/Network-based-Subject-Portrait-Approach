#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 12g
#SBATCH -t 24:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_236000-236999.data NLCRC_28000-28999.data > NLCRC_236000-236999.data+NLCRC_28000-28999.data.ig
