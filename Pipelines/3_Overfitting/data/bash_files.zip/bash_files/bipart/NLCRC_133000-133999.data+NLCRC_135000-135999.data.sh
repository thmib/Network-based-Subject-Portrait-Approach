#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 12g
#SBATCH -t 24:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_133000-133999.data NLCRC_135000-135999.data > NLCRC_133000-133999.data+NLCRC_135000-135999.data.ig
