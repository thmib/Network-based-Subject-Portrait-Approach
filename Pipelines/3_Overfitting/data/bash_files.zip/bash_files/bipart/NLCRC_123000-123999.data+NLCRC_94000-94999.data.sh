#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 12g
#SBATCH -t 24:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_123000-123999.data NLCRC_94000-94999.data > NLCRC_123000-123999.data+NLCRC_94000-94999.data.ig
