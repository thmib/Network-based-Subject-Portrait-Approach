#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 12g
#SBATCH -t 24:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_138000-138999.data NLCRC_3000-3999.data > NLCRC_138000-138999.data+NLCRC_3000-3999.data.ig
