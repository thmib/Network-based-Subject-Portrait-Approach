#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 12g
#SBATCH -t 24:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_159000-159999.data NLCRC_35000-35999.data > NLCRC_159000-159999.data+NLCRC_35000-35999.data.ig
