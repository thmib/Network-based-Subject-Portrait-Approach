#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 12g
#SBATCH -t 24:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_31000-31999.data NLCRC_40000-40999.data > NLCRC_31000-31999.data+NLCRC_40000-40999.data.ig
