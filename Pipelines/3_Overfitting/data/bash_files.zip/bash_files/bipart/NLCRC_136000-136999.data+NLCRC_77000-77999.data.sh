#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 12g
#SBATCH -t 24:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_136000-136999.data NLCRC_77000-77999.data > NLCRC_136000-136999.data+NLCRC_77000-77999.data.ig
