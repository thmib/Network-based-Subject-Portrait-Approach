#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 12g
#SBATCH -t 24:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_39000-39999.data NLCRC_9000-9999.data > NLCRC_39000-39999.data+NLCRC_9000-9999.data.ig
