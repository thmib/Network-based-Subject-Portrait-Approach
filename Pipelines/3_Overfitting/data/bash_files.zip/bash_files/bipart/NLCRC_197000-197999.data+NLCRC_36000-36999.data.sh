#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 12g
#SBATCH -t 24:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_197000-197999.data NLCRC_36000-36999.data > NLCRC_197000-197999.data+NLCRC_36000-36999.data.ig
