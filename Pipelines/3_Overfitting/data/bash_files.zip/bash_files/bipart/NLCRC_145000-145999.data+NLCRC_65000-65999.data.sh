#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 12g
#SBATCH -t 24:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_145000-145999.data NLCRC_65000-65999.data > NLCRC_145000-145999.data+NLCRC_65000-65999.data.ig
