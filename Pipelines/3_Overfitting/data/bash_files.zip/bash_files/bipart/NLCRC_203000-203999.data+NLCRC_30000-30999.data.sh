#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 12g
#SBATCH -t 24:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_203000-203999.data NLCRC_30000-30999.data > NLCRC_203000-203999.data+NLCRC_30000-30999.data.ig
