#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 12g
#SBATCH -t 24:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_212000-212999.data NLCRC_57000-57999.data > NLCRC_212000-212999.data+NLCRC_57000-57999.data.ig
