#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 12g
#SBATCH -t 24:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_122000-122999.data NLCRC_139000-139999.data > NLCRC_122000-122999.data+NLCRC_139000-139999.data.ig
