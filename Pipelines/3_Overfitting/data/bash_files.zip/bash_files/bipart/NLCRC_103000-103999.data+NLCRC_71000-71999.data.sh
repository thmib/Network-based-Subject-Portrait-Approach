#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 12g
#SBATCH -t 24:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_103000-103999.data NLCRC_71000-71999.data > NLCRC_103000-103999.data+NLCRC_71000-71999.data.ig
