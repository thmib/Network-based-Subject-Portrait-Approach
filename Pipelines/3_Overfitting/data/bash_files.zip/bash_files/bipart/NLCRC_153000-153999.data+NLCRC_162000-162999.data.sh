#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 12g
#SBATCH -t 24:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_153000-153999.data NLCRC_162000-162999.data > NLCRC_153000-153999.data+NLCRC_162000-162999.data.ig
