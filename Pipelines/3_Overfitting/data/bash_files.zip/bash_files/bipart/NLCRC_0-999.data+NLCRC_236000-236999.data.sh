#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 12g
#SBATCH -t 24:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_0-999.data NLCRC_236000-236999.data > NLCRC_0-999.data+NLCRC_236000-236999.data.ig
