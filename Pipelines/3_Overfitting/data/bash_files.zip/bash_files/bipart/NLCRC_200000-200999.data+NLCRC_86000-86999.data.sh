#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 12g
#SBATCH -t 24:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_200000-200999.data NLCRC_86000-86999.data > NLCRC_200000-200999.data+NLCRC_86000-86999.data.ig
