#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 12g
#SBATCH -t 24:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_171000-171999.data NLCRC_232000-232999.data > NLCRC_171000-171999.data+NLCRC_232000-232999.data.ig
