#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 12g
#SBATCH -t 24:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_119000-119999.data NLCRC_41000-41999.data > NLCRC_119000-119999.data+NLCRC_41000-41999.data.ig
