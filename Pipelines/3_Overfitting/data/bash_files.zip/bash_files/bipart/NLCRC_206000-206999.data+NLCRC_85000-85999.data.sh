#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 12g
#SBATCH -t 24:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_206000-206999.data NLCRC_85000-85999.data > NLCRC_206000-206999.data+NLCRC_85000-85999.data.ig
