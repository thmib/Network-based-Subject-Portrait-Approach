#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 12g
#SBATCH -t 24:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_146000-146999.data NLCRC_28000-28999.data > NLCRC_146000-146999.data+NLCRC_28000-28999.data.ig
