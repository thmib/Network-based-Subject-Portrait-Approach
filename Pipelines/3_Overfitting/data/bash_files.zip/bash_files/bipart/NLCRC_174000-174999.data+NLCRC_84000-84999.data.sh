#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 12g
#SBATCH -t 24:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_174000-174999.data NLCRC_84000-84999.data > NLCRC_174000-174999.data+NLCRC_84000-84999.data.ig
