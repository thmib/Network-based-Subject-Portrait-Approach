#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 12g
#SBATCH -t 24:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_198000-198999.data NLCRC_215000-215999.data > NLCRC_198000-198999.data+NLCRC_215000-215999.data.ig
