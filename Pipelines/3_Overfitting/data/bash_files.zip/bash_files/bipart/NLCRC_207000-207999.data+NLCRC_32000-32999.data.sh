#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 12g
#SBATCH -t 24:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_207000-207999.data NLCRC_32000-32999.data > NLCRC_207000-207999.data+NLCRC_32000-32999.data.ig
