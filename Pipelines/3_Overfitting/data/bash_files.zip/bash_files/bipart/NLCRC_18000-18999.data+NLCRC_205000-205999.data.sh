#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 12g
#SBATCH -t 24:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_18000-18999.data NLCRC_205000-205999.data > NLCRC_18000-18999.data+NLCRC_205000-205999.data.ig
