#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 12g
#SBATCH -t 24:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_183000-183999.data NLCRC_190000-190999.data > NLCRC_183000-183999.data+NLCRC_190000-190999.data.ig
