#!/bin/bash
#SBATCH --job-name=Bipartisan
#SBATCH -c 12
#SBATCH --mem 12g
#SBATCH -t 24:00:00

source ~/ENV/bin/activate


python ComprehensiveNetwork_Bipartisan.py NLCRC_38000-38999.data NLCRC_69000-69999.data > NLCRC_38000-38999.data+NLCRC_69000-69999.data.ig
