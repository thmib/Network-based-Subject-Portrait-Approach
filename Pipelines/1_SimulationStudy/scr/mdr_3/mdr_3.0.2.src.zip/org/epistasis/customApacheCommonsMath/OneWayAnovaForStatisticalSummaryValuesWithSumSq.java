package org.epistasis.customApacheCommonsMath;

/**
 * this is a copy of the Apache Commons Math OneWayAnova which accepts a
 * list of StatisticalSummary objects rather than requiring the actual raw
 * data
 */
/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
//package org.apache.commons.math3.stat.inference;

import java.util.Collection;

import org.apache.commons.math3.distribution.FDistribution;
import org.apache.commons.math3.exception.ConvergenceException;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.exception.util.LocalizedFormats;

/**
 * Implements one-way ANOVA (analysis of variance) statistics.
 * 
 * <p>
 * Tests for differences between two or more categories of univariate data (for
 * example, the body mass index of accountants, lawyers, doctors and computer
 * programmers). When two categories are given, this is equivalent to the
 * {@link org.apache.commons.math3.stat.inference.TTest}.
 * </p>
 * <p>
 * Uses the {@link org.apache.commons.math3.distribution.FDistribution
 * commons-math F Distribution implementation} to estimate exact p-values.
 * </p>
 * <p>
 * This implementation is based on a description at
 * http://faculty.vassar.edu/lowry/ch13pt1.html
 * </p>
 * 
 * <pre>
 * Abbreviations: bg = between groups,
 *                wg = within groups,
 *                ss = sum squared deviations
 * </pre>
 * 
 * @since 1.2
 * @version $Id: OneWayAnova.java 1244107 2012-02-14 16:17:55Z erans $
 */
public abstract class OneWayAnovaForStatisticalSummaryValuesWithSumSq {

    /**
     * Default constructor.
     */
    // public OneWayAnovaForStatisticalSummaryValuesWithSumSq() {
    // }

    /**
     * Computes the ANOVA F-value for a collection of <code>double[]</code>
     * arrays.
     * 
     * <p>
     * <strong>Preconditions</strong>:
     * <ul>
     * <li>The categoryData <code>Collection</code> must contain
     * <code>double[]</code> arrays.</li>
     * <li>There must be at least two <code>double[]</code> arrays in the
     * <code>categoryData</code> collection and each of these arrays must
     * contain at least two values.</li>
     * </ul>
     * </p>
     * <p>
     * This implementation computes the F statistic using the definitional
     * formula
     * 
     * <pre>
     * F = msbg / mswg
     * </pre>
     * 
     * where
     * 
     * <pre>
     *  msbg = between group mean square
     *  mswg = within group mean square
     * </pre>
     * 
     * are as defined <a href="http://faculty.vassar.edu/lowry/ch13pt1.html">
     * here</a>
     * </p>
     * 
     * @param categoryData
     *            <code>Collection</code> of
     *            <code>StatisticalSummaryValuesWithSumSq</code> arrays each
     *            containing data for one category
     * @return Fvalue
     * @throws NullArgumentException
     *             if <code>categoryData</code> is <code>null</code>
     * @throws DimensionMismatchException
     *             if the length of the <code>categoryData</code> array is less
     *             than 2 or a contained <code>double[]</code> array does not
     *             have at least two values
     */
    public static double anovaFValue(
	    final Collection<StatisticalSummaryValuesWithSumSq> categoryData,
	    final boolean doNotCheckDimensionMismatchException) {
	final AnovaStats a = OneWayAnovaForStatisticalSummaryValuesWithSumSq
		.anovaStats(categoryData, doNotCheckDimensionMismatchException);
	return a.F;
    }

    /**
     * Computes the ANOVA P-value for a collection of <code>double[]</code>
     * arrays.
     * 
     * <p>
     * <strong>Preconditions</strong>:
     * <ul>
     * <li>The categoryData <code>Collection</code> must contain
     * <code>double[]</code> arrays.</li>
     * <li>There must be at least two <code>double[]</code> arrays in the
     * <code>categoryData</code> collection and each of these arrays must
     * contain at least two values.</li>
     * </ul>
     * </p>
     * <p>
     * This implementation uses the
     * {@link org.apache.commons.math3.distribution.FDistribution commons-math F
     * Distribution implementation} to estimate the exact p-value, using the
     * formula
     * 
     * <pre>
     * p = 1 - cumulativeProbability(F)
     * </pre>
     * 
     * where <code>F</code> is the F value and
     * <code>cumulativeProbability</code> is the commons-math implementation of
     * the F distribution.
     * </p>
     * 
     * @param categoryData
     *            <code>Collection</code> of <code>double[]</code> arrays each
     *            containing data for one category
     * @return Pvalue
     * @throws NullArgumentException
     *             if <code>categoryData</code> is <code>null</code>
     * @throws DimensionMismatchException
     *             if the length of the <code>categoryData</code> array is less
     *             than 2 or a contained
     *             <code>StatisticalSummaryValuesWithSumSq</code> array does not
     *             have at least two values
     * @throws ConvergenceException
     *             if the p-value can not be computed due to a convergence error
     * @throws MaxCountExceededException
     *             if the maximum number of iterations is exceeded
     */
    public static double anovaPValue(
	    final Collection<StatisticalSummaryValuesWithSumSq> categoryData,
	    final boolean doNotCheckDimensionMismatchException)
	    throws NullArgumentException, DimensionMismatchException,
	    ConvergenceException, MaxCountExceededException {

	final AnovaStats a = OneWayAnovaForStatisticalSummaryValuesWithSumSq
		.anovaStats(categoryData, doNotCheckDimensionMismatchException);
	final FDistribution fdist = new FDistribution(a.dfbg, a.dfwg);
	return 1.0 - fdist.cumulativeProbability(a.F);

    }

    /**
     * This method actually does the calculations (except P-value).
     * 
     * @param categoryData
     *            <code>Collection</code> of <code>double[]</code> arrays each
     *            containing data for one category
     * @return computed AnovaStats
     * @throws NullArgumentException
     *             if <code>categoryData</code> is <code>null</code>
     * @throws DimensionMismatchException
     *             if the length of the <code>categoryData</code> array is less
     *             than 2 or a contained <code>double[]</code> array does not
     *             contain at least two values
     */
    private static AnovaStats anovaStats(
	    final Collection<StatisticalSummaryValuesWithSumSq> categoryData,
	    final boolean doNotCheckDimensionMismatchException)
	    throws NullArgumentException, DimensionMismatchException {

	if (categoryData == null) {
	    throw new NullArgumentException();
	}

	if (!doNotCheckDimensionMismatchException) {
	    // check if we have enough categories
	    if (categoryData.size() < 2) {
		throw new DimensionMismatchException(
			LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED,
			categoryData.size(), 2);
	    }

	    // check if each category has enough data and all is double[]
	    for (final StatisticalSummaryValuesWithSumSq array : categoryData) {
		if (array.getN() <= 1) {
		    throw new DimensionMismatchException(
			    LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED,
			    (int) array.getN(), 2);
		}
	    }
	}
	AnovaStats anovaStatsReturnValue = null;
	if (categoryData.size() < 2) {
	    // there is only one group so there is zero variance
	    anovaStatsReturnValue = new AnovaStats(categoryData.size() - 1,
		    categoryData.size() - 1, 0.0);
	} else {
	    int dfwg = 0;
	    double sswg = 0;
	    double totsum = 0;
	    double totsumsq = 0;
	    int totnum = 0;

	    for (final StatisticalSummaryValuesWithSumSq data : categoryData) {

		final double sum = data.getSum();
		final double sumsq = data.getSumSq();
		final int num = (int) data.getN();
		totnum += num;
		totsum += sum;
		totsumsq += sumsq;

		// Peter added check for num = 0. It seems to me that if a group
		// has
		// zero elements then its
		// within group variance is zero rather than NaN
		if (num > 0) {
		    dfwg += num - 1;
		    final double ss = sumsq - ((sum * sum) / num);
		    sswg += ss;
		}
	    }
	    final double sst = totsumsq - ((totsum * totsum) / totnum);
	    final double ssbg = sst - sswg;
	    final int dfbg = categoryData.size() - 1;
	    final double msbg = ssbg / dfbg;
	    final double mswg = sswg / dfwg;
	    final double F = msbg / mswg;

	    anovaStatsReturnValue = new AnovaStats(dfbg, dfwg, F);
	}
	return anovaStatsReturnValue;
    }

    /**
     * Convenience class to pass dfbg,dfwg,F values around within AnovaImpl. No
     * get/set methods provided.
     */
    private static class AnovaStats {

	/** Degrees of freedom in numerator (between groups). */
	private final int dfbg;

	/** Degrees of freedom in denominator (within groups). */
	private final int dfwg;

	/** Statistic. */
	private final double F;

	/**
	 * Constructor
	 * 
	 * @param dfbg
	 *            degrees of freedom in numerator (between groups)
	 * @param dfwg
	 *            degrees of freedom in denominator (within groups)
	 * @param F
	 *            statistic
	 */
	private AnovaStats(final int dfbg, final int dfwg, final double F) {
	    this.dfbg = dfbg;
	    this.dfwg = dfwg;
	    this.F = F;
	}
    }

}
