package org.epistasis.customApacheCommonsMath;

import java.util.Collection;
import java.util.Iterator;

import org.apache.commons.math3.stat.descriptive.StatisticalSummaryValues;
import org.apache.commons.math3.stat.descriptive.SummaryStatistics;

public class StatisticalSummaryValuesWithSumSq extends StatisticalSummaryValues {
    private static final StatisticalSummaryValuesWithSumSq EMPTY_STATISTICAL_SUMMARY_VALUES_WITH_SUM_SQ = new StatisticalSummaryValuesWithSumSq(
	    0.0, 0.0, 0L, 0.0, 0.0, 0.0, 0.0);
    private static final long serialVersionUID = 1L;
    private final double sumSq;

    /**
     * 
     * 
     * COPIED FROM
     * org.apache.commons.math3.stat.descriptive.AggregateSummaryStatistics
     * .aggregate Computes aggregate summary statistics. This method can be used
     * to combine statistics computed over partitions or subsamples - i.e., the
     * StatisticalSummaryValues returned should contain the same values that
     * would have been obtained by computing a single StatisticalSummary over
     * the combined dataset.
     * <p>
     * Returns null if the collection is empty or null.
     * </p>
     * 
     * @param statistics
     *            collection of SummaryStatistics to aggregate
     * @return summary statistics for the combined dataset
     */
    public static StatisticalSummaryValuesWithSumSq aggregate(
	    final Collection<SummaryStatistics> statistics) {
	StatisticalSummaryValuesWithSumSq returnStatisticalSummaryValuesWithSumSq = null;
	if ((statistics == null) || statistics.isEmpty()) {
	    returnStatisticalSummaryValuesWithSumSq = StatisticalSummaryValuesWithSumSq.EMPTY_STATISTICAL_SUMMARY_VALUES_WITH_SUM_SQ;
	} else {
	    final Iterator<SummaryStatistics> iterator = statistics.iterator();
	    SummaryStatistics current = iterator.next();
	    long n = current.getN();
	    double min = current.getMin();
	    double sum = current.getSum();
	    double sumSq = current.getSumsq();
	    double max = current.getMax();
	    double m2 = current.getSecondMoment();
	    double mean = current.getMean();
	    while (iterator.hasNext()) {
		current = iterator.next();
		if ((current.getMin() < min) || Double.isNaN(min)) {
		    min = current.getMin();
		}
		if ((current.getMax() > max) || Double.isNaN(max)) {
		    max = current.getMax();
		}
		sum += current.getSum();
		sumSq += current.getSumsq();
		final double oldN = n;
		final double curN = current.getN();
		n += curN;
		final double meanDiff = current.getMean() - mean;
		mean = sum / n;
		m2 = m2 + current.getSecondMoment()
			+ ((meanDiff * meanDiff * oldN * curN) / n);
	    }
	    final double variance;
	    if (n == 0) {
		variance = Double.NaN;
	    } else if (n == 1) {
		variance = 0d;
	    } else {
		variance = m2 / (n - 1);
	    }
	    returnStatisticalSummaryValuesWithSumSq = new StatisticalSummaryValuesWithSumSq(
		    mean, variance, n, max, min, sum, sumSq);
	}
	return returnStatisticalSummaryValuesWithSumSq;
    }

    /**
     * Constructor
     * 
     * @param mean
     *            the sample mean
     * @param variance
     *            the sample variance
     * @param n
     *            the number of observations in the sample
     * @param max
     *            the maximum value
     * @param min
     *            the minimum value
     * @param sum
     *            the sum of the values
     */
    public StatisticalSummaryValuesWithSumSq(final double mean,
	    final double variance, final long n, final double max,
	    final double min, final double sum, final double sumSq) {
	super(mean, variance, n, max, min, sum);
	this.sumSq = sumSq;
    }

    public double getSumSq() {
	return sumSq;
    }

    /**
     * Generates a text report displaying values of statistics. Each statistic
     * is displayed on a separate line.
     * 
     * @return String with line feeds displaying statistics
     */
    @Override
    public String toString() {
	final StringBuffer outBuffer = new StringBuffer(super.toString());
	final String endl = "\n";
	outBuffer.append("sum squared: ").append(getSumSq()).append(endl);
	return outBuffer.toString();
    }

}
