package org.epistasis;

public interface LabeledFloatInterface {

    float getFloat();

    String getLabel();
}
