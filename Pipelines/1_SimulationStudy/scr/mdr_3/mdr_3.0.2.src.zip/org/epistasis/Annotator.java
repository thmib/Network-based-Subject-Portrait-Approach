package org.epistasis;

import java.util.List;

/***
 * Very generic -- allows adding columns to tables of information.
 */
public interface Annotator {
    List<String> getAnnotationFields(boolean verbose);

    List<String> getAnnotationHeader(boolean verbose);
}
