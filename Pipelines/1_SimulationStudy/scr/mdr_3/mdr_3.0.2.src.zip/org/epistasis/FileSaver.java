package org.epistasis;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileFilter;

import org.epistasis.mdr.gui.Frame;

public class FileSaver {
    public static final List<ExtensionFilter> filtersGraphics = Collections
	    .unmodifiableList(Arrays.asList(ExtensionFilter.jpgFilter,
		    ExtensionFilter.pngFilter, ExtensionFilter.epsFilter));
    public static final List<ExtensionFilter> filtersNetworkExportTypes = Collections
	    .unmodifiableList(Arrays.asList(ExtensionFilter.gexfFilter,
		    ExtensionFilter.xgmmlFilter, ExtensionFilter.gmlFilter,
		    ExtensionFilter.gdfFilter, ExtensionFilter.graphMlFilter));
    public static final List<ExtensionFilter> filtersText = Collections
	    .unmodifiableList(Arrays.asList(ExtensionFilter.txtFilter));
    public static final List<ExtensionFilter> filtersNetworkDataTypesText;
    static {
	filtersNetworkDataTypesText = new ArrayList<ExtensionFilter>();
	FileSaver.filtersNetworkDataTypesText
		.addAll(FileSaver.filtersNetworkExportTypes);
	FileSaver.filtersNetworkDataTypesText.addAll(FileSaver.filtersText);
    }
    public static final List<ExtensionFilter> filtersNetworkDataTypesGraphicalAndText;
    static {
	filtersNetworkDataTypesGraphicalAndText = new ArrayList<ExtensionFilter>();
	FileSaver.filtersNetworkDataTypesGraphicalAndText
		.addAll(FileSaver.filtersNetworkExportTypes);
	FileSaver.filtersNetworkDataTypesGraphicalAndText
		.addAll(FileSaver.filtersGraphics);
	FileSaver.filtersNetworkDataTypesGraphicalAndText
		.addAll(FileSaver.filtersText);
    }

    final static SavePropertyListener savePropertyListener = new SavePropertyListener(
	    Frame.fileChooser);

    // final static OpenPropertyListener openPropertyListener = new
    // OpenPropertyListener(
    // Frame.fileChooser);

    static boolean debug = false;

    public static String getExtensionForFilter(final FileFilter filter) {
	String extension;
	if (filter instanceof ExtensionFilter) {
	    extension = ((ExtensionFilter) filter).getExtension();
	} else {
	    extension = "";
	}
	return extension;
    }

    public static Pair<File, FileFilter> getOpenFile(final String title,
	    final FileSuffixBeforeExtension fileSuffixBeforeExtension,
	    final List<ExtensionFilter> filters) {
	try {
	    // Frame.fileChooser.addPropertyChangeListener(
	    // JFileChooser.SELECTED_FILE_CHANGED_PROPERTY,
	    // FileSaver.openPropertyListener);
	    // configure the file chooser
	    FileSaver.prepareToUseFileChooser(title, filters,
		    fileSuffixBeforeExtension);
	    if (Frame.fileChooser.showOpenDialog(Frame.getFrame()) != JFileChooser.APPROVE_OPTION) {
		return null;
	    } else if (!Frame.fileChooser.getSelectedFile().isFile()) {
		JOptionPane.showMessageDialog(Frame.getFrame(),
			"Chosen file name is not a valid file", "I/O Error",
			JOptionPane.ERROR_MESSAGE);
		return null;

	    } else {
		FileSaver.savePropertyListener.lastFileName = Frame.fileChooser
			.getSelectedFile().getName();
		return new Pair<File, FileFilter>(
			Frame.fileChooser.getSelectedFile(),
			Frame.fileChooser.getFileFilter());
	    }

	} finally {
	    // Frame.fileChooser.removePropertyChangeListener(
	    // JFileChooser.SELECTED_FILE_CHANGED_PROPERTY,
	    // FileSaver.openPropertyListener);
	}
    }

    public static Pair<File, FileFilter> getSaveFile(final String title,
	    final FileSuffixBeforeExtension fileSuffixBeforeExtension,
	    final List<ExtensionFilter> filters) {
	File f = null;
	boolean overwrite = false;

	try {
	    Frame.fileChooser.addPropertyChangeListener(
		    JFileChooser.FILE_FILTER_CHANGED_PROPERTY,
		    FileSaver.savePropertyListener);
	    Frame.fileChooser.addPropertyChangeListener(
		    JFileChooser.SELECTED_FILE_CHANGED_PROPERTY,
		    FileSaver.savePropertyListener);
	    // set suggested save file name
	    FileSaver.prepareToUseFileChooser(title, filters,
		    fileSuffixBeforeExtension);
	    // keep asking until we get a satisfactory answer, which could be
	    // one of: cancel, write a new file, or a confirmed overwrite
	    while ((f == null) || (f.exists() && !overwrite)) {
		// ask for which file to write, and if the user cancels,
		// we're done
		if (Frame.fileChooser.showSaveDialog(Frame.getFrame()) != JFileChooser.APPROVE_OPTION) {
		    return null;
		}
		// get the user's selection
		f = Frame.fileChooser.getSelectedFile();

		// if the file the user chose exists, ask if the file should
		// be overwritten
		if (f.exists()) {
		    final int optionPaneResult = JOptionPane.showConfirmDialog(
			    Frame.getFrame(), "File '" + f.toString()
				    + "' exists.  Overwrite?", title,
			    JOptionPane.YES_NO_CANCEL_OPTION);
		    switch (optionPaneResult) {
		    // user chose yes, so write the file
		    case JOptionPane.YES_OPTION:
			overwrite = true;
			break;
		    // user chose no, so ask again what file to write
		    case JOptionPane.NO_OPTION:
			overwrite = false;
			break;
		    // user chose cancel, so we're done
		    case JOptionPane.CANCEL_OPTION:
			return null;
		    default:
			throw new RuntimeException("Unhandled switch on: "
				+ optionPaneResult);
		    }
		}
	    }
	} finally {
	    Frame.fileChooser.removePropertyChangeListener(
		    JFileChooser.FILE_FILTER_CHANGED_PROPERTY,
		    FileSaver.savePropertyListener);
	    Frame.fileChooser.removePropertyChangeListener(
		    JFileChooser.SELECTED_FILE_CHANGED_PROPERTY,
		    FileSaver.savePropertyListener);
	}
	return new Pair<File, FileFilter>(f, Frame.fileChooser.getFileFilter());
    }

    /**
     * Open a PrintWriter to a file. This function opens a file chooser dialog
     * to ask the user the filename to use.
     * 
     * @param parent
     *            The parent window for the dialog
     * @param title
     *            The title for the dialog
     * @return PrintWriter to a file, or null if user cancelled
     */
    public static PrintWriter openFileWriter(final String title,
	    final FileSuffixBeforeExtension fileSuffixBeforeExtension) {
	return FileSaver.openFileWriter(title, fileSuffixBeforeExtension, null);
    }

    /**
     * Open a PrintWriter to a file. This function opens a file chooser dialog
     * to ask the user the filename to use.
     * 
     * @param parent
     *            The parent window for the dialog
     * @param title
     *            The title for the dialog
     * @param filters
     *            FileFilters to add to the dialog
     * @return PrintWriter to a file, or null if user cancelled
     */
    public static PrintWriter openFileWriter(final String title,
	    final FileSuffixBeforeExtension fileSuffixBeforeExtension,
	    final List<ExtensionFilter> filters) {
	final Pair<File, FileFilter> ff = FileSaver.getSaveFile(title,
		fileSuffixBeforeExtension, filters);
	if (ff == null) {
	    return null;
	}
	// open the file, and display any errors
	try {
	    return new PrintWriter(ff.getFirst(), "UTF-8");
	} catch (final IOException e) {
	    JOptionPane.showMessageDialog(Frame.getFrame(), e.getMessage(),
		    "I/O Error", JOptionPane.ERROR_MESSAGE);
	}
	return null;
    }

    private static void prepareToUseFileChooser(final String title,
	    final List<ExtensionFilter> filters,
	    final FileSuffixBeforeExtension fileSuffixBeforeExtension) {
	final File currentFile = Frame.fileChooser.getSelectedFile();
	Frame.fileChooser.setDialogTitle(title);
	Frame.fileChooser.setMultiSelectionEnabled(false);

	FileFilter currentFilter = Frame.fileChooser.getFileFilter();

	Frame.fileChooser.setAcceptAllFileFilterUsed(false);
	Frame.fileChooser.resetChoosableFileFilters();
	for (final ExtensionFilter filter : filters) {
	    Frame.fileChooser.addChoosableFileFilter(filter);
	}
	Frame.fileChooser.setAcceptAllFileFilterUsed(true);
	// if the previous filter is in the current list make sure it is still
	// the current filter
	if (filters.contains(currentFilter)
		&& (Frame.fileChooser.getFileFilter() != currentFilter)) {
	    Frame.fileChooser.setFileFilter(currentFilter);
	} else {
	    currentFilter = filters.get(0);
	    Frame.fileChooser.setFileFilter(currentFilter);
	}
	if (currentFile != null) {
	    final String currentFileName = currentFile.getName();
	    String adjustedFileName = SavePropertyListener
		    .changeExtensionToMatchFileFilter(currentFilter,
			    currentFileName);
	    adjustedFileName = FileSuffixBeforeExtension
		    .removeSuffixIfPresent(adjustedFileName);
	    if (fileSuffixBeforeExtension != null) {
		adjustedFileName = fileSuffixBeforeExtension
			.insertSuffixBeforeExtension(adjustedFileName);
	    }
	    if (!adjustedFileName.equals(currentFileName)) {
		if (FileSaver.debug) {
		    System.out
			    .println("prepareToUseFileChooser changing from: "
				    + currentFileName + " to "
				    + adjustedFileName);
		}
		Frame.fileChooser.setSelectedFile(new File(adjustedFileName));
	    }
	}
    } // end prepareToUseFileChooser

    public static void saveText(final String text, final File file)
	    throws IOException {
	final PrintWriter p = new PrintWriter(file, "UTF-8");
	FileSaver.saveText(text, p);
	p.flush();
	p.close();
    }

    public static void saveText(final String text, final PrintWriter p)
	    throws IOException {
	final BufferedReader r = new BufferedReader(new StringReader(text));
	String line;
	while ((line = r.readLine()) != null) {
	    p.println(line);
	}
    }

    public static void saveText(final String text, final Writer w)
	    throws IOException {
	final PrintWriter p = new PrintWriter(w);
	FileSaver.saveText(text, p);
	p.flush();
	p.close();
    }

    public static class ExtensionFilter extends FileFilter {
	private final static Set<ExtensionFilter> allExtensions = new HashSet<ExtensionFilter>();
	public static final ExtensionFilter epsFilter = new ExtensionFilter(
		"eps", "Encapsulated Postscript Images (*.eps)");
	public static final ExtensionFilter txtFilter = new ExtensionFilter(
		"txt", "Text Files (*.txt)");
	public static final ExtensionFilter gexfFilter = new ExtensionFilter(
		"gexf", "Graph Exchange XML Format (*.gexf)");
	public static final ExtensionFilter gdfFilter = new ExtensionFilter(
		"gdf", "GUESS (*.gdf)");
	public static final ExtensionFilter gmlFilter = new ExtensionFilter(
		"gml", "Graph Modeling Language (*.gml)");
	public static final ExtensionFilter xgmmlFilter = new ExtensionFilter(
		"xgmml", "XML Graph Modeling Language (*.xgmml)");
	public static final ExtensionFilter graphMlFilter = new ExtensionFilter(
		"graphml", "GraphML (*.graphml)");
	public static final ExtensionFilter jpgFilter = new ExtensionFilter(
		"jpg", "JPEG Images (*.jpg)");
	public static final ExtensionFilter pngFilter = new ExtensionFilter(
		"png", "PNG Images (*.png)");
	private final String extension;
	private final String description;

	public static ExtensionFilter getExtensionFilter(final String fileName) {
	    ExtensionFilter matchingExtensionFilter = null;
	    for (final ExtensionFilter extensionFilter : ExtensionFilter.allExtensions) {
		final int lastIndexOf = fileName
			.lastIndexOf(extensionFilter.extension);
		if ((lastIndexOf > 0)
			&& (fileName.charAt(lastIndexOf - 1) == '.')) {
		    matchingExtensionFilter = extensionFilter;
		    break;
		}
	    } // end loop over filters
	    return matchingExtensionFilter;
	} // end getExtensionFilter

	public static int getExtensionStartPositionIndex(final String fileName) {
	    int extensionIndex = -1;
	    final ExtensionFilter matchingExtensionFilter = ExtensionFilter
		    .getExtensionFilter(fileName);
	    if (matchingExtensionFilter != null) {
		extensionIndex = fileName
			.lastIndexOf('.' + matchingExtensionFilter.extension);
	    }
	    return extensionIndex;
	} // end getExtensionFilter

	public ExtensionFilter(final String extension, final String description) {
	    this.extension = extension;
	    this.description = description;
	    ExtensionFilter.allExtensions.add(this);
	}

	@Override
	public boolean accept(final File pathname) {
	    return pathname.isDirectory()
		    || pathname.getName().endsWith('.' + extension);
	}

	@Override
	public String getDescription() {
	    return description;
	}

	public String getExtension() {
	    return extension;
	}

	@Override
	public String toString() {
	    return this.getClass().getSimpleName() + " " + extension;
	}
    }

    public enum FileSuffixBeforeExtension {
	_entropy_text, _entropy_graph, _MDR_data, _analysis, _model_details, _cross_validation_details, _if_then_rules, _cell_values_chart, _line_chart, _frequencies, _raw_text;

	/**
	 * Runt through all standard file suffixes and remove if found
	 * 
	 * @param fileName
	 * @return
	 */
	public static String removeSuffixIfPresent(final String fileName) {
	    // initialize to original so will be returned if suffix not found
	    String adjustedFileName = fileName;
	    for (final FileSuffixBeforeExtension fileSuffixBeforeExtension : FileSuffixBeforeExtension
		    .values()) {
		final int position = fileName
			.lastIndexOf(fileSuffixBeforeExtension.toString());
		if (position >= 0) {
		    final int expectedExtensionStartIndex = position
			    + fileSuffixBeforeExtension.name().length();
		    final int extensionStartIndex = ExtensionFilter
			    .getExtensionStartPositionIndex(fileName);
		    if (expectedExtensionStartIndex == extensionStartIndex) {
			// remove from the suffix to the extension
			String extension = "";
			if (extensionStartIndex >= 0) {
			    extension = fileName.substring(extensionStartIndex);
			}
			adjustedFileName = fileName.substring(0, position)
				+ extension;
			break; // BREAK OUT OF LOOP
		    }
		} // end if suffix found within files
	    } // end loop through all enum values
	    if (FileSaver.debug) {
		System.out.println("removeSuffixIfPresent(" + fileName
			+ ") returning: " + adjustedFileName);
	    }
	    return adjustedFileName;
	} // end removeSuffixIfPresent()

	public String insertSuffixBeforeExtension(final String fileName) {
	    int extensionStartIndex = ExtensionFilter
		    .getExtensionStartPositionIndex(fileName);
	    String extension = "";
	    if (extensionStartIndex >= 0) {
		extension = fileName.substring(extensionStartIndex);
	    } else {
		extensionStartIndex = fileName.length();
	    }
	    final String adjustedFileNameAfterInsertion = fileName.substring(0,
		    extensionStartIndex) + toString() + extension;
	    if (FileSaver.debug) {
		System.out.println("insertSuffixBeforeExtension(" + fileName
			+ ") returning: " + adjustedFileNameAfterInsertion);
	    }
	    return adjustedFileNameAfterInsertion;
	} // end insertSuffixBeforeExtension()

    } // end enum FileSuffixBeforeExtension

    private static class SavePropertyListener implements PropertyChangeListener {
	String lastFileName = "";

	public static String changeExtensionToMatchFileFilter(
		final FileFilter fileFilter, final String incomingFileName) {
	    String adjustedFileName = incomingFileName;
	    if ((fileFilter instanceof ExtensionFilter)
		    && (incomingFileName != null)
		    && !incomingFileName.isEmpty()) {
		final int extensionStartIndex = ExtensionFilter
			.getExtensionStartPositionIndex(incomingFileName);
		// if file ends with a different extension, strip it off
		if (extensionStartIndex >= 0) {
		    // remove known extension
		    adjustedFileName = incomingFileName.substring(0,
			    extensionStartIndex);
		}

		final String newExtension = ((ExtensionFilter) fileFilter)
			.getExtension();
		adjustedFileName += '.' + newExtension;
		if (FileSaver.debug
			&& !adjustedFileName.equals(incomingFileName)) {
		    System.out
			    .println("changeExtensionToMatchFileFilter newExtension: "
				    + newExtension
				    + " original filename: "
				    + incomingFileName
				    + " adjustedFileName: "
				    + adjustedFileName);
		} // if debug and changed
	    } // end if incomingFileName esits
	    return adjustedFileName;
	} // end changeExtensionToMatchFileFilter

	SavePropertyListener(final JFileChooser fileChooser) {
	    if (fileChooser != null) {
		final File selectedFile = fileChooser.getSelectedFile();
		if (selectedFile != null) {
		    lastFileName = selectedFile.getAbsolutePath();
		} else {
		    lastFileName = "";
		}
	    }
	}

	@Override
	public void propertyChange(final PropertyChangeEvent evt) {
	    final String propertyName = evt.getPropertyName();
	    FileFilter fileFilter = Frame.fileChooser.getFileFilter();
	    String fileName;

	    if (Frame.fileChooser.getSelectedFile() != null) {
		fileName = Frame.fileChooser.getSelectedFile().getName();
	    } else {
		fileName = lastFileName;
	    }

	    if (propertyName
		    .equals(JFileChooser.SELECTED_FILE_CHANGED_PROPERTY)) {
		final Object newValue = evt.getNewValue();
		if (newValue != null) {
		    fileName = newValue.toString();
		}
	    } else if (propertyName
		    .equals(JFileChooser.FILE_FILTER_CHANGED_PROPERTY)) {
		fileFilter = (FileFilter) evt.getNewValue();
	    } // end if FILE_FILTER_CHANGED_PROPERTY
	    lastFileName = SavePropertyListener
		    .changeExtensionToMatchFileFilter(fileFilter, fileName);
	    if ((Frame.fileChooser.getSelectedFile() == null)
		    || !Frame.fileChooser.getSelectedFile().getName()
			    .equals(lastFileName)) {
		if (FileSaver.debug) {
		    System.out.println("propertyChange: "
			    + evt.getPropertyName() + " old: "
			    + evt.getOldValue() + " ====> new: "
			    + evt.getNewValue()
			    + "\n   changed selected file to: " + lastFileName);
		}
		Frame.fileChooser.setSelectedFile(new File(lastFileName));
	    }
	} // end propertyChange
    }

    // private static class SavePropertyListenerOld implements
    // PropertyChangeListener {
    // String lastFileName;
    //
    // SavePropertyListenerOld(final JFileChooser fileChooser) {
    // final File selectedFile = fileChooser.getSelectedFile();
    // if (selectedFile != null) {
    // lastFileName = selectedFile.getAbsolutePath();
    // } else {
    // lastFileName = "";
    // }
    // }
    //
    // protected void changeExtensionToMatchFileFilter() {
    // final String newExtension = FileSaver
    // .getExtensionForFilter(Frame.fileChooser.getFileFilter());
    // if (!newExtension.isEmpty()) {
    // String incomingFileName;
    // final File selectedFile = Frame.fileChooser.getSelectedFile();
    // if (selectedFile != null) {
    // incomingFileName = selectedFile.getName();
    // } else {
    // incomingFileName = lastFileName;
    // }
    // if ((incomingFileName != null) && !incomingFileName.isEmpty()) {
    // String stringToAddExtensionTo = incomingFileName;
    // for (final ExtensionFilter extensionFilter : FileSaver.filtersAll) {
    // final int lastIndexOf = incomingFileName
    // .lastIndexOf(extensionFilter.extension);
    // if ((lastIndexOf > 0)
    // && (incomingFileName.charAt(lastIndexOf - 1) == '.')) {
    // // remove known extension
    // stringToAddExtensionTo = incomingFileName
    // .substring(0, lastIndexOf - 1);
    // break;
    // }
    // } // end loop over filters
    // // if file ends with a different extension, strip it off
    //
    // final String newFileName = stringToAddExtensionTo + '.'
    // + newExtension;
    // if (!newFileName.equals(incomingFileName)) {
    // Frame.fileChooser
    // .setSelectedFile(new File(newFileName));
    // }
    // } // if (incomingFileName != null)
    // if (FileSaver.debug) {
    // final String changedFileName = ((Frame.fileChooser
    // .getSelectedFile().getName() == null) ? "null"
    // : Frame.fileChooser.getSelectedFile().getName());
    // System.out
    // .println("changeExtensionToMatchFileFilter newExtension: "
    // + newExtension
    // + " original filename: "
    // + incomingFileName
    // + " changed file name: "
    // + changedFileName);
    // }
    // }
    //
    // } // end changeExtensionToMatchFileFilter
    //
    // @Override
    // public void propertyChange(final PropertyChangeEvent evt) {
    // if (FileSaver.debug) {
    // System.out.println("propertyChange: " + evt.getPropertyName()
    // + " old: " + evt.getOldValue() + " ====> new: "
    // + evt.getNewValue() + "\n   selectedFile: "
    // + Frame.fileChooser.getSelectedFile() + "\n   filter: "
    // + Frame.fileChooser.getFileFilter()
    // + "\nlastFileName: " + lastFileName + "\n");
    // }
    // final String propertyName = evt.getPropertyName();
    // if (propertyName
    // .equals(JFileChooser.SELECTED_FILE_CHANGED_PROPERTY)) {
    // final Object oldValue = evt.getOldValue();
    // final Object newValue = evt.getNewValue();
    // if (newValue != null) {
    // lastFileName = newValue.toString();
    // } else if (oldValue != null) {
    // lastFileName = oldValue.toString();
    // }
    // changeExtensionToMatchFileFilter();
    // } else if (propertyName
    // .equals(JFileChooser.FILE_FILTER_CHANGED_PROPERTY)) {
    // changeExtensionToMatchFileFilter();
    // } // end if FILE_FILTER_CHANGED_PROPERTY
    // } // end propertyChange
    // }
}
