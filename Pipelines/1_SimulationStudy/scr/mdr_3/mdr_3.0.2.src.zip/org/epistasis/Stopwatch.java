package org.epistasis;

import java.text.DecimalFormat;
import java.text.NumberFormat;

/**
 * Used for timing things, just like a real stopwatch!
 */
public class Stopwatch {
    private long start;
    private boolean isRunning = false;
    private long stoppedTimeMillis;

    // number formatters for hours, minutes, seconds and milliseconds
    private final static NumberFormat fmt_h = new DecimalFormat("0");

    // private final static NumberFormat fmt_minsec = new DecimalFormat("00");

    private final static NumberFormat fmt_S = new DecimalFormat("000");

    private final StringBuilder sb = new StringBuilder();
    private final boolean showMilliseconds;

    private static final int SECONDS = 1000;

    private static final int MINUTES = 60 * Stopwatch.SECONDS;

    private static final int HOURS = 60 * Stopwatch.MINUTES;

    private static final int DAYS = 24 * Stopwatch.HOURS;

    public Stopwatch() {
	this(true /* showMilliseconds */);
    }

    /**
     * Calls start.
     */
    public Stopwatch(final boolean showMilliseconds) {
	this.showMilliseconds = showMilliseconds;
	start();

    }

    /**
     * Get's the total elapsed time in the format H:mm:ss.SSS
     */
    public String getElapsedTime() {
	return getElapsedTime(getElapsedTimeMillis(), false /* useReducedPrecision */);
    }

    public String getElapsedTime(final long time,
	    final boolean useReducedPrecision) {
	// constants for conversion
	// elapsed time
	// compute hours, minutes, seconds, and milliseconds
	long accountedForTime = 0;
	final long d = time / Stopwatch.DAYS;
	accountedForTime += d * Stopwatch.DAYS;
	final long h = (time - accountedForTime) / Stopwatch.HOURS;
	accountedForTime += h * Stopwatch.HOURS;
	final long m = (time - accountedForTime) / Stopwatch.MINUTES;
	accountedForTime += m * Stopwatch.MINUTES;
	final long s = (time - accountedForTime) / Stopwatch.SECONDS;
	final long S = time % Stopwatch.SECONDS;
	sb.setLength(0);
	boolean showRemainingTimeUnits = false;
	int unitsToShowCtr;
	if (useReducedPrecision) {
	    unitsToShowCtr = 2;
	} else {
	    unitsToShowCtr = 100; // ALL
	}
	showRemainingTimeUnits |= d > 0;
	if (showRemainingTimeUnits) {
	    sb.append(Stopwatch.fmt_h.format(d));
	    sb.append("d");
	    --unitsToShowCtr;
	}
	showRemainingTimeUnits |= h > 0;
	if ((unitsToShowCtr > 0) && showRemainingTimeUnits) {
	    sb.append(Stopwatch.fmt_h.format(h));
	    sb.append("h");
	    --unitsToShowCtr;
	}
	showRemainingTimeUnits |= m > 0;
	if ((unitsToShowCtr > 0) && showRemainingTimeUnits) {
	    sb.append(Stopwatch.fmt_h.format(m));
	    sb.append("m");
	    --unitsToShowCtr;
	}
	if (unitsToShowCtr > 0) {
	    sb.append(Stopwatch.fmt_h.format(s));
	    sb.append("s");
	    --unitsToShowCtr;
	}
	if ((unitsToShowCtr > 0) && showMilliseconds) {
	    sb.append(Stopwatch.fmt_S.format(S));
	    sb.append("ms");

	}
	// now return the string
	return sb.toString();
    }

    /**
     * Gets the total elapsed time in milliseconds.
     */
    public long getElapsedTimeMillis() {
	return (isRunning ? System.currentTimeMillis() : stoppedTimeMillis)
		- start;
    }

    /**
     * Just calls start, but I like writing reset better.
     */
    public void reset() {
	start();
    }

    /**
     * Starts and resets the StopWatch.
     */
    public void start() {
	isRunning = true;
	start = System.currentTimeMillis();
    }

    public void stop() {
	isRunning = false;
	stoppedTimeMillis = System.currentTimeMillis();
    }
}
