package org.epistasis;

public class ModelNameWithTrainingAndTesting extends ModelNameWithTraining {
    private static final long serialVersionUID = 1L;
    private final Float testingFitness;

    public ModelNameWithTrainingAndTesting(final String modelName,
	    final Float trainingFitness, final Float testingFitness) {
	super(modelName, trainingFitness);
	this.testingFitness = testingFitness;
    }

    public Float getTestingFitness() {
	return testingFitness;
    }

    @Override
    public String toString() {
	return super.toString() + " testing=" + testingFitness;
    }
} // end class
