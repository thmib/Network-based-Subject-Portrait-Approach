package org.epistasis;

import java.io.Serializable;
import java.util.Comparator;

public class LabeledFloat implements LabeledFloatInterface, Serializable {
    private static final long serialVersionUID = -7315797021397634925L;
    public final static Comparator<LabeledFloatInterface> floatMaximizerComparator = new FloatMaximizerComparator();
    private final String label;
    private final float floatValue;

    public LabeledFloat(final String label, final float floatValue) {
	this.label = label;
	this.floatValue = floatValue;
    }

    @Override
    public float getFloat() {
	return floatValue;
    }

    @Override
    public String getLabel() {
	return label;
    }

    @Override
    public String toString() {
	return label + ": " + floatValue;
    }

    private static class FloatMaximizerComparator implements
	    Comparator<LabeledFloatInterface>, Serializable {

	private static final long serialVersionUID = -2771402515160035019L;

	@Override
	public int compare(final LabeledFloatInterface o1,
		final LabeledFloatInterface o2) {
	    // reverse compare result because we want larger value to sort first
	    // (DESCENDING)
	    int compareResult = -Utility.compareFloatsHandlingNan(
		    o1.getFloat(), o2.getFloat());
	    if (compareResult == 0) {
		// break ties alphabetically
		compareResult = o1.getLabel().compareTo(o2.getLabel());
	    }
	    return compareResult;
	}

    }
}
