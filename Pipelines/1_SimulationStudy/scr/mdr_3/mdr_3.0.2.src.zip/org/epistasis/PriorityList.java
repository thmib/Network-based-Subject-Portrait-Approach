package org.epistasis;

import java.io.Serializable;
import java.util.Comparator;
import java.util.TreeSet;

/**
 * List that keeps only the best n elements, and keeps them in sorted order.
 * 
 * @param <T>
 *            type of element
 */
public class PriorityList<T> extends TreeSet<T> implements Serializable,
	Iterable<T> {
    private static final long serialVersionUID = -4712297160847369833L;
    protected int capacity;
    private long numAttemptedAdds = 0;
    private long numSuccessfulAdds = 0;
    private final Comparator<? super T> cmp;

    /**
     * Construct a PriorityList of given capacity. T must implement
     * Comparable&lt;T&gt;.
     * 
     * @param capacity
     *            maximum number of elements to keep
     */
    public PriorityList(final int capacity) {
	this(capacity, null);
    }

    /**
     * Construct a PriorityList of given capacity, using a user-specified
     * comparator.
     * 
     * @param capacity
     *            maximum number of elements to keep
     * @param cmp
     *            user-specified comparator
     */
    public PriorityList(final int capacity, final Comparator<? super T> cmp) {
	super(cmp);
	this.capacity = capacity;
	this.cmp = cmp;
    }

    /**
     * Add an element to the list.
     * 
     * @param obj
     *            element to add
     * @return true if element was added
     */
    @SuppressWarnings("unchecked")
    @Override
    public boolean add(final T obj) {
	boolean added = false;
	final int currentSize = size();
	boolean doAdd = (currentSize < capacity);
	if (!doAdd) {
	    T lastObject = null;
	    do {
		try {
		    lastObject = last();
		} catch (final Exception ex) {
		    System.out
			    .println("PriorityList last() caught an exception: "
				    + ex);
		}
	    } while (lastObject == null);

	    int comparisonResult;
	    if (cmp != null) {
		comparisonResult = cmp.compare(obj, lastObject);
	    } else {
		comparisonResult = ((Comparable<T>) obj).compareTo(lastObject);
	    }
	    // only add it if it is better. In case tie, earlier object
	    // stays in. With RandomSearch and EDA it is possible the same model
	    // may be added more than once
	    doAdd = comparisonResult < 0;
	}
	if (doAdd) {
	    synchronized (this) {
		added = super.add(obj);
		if (added) {
		    ++numSuccessfulAdds;
		}
		while (size() > capacity) {
		    super.remove(last());
		}
	    }
	}

	++numAttemptedAdds;
	return added;
    }

    @Override
    public void clear() {
	numSuccessfulAdds = numAttemptedAdds = 0;
	super.clear();
    }

    /**
     * Get the maximum number of elements for the list.
     * 
     * @return the maximum number of elements for the list
     */
    public int getCapacity() {
	return capacity;
    }

    public long getNumberOfAttemptedAdditions() {
	return numAttemptedAdds;
    }

    public long getNumberOfSuccessfulAdditions() {
	return numSuccessfulAdds;
    }

    @Override
    public boolean remove(final Object o) {
	throw new UnsupportedOperationException(
		"PriorityList does not expect remove to be called");
    }

    public void setCapacity(final int capacity) {
	this.capacity = capacity;
	while (size() > capacity) {
	    remove(last());
	}
    }

    @Override
    public String toString() {
	return "capacity=" + capacity + " size=" + size()
		+ " numAttemptedAdds=" + numAttemptedAdds
		+ " numSuccessfulAdds=" + numSuccessfulAdds + " top item="
		+ ((size() == 0) ? "<none>" : first());
    }

}
