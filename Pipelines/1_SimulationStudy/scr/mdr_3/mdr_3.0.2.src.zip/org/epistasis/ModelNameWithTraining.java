package org.epistasis;

import java.io.Serializable;
import java.util.Comparator;

import org.epistasis.mdr.newengine.AttributeCombination;

public class ModelNameWithTraining implements Serializable,
	Comparable<ModelNameWithTraining> {
    private static final long serialVersionUID = 1L;
    protected final String modelName;
    protected final Float trainingFitness;
    public final static Comparator<? extends ModelNameWithTraining> trainingComparator = new Comparator<ModelNameWithTraining>() {
	@Override
	public int compare(final ModelNameWithTraining o1,
		final ModelNameWithTraining o2) {
	    // TODO Auto-generated method stub
	    return 0;
	}
    };

    public ModelNameWithTraining(
	    final Pair<String, Float> pairWithModelNameAndTrainingFitness) {
	this(pairWithModelNameAndTrainingFitness.getFirst(),
		pairWithModelNameAndTrainingFitness.getSecond());
    }

    public ModelNameWithTraining(final String modelName,
	    final Float trainingFitness) {
	this.modelName = modelName;
	this.trainingFitness = trainingFitness;
    }

    @Override
    public int compareTo(final ModelNameWithTraining o) {
	// sort in descending order of training fitness
	int compareResult = (this == o) ? 0 : 1;
	// an object is always equal to itself
	if (compareResult != 0) {
	    compareResult = -trainingFitness.compareTo(o.trainingFitness);
	    // if same training fitness then compare on attributes alphabetical
	    // order
	    // This seems strange but it useful because
	    // for Parabon distributed computing used in
	    // org.epistasis.combinatoric.mdr.crush.MDRFunction we use
	    // numerous datasets
	    // across one search. In that case the model names are actually the
	    // attribute indices so comparing them will pick the earlier
	    // combination which is how we are supposed to break ties
	    if (compareResult == 0) {
		compareResult = AttributeCombination.compareAttributeLabels(
			modelName, o.modelName);
	    }// end if compareResult == 0
	}// end if compareResult != 0
	return compareResult;
    } // end compareTo

    public String getModelName() {
	return modelName;
    }

    public Float getTrainingFitness() {
	return trainingFitness;
    }

    @Override
    public String toString() {
	return modelName + " training=" + trainingFitness;
    }
} // end class
