package org.epistasis;

import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.management.MemoryNotificationInfo;
import java.lang.management.MemoryPoolMXBean;
import java.lang.management.MemoryType;
import java.util.ArrayList;
import java.util.Collection;

import javax.management.Notification;
import javax.management.NotificationEmitter;
import javax.management.NotificationListener;

/**
 * This code is from http://www.roseindia.net/javatutorials/OutOfMemoryError_Warning_System.shtml
 * 
 */

/**
 * This memory warning system will call the listener when we exceed the
 * percentage of available memory specified. There should only be one instance
 * of this object created, since the usage threshold can only be set to one
 * number.
 */
public class MemoryWarningSystem {
    private final Collection<Listener> listeners = new ArrayList<Listener>();

    private static final MemoryPoolMXBean tenuredGenPool = MemoryWarningSystem
	    .findTenuredGenPool();

    /**
     * Tenured Space Pool can be determined by it being of type HEAP and by it
     * being possible to set the usage threshold.
     */
    private static MemoryPoolMXBean findTenuredGenPool() {
	for (final MemoryPoolMXBean pool : ManagementFactory
		.getMemoryPoolMXBeans()) {
	    // I don't know whether this approach is better, or whether
	    // we should rather check for the pool name "Tenured Gen"?
	    if ((pool.getType() == MemoryType.HEAP)
		    && pool.isUsageThresholdSupported()) {
		return pool;
	    }
	}
	throw new AssertionError("Could not find tenured space");
    }

    /**
     * This will set the warning to fire when the memory gets to the larger of
     * either the percentage remaining or minimumNumberOfBytes
     * 
     * @param warnOnPercentRemaining
     * @param warnOnBytesRemaining
     */
    public static void setRequiredMemoryThreshold(
	    final double warnOnPercentRemaining, final long warnOnBytesRemaining) {
	if ((warnOnPercentRemaining <= 0.0) || (warnOnPercentRemaining > 1.0)) {
	    throw new IllegalArgumentException("Percentage not in range");
	}
	final long maxMemory = MemoryWarningSystem.tenuredGenPool.getUsage()
		.getMax();

	final long percentageWarningThreshold = maxMemory
		- (long) (maxMemory * warnOnPercentRemaining);
	final long specificByteCountThreshold = Math.max(1, maxMemory
		- warnOnBytesRemaining);
	final long thresholdForWarning = Math.min(percentageWarningThreshold,
		specificByteCountThreshold);
	MemoryWarningSystem.tenuredGenPool
		.setUsageThreshold(thresholdForWarning);
    }

    public MemoryWarningSystem() {
	final MemoryMXBean mbean = ManagementFactory.getMemoryMXBean();
	final NotificationEmitter emitter = (NotificationEmitter) mbean;
	emitter.addNotificationListener(new NotificationListener() {
	    @Override
	    public void handleNotification(final Notification n, final Object hb) {
		if (n.getType().equals(
			MemoryNotificationInfo.MEMORY_THRESHOLD_EXCEEDED)) {
		    final long maxMemory = MemoryWarningSystem.tenuredGenPool
			    .getUsage().getMax();
		    final long usedMemory = MemoryWarningSystem.tenuredGenPool
			    .getUsage().getUsed();
		    for (final Listener listener : listeners) {
			listener.memoryUsageLow(usedMemory, maxMemory);
		    }
		}
	    }
	}, null, null);
    }

    public boolean addListener(final Listener listener) {
	return listeners.add(listener);
    }

    public boolean removeListener(final Listener listener) {
	return listeners.remove(listener);
    }

    public interface Listener {
	public void memoryUsageLow(long usedMemory, long maxMemory);
    }
}