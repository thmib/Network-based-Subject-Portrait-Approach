package org.epistasis;

import java.util.Map;
import java.util.TreeMap;

public class Entropy {
    public static double getConditionalEntropy(final byte[] attribute,
	    final byte[] given) {
	final Map<Byte, Map<Byte, Integer>> statusGenotypeCountsMap = new TreeMap<Byte, Map<Byte, Integer>>();
	double conditionalEntropy = 0;
	final int numRows = attribute.length;
	for (int index = 0; index < numRows; ++index) {
	    final byte attrKey = attribute[index];
	    final byte givenKey = given[index];
	    Map<Byte, Integer> statusGenotypeCounts = statusGenotypeCountsMap
		    .get(givenKey);
	    if (statusGenotypeCounts == null) {
		statusGenotypeCounts = new TreeMap<Byte, Integer>();
	    }
	    Integer count = statusGenotypeCounts.get(attrKey);
	    if (count == null) {
		count = 0;
	    }
	    statusGenotypeCounts.put(attrKey, count + 1);
	    statusGenotypeCountsMap.put(givenKey, statusGenotypeCounts);
	}
	for (final Map<Byte, Integer> statusGenotypeCounts : statusGenotypeCountsMap
		.values()) {
	    int totalStatusCount = 0;
	    double entropyWithinStatusRows = 0;
	    for (final int statusGenotypeCount : statusGenotypeCounts.values()) {
		totalStatusCount += statusGenotypeCount;
	    }
	    for (final int statusGenotypeCount : statusGenotypeCounts.values()) {
		final double genotypeProbability = statusGenotypeCount
			/ (double) totalStatusCount;
		entropyWithinStatusRows -= (genotypeProbability * Math
			.log(genotypeProbability)) / Math.log(2);
	    }
	    final double fractionOfTotalRows = totalStatusCount
		    / (double) numRows;
	    final double statusContributionToOverallConditionalEntropy = entropyWithinStatusRows
		    * fractionOfTotalRows;
	    conditionalEntropy += statusContributionToOverallConditionalEntropy;
	} // end loop for each status
	return conditionalEntropy;
    }

    public static double getEntropy(final byte[] columnData) {
	final Map<Byte, Integer> genotypeCounts = new TreeMap<Byte, Integer>();
	double entropy = 0;
	for (final byte levelIndex : columnData) {
	    Integer count = genotypeCounts.get(levelIndex);
	    if (count == null) {
		count = 0;
	    }
	    genotypeCounts.put(levelIndex, count + 1);
	}
	for (final int genotypeCount : genotypeCounts.values()) {
	    final double genotypeProbability = genotypeCount
		    / (double) columnData.length;
	    entropy -= (genotypeProbability * Math.log(genotypeProbability))
		    / Math.log(2);
	}
	return entropy;
    }
}
