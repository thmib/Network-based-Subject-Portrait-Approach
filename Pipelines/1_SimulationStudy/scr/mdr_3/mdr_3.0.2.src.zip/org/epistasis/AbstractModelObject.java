package org.epistasis;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

/**
 * @author lobas_av Code comes from WindowBuilder Pro Data binding tutorial
 *         which has Eclipse project name SwingBindingsTest
 *         http://code.google.com
 *         /javadevtools/wbpro/features/swing/data_binding/example.html
 */
public abstract class AbstractModelObject {
    private final PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(
	    this);

    public void addPropertyChangeListener(final PropertyChangeListener listener) {
	propertyChangeSupport.addPropertyChangeListener(listener);
    }

    public void addPropertyChangeListener(final String propertyName,
	    final PropertyChangeListener listener) {
	propertyChangeSupport.addPropertyChangeListener(propertyName, listener);
    }

    protected void firePropertyChange(final String propertyName,
	    final Object oldValue, final Object newValue) {
	// System.out.println("AbstractModelObject.firePropertyChange(" +
	// propertyName
	// + ", old: " + oldValue + ", new: " + newValue + ")");
	propertyChangeSupport.firePropertyChange(propertyName, oldValue,
		newValue);
    }

    public void removePropertyChangeListener(
	    final PropertyChangeListener listener) {
	propertyChangeSupport.removePropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(final String propertyName,
	    final PropertyChangeListener listener) {
	propertyChangeSupport.removePropertyChangeListener(propertyName,
		listener);
    }
}
