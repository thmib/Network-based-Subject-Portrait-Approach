package org.epistasis;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Creates columns of left justified strings
 */
public class ColumnFormat {
    private final List<Integer> widths;
    private final boolean useTabs;

    public static String fitStringWidth(final String string, final int width,
	    final boolean useTabs) {
	if (useTabs) {
	    return (string + "\t");
	} else {
	    return String.format("%-" + width + 's', string);
	}
    }

    public ColumnFormat(final List<Integer> widths) {
	this(widths, false /* useTabs */);
    }

    public ColumnFormat(final List<Integer> widths, final boolean useTabs) {
	this.widths = new ArrayList<Integer>(widths.size());
	this.widths.addAll(widths);
	this.useTabs = useTabs;
    }

    public String fitStringWidth(final String string, final int width) {
	return ColumnFormat.fitStringWidth(string, width, useTabs);
    }

    public String format(final List<String> values) {

	final StringBuffer b = new StringBuffer();
	final Iterator<String> i = values.iterator();
	final Iterator<Integer> j = widths.iterator();
	while (i.hasNext() && j.hasNext()) {
	    b.append(fitStringWidth(i.next().toString(), j.next()));
	}
	return b.toString();

    }
}
