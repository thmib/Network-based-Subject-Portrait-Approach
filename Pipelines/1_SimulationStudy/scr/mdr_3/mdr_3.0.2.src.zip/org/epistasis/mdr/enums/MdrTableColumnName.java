package org.epistasis.mdr.enums;

import org.epistasis.Utility;
import org.epistasis.mdr.Console;

public enum MdrTableColumnName {
    OVERALL_SCORE("overall", true), MODEL_TESTING("model testing", true), MODEL_TRAINING(
	    "model training", true), CV_TESTING("CV testing", true), CV_TRAINING(
	    "CV training", true), MODEL_ATTRIBUTES("Attributes"), NUM_ATTRIBUTES(
	    "# Attributes"), TABLE_OUTPUT_HEADER_START("Datafile\t"), LOOCV_TRAINING(
	    "LOOCV training", true), LOOCV_TESTING("LOOCV testing", false), CVC(
	    "CVC"), CHISQUARED(FilterMethod.CHISQUARED
	    .getExportableAlternateName(), false), MAXIMUM_LIKELIHOOD(
	    "maximum likelihood", false), MODEL_ADJUSTED_TESTING(
	    "model adj. testing", true), MODEL_WINNERS_TESTING(
	    "model winning intervals testing", true), COVERAGE("coverage"), RANK(
	    "rank"), PVALUE("p-value");
    private final String columnText;
    private final boolean useMetricShortTextPrefix;

    private MdrTableColumnName(final String columnText) {
	this(columnText, false);
    }

    private MdrTableColumnName(final String columnText,
	    final boolean useMetricShortTextPrefix) {
	this.columnText = columnText;
	this.useMetricShortTextPrefix = useMetricShortTextPrefix;
    }

    public String capitalized() {
	return Utility.ensureCaps(toString());
    }

    @Override
    public String toString() {
	final StringBuilder sb = new StringBuilder();
	if (useMetricShortTextPrefix) {
	    sb.append(Console.console.metricShortText);
	    sb.append(' ');
	}
	sb.append(columnText);
	return (sb.toString());

    } // end toString
} // end enum