package org.epistasis.mdr;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.LineNumberReader;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import ml.options.OptionSet;
import ml.options.Options;
import ml.options.Options.Multiplicity;
import ml.options.Options.Separator;

import org.epistasis.ColumnFormat;
import org.epistasis.LabeledFloatInterface;
import org.epistasis.Pair;
import org.epistasis.Stopwatch;
import org.epistasis.Utility;
import org.epistasis.gui.ProgressPanelUpdater;
import org.epistasis.mdr.ExpertKnowledge.RWRuntime;
import org.epistasis.mdr.analysis.AnalysisThread;
import org.epistasis.mdr.analysis.AnalysisThread.AnalysisThreadBuilder;
import org.epistasis.mdr.analysis.EDAAnalysisThread.EDAAnalysisThreadBuilder;
import org.epistasis.mdr.analysis.ExhaustiveAnalysisThread.ExhaustiveAnalysisThreadBuilder;
import org.epistasis.mdr.analysis.FixedRandomAnalysisThread.FixedRandomAnalysisThreadBuilder;
import org.epistasis.mdr.analysis.TimedRandomAnalysisThread.TimedRandomAnalysisThreadBuilder;
import org.epistasis.mdr.api.MDRExecutor;
import org.epistasis.mdr.api.MDRResult;
import org.epistasis.mdr.api.PermutationResults;
import org.epistasis.mdr.entropy.EntropyAnalysis;
import org.epistasis.mdr.enums.ContinuousEndpointSignificanceMetric;
import org.epistasis.mdr.enums.DiscreteEndpointSignificanceMetric;
import org.epistasis.mdr.enums.FilterMethod;
import org.epistasis.mdr.enums.FitnessCriteriaOrder;
import org.epistasis.mdr.enums.MdrTableColumnName;
import org.epistasis.mdr.enums.ScalingMethod;
import org.epistasis.mdr.enums.SearchMethod;
import org.epistasis.mdr.enums.TimeUnits;
import org.epistasis.mdr.enums.WeightScheme;
import org.epistasis.mdr.filters.AbstractAttributeScorer;
import org.epistasis.mdr.filters.AttributeRanker;
import org.epistasis.mdr.filters.ChiSquaredScorer;
import org.epistasis.mdr.filters.MultiSURFAttributeScorer;
import org.epistasis.mdr.filters.MultiSURFnTuRFAttributeScorer;
import org.epistasis.mdr.filters.OddsRatioScorer;
import org.epistasis.mdr.filters.ReliefFAttributeScorer;
import org.epistasis.mdr.filters.SURFAttributeScorer;
import org.epistasis.mdr.filters.SURFStarAttributeScorer;
import org.epistasis.mdr.filters.SURFStarnTuRFAttributeScorer;
import org.epistasis.mdr.filters.SURFnTuRFAttributeScorer;
import org.epistasis.mdr.filters.TuRFAttributeScorer;
import org.epistasis.mdr.gui.Frame;
import org.epistasis.mdr.newengine.AttributeCombination;
import org.epistasis.mdr.newengine.AttributeCombinationWithWildcards;
import org.epistasis.mdr.newengine.Collector;
import org.epistasis.mdr.newengine.ConfusionMatrix;
import org.epistasis.mdr.newengine.Dataset;
import org.epistasis.mdr.newengine.Model;
import org.epistasis.mdr.newengine.Model.Cell;
import org.epistasis.mdr.newengine.ModelInfoInterface;

public class Console {
    public final static String LOAD_ANALYSIS_CMD = "load_analysis";
    private static final String MDR_COMMAND_LINE_HELP_TXT = "MDR_command_line_help.txt";
    public static Console console = new Console(System.out, System.err);
    final Stopwatch stopWatch = new Stopwatch();
    private AnalysisThread analysis;
    private boolean minimalOutput = false;
    public boolean preserveTuRFRemovalOrder = Main.defaultPreserveTuRFRemovalOrder;
    public int topModelsLandscapeSize = Main.defaultTopModelsLandscapeSize;
    private int permutations = Main.defaultPermutations;
    public boolean computeAllModelsLandscape = true; // has historically had
    // landscape on by default
    public static float fishersThreshold = Main.defaultFishersThreshold;
    public AmbiguousCellStatus ambiguousCellStatus = Main.defaultAmbiguousCellStatus;
    private DiscreteEndpointSignificanceMetric discreteEndpointSignificanceMetric = DiscreteEndpointSignificanceMetric.BALANCED_ACCURACY;

    public FitnessCriteriaOrder acrossLevelsFitnessCriteriaOrder = Main.defaultInterLevelFitnessCriteriaOrder;
    public FitnessCriteriaOrder topModelsFitnessCriteriaOrder = Main.defaultTopModelsFitnessCriteriaOrder;

    public FitnessCriteriaOrder bestModelFitnessCriteriaOrder = Main.defaultBestModelsFitnessCriteriaOrder;
    public int reliefFWeightedDistanceIterations = 0;

    public WeightScheme reliefFWeightedDistanceMethod = WeightScheme.PROPORTIONAL;
    public ScalingMethod reliefFWeightedScalingMethod = ScalingMethod.EXPONENTIAL;
    public double reliefFWeightedScalingParameter = 0.99;
    public ReliefFRebalancingMethod reliefFRebalancingMethod = ReliefFRebalancingMethod.OVERSAMPLE_MINORITY;
    public boolean outputAllModels = false;
    private PrintWriter allModelsWriter = null;
    private String topModelsPredictionsFile = null;
    private ContinuousEndpointSignificanceMetric continuousEndpointSignificanceMetric = ContinuousEndpointSignificanceMetric.TTEST;
    private String missingCode = Main.defaultMissing;
    // batch modes will set parallel to false unless explicitly requested with
    // -parallel option
    private boolean parallel = Main.defaultParallel;
    private int distributedNodeCount = Main.defaultDistributedNodeCount;
    private int distributedNodeNumber = Main.defaultDistributedNodeNumber;
    private long randomSeed = Main.defaultRandomSeed;
    // can be set attribute names or zero based indices. Should be all of one or
    // the other =- not mixed.
    private Set<? extends Object> allowedAttributes = null;
    public boolean useBestModelActualIntervals = Main.defaultUseBestModelActualIntervals;
    private boolean useExplicitTestOfInteraction = Main.defaultUseExplicitTestOfInteraction;
    private boolean printDetailedConfusionMatrix = Main.defaultPrintDetailedConfusionMatrix;
    public static float lackOfCoveragePenaltyExponent = Main.defaultLackOfCoveragePenaltyExponent;
    private WeightScheme edaSearchWeightingMethod = Main.defaultEDAWeightingMethod;
    private EntropyAnalysis.NetworkDataType outputTwoWayEntropy = null;
    public String metricShortText = discreteEndpointSignificanceMetric
	    .getShortText();
    public String metricLongText = discreteEndpointSignificanceMetric
	    .getLongText();
    public PrintStream outPrintStream = System.out;
    public PrintStream errPrintStream = System.err;
    private int minLevel;
    private int maxLevel;
    private int numberOfAttributes;
    private int cv;
    public Dataset data;
    private final Stack<Dataset> datasetAncestors = new Stack<Dataset>();
    private SearchMethod searchMethod;
    private int permutationStartIndex = Dataset.PermutationSupport.PERMUTATION_DEFAULT_START_INDEX;

    public static void createDefaultConsole(final PrintStream pOutPrintStream,
	    final PrintStream pErrPrintStream) {
	Console.console = new Console(pOutPrintStream, pErrPrintStream);
    }

    /**
     * The idea of 'adjusted testing' is to create metric that shows a 'good
     * model'. Naively, you might think that a good model would be the one with
     * the highest testing score but unfortunately with the way we do cross
     * validation and pick models by CVC, the testing data is somewhat dependent
     * on the training data and therefore tends to increase with training score
     * (which tends to increase with number of levels). A different signal of
     * 'goodness' is when the difference between the training and testing score
     * is small -- this is an indication that the model is not overfit. The
     * 'adjusted testing' metric tries to increase models with reduced
     * overfitting (alternatively to punish models with excessive overfitting).
     * 
     * @param trainingScore
     * @param testingScore
     * @return
     */
    public static float getAdjustedTesting(final float trainingScore,
	    final float testingScore) {
	final float overfittingSignal = trainingScore - testingScore;
	final float adjustedTesting = testingScore - overfittingSignal;
	// adjustedTesting equivalent to (testingScore * 2) - trainingScore but
	// the way it is written here makes reasoning more clear
	return adjustedTesting;
    }

    /**
     * Returns numberOfAttributes choose model size, summed together for all
     * model sizes
     * 
     * @param numberOfAttributes
     * @param minModelSize
     * @param maxModelSize
     * @return
     */
    public static BigInteger getNumberOfModelCombinations(
	    final int numberOfAttributes, final int minModelSize,
	    final int maxModelSize) {
	BigInteger numCombinations = BigInteger.ZERO;
	for (int modelSize = minModelSize; modelSize <= maxModelSize; ++modelSize) {
	    final BigInteger levelCombinations = Utility.combinations(
		    numberOfAttributes, modelSize);
	    numCombinations = numCombinations.add(levelCombinations);
	}
	return numCombinations;
    }

    /**
     * Returns getNumberOfModelCombinations() * the # of cross-validation
     * intervals
     * 
     * @param numberOfAttributes
     * @param minModelSize
     * @param maxModelSize
     * @param crossValidationCount
     * @return
     */
    public static BigInteger getNumberOfModelTests(
	    final int numberOfAttributes, final int minModelSize,
	    final int maxModelSize, final int crossValidationCount) {
	final BigInteger numberOfTotalTests = Console
		.getNumberOfModelCombinations(numberOfAttributes, minModelSize,
			maxModelSize).multiply(
			BigInteger.valueOf(crossValidationCount));
	return numberOfTotalTests;
    }

    public static String getTableDataHeader(
	    final List<Pair<String, String>> tableData) {
	final StringBuilder sb = new StringBuilder();
	for (final Pair<String, String> pair : tableData) {
	    sb.append(pair.getFirst().replace(' ', '_') + "\t");
	}
	return sb.toString();
    }

    public static String getTableDataRowString(
	    final List<Pair<String, String>> tableData) {
	final StringBuilder sb = new StringBuilder();
	for (final Pair<String, String> pair : tableData) {
	    sb.append(pair.getSecond() + "\t");
	}
	return sb.toString();
    }

    public static String memoryToString() {
	final Runtime rt = Runtime.getRuntime();
	final long maxMem = rt.maxMemory();
	final long totalMem = rt.totalMemory();
	final long freeMem = rt.freeMemory();
	final long usedMem = totalMem - freeMem;
	return "maxMem: "
		+ Main.decimalUpToOnePrecision.format(maxMem
			/ Frame.BytesPerMegabyte)
		+ "mb totalMem: "
		+ Main.decimalUpToOnePrecision.format(totalMem
			/ Frame.BytesPerMegabyte)
		+ "mb freeMem: "
		+ Main.decimalUpToOnePrecision.format(freeMem
			/ Frame.BytesPerMegabyte)
		+ "mb usedMem = "
		+ Main.decimalUpToOnePrecision.format(usedMem
			/ Frame.BytesPerMegabyte) + "mb";
    }

    /**
     * @param errPrintStream
     * @param outPrintStream
     * @param onEndAnalysis
     * @return -1 if error, 0 if completed normally, 1 if gui should be run
     * @throws Exception
     */
    public static STATUS parseCommandLineAndRun(final String[] args,
	    final PrintStream pOutPrintStream,
	    final PrintStream pErrPrintStream, final Runnable onEndModel,
	    final Runnable onEndLevel, final Runnable onEndAnalysis) {
	Console.createDefaultConsole(pOutPrintStream, pErrPrintStream);
	return Console.console.parseCommandLineAndRun(args, onEndModel,
		onEndLevel, onEndAnalysis);
    }

    public static String replaceSuffix(final String fname, final String newsuff) {
	final int i = fname.lastIndexOf('.');
	String base;
	if (i > -1) {
	    base = fname.substring(0, i);
	} else {
	    base = fname;
	}
	return base + "." + newsuff;
    } // end runAnalysis

    private Console(final PrintStream pOutPrintStream,
	    final PrintStream pErrPrintStream) {
	outPrintStream = pOutPrintStream;
	errPrintStream = pErrPrintStream;
    }

    private AnalysisThread createAnalysisThread(final OptionSet set,
	    final Dataset data, final int min, final int max,
	    final boolean runParallel, final List<AttributeCombination> forced,
	    final int evaluations, final double runtime,
	    final TimeUnits timeUnit, final int numAgents,
	    final int numUpdates, final double retention, final int alpha,
	    final int beta, final ScalingMethod scalingMethod,
	    final double scalingParameter, final WeightScheme weightScheme,
	    final ExpertKnowledge expertKnowledge,
	    final SearchMethod searchMethod, final long seed,
	    final AmbiguousCellStatus tiePriorityList,
	    final Runnable onEndModel, final Runnable onEndLevel,
	    final Runnable onEndAnalysis) {
	// AnalysisThread newAnalysis = null;
	AnalysisThreadBuilder<? extends AnalysisThread> builder = null;
	switch (searchMethod) {
	case FORCED: {
	    builder = new ExhaustiveAnalysisThreadBuilder(Console.console.data,
		    cv, seed).setForced(forced);
	}
	    break;
	case RANDOM: {
	    if (set.isSet("random_search_eval")) {
		builder = new FixedRandomAnalysisThreadBuilder(data, cv, seed)
			.setMaxEval(evaluations).setMaxAttr(max)
			.setMinAttr(min);
	    } else if (set.isSet("random_search_runtime")) {
		builder = new TimedRandomAnalysisThreadBuilder(data, cv, seed)
			.setTimeUnits(timeUnit).setTimeAmount(runtime)
			.setMaxAttr(max).setMinAttr(min);
	    }
	}
	    break;
	case EDA: {
	    final RWRuntime currentRWRuntime = expertKnowledge.new RWRuntime(
		    weightScheme, scalingMethod, scalingParameter, alpha, beta,
		    retention);
	    builder = new EDAAnalysisThreadBuilder(data, cv, seed)
		    .setNumEntities(numAgents).setNumUpdates(numUpdates)
		    .setExpertKnowledgeRWRuntime(currentRWRuntime);
	}
	    break;
	case EXHAUSTIVE: {
	    builder = new ExhaustiveAnalysisThreadBuilder(data, cv, seed)
		    .setMinAttr(min).setMaxAttr(max);
	}
	    break;
	default:
	    throw new RuntimeException(
		    "Search parameter arguments not understood: "
			    + searchMethod);
	} // end switch

	// Fill in builder
	builder.setTiePriorityList(tiePriorityList).setOnEndModel(onEndModel)
		.setOnEndLevel(onEndLevel).setOnEndAnalysis(onEndAnalysis)
		.setParallel(runParallel)
		.setComputeAllModelsLandscape(computeAllModelsLandscape)
		.setTopModelsLandscapeSize(topModelsLandscapeSize)
		.setDistributedNodeCount(distributedNodeCount)
		.setDistributedNodeNumber(distributedNodeNumber);
	// Build analysis thread
	return builder.build();
    } // end createAnalysisThread()

    public boolean datasetCanBeReverted() {
	return !datasetAncestors.isEmpty();
    }

    private boolean edaSelected(final OptionSet set) {
	if (set.isSet("eda_search_numAgents")
		|| set.isSet("eda_search_numUpdates")
		|| set.isSet("eda_search_retention")
		|| set.isSet("eda_search_alpha")
		|| set.isSet("eda_search_beta")
		|| set.isSet("eda_search_expertKnowledge")
		|| set.isSet("eda_search_weightingMethod")
		|| set.isSet("eda_search_percentMaxAttributeRange")
		|| set.isSet("eda_search_theta")) {
	    return true;
	}
	return false;
    }

    private boolean forcedSelected(final OptionSet set) {
	if (set.isSet("forced_search")) {
	    return true;
	}
	return false;
    }

    private String getConfusionMatrixInfoHeader(
	    final MdrTableColumnName columnNameSuffix) {
	final StringBuilder sb = new StringBuilder();
	sb.append("coverage adjusted " + columnNameSuffix + "\t");
	if (printDetailedConfusionMatrix) {
	    sb.append("unadjusted " + columnNameSuffix + "\t");
	    sb.append("coverage " + columnNameSuffix + "\t");
	    sb.append("true_positives " + columnNameSuffix + "\t");
	    sb.append("false_negatives " + columnNameSuffix + "\t");
	    sb.append("true_negatives " + columnNameSuffix + "\t");
	    sb.append("false_positives " + columnNameSuffix + "\t");
	    sb.append("unknown " + columnNameSuffix + "\t");
	}
	return sb.toString();
    }

    private String getConfusionMatrixInfoString(
	    final ConfusionMatrix confusionMatrix) {
	final StringBuilder sb = new StringBuilder();
	// sb.append(Main.defaultFormat.format(confusionMatrix
	// .getScore(scoringMethod)));
	// sb.append("\t");
	if (confusionMatrix == null) {
	    sb.append(Main.decimalUpToFourPrecision.format(Float.NaN));
	    sb.append("\t");
	} else {
	    // sb.append(Main.defaultFormat.format(confusionMatrix.getBalancedAccuracy()));
	    sb.append(Main.decimalUpToFourPrecision.format(confusionMatrix
		    .getFitness()));
	    sb.append("\t");
	    if (printDetailedConfusionMatrix) {
		sb.append(Main.decimalUpToFourPrecision.format(confusionMatrix
			.getBalancedAccuracy()));
		sb.append("\t");
		sb.append(Main.decimalUpToFourPrecision.format(confusionMatrix
			.getCoverageRatio()));
		sb.append("\t");
		sb.append(Main.decimalUpToFourPrecision.format(confusionMatrix
			.numTruePositives()));
		sb.append("\t");
		sb.append(Main.decimalUpToFourPrecision.format(confusionMatrix
			.numFalseNegatives()));
		sb.append("\t");
		sb.append(Main.decimalUpToFourPrecision.format(confusionMatrix
			.numTrueNegatives()));
		sb.append("\t");
		sb.append(Main.decimalUpToFourPrecision.format(confusionMatrix
			.numFalsePositives()));
		sb.append("\t");
		sb.append(Main.decimalUpToFourPrecision.format(confusionMatrix
			.getUnknownCount()));
		sb.append("\t");
	    }
	}
	return sb.toString();
    }

    public ContinuousEndpointSignificanceMetric getContinuousEndpointSignificanceMetric() {
	return continuousEndpointSignificanceMetric;
    }

    public DiscreteEndpointSignificanceMetric getDiscreteEndpointSignificanceMetric() {
	return discreteEndpointSignificanceMetric;
    }

    private <E extends Enum<E>> String getEnumNames(final Enum<E>[] enumValues) {

	return getEnumNames(enumValues, "|");
    }

    private <E extends Enum<E>> String getEnumNames(final Enum<E>[] enumValues,
	    final String delimiter) {
	final StringBuilder sb = new StringBuilder();
	for (final Enum<E> enumValue : enumValues) {
	    if (sb.length() > 0) {
		sb.append(delimiter);
	    }
	    sb.append(enumValue.name());
	}
	return sb.toString();
    }

    /**
     * This can be used so that progress meters can know what they are counting
     * to
     * 
     * @param numberOfAttributes
     *            (usually number of columns - 1)
     * @param modelSize
     *            1-way, 2-way, etc
     * @param crossValidationCount
     * @return
     */
    public BigInteger getNumberOfModelTests() {
	return Console.getNumberOfModelTests(numberOfAttributes, minLevel,
		maxLevel, cv);
    }

    public long getRandomSeed(final String requestor) {
	long seed = randomSeed;
	StringBuilder sb;
	final boolean debug = false;
	if (debug) {
	    sb = new StringBuilder(requestor + " using random seed " + seed
		    + ".");
	}
	if (randomSeed == -1) {
	    seed = System.currentTimeMillis();
	    if (debug) {
		sb.append(" Special value of -1 caused time based seed to be substituted : "
			+ seed);
	    }
	}
	if (debug) {
	    outPrintStream.println(sb.toString());
	}
	return seed;
    }

    private SearchMethod getRequestedSearchMethod(final OptionSet set) {
	final List<SearchMethod> searchMethods = new ArrayList<SearchMethod>();
	if (forcedSelected(set)) {
	    searchMethods.add(SearchMethod.FORCED);
	}
	if (randomSelected(set)) {
	    searchMethods.add(SearchMethod.RANDOM);
	}
	if (edaSelected(set)) {
	    searchMethods.add(SearchMethod.EDA);
	}
	if (searchMethods.size() > 1) {
	    throw new IllegalArgumentException(
		    "Error: Multiple search algorithms specified! "
			    + searchMethods.toString());
	}
	// else //got Warning Statement unnecessarily nested within else clause.
	// The corresponding then clause does not complete normally
	{
	    final SearchMethod searchMethod = (searchMethods.size() == 0) ? SearchMethod.EXHAUSTIVE
		    : searchMethods.get(0);
	    return searchMethod;
	}
    }

    public SearchMethod getSearchMethod() {
	return searchMethod;
    }

    public boolean isDatasetStackEmpty() {
	return datasetAncestors.empty();
    }

    public boolean isParallel() {
	return parallel;

    }

    private boolean isPartOfDistributedProcessing() {
	return distributedNodeCount != Main.defaultDistributedNodeCount;
    }

    private void openDataSet(final String datasetIdentifier,
	    final boolean matchedPairsOrTriplets) throws Exception, IOException {
	Dataset data = null;
	String dataFileName;
	dataFileName = Utility.getLocalFileOrURL(datasetIdentifier);
	final File datasetFile = new File(dataFileName);
	final LineNumberReader lnr = new LineNumberReader(new FileReader(
		datasetFile));
	data = new Dataset(datasetFile.getName(), missingCode,
		matchedPairsOrTriplets, lnr, allowedAttributes);
	lnr.close();
	setDataset(data, Console.DatasetStackAction.CLEAR_STACK);
    }

    public STATUS parseCommandLineAndRun(final String[] args,
	    final Runnable onEndModel, final Runnable onEndLevel,
	    final Runnable onEndAnalysis) {
	STATUS status = null;
	try {
	    final Options opt = new Options(args, Multiplicity.ZERO_OR_ONE, 0);
	    final OptionSet optHelp = opt.addSet("help");
	    final OptionSet optVersion = opt.addSet("version");
	    final OptionSet optAnalysis = opt.addSet("analysis", 1, 1000);
	    final OptionSet optLoadAnalysis = opt.addSet(
		    Console.LOAD_ANALYSIS_CMD, 1, 1);
	    final OptionSet optFilter = opt.addSet("filter", 1, 2);
	    optHelp.addOption("help");
	    optHelp.addOption("h");
	    optHelp.addOption(Console.MDR_COMMAND_LINE_HELP_TXT);
	    optVersion.addOption("version");
	    optVersion.addOption("v");

	    optLoadAnalysis.addOption(Console.LOAD_ANALYSIS_CMD,
		    Multiplicity.ONCE);

	    optAnalysis.addOption("minimal_output", Separator.EQUALS);
	    optAnalysis.addOption("table_data", Separator.EQUALS);
	    optAnalysis.addOption("cv", Separator.EQUALS);
	    optAnalysis.addOption("max", Separator.EQUALS);
	    optAnalysis.addOption("min", Separator.EQUALS);
	    optAnalysis.addOption("nolandscape");
	    optAnalysis
		    .addOption("top_models_landscape_size", Separator.EQUALS);
	    optAnalysis.addOption("matched");
	    optAnalysis.addOption("parallel");
	    optAnalysis.addOption("filter_file", Separator.EQUALS);
	    optAnalysis.addOption("saveanalysis", Separator.EQUALS);
	    optAnalysis.addOption("adjust_for_covariate", Separator.EQUALS);
	    optAnalysis.addOption("seed", Separator.EQUALS);
	    optAnalysis.addOption("permutations", Separator.EQUALS);
	    optAnalysis.addOption("permutation_start_index", Separator.EQUALS);
	    optAnalysis.addOption("permute_with_explicit_test_of_interaction",
		    Separator.EQUALS);
	    optAnalysis.addOption("print_detailed_confusion_matrix",
		    Separator.EQUALS);
	    optAnalysis.addOption("lack_of_coverage_penalty_exponent",
		    Separator.EQUALS);
	    optAnalysis.addOption("distributed_node_count", Separator.EQUALS);
	    optAnalysis.addOption("distributed_node_number", Separator.EQUALS);
	    optAnalysis.addOption("tie", Separator.EQUALS);
	    optAnalysis.addOption("forced_search", Separator.EQUALS);
	    optAnalysis.addOption("random_search_eval", Separator.EQUALS);
	    optAnalysis.addOption("random_search_runtime", Separator.EQUALS);
	    optAnalysis.addOption("eda_search_numAgents", Separator.EQUALS);
	    optAnalysis.addOption("eda_search_numUpdates", Separator.EQUALS);
	    optAnalysis.addOption("eda_search_retention", Separator.EQUALS);
	    optAnalysis.addOption("eda_search_alpha", Separator.EQUALS);
	    optAnalysis.addOption("eda_search_beta", Separator.EQUALS);
	    optAnalysis.addOption("eda_search_expertKnowledge",
		    Separator.EQUALS);
	    optAnalysis.addOption("eda_search_weightingMethod",
		    Separator.EQUALS);
	    optAnalysis.addOption("eda_search_percentMaxAttributeRange",
		    Separator.EQUALS);
	    optAnalysis.addOption("eda_search_theta", Separator.EQUALS);
	    optAnalysis.addOption("fishers_threshold", Separator.EQUALS);
	    optAnalysis.addOption("all_models_outfile", Separator.EQUALS);
	    optAnalysis.addOption("output_two_way_entropy", Separator.EQUALS);
	    optAnalysis.addOption("top_models_landscape_outfile",
		    Separator.EQUALS);
	    optAnalysis.addOption("top_models_predictions_file",
		    Separator.EQUALS);
	    optAnalysis.addOption("fitness_criteria_order_top_models",
		    Separator.EQUALS);
	    optAnalysis.addOption("fitness_criteria_order_best_model",
		    Separator.EQUALS);
	    optAnalysis.addOption("fitness_criteria_order_across_levels",
		    Separator.EQUALS);
	    optAnalysis.addOption("missing_code", Separator.EQUALS);
	    optAnalysis.addOption("discrete_significance_metric",
		    Separator.EQUALS);
	    optAnalysis.addOption("continuous_significance_metric",
		    Separator.EQUALS);
	    if (Main.isExperimental) {
	    } // end isExperimental
	    optFilter.addOption("filter", Separator.EQUALS, Multiplicity.ONCE);
	    optFilter.addOption("filter_file", Separator.EQUALS);
	    optFilter.addOption("minimal_output", Separator.EQUALS);
	    optFilter.addOption("parallel");
	    optFilter.addOption("relieff_neighbors", Separator.EQUALS);
	    optFilter.addOption("relieff_samplesize", Separator.EQUALS);
	    optFilter.addOption("chisq_pvalue");
	    optFilter.addOption("turf_pct", Separator.EQUALS);
	    optFilter.addOption("seed", Separator.EQUALS);
	    optFilter.addOption("select_", true, Separator.EQUALS);
	    if (Main.isExperimental) {
		optFilter.addOption("preserve_turf_removal_order",
			Separator.EQUALS);
		optFilter.addOption("relieff_weighted_distance_iterations",
			Separator.EQUALS);
		optFilter.addOption("relieff_weighted_distance_method",
			Separator.EQUALS);
		optFilter.addOption("relieff_weighted_scaling_method",
			Separator.EQUALS);
		optFilter.addOption(
			"relieff_weighted_scaling_exponential_theta",
			Separator.EQUALS);
		optFilter
			.addOption(
				"relieff_weighted_scaling_linear_percentMaxAttributeRange",
				Separator.EQUALS);
		optFilter.addOption("relieff_rebalancing_method",
			Separator.EQUALS);
	    }
	    final OptionSet set = opt.getMatchingSet(
		    false /* ignoreUnmatched */, false /* requireDataLast */);
	    if ((set != null) && (set.getUnmatched().size() > 0)) {
		errPrintStream
			.println("The following options were not understood:");
		for (final String unmatched : set.getUnmatched()) {
		    errPrintStream.println(unmatched);
		}
		errPrintStream.println("Run with -h to see all legal options.");
		status = STATUS.COMMAND_LINE_ERROR;
	    } else if (set == optHelp) {
		if (optHelp.isSet(Console.MDR_COMMAND_LINE_HELP_TXT)) {
		    Main.isExperimental = false;
		    final String classFileDirectory = Utility
			    .getLocalDirName(this.getClass());
		    final File helpFile = new File(classFileDirectory,
			    Console.MDR_COMMAND_LINE_HELP_TXT);
		    outPrintStream.println("Wrote "
			    + Console.MDR_COMMAND_LINE_HELP_TXT
			    + " into directory: " + classFileDirectory);
		    final PrintWriter pw = new PrintWriter(helpFile);
		    printUsage(pw);
		    pw.close();
		} else {
		    printUsage(new PrintWriter(outPrintStream, true));
		}
		status = STATUS.FINISHED_HELP;
	    } else if (set == optVersion) {
		if (Main.isExperimental) {
		    outPrintStream.println("version option passed in");
		}
		status = STATUS.FINISHED_VERSION;
	    } else if (set == optLoadAnalysis) {
		status = STATUS.LOAD_ANALYSIS;
	    } else if (set == optFilter) {
		status = runFilter(args, set);
	    } else if (set == optAnalysis) {
		final ArrayList<String> files = set.getData();
		if ((files == null) || (files.size() == 0)) {
		    status = STATUS.NO_DATA_FILES_TO_ANALYZE;
		} else {
		    for (final String dataFileName : files) {
			status = runAnalysis(args, set, dataFileName,
				onEndModel, onEndLevel, onEndAnalysis);
			if (status != STATUS.FINISHED_ANALYSIS) {
			    // stop if there is a problem
			    break;
			}
		    }
		}

	    } else {
		status = STATUS.COMMAND_LINE_ERROR;
		String errorMessage = "Command line passed in: "
			+ Arrays.toString(args)
			+ "\nDid you remember to pass the input dataset after all options?"
			+ "\nIf you are trying to filter a dataset, did you remember to pass the output file as the final argument?";
		if (Main.isExperimental) {
		    errorMessage += "\nOptionSet.checkErrors()="
			    + opt.getCheckErrors();
		}
		errPrintStream.println(errorMessage);
		outPrintStream.println(errorMessage);
		printUsage(new PrintWriter(outPrintStream, true));
	    }
	} catch (final Throwable ex) {
	    status = STATUS.CAUGHT_EXCEPTION; // negative is bad
	    errPrintStream.println("Command line passed in: "
		    + Arrays.toString(args));
	    errPrintStream.println("parseCommandLine caught an exception: "
		    + ex);
	    errPrintStream.println("parseCommandLine exception stackTrace: "
		    + Utility.stackTraceToString(ex.getStackTrace(), 0));
	} finally {
	    if (allModelsWriter != null) {
		allModelsWriter.close();
	    }
	    assert status != null;
	    if (status == null) {
		errPrintStream
			.println("console.parseCommandLineAndRun returning with an error status.");
	    } else if (status.isAnErrorStatus()) {
		errPrintStream
			.println("console.parseCommandLineAndRun returning with an error status.");
	    }
	    outPrintStream.println("\n" + new Date().toString()
		    + ": MDR finished with status " + status
		    + ". Elapsed running time: " + stopWatch.getElapsedTime());
	    outPrintStream.println("\n" + Console.memoryToString());
	}
	return status;
    }

    public Dataset peekAtLastDataset() {
	return datasetAncestors.peek();
    }

    public void popDataset() {
	if (isDatasetStackEmpty()) {
	    throw new RuntimeException(
		    "popDataset called when the dataset stack is empty!");
	}
	/*
	 * pass true to saveCurrentDataset and then pop it off. This is to avoid
	 * having the stack cleared which is normally done when
	 * saveCurrentDataset is false
	 */
	setDataset(datasetAncestors.pop(), DatasetStackAction.DO_NOTHING);
    }

    private void printAnalysisRunReport(final Dataset data) {
	if (!minimalOutput && (analysis.getAllModelsLandscape() != null)) {
	    outPrintStream.println("\n### Fitness Landscape ###\n");
	    outPrintStream.println(MdrTableColumnName.MODEL_ATTRIBUTES
		    .toString()
		    + '\t'
		    + MdrTableColumnName.MODEL_TRAINING
		    + '\t');
	    for (final LabeledFloatInterface p : analysis
		    .getAllModelsLandscape()) {
		outPrintStream.print(p.getLabel());
		outPrintStream.print("\t");
		outPrintStream.println(Main.decimalUpToFourPrecision.format(p
			.getFloat()));
	    }
	    outPrintStream.println();
	}

	final boolean doTopModelsLoop = (analysis.getCollectors().size() > 0)
		&& (!minimalOutput || (topModelsPredictionsFile != null) || isPartOfDistributedProcessing());
	if (doTopModelsLoop) {
	    PrintWriter topModelsPredictionsWriter = null;
	    if (topModelsPredictionsFile != null) {
		try {
		    topModelsPredictionsWriter = new PrintWriter(
			    topModelsPredictionsFile);
		    writeOutTopModelsPredictionsHeader(data,
			    topModelsPredictionsWriter);
		} catch (final FileNotFoundException ex) {
		    ex.printStackTrace();
		}
	    }
	    String startOfTopModelsHeader = "";
	    if (isPartOfDistributedProcessing()) {
		startOfTopModelsHeader += "distributed_node_number/distributed_node_count\t";
	    }
	    startOfTopModelsHeader += MdrTableColumnName.NUM_ATTRIBUTES
		    .toString() + '\t';
	    if (doTopModelsLoop) {
		outPrintStream.println("\n\n### Top Models ###\n");
		if (analysis.getCollectors().get(0).size() > 0) {
		    final ModelInfoInterface firstModel = analysis
			    .getCollectors().get(0).first();
		    outPrintStream.println(startOfTopModelsHeader
			    + Utility.join(firstModel.getHeaders(), '\t'));
		}
	    } // end if doTopModelsLoop
	    for (final Collector collector : analysis.getCollectors()) {
		for (final ModelInfoInterface topModelData : collector) {
		    final String modelName = topModelData.getModelName();
		    if (topModelsPredictionsWriter != null) {
			writeOutTopModelsPredictionsRow(data,
				topModelsPredictionsWriter, modelName);
		    }
		    if (doTopModelsLoop) {
			if (isPartOfDistributedProcessing()) {
			    outPrintStream.print(distributedNodeNumber);
			    outPrintStream.print('/');
			    outPrintStream.print(distributedNodeCount);
			    outPrintStream.print('\t');
			}
			outPrintStream.print(topModelData.size());
			outPrintStream.print('\t');
			outPrintStream.print(Utility.join(
				topModelData.asStringArray(), '\t'));
			outPrintStream.println();
		    } // end if not minimal output
		} // end for loop
	    } // end loop over collectors

	    if (doTopModelsLoop) {
		outPrintStream.println();
	    }

	    if (topModelsPredictionsWriter != null) {
		topModelsPredictionsWriter.close();
	    }
	} // end if collectors if has top models
	outPrintStream.flush();
    } // end oldOnEndAllLevels;

    public void printTableDataHeader(
	    final List<Pair<String, String>> tableData, final Dataset data) {
	outPrintStream.print(MdrTableColumnName.TABLE_OUTPUT_HEADER_START);
	outPrintStream.print(Console.getTableDataHeader(tableData));
	outPrintStream.print("# cases/control\t# CV partitions\t"
		+ MdrTableColumnName.NUM_ATTRIBUTES + "\t"
		+ MdrTableColumnName.MODEL_ATTRIBUTES + "\t"
		+ MdrTableColumnName.CVC + "\t");
	outPrintStream
		.print(getConfusionMatrixInfoHeader(MdrTableColumnName.OVERALL_SCORE));
	outPrintStream
		.print(getConfusionMatrixInfoHeader(MdrTableColumnName.CV_TRAINING));
	outPrintStream
		.print(getConfusionMatrixInfoHeader(MdrTableColumnName.CV_TESTING));
	outPrintStream
		.print(getConfusionMatrixInfoHeader(MdrTableColumnName.MODEL_TRAINING));
	outPrintStream
		.print(getConfusionMatrixInfoHeader(MdrTableColumnName.MODEL_TESTING));
	// if (!data.hasContinuousEndpoints()) {
	// outPrintStream
	// .print(getConfusionMatrixInfoHeader(MdrTableColumnName.LOOCV_TRAINING_COLUMN_NAME));
	// outPrintStream
	// .print(getConfusionMatrixInfoHeader(MdrTableColumnName.LOOCV_TESTING_COLUMN_NAME));
	// }
    }

    private void printUsage(final PrintWriter out) {
	out.println("Usage of Multifactor Dimensionality Reduction (MDR) jar file:");
	out.println();
	out.println("java -jar mdr.jar");
	out.println("  (GUI mode) (can also just double-click on many systems) ");
	out.println();
	out.println("java -Xmx1000m -jar mdr.jar ...");
	out.println("  (can optionally specify how much memory to allocate) ");
	out.println();
	out.println("java -jar mdr.jar -help");
	out.println("  (Display this message)");
	out.println();
	out.println("java -jar mdr.jar -version");
	out.println("  (Display version information)");
	out.println();
	out.println("java -jar mdr.jar [analysis options] <datafile>");
	out.println("  (Batch mode analysis)");
	out.println();
	out.println("java -jar mdr.jar [filter options] <datafile> "
		+ "<outputfile>");
	out.println("  (Batch mode filter)");
	out.println();
	out.println("Example of a batch run generating a tab delimited table of summary results:");
	out.println("java -jar mdr.jar -min=1 -max=2 -cv=10 -table_data=true -minimal_output=true MDR-SampleData.txt");
	out.println();
	out.println("Analysis Options:");
	out.println();
	out.println("-cv=<int>\n\tdefault: "
		+ Main.defaultCrossValidationCount
		+ "\n\tCross-validation count. Determines partitioning of the data into multiple overlapping datasets which can be used to check against over-fitting. Setting to 1 disables cross-validation.");
	out.println("-min=<int>\n\tdefault: "
		+ Main.defaultAttributeCountMin
		+ "\n\tThe minimum number of attributes considered together. Referred to in UI under 'Attribute Count Range'.");
	out.println("-max=<int>\n\tdefault: "
		+ Main.defaultAttributeCountMax
		+ "\n\tThe maximum number of attributes considered together. Referred to in UI under 'Attribute Count Range'.");
	out.println("-nolandscape\n\tdefault: this is not a boolean and takes no argument -- if present then true\n\tThis will stop the output of the fitness of every attribute combination looked at. This will signifigantly reduce the size of your output.");
	out.println("-top_models_landscape_size\n\tdefault: "
		+ topModelsLandscapeSize
		+ "\n\tMinimum of 1. This will keep track of this number of the best models for each level.");
	out.println("-filter_file=<path to file of attribute names>\nIf present, only those attributes in this file will be read in from disk to create a filtered dataset.");
	out.println("-parallel\n\tdefault: this is not a boolean and takes no argument -- if present then true\n\tIf present, program will make best use of multiple processors/cores.");
	out.println("-forced_search=<comma-separated attribute list or attribute names or zero-based indices>\n\tdefault: exhaustive search\n\tChanges search from exhaustive testing of all attribute combinations to only test the combination specified with this option.  Can also include one or more asterisks to exhaustively searchforced attributes on additional levels");
	out.println("-random_search_eval=<int>\n\tdefault: exhaustive search\n\tChanges search from exhaustive testing of all attribute combinations to instead test the passed in number of random combinations of attributes. There is nothing to prevent the same combination from being repeatedly tested.");
	out.println("-random_search_runtime=<double><s|m|h|d>\n\tdefault: exhaustive search\n\tchanges search from exhaustive testing of all attribute combinations to instead test the passed random combinations of attributes for a specified time such as 30m (30 minutes) or 1h (1 hour). There is nothing to prevent the same combination from being repeatedly tested.");
	out.println("-adjust_for_covariate=<attributeName>\n\tdefault: not used\n\tIf specified, the dataset will be modified to remove all main effects attributable to the passed in attribute.");
	out.println("-seed=<long>\n\tdefault: "
		+ randomSeed
		+ "\n\tThis number will be used to seed the random number generator. This is used to partition the datasets when using cross validation. Varying this number will change the cross validation results slightly. It is also used more extensively for types of searches that involve probabilities or random choices such as EDA and Random.");
	out.println("-tie=<"
		+ getEnumNames(AmbiguousCellStatus.values())
		+ ">\n\tdefault: "
		+ Main.defaultAmbiguousCellStatus.name()
		+ "\n\tIf the case and control counts are equal for an attribute combination cell, the status of that cell will be as specified here.");
	out.println("-saveanalysis=<filename>\n\tdefault: analysis not saved by default\n\tname of file to save MDR Gui compatible analysis file.");
	out.println("-minimal_output=<boolean>\n\tdefault: "
		+ minimalOutput
		+ "\n\tThis will output only the best attribute combination for each level, skipping all other normal information such as cross-validation, etcetera.");
	out.println("-matched\n\tdefault: this is not a boolean and takes no argument -- if present then true\n\tThis alters the way data sets are partitioned to make sure matched rows (either pairs or triplets) always end up in the same cross-validation interval. Also affects permutation.");
	out.println("-permutations=<int>\n\tdefault: "
		+ permutations
		+ "\tIf non-zero the mdr status column will be shuffled and mdr run a number of times. The probability of the observed mdr model testing accuracy and cv will be output.");
	out.println("-permutation_start_index=<int>\n\tdefault: "
		+ permutationStartIndex
		+ "\tUseful when you want to reproduce permutation results. This will advance the random number generator so that the first permutation will be identical to the permutation #(permutationStartIndex+1).");
	out.println("-permute_with_explicit_test_of_interaction=<boolean>\n\tdefault: "
		+ useExplicitTestOfInteraction
		+ "\n\tVariant of permutation testing that keeps main affects while permuting attribute interactions");
	out.println("-lack_of_coverage_penalty_exponent=float\n\tdefault: "
		+ Console.lackOfCoveragePenaltyExponent
		+ "\n\tWhen rows cannot be classified, decrease score using this value. Formula is (ba - 0.5)*POW(coverage,exponent) + 0.5.");
	out.println("-fitness_criteria_order_top_models=<"
		+ Utility.join(
			FitnessCriteriaOrder.topModelsCriteriaIndependentOfCVC,
			'|')
		+ ">\n\tdefault: "
		+ topModelsFitnessCriteriaOrder
		+ "\tDetermines the metrics and the order they are applied for top models.");
	out.println("-fitness_criteria_order_best_model=<"
		+ Utility
			.join(FitnessCriteriaOrder.bestModelCriteriaPossiblyDependentOnCVC,
				'|')
		+ ">\n\tdefault: "
		+ bestModelFitnessCriteriaOrder
		+ "\tDetermines the metrics and the order they are to choose the best model from the top models.");
	out.println("-fitness_criteria_order_across_levels=<"
		+ Utility
			.join(FitnessCriteriaOrder.bestModelCriteriaPossiblyDependentOnCVC,
				'|') + ">\n\tdefault: "
		+ acrossLevelsFitnessCriteriaOrder
		+ "\tDetermines the overall best model across levels");
	out.println("-print_detailed_confusion_matrix=<boolean>\n\tdefault: "
		+ printDetailedConfusionMatrix
		+ "\n\tWhen printing table_data print entire confusion matrix, TP, FP, TN, FN and # of unclassified rows.");
	out.println("-discrete_significance_metric=<"
		+ getEnumNames(DiscreteEndpointSignificanceMetric.values())
		+ ">\n\tdefault: "
		+ discreteEndpointSignificanceMetric.name()
		+ "\tEXPERIMENTAL: For discrete endpoints, what metric to use to evaluate model.");
	out.println("-continuous_significance_metric=<"
		+ getEnumNames(ContinuousEndpointSignificanceMetric.values())
		+ ">\n\tdefault: "
		+ continuousEndpointSignificanceMetric.name()
		+ "\tEXPERIMENTAL: For continuous endpoints, what metric to use to evaluate model.");
	out.println("-missing_code=<String>\n\tdefault: "
		+ missingCode
		+ "\tEXPERIMENTAL: What string should be interpreted as missing data. Models with missing data will be considered UNASSIGNED and a coverage penalty applied (coverage penalty not implemented for continuous endpoints). Note: the default is an empty cell.");
	out.println("-distributed_node_count=<Integer>\n\tdefault: "
		+ distributedNodeCount
		+ "\tIf greater than 1, attribute combinations will be split into the specified number of subsets. Which subset mdr looks at is determined by distributed_node_number. This number must be evenly divisible by the -cv parameter. This can be used as a primitive form of parallelization where multiple mdr instances (perhaps on a cluster) process a subset of the data. It will be up to the user to collate the results.");
	out.println("-distributed_node_number=<Integer>\n\tdefault: "
		+ distributedNodeNumber
		+ "\tOnly relevant if distributed_node_count is greater than 1. This will determine which subset of the attribute combinations the current instance of mdr will examine.");
	out.println("-eda_search_numAgents=<int>\n\tdefault: "
		+ Main.defaultEDANumAgents
		+ "\n\tnumber of MDR models (attribute combinations) evaluated in each generation");
	out.println("-eda_search_numUpdates=<int>\n\tdefault: "
		+ Main.defaultEDANumUpdates + "\n\tnumber of generations");
	out.println("-eda_search_retention=<double>\n\tdefault: "
		+ Main.defaultEDARetention
		+ "\n\tdetermines how much weight information from previous iterations is given relative to information gained in the most recent iteration");
	out.println("-eda_search_alpha=<int>\n\tdefault: "
		+ Main.defaultEDAAlpha
		+ "\n\tthe relative weight given to the current generations MDR score (balanced accuracy).");
	out.println("-eda_search_beta=<int>\n\tdefault: "
		+ Main.defaultEDABeta
		+ "\n\tthe relative weight given to the expert knowledge score of an attribute.");
	out.println("-eda_search_expertKnowledge=<filename>\n\tdefault: no file read in by default\n\tformat is one row per attribute with two tab-delimited columns: attribute name and floating point number as weight. Higher numbers are considered better.");
	out.println("-eda_search_weighting_method=<"
		+ getEnumNames(WeightScheme.values()) + ">\n\tdefault: "
		+ Main.defaultEDAWeightingMethod.name() + "\n\t");
	out.println("-eda_search_theta=<double>\n\tdefault: "
		+ Main.defaultEDAExponentialTheta + "\n\t");
	out.println("-eda_search_percentMaxAttributeRange=<0-100>\n\tdefault: "
		+ Main.defaultEDAPercentMaxAttributeRange + "\n\t");
	out.println("-table_data=<either 'true' or else comma delimited name=value pairs>\n\tIf this is present the format of the output data is changed into a tab-delimited table format with each attribute level result generating only one row/line. It is useful when doing many runs with different parameters. You add the parameters that can vary and their value for the current run and these will shown in their own columns.");
	out.println("-fishers_threshold=<float>\n\tdefault: "
		+ Console.fishersThreshold
		+ "\n\tIf not Double.NaN this alters how MDR determines how ties are determined when determining the classification for an attribute combination. Instead of looking only to see if case and control are equal, this uses the Fisher's Exact Test to determine if the two numbers differ significantly. If the Fisher's two tailed result is greater than or equal to the passed in number the differences are considered significant, else considered a tie and the cell is classified according to tie priority.");
	out.println("-all_models_outfile=<filename>\n\tdefault: <none>\tIf present, all model results will be output as they are calculated. This is better than landscape which does not output until the end and may fail due to running out of memory.");
	out.println("-output_two_way_entropy\n\tdefault: NOT PRESENT. If present this must be one of the values: "
		+ getEnumNames(EntropyAnalysis.NetworkDataType.values())
		+ "\n\tThis will cause entropy to be computed for every attribute and every attribute combination");
	out.println("-top_models_predictions_file=<String>\n\tdefault: NOT PRESENT.\n\tIf present this a tab delimited table will be written to the file specified which hava column for every top model and a row fr every sample. Each cell will be 1 if the model correctly predicted the class else zero.");
	if (Main.isExperimental) {
	    out.println("============ EXPERIMENTAL ANALYSIS PARAMETERS =================================");
	    out.println("============ END EXPERIMENTAL ANALYSIS PARAMETERS =================================");
	} // end isExperimental
	out.println();
	out.println("Filter Options:");
	out.println();
	out.println("-chisq_pvalue\n\tdefault: this is not a boolean and takes no argument -- if present then true\n\tif present then uses chi squared p-value, else it uses the chi squared value.");
	out.println("-filter=One of these choices: <"
		+ getEnumNames(FilterMethod.values())
		+ ">\n\tdefault: no default - if not specified then must not be doing a filter\n\tspecifies which measure used to filter data.\nTo save the filtered dataset, include the name of the output file as your final argument.");
	out.println("-filter_file=<path to file of attribute names>: "
		+ ">\n\tdefault: no default - filter dataset to only the included columns. Used in with -filter="
		+ FilterMethod.ATTRIBUTE_FILE.name());
	out.println("-parallel\n\tdefault: this is not a boolean and takes no argument -- if present then true\n\tIf present, program will make best use of multiple processors/cores.");
	out.println("-seed=<long>\n\tdefault: "
		+ randomSeed
		+ "\n\tThis number will be used to seed the random number generator. This is used to pick random samples if relieff_samplesize less than entire dataset.");
	out.println("-relieff_neighbors=<int>\n\tdefault: "
		+ Main.defaultReliefFNeighbors
		+ " or number of datarows if smaller\n\tnumber of instances with most similar attributes used in calculating score");
	out.println("-relieff_samplesize=<int>\n\tdefault: "
		+ "<entire dataset>\n\tnumber of instances used in calculating scores. Recommended to use all.");
	out.println("-select_<N | PCT | THRESH>=<value>\n\tN selects a set number of top attributes based on score, percent selects a percentage of top attributes, threshold selects ones with a score above a specified value.");
	out.println("-turf_pct=<float>\n\tdefault: "
		+ (Main.defaultTuRFPct / 100.0f)
		+ "\n\tNumber between 0 and 1 which represents fraction of attributes removed in each TuRF iteration.");
	if (Main.isExperimental) {
	    out.println("============ EXPERIMENTAL FILTER PARAMETERS =================================");
	    out.println("-preserve_turf_removal_order=<boolean>\n\tdefault: "
		    + preserveTuRFRemovalOrder
		    + "\tIf false, TurF scores are last reliefF (or Surf or SurfStar) scores for each attributes. If true, then the order attributes are removed is kept track of and the last reliefF score is normalized so that the scores sorting order is in reverse order of removal.");
	    out.println("-relieff_weighted_distance_iterations=<int>\n\tdefault: "
		    + reliefFWeightedDistanceIterations
		    + "\tIf non-zero reliefF will iterate n times using the previous generation relieff scores based on relieff_weighted_distance_method");
	    out.println("-relieff_weighted_distance_method=<"
		    + getEnumNames(WeightScheme.values())
		    + ">\n\tdefault: "
		    + reliefFWeightedDistanceMethod.name()
		    + "\tWhen relieff_weighted_distance_iterations is > 0, this specifies the weighting method of the previous iteration of relieff scores.");
	    out.println("-relieff_weighted_scaling_method=<"
		    + getEnumNames(ScalingMethod.values())
		    + ">\n\tdefault: "
		    + reliefFWeightedScalingMethod.name()
		    + "\tWhen relieff_weighted_distance_iterations is > 0, this specifies the scaling method of the previous iteration of relieff scores.");
	    out.println("-relieff_weighted_scaling_exponential_theta=<double>\n\tdefault: "
		    + Main.defaultEDAExponentialTheta + "\n\t");
	    out.println("-relieff_weighted_scaling_linear_percentMaxAttributeRange=<0-100>\n\tdefault: "
		    + Main.defaultEDAPercentMaxAttributeRange + "\n\t");
	    out.println("-relieff_rebalancing_method=<"
		    + getEnumNames(ReliefFRebalancingMethod.values())
		    + ">\n\tdefault: "
		    + reliefFRebalancingMethod.name()
		    + "\tHow relieff deals with data. Even when balanced slightly changes behavior because samples drawn equally from classes.");
	    out.println("============ END EXPERIMENTAL FILTER PARAMETERS =================================");
	} // end if Main.isExperimental
	out.println();
    }

    private boolean randomSelected(final OptionSet set) {
	if (set.isSet("random_search_eval")
		|| set.isSet("random_search_runtime")) {
	    return true;
	}
	return false;
    }

    /**
     * @return -1 if error, 0 if completed normally, 1 if gui should be run
     * @throws Exception
     */
    private STATUS runAnalysis(final String[] args, final OptionSet set,
	    final String dataFileName, final Runnable callersOnEndModel,
	    final Runnable callersOnEndLevel,
	    final Runnable callersOnEndAnalysis) throws Exception {
	final StringBuffer config = new StringBuffer();
	final ColumnFormat columns = new ColumnFormat(
		Arrays.asList(new Integer[] { new Integer(100),
			new Integer(100) }), true /* useTabs */);
	boolean matchedPairsOrTriplets = false;
	if (set.isSet("matched")) {
	    matchedPairsOrTriplets = true;
	}
	parallel = set.isSet("parallel");
	config.append(columns.format(Arrays.asList(new String[] { "Parallel:",
		Boolean.toString(parallel) })) + '\n');
	List<Pair<String, String>> tableData = null;
	if (set.isSet("table_data")) {
	    final String rawTableData = set.getOptionString("table_data")
		    .trim();
	    config.append(columns.format(Arrays.asList(new String[] {
		    "table_data:", rawTableData })) + '\n');
	    if (Boolean.parseBoolean(rawTableData)) {
		tableData = new ArrayList<Pair<String, String>>(0);
	    } else {
		if (!rawTableData.equalsIgnoreCase("False")) {
		    final String[] pairs = rawTableData.split("[,]"); // name
		    // value
		    // pairs
		    // split
		    // on
		    // commas
		    tableData = new ArrayList<Pair<String, String>>(
			    pairs.length);
		    for (final String nameEqualValue : pairs) {
			final String[] pairInfo = nameEqualValue.split("=");
			if (pairInfo.length != 2) {
			    throw new RuntimeException(
				    "-table_data parameter cound not be parsed into key value pairs. Value passed in was: "
					    + rawTableData);
			}
			tableData.add(new Pair<String, String>(pairInfo[0],
				pairInfo[1]));
		    }
		}
	    }
	} // end if tableData
	if (set.isSet("tie")) {
	    final String tieStatusString = set.getOptionString("tie");
	    try {
		ambiguousCellStatus = AmbiguousCellStatus
			.getTiePriorityFromString(tieStatusString);
		config.append(columns.format(Arrays.asList(new String[] {
			"Tie Cells:", ambiguousCellStatus.toString() })) + '\n');
	    } catch (final IllegalArgumentException ex) {
		errPrintStream.println("Error: tie value. Legal values: "
			+ getEnumNames(AmbiguousCellStatus.values())
			+ ". Passed in value: " + tieStatusString);
		return STATUS.ILLEGAL_ARGUMENT;
	    }
	}
	if (set.isSet("fishers_threshold")) {
	    try {
		final String fishersThresholdString = set
			.getOptionString("fishers_threshold");
		Console.fishersThreshold = Float
			.parseFloat(fishersThresholdString);
		if ((Console.fishersThreshold > 1.0f)
			|| (Console.fishersThreshold <= 0.0f)) {
		    errPrintStream
			    .println("Error: fishers_threshold out of range. This must a number greater than zero and less than or equal to one. Passed in value: "
				    + fishersThresholdString);
		    return STATUS.ILLEGAL_ARGUMENT;
		}
		if (ambiguousCellStatus != AmbiguousCellStatus.UNCLASSIFIED) {
		    outPrintStream
			    .println("Warning: fishers_threshold was passed in but 'tie' is set to "
				    + ambiguousCellStatus
				    + ".\n\tAmbiguous cells will automatically be set to that status rather than being considered UNASSIGNED\n\twhich is the more commonn choice when fishers_threshold is specified.");
		}
		config.append(columns.format(Arrays.asList(new String[] {
			"fishers_threshold:",
			String.valueOf(Console.fishersThreshold) })) + '\n');
	    } catch (final NumberFormatException ex) {
		errPrintStream
			.println("Error: fishers_threshold accepts float values only.");
		return STATUS.ILLEGAL_ARGUMENT;
	    }
	}
	if (set.isSet("top_models_predictions_file")) {
	    topModelsPredictionsFile = set
		    .getOptionString("top_models_predictions_file");
	    config.append(columns.format(Arrays.asList(new String[] {
		    "top_models_predictions_file:", topModelsPredictionsFile })) + '\n');
	}
	if (set.isSet("discrete_significance_metric")) {
	    final String discreteSignificanceMetricString = set
		    .getOptionString("discrete_significance_metric");
	    try {
		discreteEndpointSignificanceMetric = Enum.valueOf(
			DiscreteEndpointSignificanceMetric.class,
			discreteSignificanceMetricString.toUpperCase());
		config.append(columns.format(Arrays.asList(new String[] {
			"discrete_significance_metric:",
			String.valueOf(discreteEndpointSignificanceMetric) })) + '\n');
	    } catch (final IllegalArgumentException ex) {
		errPrintStream
			.println("Error: unknown discrete significance metric. Legal values: "
				+ getEnumNames(DiscreteEndpointSignificanceMetric
					.values())
				+ ". Passed in value: "
				+ discreteSignificanceMetricString);
		return STATUS.ILLEGAL_ARGUMENT;
	    }
	}
	if (set.isSet("continuous_significance_metric")) {
	    final String continuousSignificanceMetricString = set.getOption(
		    "continuous_significance_metric").getResultValue(0);
	    try {
		continuousEndpointSignificanceMetric = Enum.valueOf(
			ContinuousEndpointSignificanceMetric.class,
			continuousSignificanceMetricString.toUpperCase());
		config.append(columns.format(Arrays.asList(new String[] {
			"continuous_significance_metric:",
			String.valueOf(continuousEndpointSignificanceMetric) })) + '\n');
	    } catch (final IllegalArgumentException ex) {
		errPrintStream
			.println("Error: unknown continuousSignificanceMetric. Legal values: "
				+ getEnumNames(ContinuousEndpointSignificanceMetric
					.values())
				+ ". Passed in value: "
				+ continuousSignificanceMetricString);
		return STATUS.ILLEGAL_ARGUMENT;
	    }
	}
	if (set.isSet("missing_code")) {
	    missingCode = set.getOptionString("missing_code");
	    config.append(columns.format(Arrays.asList(new String[] {
		    "missing_code:", missingCode })) + '\n');
	}
	if (set.isSet("fitness_criteria_order_top_models")) {
	    final String fitnessCriteriaOrderString = set
		    .getOptionString("fitness_criteria_order_top_models");
	    try {
		topModelsFitnessCriteriaOrder = FitnessCriteriaOrder
			.lookup(fitnessCriteriaOrderString);
		config.append(columns.format(Arrays.asList(new String[] {
			"fitness_criteria_order_top_models:",
			String.valueOf(topModelsFitnessCriteriaOrder) })) + '\n');
	    } catch (final IllegalArgumentException ex) {
		errPrintStream
			.println("Error: unknown fitness criteria order. Legal values: "
				+ Utility
					.join(FitnessCriteriaOrder.topModelsCriteriaIndependentOfCVC,
						'|')
				+ ". Passed in value: "
				+ fitnessCriteriaOrderString);
		return STATUS.ILLEGAL_ARGUMENT;
	    }
	}
	if (set.isSet("fitness_criteria_order_best_model")) {
	    final String fitnessCriteriaOrderString = set
		    .getOptionString("fitness_criteria_order_best_model");
	    try {
		bestModelFitnessCriteriaOrder = FitnessCriteriaOrder
			.lookup(fitnessCriteriaOrderString);
		config.append(columns.format(Arrays.asList(new String[] {
			"fitness_criteria_order_best_model:",
			String.valueOf(bestModelFitnessCriteriaOrder) })) + '\n');
	    } catch (final IllegalArgumentException ex) {
		errPrintStream
			.println("Error: unknown fitness criteria order. Legal values: "
				+ Utility
					.join(FitnessCriteriaOrder.bestModelCriteriaPossiblyDependentOnCVC,
						'|')
				+ ". Passed in value: "
				+ fitnessCriteriaOrderString);
		return STATUS.ILLEGAL_ARGUMENT;
	    }
	}

	if (set.isSet("fitness_criteria_order_across_levels")) {
	    final String fitnessCriteriaOrderString = set
		    .getOptionString("fitness_criteria_order_across_levels");
	    try {
		acrossLevelsFitnessCriteriaOrder = FitnessCriteriaOrder
			.lookup(fitnessCriteriaOrderString);
		config.append(columns.format(Arrays.asList(new String[] {
			"fitness_criteria_order_across_levels:",
			String.valueOf(acrossLevelsFitnessCriteriaOrder) })) + '\n');
	    } catch (final IllegalArgumentException ex) {
		errPrintStream
			.println("Error: unknown fitness criteria order. Legal values: "
				+ Utility
					.join(FitnessCriteriaOrder.bestModelCriteriaPossiblyDependentOnCVC,
						'|')
				+ ". Passed in value: "
				+ fitnessCriteriaOrderString);
		return STATUS.ILLEGAL_ARGUMENT;
	    }
	}
	if (Main.isExperimental) {
	} // end is experimental
	if (set.isSet("seed")) {
	    try {
		setRandomSeed(Long.parseLong(set.getOption("seed")
			.getResultValue(0)));
	    } catch (final NumberFormatException ex) {
		errPrintStream
			.println("Error: seed accepts integer values only.");
		return STATUS.ILLEGAL_ARGUMENT;
	    }
	}
	config.append(columns.format(Arrays.asList(new String[] {
		"Random Seed:", Long.toString(randomSeed) })) + '\n');

	if (set.isSet("filter_file")) {
	    final String filterFilePath = set.getOptionString("filter_file");
	    final boolean foundFilterFile = setAllowedAttributes(filterFilePath);
	    if (foundFilterFile) {
		config.append(columns.format(Arrays.asList(new String[] {
			"filter_file:", filterFilePath })) + '\n');
		config.append(columns.format(Arrays.asList(new String[] {
			"# of attributes from filter_file:",
			String.valueOf(allowedAttributes.size()) })) + '\n');
	    } else {
		errPrintStream.println("Error: -filter_file passed in value '"
			+ filterFilePath
			+ "' is not a file containing attribute names.");
		return STATUS.ILLEGAL_ARGUMENT;
	    }
	} // end dealing with filter_file

	// finally open datafile. This will be filtered by allowedAttributes is
	// not null
	openDataSet(dataFileName, matchedPairsOrTriplets);
	config.append(columns.format(Arrays.asList(new String[] { "Datafile:",
		dataFileName })) + '\n');
	setMetricDisplayText();
	cv = Math.min(Main.defaultCrossValidationCount, data.getRows());
	if (set.isSet("cv")) {
	    cv = set.getOptionInteger("cv");
	    if ((cv < 1) || (cv > data.getRows())) {
		errPrintStream
			.println("Error: cv must be > 0 and <= number of instances in the data set. cv passed in was: "
				+ cv
				+ " and the number of instances is: "
				+ data.getRows());
		return STATUS.ILLEGAL_ARGUMENT;
	    }
	}
	config.append(columns.format(Arrays.asList(new String[] {
		"CV Intervals:", Integer.toString(cv) })) + '\n');
	if (set.isSet("permutations")) {
	    permutations = set.getOptionInteger("permutations");
	    // tableData must be true for permutations
	    if (tableData == null) {
		tableData = new ArrayList<Pair<String, String>>(0);
	    }
	    if (set.isSet("permute_with_explicit_test_of_interaction")) {
		useExplicitTestOfInteraction = Boolean.parseBoolean(set
			.getOption("permute_with_explicit_test_of_interaction")
			.getResultValue(0));
	    }

	    if (set.isSet("permutation_start_index")) {
		permutationStartIndex = set
			.getOptionInteger("permutation_start_index");
	    }
	    config.append(columns.format(Arrays.asList(new String[] {
		    "Permutations:", String.valueOf(permutations) })) + '\n');
	    config.append(columns.format(Arrays.asList(new String[] {
		    "Permute explicit test:",
		    String.valueOf(useExplicitTestOfInteraction) })) + '\n');
	    config.append(columns.format(Arrays.asList(new String[] {
		    "Permutation start index:",
		    String.valueOf(permutationStartIndex) })) + '\n');
	}
	if (set.isSet("print_detailed_confusion_matrix")) {
	    printDetailedConfusionMatrix = set
		    .getOptionBoolean("print_detailed_confusion_matrix");
	    config.append(columns.format(Arrays.asList(new String[] {
		    "print_detailed_confusion_matrix:",
		    String.valueOf(printDetailedConfusionMatrix) })) + '\n');
	}
	if (set.isSet("lack_of_coverage_penalty_exponent")) {
	    Console.lackOfCoveragePenaltyExponent = Float.parseFloat(set
		    .getOption("lack_of_coverage_penalty_exponent")
		    .getResultValue(0));
	    config.append(columns.format(Arrays.asList(new String[] {
		    "lack_of_coverage_penalty_exponent:",
		    String.valueOf(Console.lackOfCoveragePenaltyExponent) })) + '\n');
	}
	numberOfAttributes = data.getCols() - 1;
	minLevel = Math.min(Main.defaultAttributeCountMin, numberOfAttributes);
	maxLevel = Math.min(Main.defaultAttributeCountMax, numberOfAttributes);
	// Forced Search Options
	List<AttributeCombination> forced = null;
	// Random Search Options
	int evaluations = 0;
	double runtime = 0;
	TimeUnits timeUnits = null;
	// EDA Search Options
	int numAgents = Main.defaultEDANumAgents;
	int numUpdates = Main.defaultEDANumUpdates;
	double retention = Main.defaultEDARetention;
	int alpha = Main.defaultEDAAlpha;
	int beta = Main.defaultEDABeta;
	double percentMaxAttributeRange = Main.defaultEDAPercentMaxAttributeRange;
	double theta = Main.defaultEDAExponentialTheta;
	ScalingMethod scalingMethod = null;
	double scalingParameter = 0.0;
	ExpertKnowledge expertKnowledge = null;
	boolean expertKnowledgeLoaded = false;
	if (set.isSet("minimal_output")) {
	    minimalOutput = Boolean.parseBoolean(set
		    .getOption("minimal_output").getResultValue(0));
	} // Specify Search
	setSearchMethod(getRequestedSearchMethod(set));
	switch (searchMethod) {
	case FORCED: {
	    final String value = set.getOptionString("forced_search");
	    if (set.isSet("min") || set.isSet("max")) {
		outPrintStream
			.println("Warning: -min and -max ignored for forced "
				+ "analysis.");
	    }
	    try {
		forced = AttributeCombinationWithWildcards
			.parseComboWithPossibilityOfWildcards(value,
				data.getNumAttributes(), data.getLabels());
	    } catch (final IllegalArgumentException ex) {
		errPrintStream.println("Error: " + ex.getMessage());
		return STATUS.ILLEGAL_ARGUMENT;
	    }
	    config.append(columns.format(Arrays.asList(new String[] {
		    "Wrapper:", "Forced" })) + '\n');
	    config.append(columns.format(Arrays.asList(new String[] {
		    "Forced:", forced.toString() })) + '\n');
	    final SortedSet<Integer> combinationSizes = AttributeCombination
		    .getCombinationSizes(forced);
	    minLevel = combinationSizes.first();
	    maxLevel = combinationSizes.last();
	}
	    break;
	case RANDOM: {
	    if (set.isSet("random_search_eval")) {
		if (set.isSet("random_search_runtime")) {
		    errPrintStream
			    .println("Error: Multiple search algorithms specified!");
		    return STATUS.ILLEGAL_ARGUMENT;
		}
		evaluations = set.getOptionInteger("random_search_eval");
		config.append(columns.format(Arrays.asList(new String[] {
			"Wrapper:", "Random (Evaluations)" })) + '\n');
		config.append(columns.format(Arrays.asList(new String[] {
			"Evaluations:", Integer.toString(evaluations) })) + '\n');
	    } else if (set.isSet("random_search_runtime")) {
		final String s = set.getOptionString("random_search_runtime");
		final Pattern p = Pattern.compile("^(.+?)([smhd]?)$",
			Pattern.CASE_INSENSITIVE);
		final Matcher m = p.matcher(s);
		if (m.matches()) {
		    runtime = Double.parseDouble(m.group(1));
		    if (m.group(2).equalsIgnoreCase("S")) {
			timeUnits = TimeUnits.Seconds;
		    } else if ((m.group(2).length() == 0)
			    || m.group(2).equalsIgnoreCase("M")) {
			timeUnits = TimeUnits.Minutes;
		    } else if (m.group(2).equalsIgnoreCase("H")) {
			timeUnits = TimeUnits.Hours;
		    } else if (m.group(2).equalsIgnoreCase("D")) {
			timeUnits = TimeUnits.Days;
		    }
		}
		config.append(columns.format(Arrays.asList(new String[] {
			"Wrapper:", "Random (Runtime)" })) + '\n');
		config.append(columns.format(Arrays.asList(new String[] {
			"Runtime:", Double.toString(runtime) }))
			+ ' ' + timeUnits + '\n');
	    }
	}
	    break;
	case EDA: {
	    /**
	     * Might need to catch improper arguments here, i.e. given a double
	     * when expecting an int
	     */
	    // NumAgents
	    if (set.isSet("eda_search_numAgents")) {
		numAgents = set.getOptionInteger("eda_search_numAgents");
	    }
	    // NumUpdates
	    if (set.isSet("eda_search_numUpdates")) {
		numUpdates = set.getOptionInteger("eda_search_numUpdates");
	    }
	    // Retention
	    if (set.isSet("eda_search_retention")) {
		retention = set.getOptionDouble("eda_search_retention");
	    }
	    // Alpha
	    if (set.isSet("eda_search_alpha")) {
		alpha = set.getOptionInteger("eda_search_alpha");
	    }
	    // Beta
	    if (set.isSet("eda_search_beta")) {
		beta = set.getOptionInteger("eda_search_beta");
	    }
	    // ExpertKnowledge
	    if (set.isSet("eda_search_expertKnowledge")) {
		final String expertFileName = set
			.getOption("eda_search_expertKnowledge")
			.getResultValue(0).toString();
		try {
		    final File ekFile = new File(expertFileName);
		    expertKnowledge = new ExpertKnowledge(ekFile,
			    data.getLabels());
		} catch (final IOException ex) {
		    errPrintStream
			    .println("Error: Unable to read specified ExpertKnowledge file: "
				    + expertFileName);
		    return STATUS.ILLEGAL_ARGUMENT;
		}
		if (set.isSet("eda_search_weightingMethod")) {
		    final String edaSearchWeightingMethodString = set
			    .getOption("eda_search_weightingMethod")
			    .getResultValue(0);
		    try {
			edaSearchWeightingMethod = Enum.valueOf(
				WeightScheme.class,
				edaSearchWeightingMethodString.toUpperCase());
			config.append(columns.format(Arrays
				.asList(new String[] {
					"eda_search_weightingMethod:",
					edaSearchWeightingMethod.toString() })) + '\n');
		    } catch (final IllegalArgumentException ex) {
			errPrintStream
				.println("Error: unknown eda_search_weightingMethod. Legal values: "
					+ getEnumNames(WeightScheme.values())
					+ ". Passed in value: "
					+ edaSearchWeightingMethodString);
			return STATUS.ILLEGAL_ARGUMENT;
		    }
		}
		if (set.isSet("eda_search_theta")) {
		    if (set.isSet("eda_search_percentMaxAttributeRange")) {
			errPrintStream
				.println("Error: Multiple search algorithms specified!");
			return STATUS.ILLEGAL_ARGUMENT;
		    }
		    theta = Double.parseDouble(set
			    .getOption("eda_search_theta").getResultValue(0));
		    scalingMethod = ScalingMethod.EXPONENTIAL;
		    scalingParameter = theta;
		} else {
		    if (set.isSet("eda_search_percentMaxAttributeRange")) {
			percentMaxAttributeRange = Double.parseDouble(set
				.getOption(
					"eda_search_percentMaxAttributeRange")
				.getResultValue(0));
		    }
		    if ((percentMaxAttributeRange < 0.0)
			    || (percentMaxAttributeRange > 100.0)) {
			errPrintStream
				.println("Error: eda_search_percentMaxAttributeRange must be from 0-100. You passed in: "
					+ percentMaxAttributeRange);
			return STATUS.ILLEGAL_ARGUMENT;
		    }
		    scalingParameter = percentMaxAttributeRange / 100.0;
		    scalingMethod = ScalingMethod.LINEAR;
		}
		expertKnowledgeLoaded = true;
	    } else {
		expertKnowledge = new ExpertKnowledge(data.getLabels());
		beta = 0;
		// scalingMethod = null; got Redundant assignment warning that
		// it is already null
		scalingParameter = Double.NaN;
		// weightScheme = null; got Redundant assignment warning that it
		// is already null
		if (set.isSet("eda_search_theta")) {
		    outPrintStream
			    .println("Warning: Scaling parameter 'eda_search_theta' was passed in when no expertKnowledge file loaded and therefore will not be used.");
		}
		if (set.isSet("eda_search_percentMaxAttributeRange")) {
		    outPrintStream
			    .println("Warning: Scaling parameters 'eda_search_percentMaxAttributeRange' was passed in when no expertKnowledge file loaded and therefore will not be used.");
		}
		if (set.isSet("eda_search_beta")) {
		    outPrintStream
			    .println("Warning: 'eda_search_beta' was passed in when no expertKnowledge file loaded and therefore will be ignored.");
		}
	    } // end if EDA but no expert knowledge file passed in
	    if (!minimalOutput) {
		// Report parameter upload to user
		config.append(columns.format(Arrays.asList(new String[] {
			"Wrapper:", "EDA (numAgents)" })) + '\n');
		config.append(columns.format(Arrays.asList(new String[] {
			"numAgents:", Integer.toString(numAgents) })) + '\n');
		config.append(columns.format(Arrays.asList(new String[] {
			"Wrapper:", "EDA (numUpdates)" })) + '\n');
		config.append(columns.format(Arrays.asList(new String[] {
			"numUpdates:", Integer.toString(numUpdates) })) + '\n');
		config.append(columns.format(Arrays.asList(new String[] {
			"Wrapper:", "EDA (retention)" })) + '\n');
		config.append(columns.format(Arrays.asList(new String[] {
			"retention:", Double.toString(retention) })) + '\n');
		config.append(columns.format(Arrays.asList(new String[] {
			"Wrapper:", "EDA (alpha)" })) + '\n');
		config.append(columns.format(Arrays.asList(new String[] {
			"alpha:", Integer.toString(alpha) })) + '\n');
		if (expertKnowledgeLoaded) {
		    config.append(columns.format(Arrays.asList(new String[] {
			    "Wrapper:", "EDA (beta)" })) + '\n');
		    config.append(columns.format(Arrays.asList(new String[] {
			    "beta:", Integer.toString(beta) })) + '\n');
		    config.append(columns.format(Arrays.asList(new String[] {
			    "Wrapper:", "EDA (expertKnowledge)" })) + '\n');
		    config.append(columns.format(Arrays.asList(new String[] {
			    "expertKnowledge:",
			    set.getOption("eda_search_expertKnowledge")
				    .getResultValue(0) })) + '\n');
		    if ((scalingMethod != null)
			    && scalingMethod.equals(ScalingMethod.LINEAR)) {
			config.append(columns.format(Arrays
				.asList(new String[] { "Wrapper:",
					"EDA (maxProb)" })) + '\n');
			config.append(columns.format(Arrays.asList(new String[] {
				"maxProb:",
				Double.toString(percentMaxAttributeRange) })) + '\n');
		    } else {
			config.append(columns.format(Arrays
				.asList(new String[] { "Wrapper:",
					"EDA (theta)" })) + '\n');
			config.append(columns.format(Arrays
				.asList(new String[] { "theta:",
					Double.toString(theta) })) + '\n');
		    }
		}
	    } // end if !minimalOutput
	} // end if EDA search
	    break;
	case EXHAUSTIVE:
	    // nothing special needed here
	    break;
	default:
	    throw new RuntimeException(
		    "Search parameter arguments not understood: "
			    + searchMethod);
	} // end switch
	if ((forced == null) && set.isSet("min")) {
	    minLevel = set.getOptionInteger("min");
	    if ((minLevel < 1) || (minLevel > (data.getCols() - 1))) {
		errPrintStream.println("Error: min must be > 0 and <= number "
			+ "of attributes in the data set.");
		return STATUS.ILLEGAL_ARGUMENT;
	    }
	}
	if ((forced == null) && set.isSet("max")) {
	    maxLevel = set.getOptionInteger("max");
	    if ((maxLevel < 1) || (maxLevel > (data.getCols() - 1))) {
		errPrintStream.println("Error: max must be > 0 and <= number "
			+ "of attributes in the data set.");
		return STATUS.ILLEGAL_ARGUMENT;
	    }
	}
	if (maxLevel < minLevel) {
	    errPrintStream.println("Error: max must be >= min.");
	    return STATUS.ILLEGAL_ARGUMENT;
	}
	config.append(columns.format(Arrays.asList(new String[] { "Min Attr:",
		Integer.toString(minLevel) })) + '\n');
	config.append(columns.format(Arrays.asList(new String[] { "Max Attr:",
		Integer.toString(maxLevel) })) + '\n');
	config.append(columns.format(Arrays.asList(new String[] { "Matched:",
		Boolean.toString(matchedPairsOrTriplets) })) + '\n');
	if (set.isSet("nolandscape")) {
	    computeAllModelsLandscape = false;
	} else {
	    computeAllModelsLandscape = true;
	}
	if (set.isSet("top_models_landscape_size")) {
	    try {
		topModelsLandscapeSize = set
			.getOptionInteger("top_models_landscape_size");
		if (topModelsLandscapeSize < 1) {
		    errPrintStream
			    .println("Error:top_models_landscape_size >= 1");
		    return STATUS.ILLEGAL_ARGUMENT;
		}
	    } catch (final NumberFormatException ex) {
		errPrintStream
			.println("Error: top_models_landscape_size accepts integer values only.");
		return STATUS.ILLEGAL_ARGUMENT;
	    }
	}
	config.append(columns.format(Arrays.asList(new String[] {
		"top_models_landscape_size:",
		String.valueOf(topModelsLandscapeSize) })) + '\n');
	// parallelization
	if (set.isSet("distributed_node_count")) {
	    distributedNodeCount = set
		    .getOptionInteger("distributed_node_count");
	    config.append(columns.format(Arrays.asList(new String[] {
		    "distributed_node_count:",
		    String.valueOf(distributedNodeCount) })) + '\n');
	}
	if (set.isSet("distributed_node_number")) {
	    distributedNodeNumber = set
		    .getOptionInteger("distributed_node_number");
	    config.append(columns.format(Arrays.asList(new String[] {
		    "distributed_node_number:",
		    String.valueOf(distributedNodeNumber) })) + '\n');
	}
	// argument checking for isPartOfDistributedProcessing
	if (isPartOfDistributedProcessing()) {
	    if ((distributedNodeNumber < 1)
		    || (distributedNodeNumber > distributedNodeCount)) {
		errPrintStream
			.println("Error: -distributed_node_number must be a positive integer between 1 and -distributed_node_count "
				+ distributedNodeCount + " inclusive");
		return STATUS.ILLEGAL_ARGUMENT;
	    }

	    if (cv > 1) {
		errPrintStream
			.println("Error: when doing distributed analysis, CV MUST BE ONE. After getting top 1000 models is a good time to do cross-validation");

		return STATUS.ILLEGAL_ARGUMENT;
	    }
	    // check that the number of nodes is not greater than the number of
	    // model combinations to be tested
	    final BigInteger levelCombinations = Utility.combinations(
		    data.getNumAttributes(), minLevel);
	    if (levelCombinations.compareTo(BigInteger
		    .valueOf(distributedNodeCount)) < 0) {
		errPrintStream
			.println("Error: -distributed_node_count must not be greater than the number of model combinations being tested. For level "
				+ minLevel
				+ " there are only "
				+ levelCombinations + " being tested");
		return STATUS.ILLEGAL_ARGUMENT;

	    }

	} // end isPartOfDistributedProcessing
	if (set.isSet("output_two_way_entropy")) {
	    final String entropyNetworkDataTypeString = set
		    .getOptionString("output_two_way_entropy");
	    try {
		outputTwoWayEntropy = Enum.valueOf(
			EntropyAnalysis.NetworkDataType.class,
			entropyNetworkDataTypeString.toUpperCase());
	    } catch (final IllegalArgumentException ex) {
		errPrintStream
			.println("Error: unknown output_two_way_entropy. Legal values: "
				+ getEnumNames(EntropyAnalysis.NetworkDataType
					.values())
				+ ". Passed in value: '"
				+ entropyNetworkDataTypeString + "'");
		return STATUS.ILLEGAL_ARGUMENT;
	    }
	}
	if (set.isSet("all_models_outfile")) {
	    final String landscapeOutFname = set
		    .getOption("all_models_outfile").getResultValue(0);
	    if (landscapeOutFname.length() > 0) {
		outputAllModels = true;
		allModelsWriter = new PrintWriter(landscapeOutFname);
		writeOutAllModelsHeader();
		config.append(columns.format(Arrays.asList(new String[] {
			"all_models_outfile:", landscapeOutFname })) + '\n');
	    }
	}
	if (set.isSet("adjust_for_covariate")) {
	    final String covariateAttributeName = set
		    .getOptionString("adjust_for_covariate");
	    try {
		data = data.adjustForCovariate(
			getRandomSeed("before call to adjustForCovariate"),
			covariateAttributeName);
		config.append(columns.format(Arrays.asList(new String[] {
			"Covariate adjustment:", covariateAttributeName })) + '\n');
	    } catch (final Exception ex) {
		outPrintStream.println("Covariate adjustment for attribute '"
			+ covariateAttributeName + "' in dataset '"
			+ dataFileName + "' caught an exception: "
			+ ex.toString());
	    }
	}
	if (matchedPairsOrTriplets && useExplicitTestOfInteraction) {
	    errPrintStream
		    .println("Error: permute_with_explicit_test_of_interaction is set to true when 'matched' analysis specified. An explicitTestOfInteraction cannot be done in conjunction with a matched analysis.");
	    return STATUS.ILLEGAL_ARGUMENT;
	}
	if (!minimalOutput) {
	    outPrintStream.println("=== Configuration ===");
	    outPrintStream.println("Command line arguments: "
		    + Arrays.toString(args));
	    outPrintStream.println(config.toString());
	}
	final OnEndLevel onEndLevel = new OnEndLevel(minLevel, maxLevel,
		callersOnEndLevel);
	final List<String> tableRowStrings = new ArrayList<String>(
		(maxLevel - minLevel) + 1);
	final Runnable onEndAnalysis = new OnEndAllLevels(dataFileName,
		tableData, minLevel, maxLevel, cv, minimalOutput, onEndLevel,
		tableRowStrings, callersOnEndAnalysis);
	if (permutations != 0) {
	    if ((searchMethod == SearchMethod.EXHAUSTIVE)
		    || (searchMethod == SearchMethod.FORCED)) {
		final MDRExecutor executor = new MDRExecutor(data);
		executor.setCv(cv)
			.setMinLevel(minLevel)
			.setMaxLevel(maxLevel)
			.setSeed(
				getRandomSeed("runAnalysis setting seed in MDRExecutor"))
			.setForcedSearchAttributes(forced)
			.setAmbiguousCellStatus(ambiguousCellStatus)
			.setParallel(parallel);

		MDRResult originalResult = null;
		final boolean doUnpermutedAnalysisForFirstPermutationResult = permutationStartIndex == Dataset.PermutationSupport.PERMUTATION_DEFAULT_START_INDEX;
		if (doUnpermutedAnalysisForFirstPermutationResult) {
		    executor.runInCurrentThread();
		    originalResult = executor.getResult();
		}
		final PermutationResults permutationResults = executor
			.enterPermutationMode(acrossLevelsFitnessCriteriaOrder,
				originalResult, 0 /* permutationRandomSeed */,
				useExplicitTestOfInteraction,
				permutationStartIndex);
		for (int permutationCtr = 0; permutationCtr < permutations; ++permutationCtr) {
		    executor.permuteDataset();
		    executor.runInCurrentThread();
		}
		permutationResults.printReport(outPrintStream);
		return STATUS.FINISHED_PERMUTATIONS;
	    } else {
		errPrintStream
			.println("Permutation testing is not supported for this type of search: "
				+ searchMethod);
		return STATUS.ILLEGAL_ARGUMENT;

	    }
	} else {

	    analysis = createAnalysisThread(set, data, minLevel, maxLevel,
		    parallel, forced, evaluations, runtime, timeUnits,
		    numAgents, numUpdates, retention, alpha, beta,
		    scalingMethod, scalingParameter, edaSearchWeightingMethod,
		    expertKnowledge, searchMethod,
		    getRandomSeed("runAnalysis pass to createAnalysisThread"),
		    ambiguousCellStatus, callersOnEndModel, onEndLevel,
		    onEndAnalysis);
	    // use run() instead of start. This is so MDR is reasonably behaved
	    // when
	    // running in batch mode on supercomputer cluster
	    analysis.run();
	    if (tableData != null) {
		printTableDataHeader(tableData, data);
		outPrintStream.println();
	    } // end if tableData
	    for (final String rowString : tableRowStrings) {
		outPrintStream.println(rowString);
	    }
	    outPrintStream.println();
	    printAnalysisRunReport(data);
	    if (set.isSet("saveanalysis")) {
		try {
		    // each analysis overrides saveAnalysis to do the correct
		    // thing
		    final String analysisSavePath = set
			    .getOptionString("saveanalysis");
		    analysis.saveAnalysis(analysisSavePath);
		} catch (final IOException ex) {
		    errPrintStream
			    .println("Error: Unable to write to analysis file.");
		    return STATUS.ILLEGAL_ARGUMENT;
		}
	    } // end save analysis
	    if (outputTwoWayEntropy != null) {
		final EntropyAnalysis entropyAnalysis = new EntropyAnalysis();
		entropyAnalysis
			.set(data, outputTwoWayEntropy, ambiguousCellStatus,
				parallel, (ProgressPanelUpdater) null,
				true /* waitForCalculationToComplete */,
				true /* calculateAllEntropyMetrics */,
				(Integer) null /* topNVertices */);
		outPrintStream.println(entropyAnalysis.getEntropyText(
			Main.decimalUpToFourPrecision, true /* useTabs */));
	    } // end if output entropy
	} // end if not permutations
	return STATUS.FINISHED_ANALYSIS;
    }// end runAnalysis()

    /**
     * @return -1 if error, 0 if completed normally, 1 if gui should be run
     * @throws Exception
     */
    private STATUS runFilter(final String[] args, final OptionSet set)
	    throws Exception {
	final StringBuffer config = new StringBuffer();
	final ColumnFormat columns = new ColumnFormat(Arrays.asList(
		new Integer(20), new Integer(59)), true /* useTabs */);
	final String dataFileName = set.getData().get(0);
	AbstractAttributeScorer scorer = null;
	boolean ascending = false;
	int criterion = 0;
	double percentMaxAttributeRange = Main.defaultEDAPercentMaxAttributeRange;
	double theta = Main.defaultEDAExponentialTheta;
	Number critValue = new Integer(Main.defaultCriterionFilterTopN);
	config.append(columns.format(Arrays.asList(new String[] {
		"Input File:", set.getData().get(0) })) + '\n');

	// prepare output file if specified
	File output = null;
	if (set.getData().size() < 2) {
	    if (!minimalOutput) {
		outPrintStream
			.println("Warning: No output file was passed in so a filtered dataset will not be created.");
	    }
	} else {
	    final String outputFileName = set.getData().get(1);
	    output = new File(outputFileName);
	    if (!output.getAbsoluteFile().getParentFile().canWrite()
		    && !output.canWrite()) {
		errPrintStream.println("Error: Unable to open '"
			+ outputFileName + "' for writing.");
		return STATUS.ILLEGAL_ARGUMENT;
	    }
	    config.append("Output file:        " + outputFileName + '\n');
	}
	final String filter = set.getOptionString("filter");
	FilterMethod filterMethod = null;
	try {
	    filterMethod = Enum.valueOf(FilterMethod.class,
		    filter.toUpperCase());
	} catch (final IllegalArgumentException ex) {
	    errPrintStream.println("Error: unknown -filter. Legal values: "
		    + getEnumNames(FilterMethod.values())
		    + ". Passed in value: " + filter);
	    return STATUS.ILLEGAL_ARGUMENT;
	}
	if (filterMethod == FilterMethod.ATTRIBUTE_FILE) {
	    if (output == null) {
		errPrintStream
			.println("Error: -filter passed in value '"
				+ filter
				+ "' which but no output file was specified. This does not make sense since there are no sorted scores to display.");
		return STATUS.ILLEGAL_ARGUMENT;

	    }
	    final String filterFilePath = set.getOptionString("filter_file");
	    final boolean foundFilterFile = setAllowedAttributes(filterFilePath);
	    if (!foundFilterFile) {
		errPrintStream.println("Error: -filter_file passed in value '"
			+ filterFilePath
			+ "' is not a file containing attribute names.");
		return STATUS.ILLEGAL_ARGUMENT;
	    }

	}

	// now that allowed attributes may have been set, read in dataset
	openDataSet(dataFileName, false);

	if (set.isSet("minimal_output")) {
	    minimalOutput = Boolean.parseBoolean(set
		    .getOption("minimal_output").getResultValue(0));
	}
	// filter method == null if filtered by allowed attributes as file read
	// in
	if (filterMethod == FilterMethod.ATTRIBUTE_FILE) {
	    if (!minimalOutput) {
		outPrintStream.println("=== Configuration ===");
		outPrintStream.println("Command line arguments: "
			+ Arrays.toString(args));
		outPrintStream.println(config.toString());
	    }
	    PrintWriter printWriter = null;
	    try {
		printWriter = new PrintWriter(output);
		data.write(printWriter);
		outPrintStream.print("'");
		outPrintStream.print(output);
		outPrintStream.println("' successfully written.\n");
	    } catch (final IOException ex) {
		errPrintStream.println("Error: cannot write to output file.\n");
		return STATUS.ILLEGAL_ARGUMENT;
	    } finally {
		if (printWriter != null) {
		    printWriter.close();
		}
	    }
	    return STATUS.FINISHED_FILTER;
	} // end if used an attribute file to filter

	if (set.isSet("seed")) {
	    try {
		setRandomSeed(Long.parseLong(set.getOption("seed")
			.getResultValue(0)));
	    } catch (final NumberFormatException ex) {
		errPrintStream
			.println("Error: seed accepts integer values only.");
		return STATUS.ILLEGAL_ARGUMENT;
	    }
	}
	config.append(columns.format(Arrays.asList(new String[] {
		"Random Seed:", Long.toString(randomSeed) })) + '\n');
	if (set.isSet("select_")) {
	    final String sCriterion = set.getOption("select_").getResultDetail(
		    0);
	    final String sCritValue = set.getOptionString("select_");
	    if (sCriterion.equalsIgnoreCase("N")) {
		try {
		    critValue = Integer.valueOf(sCritValue);
		} catch (final NumberFormatException ex) {
		    errPrintStream
			    .println("Error: select_N accepts integer values "
				    + "only.");
		    return STATUS.ILLEGAL_ARGUMENT;
		}
		if ((critValue.intValue() <= 0)
			|| (critValue.intValue() > (data.getCols() - 1))) {
		    errPrintStream
			    .println("Error: N must be > 0 and <= number of "
				    + "attributes in the data set.");
		    return STATUS.ILLEGAL_ARGUMENT;
		}
		criterion = 0;
		config.append(columns.format(Arrays.asList(new String[] {
			"Selection:", "Top N (" + critValue.toString() + ')' })) + '\n');
	    } else if (sCriterion.equalsIgnoreCase("PCT")) {
		try {
		    critValue = Double.valueOf(sCritValue);
		} catch (final NumberFormatException ex) {
		    errPrintStream.println("Error: select_PCT accepts numeric "
			    + "values only.");
		    return STATUS.ILLEGAL_ARGUMENT;
		}
		if ((critValue.doubleValue() <= 0)
			|| (critValue.doubleValue() > 100)) {
		    errPrintStream.println("Error: PCT must be > 0 and <= 100");
		    return STATUS.ILLEGAL_ARGUMENT;
		}
		criterion = 1;
		config.append(columns.format(Arrays.asList(new String[] {
			"Selection:",
			"Top Percent (" + critValue.toString() + "%)" })) + '\n');
	    } else if (sCriterion.equalsIgnoreCase("THRESH")) {
		try {
		    critValue = Double.valueOf(sCritValue);
		} catch (final NumberFormatException ex) {
		    errPrintStream
			    .println("Error: select_THRESH accepts numeric "
				    + "values only.");
		    return STATUS.ILLEGAL_ARGUMENT;
		}
		criterion = 2;
		config.append(columns.format(Arrays.asList(new String[] {
			"Selection:",
			"Threshold (" + critValue.toString() + ")" })) + '\n');
	    } else {
		errPrintStream.println("Error: Invalid selection criterion: "
			+ sCriterion + "\n");
		return STATUS.ILLEGAL_ARGUMENT;
	    }
	} else {
	    config.append(columns.format(Arrays.asList(new String[] {
		    "Selection:", "Top N (" + critValue.toString() + ')' })) + '\n');
	}
	parallel = set.isSet("parallel");
	config.append("Parallel:           " + Boolean.toString(parallel)
		+ '\n');
	if (filter.equalsIgnoreCase("ChiSquared")) {
	    boolean pvalue = false;
	    if (set.isSet("chisq_pvalue")) {
		pvalue = true;
		ascending = true;
	    }
	    if (set.isSet("relieff_neighbors")
		    || set.isSet("relieff_samplesize")) {
		outPrintStream
			.println("Warning: ReliefF parameters ignored for ChiSquared filter.");
		outPrintStream.println();
	    }
	    if (set.isSet("turf_pct")) {
		outPrintStream
			.println("Warning: TuRF parameters ignored for ChiSquared filter.");
		outPrintStream.println();
	    }
	    scorer = new ChiSquaredScorer(data, pvalue, parallel);
	    config.append(columns.format(Arrays.asList(new String[] {
		    "Filter:", "\u03a7\u00b2" })) + '\n');
	    config.append(columns.format(Arrays.asList(new String[] {
		    "Use P-Value:", Boolean.toString(pvalue) })) + '\n');
	} else if (filter.equalsIgnoreCase("OddsRatio")) {
	    ascending = false;
	    if (set.isSet("relieff_neighbors")
		    || set.isSet("relieff_samplesize")) {
		outPrintStream
			.println("Warning: ReliefF parameters ignored for OddsRatio filter.");
		outPrintStream.println();
	    }
	    if (set.isSet("chisq_pvalue")) {
		outPrintStream
			.println("Warning: ChiSquared parameters ignored for OddsRatio filter.");
		outPrintStream.println();
	    }
	    if (set.isSet("turf_pct")) {
		outPrintStream
			.println("Warning: TuRF parameters ignored for OddsRatio filter.");
		outPrintStream.println();
	    }
	    scorer = new OddsRatioScorer(data, parallel);
	    config.append(columns.format(Arrays.asList(new String[] {
		    "Filter:", "OddsRatio" })) + '\n');
	} else {
	    int neighbors = Math.min(Main.defaultReliefFNeighbors,
		    data.getRows());
	    if (set.isSet("relieff_neighbors")) {
		neighbors = set.getOptionInteger("relieff_neighbors");
		if ((neighbors < 1) || (neighbors > data.getRows())) {
		    errPrintStream
			    .println("Error: relieff_neighbors must be > 0 and <= number of instances in the data set ");
		    return STATUS.ILLEGAL_ARGUMENT;
		}
	    }
	    int sampleSize = data.getRows();
	    if (set.isSet("relieff_samplesize")) {
		sampleSize = set.getOptionInteger("relieff_samplesize");
		if ((sampleSize < 1) || (sampleSize > data.getRows())) {
		    outPrintStream
			    .println("Warning: relieff_samplesize was not set in range of 1 to number of data rows and will be changed to be all rows ");
		    sampleSize = data.getRows();
		}
	    }
	    if (set.isSet("chisq_pvalue")) {
		outPrintStream
			.println("Warning: ChiSquared parameters ignored for "
				+ filter + " filter.");
		outPrintStream.println();
	    }
	    final Random filterRandomNumberGenerator = new Random(
		    getRandomSeed("filter"));
	    if (filter.toUpperCase().contains("TURF")) {
		float pct = Main.defaultTuRFPct / 100.0f;
		if (set.isSet("turf_pct")) {
		    pct = set.getOptionFloat("turf_pct");
		    if ((pct <= 0) || (pct > 1)) {
			errPrintStream
				.println("Error: turf_pct must be > 0 and <= 1.");
			return STATUS.ILLEGAL_ARGUMENT;
		    }
		}
		config.append(columns.format(Arrays.asList(new String[] {
			"Filter:", filter })) + '\n');
		config.append(columns.format(Arrays.asList(new String[] {
			"Pct:", Float.toString(pct) })) + '\n');
		if (filter.equalsIgnoreCase("TuRF")) {
		    config.append(columns.format(Arrays.asList(new String[] {
			    "Sample Size:", Integer.toString(sampleSize) })) + '\n');
		    config.append(columns.format(Arrays.asList(new String[] {
			    "Nearest Neighbors:", Integer.toString(neighbors) })) + '\n');
		    scorer = new TuRFAttributeScorer(data, sampleSize,
			    neighbors, pct, filterRandomNumberGenerator,
			    parallel);
		} else if (filter.equalsIgnoreCase("SURFnTuRF")) {
		    scorer = new SURFnTuRFAttributeScorer(data, pct,
			    filterRandomNumberGenerator, parallel);
		} else if (filter.equalsIgnoreCase("SURF*NTURF")
			|| filter.equalsIgnoreCase("SURFStarNTURF")) {
		    scorer = new SURFStarnTuRFAttributeScorer(data, pct,
			    filterRandomNumberGenerator, parallel);
		} else if (filter.equalsIgnoreCase("multiSURFnTURF")) {
		    scorer = new MultiSURFnTuRFAttributeScorer(data, pct,
			    filterRandomNumberGenerator, parallel);
		}
	    } else {
		if (set.isSet("turf_pct")) {
		    outPrintStream
			    .println("Warning: TuRF parameters ignored for"
				    + filter + " filter.");
		    outPrintStream.println();
		}
		if (filter.equalsIgnoreCase("ReliefF")) {
		    scorer = new ReliefFAttributeScorer(data, sampleSize,
			    neighbors, filterRandomNumberGenerator, parallel);
		    config.append(columns.format(Arrays.asList(new String[] {
			    "Filter:", "ReliefF" })) + '\n');
		    config.append(columns.format(Arrays.asList(new String[] {
			    "Nearest Neighbors:", Integer.toString(neighbors) })) + '\n');
		    config.append(columns.format(Arrays.asList(new String[] {
			    "Sample Size:", Integer.toString(sampleSize) })) + '\n');
		} else if (filter.equalsIgnoreCase("SURF")) {
		    scorer = new SURFAttributeScorer(data, sampleSize,
			    filterRandomNumberGenerator, parallel);
		    config.append(columns.format(Arrays.asList(new String[] {
			    "Filter:", "SURF" })) + '\n');
		    config.append(columns.format(Arrays.asList(new String[] {
			    "Sample Size:", Integer.toString(sampleSize) })) + '\n');
		} else if (filter.equalsIgnoreCase("SURF*")
			|| filter.equalsIgnoreCase("SURFStar")) {
		    scorer = new SURFStarAttributeScorer(data,
			    filterRandomNumberGenerator, parallel);
		    config.append(columns.format(Arrays.asList(new String[] {
			    "Filter:", "SURF*" })) + '\n');
		} else if (filter.equalsIgnoreCase("multiSURF")) {
		    scorer = new MultiSURFAttributeScorer(data,
			    filterRandomNumberGenerator, parallel);
		    config.append(columns.format(Arrays.asList(new String[] {
			    "Filter:", "multiSURF" })) + '\n');
		} else {
		    outPrintStream.println("Unknown filter type: " + filter
			    + "\n");
		    return STATUS.ILLEGAL_ARGUMENT;
		}
	    }
	} // end if a reliefF family filter
	if (Main.isExperimental) {
	    if (set.isSet("preserve_turf_removal_order")) {
		preserveTuRFRemovalOrder = set
			.getOptionBoolean("preserve_turf_removal_order");
		config.append(columns.format(Arrays.asList(new String[] {
			"Order by survival:",
			String.valueOf(preserveTuRFRemovalOrder) })) + '\n');
	    }
	    if (set.isSet("relieff_weighted_distance_iterations")) {
		try {
		    reliefFWeightedDistanceIterations = Integer.parseInt(set
			    .getOption("relieff_weighted_distance_iterations")
			    .getResultValue(0));
		    config.append(columns.format(Arrays.asList(new String[] {
			    "Iterations:",
			    String.valueOf(reliefFWeightedDistanceIterations) })) + '\n');
		} catch (final NumberFormatException ex) {
		    errPrintStream
			    .println("Error: relieff_weighted_distance_iterations accepts integer values only.");
		    return STATUS.ILLEGAL_ARGUMENT;
		}
	    }
	    if (reliefFWeightedDistanceIterations > 0) {
		if (set.isSet("relieff_weighted_distance_method")) {
		    final String reliefFWeightedDistanceString = set
			    .getOptionString("relieff_weighted_distance_method");
		    try {
			reliefFWeightedDistanceMethod = Enum.valueOf(
				WeightScheme.class,
				reliefFWeightedDistanceString.toUpperCase());
			config.append(columns.format(Arrays
				.asList(new String[] {
					"Weighting method:",
					reliefFWeightedDistanceMethod
						.toString() })) + '\n');
		    } catch (final IllegalArgumentException ex) {
			errPrintStream
				.println("Error: unknown relieff_weighted_distance_method. Legal values: "
					+ getEnumNames(WeightScheme.values())
					+ ". Passed in value: "
					+ reliefFWeightedDistanceString);
			return STATUS.ILLEGAL_ARGUMENT;
		    }
		} // end weighted distance method
		if (set.isSet("relieff_weighted_scaling_method")) {
		    final String reliefFWeightedScalingString = set
			    .getOptionString("relieff_weighted_scaling_method");
		    try {
			reliefFWeightedScalingMethod = Enum.valueOf(
				ScalingMethod.class,
				reliefFWeightedScalingString.toUpperCase());
			config.append(columns.format(Arrays
				.asList(new String[] { "Scaling method:",
					reliefFWeightedScalingMethod.toString() })) + '\n');
		    } catch (final IllegalArgumentException ex) {
			errPrintStream
				.println("Error: unknown relieff_weighted_scaling_method. Legal values: "
					+ getEnumNames(ScalingMethod.values())
					+ ". Passed in value: "
					+ reliefFWeightedScalingString);
			return STATUS.ILLEGAL_ARGUMENT;
		    }
		} // end weighted scaling method
		switch (reliefFWeightedScalingMethod) {
		case LINEAR:
		    if (set.isSet("relieff_weighted_scaling_linear_percentMaxAttributeRange")) {
			try {
			    percentMaxAttributeRange = Double
				    .parseDouble(set
					    .getOption(
						    "relieff_weighted_scaling_linear_percentMaxAttributeRange")
					    .getResultValue(0));
			} catch (final NumberFormatException ex) {
			    errPrintStream
				    .println("Error: relieff_weighted_scaling_linear_percentMaxAttributeRange accepts values from 0-100 only.");
			    return STATUS.ILLEGAL_ARGUMENT;
			}
			if ((percentMaxAttributeRange < 0.0)
				|| (percentMaxAttributeRange > 100.0)) {
			    errPrintStream
				    .println("Error: relieff_weighted_scaling_linear_percentMaxAttributeRange must be from 0-100. You passed in: "
					    + percentMaxAttributeRange);
			    return STATUS.ILLEGAL_ARGUMENT;
			}
		    }
		    reliefFWeightedScalingParameter = percentMaxAttributeRange / 100.0;
		    break;
		case EXPONENTIAL:
		    if (set.isSet("relieff_weighted_scaling_exponential_theta")) {
			final String optionString = set
				.getOptionString("relieff_weighted_scaling_exponential_theta");
			try {
			    theta = Double.parseDouble(optionString);
			    if ((theta < 0) || (theta > 1)) {
				errPrintStream
					.println("Error: relieff_weighted_scaling_exponential_theta must be >= 0 and <= 1. You passed in: "
						+ optionString);
				return STATUS.ILLEGAL_ARGUMENT;
			    }
			} catch (final NumberFormatException ex) {
			    errPrintStream
				    .println("Error: relieff_weighted_scaling_exponential_theta accepts double values only. You passed in: "
					    + optionString);
			    return STATUS.ILLEGAL_ARGUMENT;
			}
		    }
		    reliefFWeightedScalingParameter = theta;
		    break;
		default:
		    throw new IllegalArgumentException(
			    "Unhandled value for console.reliefFWeightedScalingMethod: "
				    + reliefFWeightedScalingMethod);
		    // break;
		} // end switch (console.reliefFWeightedScalingMethod)
	    } // end if # iterations > 0
	    if (set.isSet("relieff_rebalancing_method")) {
		final String reliefFRebalancingMethodString = set
			.getOptionString("relieff_rebalancing_method");
		try {
		    reliefFRebalancingMethod = Enum.valueOf(
			    ReliefFRebalancingMethod.class,
			    reliefFRebalancingMethodString.toUpperCase());
		} catch (final IllegalArgumentException ex) {
		    errPrintStream
			    .println("Error: unknown relieff_rebalancing_method. Legal values: "
				    + getEnumNames(ReliefFRebalancingMethod
					    .values())
				    + ". Passed in value: '"
				    + reliefFRebalancingMethodString + "'");
		    return STATUS.ILLEGAL_ARGUMENT;
		}
	    }
	} // end is experimental
	if (!minimalOutput) {
	    outPrintStream.println("=== Configuration ===");
	    outPrintStream.println("Command line arguments: "
		    + Arrays.toString(args));
	    outPrintStream.println(config.toString());
	}
	final AttributeRanker ranker = new AttributeRanker();
	AttributeCombination combo = null;
	ranker.setScorer(scorer);
	switch (criterion) {
	// top N
	case 0:
	    combo = ranker.selectN(critValue.intValue(), ascending);
	    break;
	// top %
	case 1:
	    combo = ranker
		    .selectPct(critValue.doubleValue() / 100.0, ascending);
	    break;
	// THRESH
	case 2:
	    combo = ranker.selectThreshold(critValue.doubleValue(), !ascending,
		    true);
	    break;
	default:
	    throw new RuntimeException(
		    "criterion is expected to be 0,1, or 2 but is: "
			    + criterion);
	    // break;
	}
	outPrintStream.println("=== Scores ===");
	int outputNumber = 0;
	final StringBuffer experimentalSummary = new StringBuffer();
	for (final Pair<Integer, Double> p : ranker.getSortedScores()) {
	    final String attributeName = data.getLabels().get(p.getFirst());
	    outPrintStream.print(attributeName);
	    outPrintStream.print("\t");
	    outPrintStream.print(p.getSecond());
	    outPrintStream.print("\t");
	    outPrintStream.println(++outputNumber);
	    if (Main.isExperimental
		    && (attributeName.equals("X0") || attributeName
			    .equals("X1"))) {
		experimentalSummary.append(attributeName + ": rank: "
			+ outputNumber + "\n");
	    }
	}
	if (Main.isExperimental && (experimentalSummary.length() > 0)) {
	    outPrintStream
		    .println("Experimental output for standard test files:\n"
			    + experimentalSummary.toString());
	}
	if (minimalOutput) {
	    if ((output != null) && (combo.size() > 0)) {
		PrintWriter printWriter = null;
		try {
		    setDataset(data.filter(combo.getAttributeIndices()),
			    DatasetStackAction.DO_NOTHING);
		    printWriter = new PrintWriter(output);
		    data.write(printWriter);
		} catch (final IOException ex) {
		    errPrintStream
			    .println("Error: cannot write to output file.\n");
		    return STATUS.ILLEGAL_ARGUMENT;
		} finally {
		    if (printWriter != null) {
			printWriter.close();
		    }
		}
	    }
	} else {
	    outPrintStream.println("\n=== Selected Attributes ===\n");
	    if (combo.size() == 0) {
		outPrintStream
			.println("No attributes selected. Output file not written.\n");
	    } else {
		outPrintStream.println(combo);
		outPrintStream.println();
		if (output != null) {
		    PrintWriter printWriter = null;
		    try {
			printWriter = new PrintWriter(output);
			data.filter(combo.getAttributeIndices()).write(
				printWriter);
		    } catch (final IOException ex) {
			errPrintStream
				.println("Error: cannot write to output file.\n");
			return STATUS.ILLEGAL_ARGUMENT;
		    } finally {
			if (printWriter != null) {
			    printWriter.close();
			}
		    }
		    outPrintStream.print("'");
		    outPrintStream.print(output);
		    outPrintStream.println("' successfully written.\n");
		}
	    }
	} // end if !minimal_output
	  // Write out scores in format suitable for use by CES as expert
	  // knowledge scores
	if (Main.isExperimental && (output != null)) {
	    FileWriter expertKnowledgeScoresFileWriter = null;

	    try {
		final File expertKnowledgeScoresFile = new File(filter
			+ "_scores_for_" + new File(dataFileName).getName());
		expertKnowledgeScoresFileWriter = new FileWriter(
			expertKnowledgeScoresFile);
		outPrintStream
			.println("Writing out CES expert knowledge file (scores in attribute order): "
				+ expertKnowledgeScoresFile.getCanonicalPath());
		for (final double score : ranker.getUnsortedScores()) {
		    expertKnowledgeScoresFileWriter.append(score + "\n");
		}
		expertKnowledgeScoresFileWriter.close();
	    } catch (final IOException ex) {
		ex.printStackTrace();
	    } finally {
		if (expertKnowledgeScoresFileWriter != null) {
		    expertKnowledgeScoresFileWriter.close();
		}
	    }
	} // end if isExperimental
	return STATUS.FINISHED_FILTER;
    }// end runFilter

    private boolean setAllowedAttributes(final String filterFilePath)
	    throws FileNotFoundException, IOException {
	if ((filterFilePath != null) && (filterFilePath.length() > 0)) {
	    final File allowedAttributesOnlyFile = new File(filterFilePath);
	    allowedAttributes = AttributeCombination
		    .readAttributeNamesFile(allowedAttributesOnlyFile);
	}
	return allowedAttributes != null;
    }

    public void setContinuousEndpointSignificanceMetric(
	    final ContinuousEndpointSignificanceMetric continuousEndpointSignificanceMetric) {
	this.continuousEndpointSignificanceMetric = continuousEndpointSignificanceMetric;
	setMetricDisplayText();
    }

    public void setDataset(final Dataset pData,
	    final DatasetStackAction datasetStackAction) {

	switch (datasetStackAction) {
	case CLEAR_STACK:
	    datasetAncestors.clear();
	    break;
	case DO_NOTHING:
	    break;
	case PUSH_ONTO_STACK:
	    if (datasetAncestors.contains(data)) {
		throw new RuntimeException(
			"Console.console.setDataset called with saveCurrentDataset true but current dataset already in the stack. Stack: "
				+ datasetAncestors.toString());
	    }
	    datasetAncestors.push(data);
	    break;
	default:
	    throw new RuntimeException(
		    "Console.console.setDataset called with unhandled DatasetStackAction: "
			    + datasetStackAction);
	} // end switch
	  // System.out.println(datasetStackAction + " changing dataset from "
	  // + String.valueOf(data) + " to "
	  // + ((data == pData) ? " itself " : pData));
	data = pData;
	if (data.hasContinuousEndpoints()) {
	    setContinuousEndpointSignificanceMetric(continuousEndpointSignificanceMetric);
	} else {
	    setDiscreteEndpointSignificanceMetric(discreteEndpointSignificanceMetric);
	}
    }

    public void setDiscreteEndpointSignificanceMetric(
	    final DiscreteEndpointSignificanceMetric discreteEndpointSignificanceMetric) {
	this.discreteEndpointSignificanceMetric = discreteEndpointSignificanceMetric;
	setMetricDisplayText();
    }

    public void setMetricDisplayText() {
	if (data.hasContinuousEndpoints()) {
	    metricShortText = continuousEndpointSignificanceMetric
		    .getShortText();
	    metricLongText = continuousEndpointSignificanceMetric.getLongText();
	} else {
	    metricShortText = discreteEndpointSignificanceMetric.getShortText();
	    metricLongText = discreteEndpointSignificanceMetric.getLongText();
	    if ((discreteEndpointSignificanceMetric == DiscreteEndpointSignificanceMetric.BALANCED_ACCURACY)
		    && (ambiguousCellStatus
			    .equals(AmbiguousCellStatus.UNCLASSIFIED))) {
		metricShortText = "adj. " + metricShortText;
		metricLongText = "adj. " + metricLongText;
	    }
	}
    }

    public void setParallel(final boolean shouldBeMultiThreaded) {
	parallel = shouldBeMultiThreaded;

    }

    public void setRandomSeed(final long newSeed) {
	randomSeed = newSeed;
    }

    public void setSearchMethod(final SearchMethod searchMethod) {
	this.searchMethod = searchMethod;
    }

    private void writeOutAllModelsHeader() {
	allModelsWriter.print(MdrTableColumnName.NUM_ATTRIBUTES + "\t");
	allModelsWriter.print(MdrTableColumnName.CVC + "\t");
	allModelsWriter.print(MdrTableColumnName.MODEL_ATTRIBUTES + "\t");
	allModelsWriter.print(MdrTableColumnName.MODEL_TRAINING + "\t");
	allModelsWriter.println();
    }

    public synchronized void writeOutAllModelsRow(
	    final AttributeCombination attributeCombo,
	    final int numCVIntervals, final float trainingBalancedAccuracy,
	    final float testingBalancedAccuracy) {
	allModelsWriter.print(attributeCombo.size() + "\t");
	allModelsWriter.print(numCVIntervals + "\t");
	allModelsWriter.print(attributeCombo.toString() + "\t");
	allModelsWriter.print(Main.decimalUpToFourPrecision
		.format(trainingBalancedAccuracy) + "\t");
	allModelsWriter.println();
    }

    private void writeOutTopModelsPredictionsHeader(final Dataset data,
	    final PrintWriter topModelsPredictionsWriter) {
	topModelsPredictionsWriter.print(MdrTableColumnName.MODEL_ATTRIBUTES
		+ "\t");
	for (int rowCtr = 1; rowCtr <= data.getRows(); ++rowCtr) {
	    if (rowCtr > 1) {
		topModelsPredictionsWriter.print("\t");
	    }
	    topModelsPredictionsWriter.print("sample_" + rowCtr);
	}
	topModelsPredictionsWriter.println();
    }

    private void writeOutTopModelsPredictionsRow(final Dataset data,
	    final PrintWriter topModelsPredictionsWriter, final String modelName) {
	final Model model = new Model(new AttributeCombination(modelName,
		data.getNumAttributes(), data.getLabels()), ambiguousCellStatus);
	final int statusColIndex = data.getStatusColIndex();
	final int[] attributeIndices = model.getCombo().getAttributeIndices();
	final SortedMap<byte[], Cell> cells = model.buildCounts(data);
	model.buildStatuses(data, data.getStatusCounts(), cells);
	topModelsPredictionsWriter.print(modelName);
	topModelsPredictionsWriter.print("\t");
	for (int rowIndex = 0; rowIndex < data.getRows(); ++rowIndex) {
	    if (rowIndex > 0) {
		topModelsPredictionsWriter.print("\t");
	    }
	    final byte status = data.getRawDatum(rowIndex, statusColIndex);
	    final byte[] rowSlice = data
		    .getRowSlice(rowIndex, attributeIndices);
	    final byte predictedStatus = model.getGenotypePredictedStatus(
		    cells, rowSlice);
	    topModelsPredictionsWriter.print((predictedStatus == status) ? '1'
		    : '0');
	} // end for
	topModelsPredictionsWriter.println();
    } // end outputTopModelsPredictionsRow,

    public enum DatasetStackAction {
	DO_NOTHING, PUSH_ONTO_STACK, CLEAR_STACK
    }

    private class OnEndAllLevels implements Runnable {
	private final boolean onEndAllLevelsMinimalOutput;
	private final String dataFileName;
	private final OnEndLevel onEndLevel;
	private final int minAttr;
	private final List<Pair<String, String>> tableData;
	private final int intervals;
	private final List<String> tableRowStrings;
	private final Runnable callersOnEndAnalysis;

	public OnEndAllLevels(final String dataFileName,
		final List<Pair<String, String>> tableData, final int minAttr,
		final int maxAttr, final int intervals,
		final boolean pMinimalOutput, final OnEndLevel onEndLevel,
		final List<String> tableRowStrings,
		final Runnable callersOnEndAnalysis) {
	    this.dataFileName = dataFileName;
	    this.tableData = tableData;
	    this.minAttr = minAttr;
	    this.intervals = intervals;
	    onEndAllLevelsMinimalOutput = pMinimalOutput;
	    this.onEndLevel = onEndLevel;
	    this.tableRowStrings = tableRowStrings;
	    this.callersOnEndAnalysis = callersOnEndAnalysis;
	} // end constructor

	@Override
	public void run() {
	    if (callersOnEndAnalysis != null) {
		callersOnEndAnalysis.run();
	    }
	    for (int collectorIndex = 0; collectorIndex < onEndLevel.levelsBestModelNames.length; ++collectorIndex) {
		final StringBuilder sb = new StringBuilder();
		final Collector coll = analysis.getCollectors().get(
			collectorIndex);
		final ModelInfoInterface bestModel = onEndLevel.levelsBestModels[collectorIndex];
		final int modelSize = minAttr + collectorIndex;
		if (bestModel == null) {
		    errPrintStream
			    .println("Error: for dataset '"
				    + dataFileName
				    + "' no attribute combination had good data when looking for "
				    + modelSize + "-way models.");
		} else {
		    final AttributeCombination bestModelAttributeCombination = bestModel
			    .getModel().getCombo();
		    if (tableData != null) {
			sb.append(dataFileName);
			sb.append("\t");
			sb.append(Console.getTableDataRowString(tableData));
			sb.append("" + data.getAffectedStatusCount() + '/'
				+ data.getUnaffectedStatusCount());
			sb.append("\t");
			sb.append(intervals);
			sb.append("\t");
			sb.append(bestModelAttributeCombination.size());
			sb.append("\t");
			sb.append(bestModelAttributeCombination);
			sb.append("\t");
			sb.append(bestModel.getCVC());
			sb.append("\t");
			sb.append(getConfusionMatrixInfoString(bestModel
				.getOverallConfusionMatrix()));
			sb.append(getConfusionMatrixInfoString(bestModel
				.getCVAverageTrainingConfusionMatrix()));
			sb.append(getConfusionMatrixInfoString(bestModel
				.getCVAggregateTestingConfusionMatrix()));
			sb.append(getConfusionMatrixInfoString(bestModel
				.getAverageTrainingConfusionMatrix()));
			sb.append(getConfusionMatrixInfoString(bestModel
				.getAggregateTestingConfusionMatrix()));
			// if (!data.hasContinuousEndpoints()) {
			// sb.append(Main.decimalFourPrecision
			// .format(onEndLevel.levelsLeaveOneOutCrossValidationTraining[collectorIndex]));
			// sb.append("\t");
			// sb.append(Main.decimalFourPrecision
			// .format(onEndLevel.levelsLeaveOneOutCrossValidationTesting[collectorIndex]));
			// sb.append("\t");
			// }
			tableRowStrings.add(sb.toString());

		    } else if (onEndAllLevelsMinimalOutput) {
			outPrintStream.println(coll.getBestModel()
				.getModelName());
		    } else {
			outPrintStream.println("### " + modelSize
				+ "-Attribute Results ###");
			outPrintStream.println("\n=== Best Model ===\n");
			outPrintStream.println(new BestModelTextGenerator(data,
				ambiguousCellStatus, coll.getBestModel(),
				intervals, Main.decimalUpToFourPrecision,
				Main.pValueTol, true /* verbose */));
			outPrintStream.println("=== If-Then Rules ===\n");
			outPrintStream.println(new IfThenRulesTextGenerator(
				data, coll.getBestModel()));
			if (intervals > 1) {
			    outPrintStream
				    .println("\n=== Cross-Validation Results ===\n");
			    outPrintStream.println(new CVResultsTextGenerator(
				    data, coll, ambiguousCellStatus, data
					    .getAffectedStatus(),
				    Main.decimalUpToFourPrecision,
				    Main.pValueTol, true /* verbose */));
			}
		    }
		    outPrintStream.flush();
		}
	    } // end collector loop
	} // end OnEndAllLevels.run()
    }

    private class OnEndLevel implements Runnable {
	private final ModelInfoInterface[] levelsBestModels;
	private final String[] levelsBestModelNames;
	private final int[] levelsCVCs;
	private final float[] levelsOverallAverages;
	private final float[] levelsCVIntervalsTrainAverages;
	private final float[] levelsCVIntervalsTestAverages;
	private final float[] levelsBestModelTrainAverages;
	private final float[] levelsBestModelTestAverages;
	// private final float[] levelsLeaveOneOutCrossValidationTraining;
	// private final float[] levelsLeaveOneOutCrossValidationTesting;
	// private final double[] attributeLevelsModelSignificance;
	private final int numCollectors;
	private int levelsFinishedCount = 0;
	private final Runnable callersOnEndLevel;

	public OnEndLevel(final int minAttr, final int maxAttr,
		final Runnable callersOnEndLevel) {
	    numCollectors = (maxAttr - minAttr) + 1;
	    levelsBestModels = new ModelInfoInterface[numCollectors];
	    levelsBestModelNames = new String[numCollectors];
	    levelsCVCs = new int[numCollectors];
	    levelsOverallAverages = new float[numCollectors];
	    levelsCVIntervalsTrainAverages = new float[numCollectors];
	    levelsCVIntervalsTestAverages = new float[numCollectors];
	    levelsBestModelTrainAverages = new float[numCollectors];
	    levelsBestModelTestAverages = new float[numCollectors];
	    // levelsLeaveOneOutCrossValidationTraining = new
	    // float[numCollectors];
	    // levelsLeaveOneOutCrossValidationTesting = new
	    // float[numCollectors];
	    // attributeLevelsModelSignificance = new double[numCollectors];
	    this.callersOnEndLevel = callersOnEndLevel;
	}

	@Override
	public void run() {
	    synchronized (this) {
		final int collectorIndex = analysis.getCollectors().size() - 1;
		if ((levelsFinishedCount % numCollectors) != collectorIndex) {
		    throw new RuntimeException(
			    "run method of OnEndLevel called more times than expected");
		}
		final Collector coll = analysis.getCollectors().get(
			collectorIndex);
		final ModelInfoInterface bestModel = levelsBestModels[collectorIndex] = coll
			.getBestModel();
		final AttributeCombination attributeCombination = bestModel
			.getModel().getCombo();
		if (permutations == 0) {
		    outPrintStream.println("Finished level "
			    + attributeCombination.size()
			    + " with best model: " + bestModel);
		}
		levelsBestModelNames[collectorIndex] = attributeCombination
			.toString();
		levelsOverallAverages[collectorIndex] = bestModel
			.getOverallConfusionMatrix().getFitness();
		levelsCVIntervalsTrainAverages[collectorIndex] = bestModel
			.getCVAverageTrainingConfusionMatrix().getFitness();
		// WARNING: bestModelTestingAverageConfusionMatrix could be null
		// if the best model is not in the top models
		final ConfusionMatrix bestModelTestingAverageConfusionMatrix = bestModel
			.getCVAggregateTestingConfusionMatrix();
		if (bestModelTestingAverageConfusionMatrix == null) {
		    levelsCVIntervalsTestAverages[collectorIndex] = Float.NaN;
		} else {
		    levelsCVIntervalsTestAverages[collectorIndex] = bestModelTestingAverageConfusionMatrix
			    .getFitness();
		}
		levelsCVCs[collectorIndex] = bestModel.getCVC();
		levelsBestModelTrainAverages[collectorIndex] = bestModel
			.getAverageTrainingFitness();
		levelsBestModelTestAverages[collectorIndex] = bestModel
			.getAggregateTestingFitness();
		// levelsLeaveOneOutCrossValidationTraining[collectorIndex] =
		// bestModel
		// .getLeaveOneOutCrossValidationTraining().getFitness();
		// levelsLeaveOneOutCrossValidationTesting[collectorIndex] =
		// bestModel
		// .getLeaveOneOutCrossValidationTesting().getFitness();
		++levelsFinishedCount;
	    } // end synchronized()
	    if (callersOnEndLevel != null) {
		callersOnEndLevel.run();
	    }
	} // end OnEndLevel.run()
    } // end OnEndLevel private class

    public enum ReliefFRebalancingMethod {
	DO_NOTHING, PROPORTIONAL_WEIGHTING, OVERSAMPLE_MINORITY, OVERSAMPLE_MINORITY_MULTIPLE_DATASETS
    }

    public enum STATUS {
	LOAD_ANALYSIS, FINISHED_ANALYSIS, FINISHED_FILTER, BATCH_WORK_ERROR, COMMAND_LINE_ERROR, ILLEGAL_ARGUMENT, CAUGHT_EXCEPTION, FINISHED_PERMUTATIONS, FINISHED_HELP, FINISHED_VERSION, NO_DATA_FILES_TO_ANALYZE;

	public boolean isAnErrorStatus() {
	    switch (this) {
	    case FINISHED_ANALYSIS:
	    case FINISHED_HELP:
	    case FINISHED_VERSION:
	    case FINISHED_PERMUTATIONS:
	    case FINISHED_FILTER:
	    case LOAD_ANALYSIS:
		return false;
	    case NO_DATA_FILES_TO_ANALYZE:
	    case BATCH_WORK_ERROR:
	    case CAUGHT_EXCEPTION:
	    case COMMAND_LINE_ERROR:
	    case ILLEGAL_ARGUMENT:
		return false;
	    default:
		throw new RuntimeException("UNHANDLED STATUS: " + this);

	    }
	}
    }

} // end class Console
