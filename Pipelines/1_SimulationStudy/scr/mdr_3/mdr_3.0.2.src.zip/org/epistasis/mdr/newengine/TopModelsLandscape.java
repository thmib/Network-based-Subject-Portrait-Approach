package org.epistasis.mdr.newengine;

import java.util.Iterator;

import org.epistasis.LabeledFloatInterface;
import org.epistasis.Utility;

public class TopModelsLandscape extends Landscape {
    private final Collector priorityListOfModels;

    public TopModelsLandscape(final Collector priorityListOfModels) {
	this.priorityListOfModels = priorityListOfModels;
    }

    @Override
    public LabeledFloatInterface first() {
	return priorityListOfModels.first();
    }

    @Override
    public LabeledFloatInterface get(final int requestedIndex) {
	// SLOW
	final Iterator<LabeledFloatInterface> iter = iterator();
	for (@SuppressWarnings("unused")
	final int currentIndex : Utility.range(requestedIndex)) {
	    iter.next();
	}
	return iter.next();
    }

    @Override
    public Iterator<LabeledFloatInterface> iterator() {
	return priorityListOfModels.getTopModelsLabeledFloatIterator();
    }

    @Override
    public LabeledFloatInterface last() {
	return priorityListOfModels.last();
    }

    @Override
    public int size() {
	return priorityListOfModels.size();
    }
}
