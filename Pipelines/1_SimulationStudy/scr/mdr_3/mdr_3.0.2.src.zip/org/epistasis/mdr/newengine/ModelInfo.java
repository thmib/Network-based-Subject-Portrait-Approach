package org.epistasis.mdr.newengine;

import java.io.Serializable;
import java.text.NumberFormat;

import org.epistasis.LabeledFloatInterface;
import org.epistasis.Utility;
import org.epistasis.mdr.Main;
import org.epistasis.mdr.enums.MdrTableColumnName;

public class ModelInfo implements ModelInfoInterface, LabeledFloatInterface,
	Serializable {

    private static final long serialVersionUID = 1L;
    private final Model model;
    private final ConfusionMatrix averageTrainingConfusionMatrix;
    private final ConfusionMatrix aggregateTestingConfusionMatrix;
    private final ConfusionMatrix cvAggregateTestingConfusionMatrix;
    private final ConfusionMatrix cvAverageTrainingConfusionMatrix;
    private final Integer numCrossValidations;
    private final Integer cvc;
    private final Float adjustedTesting;
    private final Float modelWinnersAggregateTestingFitness;
    private final ConfusionMatrix overallConfusionMatrix;
    private final float primaryFitnessValue;

    public static String[] asStringArray(
	    final ModelInfoInterface modelInfoInterface) {

	return ModelInfo.asStringArray(modelInfoInterface,
		Main.decimalUpToFourPrecision);
    }

    public static String[] asStringArray(
	    final ModelInfoInterface modelInfoInterface,
	    final NumberFormat numberFormatter) {
	String[] stringArray;
	if (modelInfoInterface.hasTesting()) {
	    stringArray = new String[] {
		    modelInfoInterface.getModelName(),
		    modelInfoInterface.getCVC() + "/"
			    + modelInfoInterface.getNumCrossValidations(),
		    numberFormatter.format(modelInfoInterface
			    .getCVAverageTrainingFitness()),
		    numberFormatter.format(modelInfoInterface
			    .getCVAggregateTestingFitness()),
		    numberFormatter.format(modelInfoInterface
			    .getAverageTrainingFitness()),
		    numberFormatter.format(modelInfoInterface
			    .getAggregateTestingFitness()),
		    numberFormatter.format(modelInfoInterface
			    .getOverallFitness()) };

	} else {
	    stringArray = new String[] {
		    String.valueOf(modelInfoInterface.getModelName()),
		    String.valueOf(modelInfoInterface.getOverallFitness()) };
	}
	return stringArray;
    }

    public static String[] getHeaders(
	    final ModelInfoInterface modelInfoInterface) {
	String[] stringArray;
	if (modelInfoInterface.hasTesting()) {
	    stringArray = new String[] {
		    MdrTableColumnName.MODEL_ATTRIBUTES.capitalized(),
		    MdrTableColumnName.CVC.capitalized(),
		    MdrTableColumnName.CV_TRAINING.capitalized(),
		    MdrTableColumnName.CV_TESTING.capitalized(),
		    MdrTableColumnName.MODEL_TRAINING.capitalized(),
		    MdrTableColumnName.MODEL_TESTING.capitalized(),
		    MdrTableColumnName.OVERALL_SCORE.capitalized() };

	} else {
	    stringArray = new String[] {
		    MdrTableColumnName.MODEL_ATTRIBUTES.capitalized(),
		    MdrTableColumnName.OVERALL_SCORE.capitalized() };
	}
	return stringArray;
    }

    public static String toTable(final ModelInfoInterface modelInfoInterface) {
	return Utility.join(ModelInfo.getHeaders(modelInfoInterface), '\t')
		+ '\n'
		+ Utility.join(ModelInfo.asStringArray(modelInfoInterface),
			'\t') + '\n';

    }

    public ModelInfo(final Model model, final float primaryFitnessValue,
	    final ConfusionMatrix overallConfusionMatrix,
	    final ConfusionMatrix averageTrainingConfusionMatrix,
	    final ConfusionMatrix aggregateTestingConfusionMatrix,
	    final ConfusionMatrix cvAverageTrainingConfusionMatrix,
	    final ConfusionMatrix cvAggregateTestingConfusionMatrix,
	    final Integer numCrossValidations, final Integer cvc,
	    final Float adjustedTesting,
	    final Float modelWinnersAggregateTestingFitness) {
	this.model = model;
	this.primaryFitnessValue = primaryFitnessValue;
	this.overallConfusionMatrix = overallConfusionMatrix;
	this.averageTrainingConfusionMatrix = averageTrainingConfusionMatrix;
	this.aggregateTestingConfusionMatrix = aggregateTestingConfusionMatrix;
	this.cvAverageTrainingConfusionMatrix = cvAverageTrainingConfusionMatrix;
	this.cvAggregateTestingConfusionMatrix = cvAggregateTestingConfusionMatrix;
	this.numCrossValidations = numCrossValidations;
	this.cvc = cvc;
	this.adjustedTesting = adjustedTesting;
	this.modelWinnersAggregateTestingFitness = modelWinnersAggregateTestingFitness;
    }

    public ModelInfo(final ModelInfoInterface modelInfoInterface) {
	model = modelInfoInterface.getModel();
	primaryFitnessValue = modelInfoInterface
		.getPrimaryFitnessCriterionValue();
	overallConfusionMatrix = modelInfoInterface.getOverallConfusionMatrix();
	averageTrainingConfusionMatrix = modelInfoInterface
		.getAverageTrainingConfusionMatrix();
	aggregateTestingConfusionMatrix = modelInfoInterface
		.getAggregateTestingConfusionMatrix();
	cvAverageTrainingConfusionMatrix = modelInfoInterface
		.getCVAverageTrainingConfusionMatrix();
	cvAggregateTestingConfusionMatrix = modelInfoInterface
		.getCVAggregateTestingConfusionMatrix();
	numCrossValidations = modelInfoInterface.getNumCrossValidations();
	cvc = modelInfoInterface.getCVC();
	adjustedTesting = modelInfoInterface.getAdjustedTesting();
	modelWinnersAggregateTestingFitness = modelInfoInterface
		.getModelWinnersAggregateTestingFitness();
    }

    @Override
    public String[] asStringArray() {
	return ModelInfo.asStringArray(this);
    }

    @Override
    public String[] asStringArray(final NumberFormat numberFormatter) {
	return ModelInfo.asStringArray(this, numberFormatter);
    }

    @Override
    public boolean equals(final Object obj) {
	return hashCode() == obj.hashCode();
    }

    @Override
    public float getAdjustedTesting() {
	return adjustedTesting;
    }

    @Override
    public ConfusionMatrix getAggregateTestingConfusionMatrix() {
	return aggregateTestingConfusionMatrix;
    }

    @Override
    public float getAggregateTestingFitness() {
	return aggregateTestingConfusionMatrix.getFitness();
    }

    @Override
    public ConfusionMatrix getAverageTrainingConfusionMatrix() {
	return averageTrainingConfusionMatrix;
    }

    @Override
    public float getAverageTrainingFitness() {
	return averageTrainingConfusionMatrix.getFitness();
    }

    ConfusionMatrix getCvAggregateTestingConfusionMatrix() {
	return cvAggregateTestingConfusionMatrix;
    }

    @Override
    public ConfusionMatrix getCVAggregateTestingConfusionMatrix() {
	return cvAggregateTestingConfusionMatrix;
    }

    @Override
    public float getCVAggregateTestingFitness() {
	return cvAggregateTestingConfusionMatrix.getFitness();
    }

    ConfusionMatrix getCvAverageTrainingConfusionMatrix() {
	return cvAverageTrainingConfusionMatrix;
    }

    @Override
    public ConfusionMatrix getCVAverageTrainingConfusionMatrix() {
	return cvAverageTrainingConfusionMatrix;
    }

    @Override
    public float getCVAverageTrainingFitness() {
	return cvAverageTrainingConfusionMatrix.getFitness();
    }

    @Override
    public int getCVC() {
	return cvc;
    }

    @Override
    public float getFloat() {
	return primaryFitnessValue;
    }

    @Override
    public String[] getHeaders() {
	return ModelInfo.getHeaders(this);
    }

    @Override
    public String getLabel() {
	return getModelName();
    }

    @Override
    public Model getModel() {
	return model;
    }

    @Override
    public String getModelName() {
	return model.getModelName();
    }

    @Override
    public float getModelWinnersAggregateTestingFitness() {
	return modelWinnersAggregateTestingFitness;
    }

    @Override
    public int getNumCrossValidations() {
	return numCrossValidations;
    }

    @Override
    public ConfusionMatrix getOverallConfusionMatrix() {
	return overallConfusionMatrix;
    }

    @Override
    public float getOverallFitness() {
	return overallConfusionMatrix.getFitness();
    }

    @Override
    public float getPrimaryFitnessCriterionValue() {
	return primaryFitnessValue;
    }

    @Override
    public int hashCode() {
	return toString().hashCode();
    }

    @Override
    public boolean hasTesting() {
	return aggregateTestingConfusionMatrix != ConfusionMatrix.EMPTY;
    }

    @Override
    public int size() {
	return model.size();
    }

    @Override
    public String toString() {
	return ModelInfo.toTable(this);
    }
}