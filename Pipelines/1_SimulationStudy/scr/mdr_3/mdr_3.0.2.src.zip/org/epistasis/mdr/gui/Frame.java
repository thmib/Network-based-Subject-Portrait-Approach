package org.epistasis.mdr.gui;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GraphicsConfiguration;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.HeadlessException;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;

import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JEditorPane;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.filechooser.FileFilter;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

import org.epistasis.BareBonesBrowserLaunch;
import org.epistasis.FileSaver;
import org.epistasis.FileSaver.FileSuffixBeforeExtension;
import org.epistasis.IterableEnumeration;
import org.epistasis.LabeledFloat;
import org.epistasis.LabeledFloatInterface;
import org.epistasis.MemoryWarningSystem;
import org.epistasis.Pair;
import org.epistasis.TimerRunnableTask;
import org.epistasis.Utility;
import org.epistasis.gui.CenterFrame;
import org.epistasis.gui.ComponentEnabler;
import org.epistasis.gui.DatafileFrame;
import org.epistasis.gui.DatafilePanel;
import org.epistasis.gui.OrderedTabbedPane;
import org.epistasis.gui.ProgressPanel;
import org.epistasis.gui.ProgressPanelUpdater;
import org.epistasis.gui.ReadOnlyTableModel;
import org.epistasis.gui.SwingInvoker;
import org.epistasis.gui.TextComponentUpdaterThread;
import org.epistasis.gui.TitledPanel;
import org.epistasis.gui.WarningPanel;
import org.epistasis.mdr.AmbiguousCellStatus;
import org.epistasis.mdr.AnalysisFileManager;
import org.epistasis.mdr.AnalysisFileManager.EDAVariables;
import org.epistasis.mdr.BestModelTextGenerator;
import org.epistasis.mdr.CVResultsTextGenerator;
import org.epistasis.mdr.Console;
import org.epistasis.mdr.Console.DatasetStackAction;
import org.epistasis.mdr.ExpertKnowledge;
import org.epistasis.mdr.ExpertKnowledge.RWRuntime;
import org.epistasis.mdr.IfThenRulesTextGenerator;
import org.epistasis.mdr.MDRProperties;
import org.epistasis.mdr.Main;
import org.epistasis.mdr.analysis.AnalysisThread;
import org.epistasis.mdr.analysis.AnalysisThread.AnalysisThreadBuilder;
import org.epistasis.mdr.analysis.EDAAnalysisThread.EDAAnalysisThreadBuilder;
import org.epistasis.mdr.analysis.ExhaustiveAnalysisThread.ExhaustiveAnalysisThreadBuilder;
import org.epistasis.mdr.analysis.FixedRandomAnalysisThread.FixedRandomAnalysisThreadBuilder;
import org.epistasis.mdr.analysis.TimedRandomAnalysisThread.TimedRandomAnalysisThreadBuilder;
import org.epistasis.mdr.enums.ContinuousEndpointSignificanceMetric;
import org.epistasis.mdr.enums.DiscreteEndpointSignificanceMetric;
import org.epistasis.mdr.enums.FilterMethod;
import org.epistasis.mdr.enums.FitnessCriteriaOrder;
import org.epistasis.mdr.enums.MdrTableColumnName;
import org.epistasis.mdr.enums.ScalingMethod;
import org.epistasis.mdr.enums.SearchMethod;
import org.epistasis.mdr.enums.TimeUnits;
import org.epistasis.mdr.enums.WeightScheme;
import org.epistasis.mdr.filters.AbstractAttributeScorer;
import org.epistasis.mdr.filters.AttributeNameFileScorer;
import org.epistasis.mdr.filters.AttributeRankerThread;
import org.epistasis.mdr.filters.ChiSquaredScorer;
import org.epistasis.mdr.filters.MultiSURFAttributeScorer;
import org.epistasis.mdr.filters.MultiSURFnTuRFAttributeScorer;
import org.epistasis.mdr.filters.OddsRatioScorer;
import org.epistasis.mdr.filters.ReliefFAttributeScorer;
import org.epistasis.mdr.filters.SURFAttributeScorer;
import org.epistasis.mdr.filters.SURFStarAttributeScorer;
import org.epistasis.mdr.filters.SURFStarnTuRFAttributeScorer;
import org.epistasis.mdr.filters.SURFnTuRFAttributeScorer;
import org.epistasis.mdr.filters.TuRFAttributeScorer;
import org.epistasis.mdr.gui.landscape.LandscapePanel;
import org.epistasis.mdr.newengine.AttributeCombination;
import org.epistasis.mdr.newengine.AttributeCombinationWithWildcards;
import org.epistasis.mdr.newengine.Collector;
import org.epistasis.mdr.newengine.Dataset;
import org.epistasis.mdr.newengine.LabeledFloatListLandscape;
import org.epistasis.mdr.newengine.Model;
import org.epistasis.mdr.newengine.ModelInfoInterface;
import org.epistasis.mdr.newengine.TopModelsLandscape;

public class Frame extends CenterFrame {
    private static final int CV_RESULTS_TAB_SIZE = 30;
    private static final String CHOOSE_FILE_WITH_ATTRIBUTE_NAMES_TO_KEEP = "Choose file with attribute names to keep...";
    private static final String STARTING_ANALYSIS = "Starting...";
    private static final String RUN_ANALYSIS = "Run Analysis";
    private static final String STOP_ANALYSIS = "Stop Analysis";
    private static final String CV_CONSISTENCY = "CV Consistency";
    private File attributeNameFilterFile;
    private static final boolean debugRunStopAnalysis = false;
    public static JFileChooser fileChooser;

    /**
     * Runnable used to update the memory usage fields on the panel. A megabyte
     * is 1000 kilobytes
     */
    public final static int BytesPerMegabyte = 1000 * 1024;

    private static final long serialVersionUID = 1L;
    public static final Font font = new Font("Dialog", Font.PLAIN, 11);
    public static final Font fontBold = Frame.font.deriveFont(Font.BOLD);
    public static final Font fontFixed = new Font("Monospaced", Font.PLAIN, 12);
    private static final String STOPPING_ANALYSIS = "Stopping...";
    private static Frame frame;
    protected static boolean initializing = true;
    private final Runnable onEndAnalysis = new SwingInvoker(
	    new OnEndAnalysis(), false);
    private final Runnable onEndLevel = new SwingInvoker(new OnEndLevel(),
	    false);
    private final ChangeListener frameChangeListener = new ChangeListener() {
	@Override
	public void stateChanged(final ChangeEvent e) {
	    checkConfigDefaultsOnEvent(e);
	}
    };
    private final ItemListener frameItemListener = new ItemListener() {
	@Override
	public void itemStateChanged(final ItemEvent e) {
	    checkConfigDefaultsOnEvent(e);
	}
    };

    private AttributeRankerThread rankerThread;
    private final AttributeConstructionPanel pnlConstruct = new AttributeConstructionPanel();
    private final CovariateAdjustmentPanel pnlCovariateAdjustment = new CovariateAdjustmentPanel();
    private List<AttributeCombination> forced;
    private AnalysisThread analysis;
    private AnalysisFileManager afm;
    private List<Collector> loadedCollectors;
    private final DatafileFrame frmDatafile = new DatafileFrame(this);
    public final DatafileFrame frmExpertKnowledge = new DatafileFrame(this);
    private String datafileName = "";
    private ExpertKnowledge expertKnowledge = null;
    private final SpinnerNumberModel snmTopN = new SpinnerNumberModel(
	    new Integer(Main.defaultCriterionFilterTopN), new Integer(1), null,
	    new Integer(1));
    private final SpinnerNumberModel snmTopPct = new SpinnerNumberModel(
	    new Double(Main.defaultCriterionFilterTopPct), new Double(
		    Double.MIN_VALUE), new Double(100), new Double(5));
    private final SpinnerNumberModel snmThreshold = new SpinnerNumberModel(
	    new Double(Main.defaultCriterionFilterThreshold), null, null,
	    new Double(1));
    private Timer tmrProgress;
    JTabbedPane tpnAnalysis = new JTabbedPane();
    ProgressPanel prgProgress = new ProgressPanel();
    TitledPanel pnlSummaryTable = new TitledPanel(new BorderLayout());
    OrderedTabbedPane tpnResults = new OrderedTabbedPane();
    JPanel pnlBestModel = new JPanel(new BorderLayout());
    JPanel pnlCVResults = new JPanel(new BorderLayout());
    JPanel pnlAnalysis = new JPanel();
    JScrollPane scpMain = new JScrollPane();
    JPanel pnlMain = new JPanel();
    JPanel pnlBestModelButtons = new JPanel(new GridBagLayout());
    JScrollPane scpBestModel = new JScrollPane();
    JTextArea txaBestModel = new JTextArea();
    private JScrollPane scpAbout;
    private JEditorPane editorPaneAbout;
    private JPanel pnlAbout;
    JButton cmdBestModelSave = new JButton();
    private JComboBox cboBestModelMetric;
    final JCheckBox chkBestModelVerbose = new JCheckBox();
    final JCheckBox chkCVResultsVerbose = new JCheckBox();
    JPanel pnlCVResultsButtons = new JPanel(new GridBagLayout());
    JButton cmdCVResultsSave = new JButton();
    JScrollPane scpCVResults = new JScrollPane();
    JTextArea txaCVResults = new JTextArea();
    JScrollPane scpSummaryTable = new JScrollPane();
    JTable tblSummaryTable = new JTable();
    DefaultTableModel dtmSummaryTable = new ReadOnlyTableModel();
    DefaultTableCellRenderer dcrRightJustified = new DefaultTableCellRenderer();
    TableColumn tbcModel;
    TableColumn tbcTrainingValue;
    TableColumn tbcTestingValue;
    TableColumn tbcCVConsistency;
    TitledPanel pnlDatafileInformation = new TitledPanel(new GridBagLayout());
    JButton cmdRunAnalysis = new JButton();
    JButton cmdLoadAnalysis = new JButton();
    JButton cmdSaveAnalysis = new JButton();
    JLabel lblMaxMem = new JLabel();
    JLabel lblMaxMemLabel = new JLabel("Max Mem:");
    JLabel lblTotalMem = new JLabel();
    JLabel lblTotalMemLabel = new JLabel("Total Mem:");
    JLabel lblUsedMem = new JLabel();
    JLabel lblUsedMemLabel = new JLabel("Used Mem:");
    private final JPanel pnlTotalMem = new JPanel(new GridBagLayout());
    private final JPanel pnlMaxMem = new JPanel(new GridBagLayout());
    private final JPanel pnlUsedMem = new JPanel(new GridBagLayout());
    /** Thread used to continually update the memory usage fields. */
    final MemoryDisplay memDisp = new MemoryDisplay();
    JButton cmdLoadDatafile = new JButton();
    JButton cmdViewDatafile = new JButton();
    JButton cmdViewExpertKnowledge = new JButton();
    JPanel pnlDatafile = new JPanel(new GridBagLayout());
    JPanel pnlAttributes = new JPanel(new GridBagLayout());
    JPanel pnlInstances = new JPanel(new GridBagLayout());
    JLabel lblDatafileValue = new JLabel();
    JLabel lblDatafile = new JLabel();
    JLabel lblAttributesValue = new JLabel();
    JLabel lblAttributes = new JLabel();
    JLabel lblInstancesValue = new JLabel();
    JLabel lblInstances = new JLabel();
    JPanel pnlConfiguration = new JPanel();
    // Declaration of "Configuration" tab objects
    JPanel pnlSearchAlgorithm, pnlSearchOptions, pnlExhaustiveSearchOptions,
	    pnlForcedSearchOptions, pnlRandomSearchOptions,
	    pnlEDASearchOptions, pnlEDAUpdate, pnlEDAEKPanel, pnlEDAEKInfo,
	    pnlEDAEKConv;
    TitledPanel pnlAnalysisConfiguration, pnlSearchMethodConfiguration,
	    pnlEDAExpertKnowledge, pnlAmbiguousCellAnalysis;
    JLabel lblRandomSeed, lblAttributeCountRange, lblAttributeCountRangeColon,
	    lblCrossValidationCount, lblPairedAnalysis,
	    lblAmbiguousCellAssignment, lblTieCells,
	    lblComputeAllModelsLandscape, lblSearchType,
	    lblForcedAttributeCombination, lblUnits, lblNumUpdates,
	    lblNumAgents, lblExpertKnowledgeValue,
	    lblExpertKnowledgeFileLoaded, lblLinearMax, lblLinearMin,
	    lblExponentialTheta, lblRetention, lblAlpha, lblBeta;
    JSpinner spnRandomSeed, spnAttributeCountMin, spnAttributeCountMax,
	    spnCrossValidationCount, spnEvaluations, spnRuntime,
	    spnLinearMaxPercent, spnExponentialTheta, spnNumUpdates,
	    spnNumAgents, spnRetention, spnAlpha, spnBeta, spnFisherThreshold;
    final JCheckBox chkPairedAnalysis = new JCheckBox();
    JSpinner spnTopModels;
    final JCheckBox chkComputeAllModelsLandscape = new JCheckBox();
    JComboBox cboAmbiguousCellStatuses, cboSearchType, cboUnits;
    JTextField txtForcedAttributeCombination;
    ButtonGroup bgrExpertKnowledgeScalingMethod,
	    bgrExpertKnowledgeWeightingScheme, bgrAmbiguousCellCriteria;
    JRadioButton rdoEvaluations, rdoRuntime, rdoFitnessProportional,
	    rdoRankedSelection, rdoLinearKnowledge, rdoExponentialKnowledge,
	    rdoAmbiguousCellCriteriaTieCells,
	    rdoAmbiguousCellCriteriaFishersExact;
    JButton cmdDefaults, cmdLoadExpertKnowledge;
    /*
     * Map<String, Double> antCacheMap; public Vector<Pair< String, Float >>
     * bestAnts;
     */
    // End "Configuration" tab declarations
    TitledPanel pnlAnalysisControls = new TitledPanel(new GridBagLayout());
    WarningPanel pnlWarning = new WarningPanel();
    JPanel pnlRatio = new JPanel(new GridBagLayout());
    JLabel lblRatio = new JLabel();
    JLabel lblRatioValue = new JLabel();
    JPanel pnlFilter = new JPanel();
    JLabel lblFilter = new JLabel();
    JComboBox cboFilter = new JComboBox(FilterMethod.values());
    JLabel lblCriterion = new JLabel();
    JComboBox cboFilterCriterion = new JComboBox();
    JLabel lblCriterionValue = new JLabel();
    JSpinner spnCriterionFilter = new JSpinner();
    TitledPanel pnlFilterOptions = new TitledPanel(new GridBagLayout());
    TitledPanel pnlFilterControls = new TitledPanel(new GridBagLayout());
    NetworkDisplay pnlNetworkAnalysis = new NetworkDisplay();
    JButton cmdDefaultFilter = new JButton();
    JButton cmdExportFiltered = new JButton();
    JButton cmdRevertFilter = new JButton();
    JButton cmdFilter = new JButton();
    CardLayout crdFilterOptions = new CardLayout();
    JPanel pnlReliefFOptions = new JPanel(new GridBagLayout());
    JLabel lblReliefFNeighbors = new JLabel();
    JSpinner spnReliefFNeighbors = new JSpinner();
    JLabel lblReliefFSampleSize = new JLabel();
    JSpinner spnReliefFSampleSize = new JSpinner();
    final JCheckBox chkReliefFWholeDataset = new JCheckBox();
    final JPanel pnlOddsRatioOptions = new JPanel(new GridBagLayout());
    JPanel pnlChiSquaredOptions = new JPanel(new GridBagLayout());
    final JCheckBox chkChiSquaredPValue = new JCheckBox();
    JPanel pnlTuRFOptions = new JPanel(new GridBagLayout());
    JLabel lblTuRFPercent = new JLabel();
    JSpinner spnTuRFPercent = new JSpinner();
    JLabel lblTuRFNeighbors = new JLabel();
    JSpinner spnTuRFNeighbors = new JSpinner();
    JLabel lblTuRFSampleSize = new JLabel();
    JSpinner spnTuRFSampleSize = new JSpinner();
    final JCheckBox chkTuRFWholeDataset = new JCheckBox();
    JPanel pnlSURFOptions = new JPanel(new GridBagLayout());
    JPanel pnlSURFStarOptions = new JPanel(new GridBagLayout());
    JPanel pnlSURFnTuRFOptions = new JPanel(new GridBagLayout());
    JLabel lblSURFnTuRFPercent = new JLabel();
    JSpinner spnSURFnTuRFPercent = new JSpinner();
    JPanel pnlMultiSURFOptions = new JPanel(new GridBagLayout());
    JPanel pnlMultiSURFnTuRFOptions = new JPanel(new GridBagLayout());
    JPanel pnlSURFStarnTuRFOptions = new JPanel(new GridBagLayout());

    JLabel lblSURFStarnTuRFPercent = new JLabel();
    JLabel lblMultiSURFnTuRFPercent = new JLabel();
    JSpinner spnSURFStarnTuRFPercent = new JSpinner();
    JSpinner spnMultiSURFnTuRFPercent = new JSpinner();
    GraphicalModelControls pnlGraphicalModel = new GraphicalModelControls();

    JPanel pnlIfThenRules = new JPanel(new BorderLayout());
    JPanel pnlIfThenRulesButtons = new JPanel(new GridBagLayout());
    JButton cmdIfThenRulesSave = new JButton();
    JScrollPane scpIfThenRules = new JScrollPane();
    JTextArea txaIfThenRules = new JTextArea();
    LandscapePanel pnlAllModelsLandscape = new LandscapePanel();
    LandscapePanel pnlTopModelsLandscape = new LandscapePanel();
    JTabbedPane tpnFilter = new JTabbedPane();
    JPanel pnlDatasetView = new JPanel(new BorderLayout());
    LandscapePanel pnlFilterLandscape = new LandscapePanel();
    DatafilePanel pnlDatafileTable = new DatafilePanel();
    JPanel pnlDatafileViewButtons = new JPanel(new GridBagLayout());
    JButton cmdRevert = new JButton(Main.REVERT_DATAFILE);
    JButton cmdExport = new JButton(Main.EXPORT_DATAFILE);
    ProgressPanel prgFilterProgress = new ProgressPanel();
    TitledPanel pnlFilterSelection = new TitledPanel(new GridBagLayout());
    JLabel lblDatafileLoaded = new JLabel();
    JLabel lblDatafileFiltered = new JLabel();
    ButtonGroup bgrRandomOptions = new ButtonGroup();
    CardLayout crdSearchOptions = new CardLayout();
    EntropyPanel pnlEntropy = new EntropyPanel();
    private JLabel lblTopModelsCriteria;
    private JLabel lblBestModelCriteria;
    private JLabel lblUseBestModelActualIntervals;
    private JCheckBox chkUseBestModelActualIntervals;
    private final ChangeListener filterChangeListener = new ChangeListener() {
	@Override
	public void stateChanged(final ChangeEvent e) {
	    cmdDefaultFilter.setEnabled(!isDefaultFilter());
	}
    };
    private final PropertyChangeListener filterPropertyChangeListener = new PropertyChangeListener() {
	@Override
	public void propertyChange(final PropertyChangeEvent evt) {
	    cmdDefaultFilter.setEnabled(!isDefaultFilter());
	}
    };
    private final JPanel panelTop = new JPanel();
    private final JLabel lblMdrIcon = new JLabel();
    private final Set<Component> discreteEndpointDependentPanels;
    private final Set<Component> dataDependentPanels;
    private final JPanel pnlAttributesFileFilter = new JPanel();
    private final JButton btnChooseAttributesFilterFile = new JButton(
	    Frame.CHOOSE_FILE_WITH_ATTRIBUTE_NAMES_TO_KEEP);
    private final JLabel lblAttributesFilterFile = new JLabel("");
    private final JPanel pnlSubsetCriterion = new JPanel();

    private final JPanel pnlFilterCombo = new JPanel();
    private JLabel lblBestModelMetric;
    private JComboBox cboBestModelCriterionOrder;
    private JComboBox cboTopModelsCriteria;
    private final JPanel pnlExperimental = new JPanel();
    private final JLabel lblLowMemory = new JLabel(
	    "LOW MEMORY! Please restart with more memory.");

    public static void cmdExportData() {
	final PrintWriter p = FileSaver.openFileWriter(Main.EXPORT_DATAFILE,
		FileSuffixBeforeExtension._MDR_data, FileSaver.filtersText);
	if (p != null) {
	    Console.console.data.write(p);
	    p.flush();
	    p.close();
	}
    }

    public static void cmdRevertData() {
	if (JOptionPane
		.showConfirmDialog(
			Frame.frame,
			"Really revert data set and undo filter or covariate adjustment? This will clear the current analysis pane.",
			Main.REVERT_DATAFILE, JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
	    Console.console.popDataset();
	    Frame.frame.dataFileChange();
	}
    }

    public static Frame getFrame() {
	return Frame.frame;
    }

    private static SwingInvoker indeterminateProgressUpdaterStart(
	    final ProgressPanel progressPanel, final String indeterminateMessage) {
	progressPanel.setIndeterminate(true);
	progressPanel.setString(indeterminateMessage);
	final SwingInvoker progressUpdater = new SwingInvoker(
		new ProgressPanelUpdater(progressPanel, Long.MAX_VALUE), false);
	return progressUpdater;
    }

    private static void indeterminateProgressUpdaterStop(
	    final ProgressPanel progressPanel) {
	progressPanel.setIndeterminate(false);
	progressPanel.setString(null);
    }

    public Frame(final GraphicsConfiguration gc, final String applicationTitle)
	    throws HeadlessException {
	super(gc);
	setIconImage(Toolkit.getDefaultToolkit().getImage(
		Frame.class.getResource("/images/mdrlogo.png")));
	setTitle(applicationTitle);
	discreteEndpointDependentPanels = new HashSet<Component>(
		Arrays.asList(pnlCovariateAdjustment));
	dataDependentPanels = new HashSet<Component>(Arrays.asList(
		pnlConfiguration, pnlNetworkAnalysis, pnlFilter, pnlConstruct,
		pnlCovariateAdjustment));
	Frame.frame = this;
	Console.console.setParallel(true);
	init();
	center(gc.getBounds());

	Frame.fileChooser = new JFileChooser(); // initialized here rather than
						// statically so that look and
						// feel has been set

	// if (Runtime.getRuntime().maxMemory() <
	// (Frame.RecommendedMinimumMemoryMegabytes * Frame.BytesPerMegabyte)) {
	// SwingUtilities.invokeLater(new Runnable() {
	// public void run() {
	// JOptionPane
	// .showMessageDialog(
	// Frame.this,
	// "Java was given less than "
	// + Frame.RecommendedMinimumMemoryMegabytes
	// + " meagabytes of memory which may make MDR fail.\n"
	// +
	// "We recommend starting java from the command line like this 'java -Xmx1000mb -jar MDR.jar'",
	// "Low memory", JOptionPane.WARNING_MESSAGE);
	// }
	// });
	// }
    }

    private void addTableRow(final ModelInfoInterface summary,
	    final int intervals) {
	final Vector<String> v = new Vector<String>(5);
	v.add(summary.getModelName());
	v.add(Main.decimalUpToFourPrecision.format(summary
		.getCVAverageTrainingConfusionMatrix().getFitness()));
	if (intervals > 1) {
	    v.add(Main.decimalUpToFourPrecision.format(summary
		    .getCVAggregateTestingConfusionMatrix().getFitness()));
	    v.add(Integer.toString(summary.getCVC()) + '/' + intervals);
	}
	dtmSummaryTable.addRow(v);
	if (tblSummaryTable.getSelectedRow() < 0) {
	    tblSummaryTable.getSelectionModel().setSelectionInterval(0, 0);
	}
    }

    public void checkConfigDefaultsOnEvent(final Object e) {
	cmdDefaults.setEnabled(!isDefaultConfig());
    }

    private void clearFilterTabs() {
	pnlFilterLandscape.setEnabled(false);
	pnlFilterLandscape.setLandscape(null);
    }

    private void clearTabs(final boolean modelBasedOnly) {
	cmdSaveAnalysis.setEnabled(false);
	txaBestModel.setText("");
	cmdBestModelSave.setEnabled(false);
	txaCVResults.setText("");
	cmdCVResultsSave.setEnabled(false);
	txaIfThenRules.setText("");
	cmdIfThenRulesSave.setEnabled(false);
	pnlGraphicalModel.setDatasetAndModel((Dataset) null, (Model) null);
	setModelDependentItemsEnabled(false);
	if (!modelBasedOnly) {
	    pnlWarning.clear();
	    pnlAllModelsLandscape.setEnabled(false);
	    pnlAllModelsLandscape.setLandscape(null);
	    pnlTopModelsLandscape.setEnabled(false);
	    pnlTopModelsLandscape.setLandscape(null);
	    pnlEntropy.pnlEntropy_clearTabs();
	}
    }

    private void cmdFilter() {
	if ((rankerThread != null) && rankerThread.isAlive()) {
	    rankerThread.interrupt();
	    return;
	}
	AbstractAttributeScorer scorer = null;
	boolean ascending = false;
	final Random filterRandomNumberGenerator = new Random(
		Console.console.getRandomSeed("Console.console.filter"));
	final FilterMethod filterMethod = (FilterMethod) cboFilter
		.getSelectedItem();
	switch (filterMethod) {
	// relief-f
	case RELIEFF: {
	    final int numSamples = chkReliefFWholeDataset.isSelected() ? Console.console.data
		    .getRows() : ((Number) spnReliefFSampleSize.getValue())
		    .intValue();
	    scorer = new ReliefFAttributeScorer(Console.console.data,
		    numSamples,
		    ((Number) spnReliefFNeighbors.getValue()).intValue(),
		    filterRandomNumberGenerator, Console.console.isParallel(),
		    new SwingInvoker(
			    new ProgressPanelUpdater(prgFilterProgress,
				    numSamples, true /* showElapsedTime */)));
	}
	    break;
	// turf
	case TURF: {
	    final int numSamples = chkTuRFWholeDataset.isSelected() ? Console.console.data
		    .getRows() : ((Number) spnTuRFSampleSize.getValue())
		    .intValue();
	    final float TuRFPercent = ((Number) spnTuRFPercent.getValue())
		    .intValue() / 100f;
	    final int sampleMultiplier = (int) Math.ceil(1 / TuRFPercent);
	    final int totalSamples = sampleMultiplier * numSamples;
	    scorer = new TuRFAttributeScorer(Console.console.data, numSamples,
		    ((Number) spnTuRFNeighbors.getValue()).intValue(),
		    ((Number) spnTuRFPercent.getValue()).intValue() / 100f,
		    filterRandomNumberGenerator, true, new SwingInvoker(
			    new ProgressPanelUpdater(prgFilterProgress,
				    totalSamples, true /* showElapsedTime */)));
	}
	    break;
	// chi-squared
	case CHISQUARED:
	    scorer = new ChiSquaredScorer(
		    Console.console.data,
		    chkChiSquaredPValue.isSelected(),
		    true,
		    new SwingInvoker(
			    new ProgressPanelUpdater(prgFilterProgress,
				    Console.console.data.getCols() - 1, true /* showElapsedTime */)));
	    ascending = chkChiSquaredPValue.isSelected();
	    break;
	// odds ratio
	case ODDSRATIO:
	    scorer = new OddsRatioScorer(
		    Console.console.data,
		    true,
		    new SwingInvoker(new ProgressPanelUpdater(
			    prgFilterProgress,
			    Console.console.data.getCols() - 1), true /* showElapsedTime */));
	    break;
	// SuRF
	case SURF: {
	    scorer = new SURFAttributeScorer(Console.console.data,
		    filterRandomNumberGenerator, Console.console.isParallel(),
		    new SwingInvoker(new ProgressPanelUpdater(
			    prgFilterProgress, Console.console.data.getRows(),
			    true /* showElapsedTime */)));
	    break;
	}
	// SuRFnTuRF
	case SURFNTURF: {
	    final int numSamples = Console.console.data.getRows();
	    final float SURFnTuRFPercent = ((Number) spnSURFnTuRFPercent
		    .getValue()).intValue() / 100f;
	    final int sampleMultiplier = (int) Math.ceil(1 / SURFnTuRFPercent);
	    final int totalSamples = sampleMultiplier * numSamples;
	    scorer = new SURFnTuRFAttributeScorer(
		    Console.console.data,
		    ((Number) spnSURFnTuRFPercent.getValue()).intValue() / 100f,
		    filterRandomNumberGenerator, true, new SwingInvoker(
			    new ProgressPanelUpdater(prgFilterProgress,
				    totalSamples, true /* showElapsedTime */)));
	    break;
	}
	// SURFStar
	case SURFSTAR: {
	    scorer = new SURFStarAttributeScorer(Console.console.data,
		    filterRandomNumberGenerator, Console.console.isParallel(),
		    new SwingInvoker(new ProgressPanelUpdater(
			    prgFilterProgress, Console.console.data.getRows(),
			    true /* showElapsedTime */)));
	    break;
	}
	// SuRF*nTuRF
	case SURFSTARNTURF: {
	    final int numSamples = Console.console.data.getRows();
	    final float SURFStarnTuRFPercent = ((Number) spnSURFStarnTuRFPercent
		    .getValue()).intValue() / 100f;
	    final int sampleMultiplier = (int) Math
		    .ceil(1 / SURFStarnTuRFPercent);
	    final int totalSamples = sampleMultiplier * numSamples;
	    scorer = new SURFStarnTuRFAttributeScorer(
		    Console.console.data,
		    ((Number) spnSURFStarnTuRFPercent.getValue()).intValue() / 100f,
		    filterRandomNumberGenerator, true, new SwingInvoker(
			    new ProgressPanelUpdater(prgFilterProgress,
				    totalSamples, true /* showElapsedTime */)));
	    break;
	}
	// MultiSURF
	case MULTISURF: {
	    scorer = new MultiSURFAttributeScorer(Console.console.data,
		    filterRandomNumberGenerator, Console.console.isParallel(),
		    new SwingInvoker(new ProgressPanelUpdater(
			    prgFilterProgress, Console.console.data.getRows())));
	    break;
	}
	// MultiSURFnTuRF
	case MULTISURFNTURF: {
	    final int numSamples = Console.console.data.getRows();
	    final float MultiSURFnTuRFPercent = ((Number) spnMultiSURFnTuRFPercent
		    .getValue()).intValue() / 100f;
	    final int sampleMultiplier = (int) Math
		    .ceil(1 / MultiSURFnTuRFPercent);
	    final int totalSamples = sampleMultiplier * numSamples;
	    scorer = new MultiSURFnTuRFAttributeScorer(
		    Console.console.data,
		    ((Number) spnMultiSURFnTuRFPercent.getValue()).intValue() / 100f,
		    filterRandomNumberGenerator, true, new SwingInvoker(
			    new ProgressPanelUpdater(prgFilterProgress,
				    totalSamples, true /* showElapsedTime */)));
	    break;
	}
	case ATTRIBUTE_FILE: {
	    if (attributeNameFilterFile == null) {
		JOptionPane
			.showMessageDialog(Frame.getFrame(),
				Frame.CHOOSE_FILE_WITH_ATTRIBUTE_NAMES_TO_KEEP,
				"No attribute file picked",
				JOptionPane.WARNING_MESSAGE);

	    } else {
		Frame.indeterminateProgressUpdaterStart(prgFilterProgress,
			"Filtering attributes based on: "
				+ attributeNameFilterFile.getName());
		scorer = new AttributeNameFileScorer(attributeNameFilterFile,
			Console.console.data);

	    }
	    break;
	}
	default:
	    throw new RuntimeException("Unhandled switch on FilterMethod: "
		    + filterMethod);
	}
	if (scorer != null) {
	    final Runnable tempOnEndRanking = new SwingInvoker(new OnFilterEnd(
		    ascending), false);
	    if (filterMethod == FilterMethod.ATTRIBUTE_FILE) {
		rankerThread = new AttributeRankerThread(scorer,
			AttributeNameFileScorer.KEEP_ATTRIBUTE_SCORE,
			!ascending, true, tempOnEndRanking);
	    } else {
		switch (cboFilterCriterion.getSelectedIndex()) {
		// Top N
		case 0:
		    rankerThread = new AttributeRankerThread(scorer, snmTopN
			    .getNumber().intValue(), ascending,
			    tempOnEndRanking);
		    break;
		// Top %
		case 1:
		    rankerThread = new AttributeRankerThread(scorer, snmTopPct
			    .getNumber().doubleValue() / 100.0, ascending,
			    tempOnEndRanking);
		    break;
		// Threshold
		case 2:
		    rankerThread = new AttributeRankerThread(scorer,
			    snmThreshold.getNumber().doubleValue(), !ascending,
			    true, tempOnEndRanking);
		    break;
		default:
		    throw new RuntimeException("Unhandled switch on: "
			    + cboFilterCriterion.getSelectedIndex());
		}
	    }
	    lockdown(true);
	    cmdFilter.setText("Stop");
	    cmdFilter.setForeground(Color.RED);
	    cmdFilter.setEnabled(true);
	    rankerThread.start();
	}
    }

    private void cmdLoadAnalysis() {
	final Pair<File, FileFilter> openFileWithExtension = FileSaver
		.getOpenFile("Load Analysis",
			FileSuffixBeforeExtension._analysis,
			FileSaver.filtersText);
	if (openFileWithExtension != null) {

	    loadAnalysis(Frame.fileChooser.getSelectedFile());
	} // if user chose file
    }

    private void cmdLoadDataset() {
	final Pair<File, FileFilter> openFileWithExtension = FileSaver
		.getOpenFile("Load Datafile", null, FileSaver.filtersText);
	if (openFileWithExtension != null) {
	    final Thread loadThread = new Thread(new Runnable() {
		@Override
		public void run() {
		    try {
			final String dataFileSimpleName = Frame.fileChooser
				.getSelectedFile().getName();
			final SwingInvoker progressUpdater = indeterminateProgressUpdaterStart("Loading datafileName: "
				+ dataFileSimpleName);
			lockdown(true);
			// create a blank placeholder dataset since code
			// doesn't deal well with no dataset
			Console.console.setDataset(
				Dataset.createPlaceholderDataset(),
				Console.DatasetStackAction.CLEAR_STACK);
			datafileName = "";
			loadedCollectors = null;
			dataFileChange();
			Console.console.data.setMatchedPairsOrTriplets(chkPairedAnalysis
				.isSelected());
			try {
			    Console.console.data.read(
				    new LineNumberReader(
					    new FileReader(Frame.fileChooser
						    .getSelectedFile())),
				    progressUpdater, (Set<Object>) null /* allowedAttributes */);
			} catch (final IOException ex) {
			    Utility.logException(ex);
			    JOptionPane
				    .showMessageDialog(
					    Frame.this,
					    "Unable to open datafile '"
						    + Frame.fileChooser
							    .getSelectedFile()
							    .toString()
						    + "' or unrecognized file format.\n\nMessage:\n"
						    + ex.getMessage(),
					    "Datafile Error",
					    JOptionPane.ERROR_MESSAGE);
			    return;
			}
			datafileName = Frame.fileChooser.getSelectedFile()
				.getAbsolutePath();
			loadedCollectors = null;
			dataFileChange();
		    } finally {
			indeterminateProgressUpdaterStop();
			lockdown(false);
		    }
		} // end run

	    }, "LoadDatasetThread");
	    loadThread.start();
	} // if user chose file
    } // end cmdLoadDataset

    private void cmdLoadScores() {
	final Pair<File, FileFilter> openFileWithExtension = FileSaver
		.getOpenFile("Load Scores", null, FileSaver.filtersText);
	if (openFileWithExtension != null) {
	    try {
		final ExpertKnowledge newExpertKnowledge = new ExpertKnowledge(
			Frame.fileChooser.getSelectedFile(),
			Console.console.data.getLabels());

		expertKnowledgeSetEnabled(Frame.fileChooser.getSelectedFile()
			.toString(), newExpertKnowledge);
		final List<String> nonMatchingExpertKnowledgeAttributes = expertKnowledge
			.getNonMatchingExpertKnowledgeAttributes();
		if (nonMatchingExpertKnowledgeAttributes.size() > 0) {
		    JOptionPane
			    .showMessageDialog(
				    Frame.this,
				    nonMatchingExpertKnowledgeAttributes.size()
					    + " attribute names from the expert knowledge file could not be matched to dataset attributes. Unmatched expert knowledge attributes: "
					    + nonMatchingExpertKnowledgeAttributes
						    .toString(),
				    "Unmatched Expert Knowledge scores",
				    JOptionPane.WARNING_MESSAGE);
		}
		final List<String> nonMatchingDatasetAttributes = expertKnowledge
			.getNonMatchingDatasetAttributes();
		if (nonMatchingDatasetAttributes.size() > 0) {
		    JOptionPane
			    .showMessageDialog(
				    Frame.this,
				    nonMatchingDatasetAttributes.size()
					    + " dataset attributes do not have an expert knowledge score provided. Unmatched expert knowledge attributes: "
					    + nonMatchingDatasetAttributes
						    .toString(),
				    "Missing Expert Knowledge scores for dataset file attributes",
				    JOptionPane.WARNING_MESSAGE);
		}
	    } catch (final Exception ex) {
		Utility.logException(ex);
		JOptionPane
			.showMessageDialog(
				Frame.this,
				"Unable to open file '"
					+ Frame.fileChooser.getSelectedFile()
						.toString()
					+ "' or unrecognized file format.\n\nMessage:\n"
					+ ex.getMessage(), "Datafile Error",
				JOptionPane.ERROR_MESSAGE);
	    }
	}
    }

    private void cmdRunAnalysis() {
	// if ((analysis == null) || !analysis.isAlive()) {
	final String currentCmdText = cmdRunAnalysis.getText();
	if (Frame.debugRunStopAnalysis) {
	    System.err.println("\ncmdRunAnalysis.getText()=" + currentCmdText);
	}
	try {
	    if (currentCmdText.equals(Frame.RUN_ANALYSIS)) {
		cmdRunAnalysis.setText(Frame.STARTING_ANALYSIS);
		if (Frame.debugRunStopAnalysis) {
		    System.err.println("cmdRunAnalysis.setText()="
			    + cmdRunAnalysis.getText());
		}
		cmdRunAnalysis.repaint();
		resetForm();
		loadedCollectors = null;
		final int intervals = ((Integer) spnCrossValidationCount
			.getValue()).intValue();
		final int min = ((Integer) spnAttributeCountMin.getValue())
			.intValue();
		final int max = ((Integer) spnAttributeCountMax.getValue())
			.intValue();
		final int topModelsLandscapeSize = ((Integer) spnTopModels
			.getValue()).intValue();
		final boolean computeAllModelsLandscape = chkComputeAllModelsLandscape
			.isSelected();

		final AmbiguousCellStatus ambiguousCellStatus = getAmbiguousStatusComboValue();
		Console.console.ambiguousCellStatus = ambiguousCellStatus;
		if (Main.isExperimental) {
		    final Object selectedItem = cboBestModelMetric
			    .getSelectedItem();
		    if (selectedItem instanceof ContinuousEndpointSignificanceMetric) {
			Console.console
				.setContinuousEndpointSignificanceMetric((ContinuousEndpointSignificanceMetric) selectedItem);
		    } else if (selectedItem instanceof DiscreteEndpointSignificanceMetric) {
			Console.console
				.setDiscreteEndpointSignificanceMetric((DiscreteEndpointSignificanceMetric) selectedItem);
		    } else {
			throw new RuntimeException(
				"Unexpected type of object in cboBestModelMetric: "
					+ selectedItem.toString());
		    }
		}
		setMetricUIItems();

		TimerTask task = null;
		Runnable onEndModel = null;
		final SearchMethod searchMethod = (SearchMethod) cboSearchType
			.getSelectedItem();

		AnalysisThreadBuilder<? extends AnalysisThread> builder = null;
		final long analysisSeed = Console.console
			.getRandomSeed("Frame analysis seed");
		switch (searchMethod) {
		case EXHAUSTIVE: {
		    final long count = Console.getNumberOfModelCombinations(
			    Console.console.data.getNumAttributes(), min, max)
			    .longValue();
		    onEndModel = new SwingInvoker(new ProgressPanelUpdater(
			    prgProgress, count, true /* showElapsedTime */),
			    false);
		    builder = new ExhaustiveAnalysisThreadBuilder(
			    Console.console.data, intervals, analysisSeed)
			    .setMinAttr(min).setMaxAttr(max);
		}
		    break;
		case FORCED: {
		    if ((forced == null) || (forced.size() == 0)) {
			JOptionPane
				.showMessageDialog(
					this,
					"Search type is forced but '"
						+ txtForcedAttributeCombination
							.getText()
						+ "' is not a list of attribute names or indices",
					"Forced Attributes Not Understood",
					JOptionPane.WARNING_MESSAGE);
			resetToReadyToRunAnalysis();
			return;
		    }
		    onEndModel = new SwingInvoker(new ProgressPanelUpdater(
			    prgProgress, 1), false);
		    // use a timer if there are wildcards
		    long count = 0;
		    for (final AttributeCombination attributeCombination : forced) {
			final int levelsBeyondForcedAttributes = attributeCombination
				.getMax() - attributeCombination.getMin();
			count += Math
				.max(1,
					Console.getNumberOfModelCombinations(
						Console.console.data
							.getNumAttributes(),
						levelsBeyondForcedAttributes,
						levelsBeyondForcedAttributes)
						.longValue());
		    }

		    onEndModel = new SwingInvoker(new ProgressPanelUpdater(
			    prgProgress, count, true /* showElapsedTime */),
			    false);
		    builder = new ExhaustiveAnalysisThreadBuilder(
			    Console.console.data, intervals, analysisSeed)
			    .setForced(forced);
		}
		    break;
		case RANDOM: {
		    if (rdoEvaluations.isSelected()) {
			onEndModel = new SwingInvoker(
				new ProgressPanelUpdater(
					prgProgress,
					((Number) spnEvaluations.getValue())
						.intValue() * ((max - min) + 1),
					true /* showElapsedTime */), false);
			builder = new FixedRandomAnalysisThreadBuilder(
				Console.console.data, intervals, analysisSeed)
				.setMaxAttr(max)
				.setMaxEval(
					((Number) spnEvaluations.getValue())
						.intValue()).setMinAttr(min);
		    } else {
			final TimeUnits timeUnit = (TimeUnits) cboUnits
				.getSelectedItem();
			final long seconds = timeUnit.getSeconds();
			final Double timeAmount = (Double) spnRuntime
				.getValue();
			final long totalSecondsToRunForAllLevels = (long) Math
				.ceil(timeAmount * seconds) * ((max - min) + 1);
			task = new TimerRunnableTask(
				new ProgressPanelUpdater(prgProgress,
					totalSecondsToRunForAllLevels,
					true /* showElapsedTime */, 0 /* refreshInterval */));
			builder = new TimedRandomAnalysisThreadBuilder(
				Console.console.data, intervals, analysisSeed)
				.setTimeUnits(timeUnit)
				.setTimeAmount(timeAmount).setMaxAttr(max)
				.setMinAttr(min);
		    }
		}
		    break;
		case EDA: {
		    final int numEntities = ((SpinnerNumberModel) spnNumAgents
			    .getModel()).getNumber().intValue();
		    final int numUpdates = ((SpinnerNumberModel) spnNumUpdates
			    .getModel()).getNumber().intValue();
		    onEndModel = new SwingInvoker(
			    new ProgressPanelUpdater(prgProgress, numEntities
				    * numUpdates * ((max - min) + 1), true /* showElapsedTime */),
			    false);
		    final RWRuntime currentRWRuntime = createExpertKnowledgeRuntime();
		    builder = new EDAAnalysisThreadBuilder(
			    Console.console.data, intervals, analysisSeed)
			    .setNumEntities(numEntities)
			    .setNumUpdates(numUpdates)
			    .setExpertKnowledgeRWRuntime(currentRWRuntime)
			    .setMinAttr(min).setMaxAttr(max);
		}
		    break;
		default:
		    throw new RuntimeException(
			    "Unhandled switch case on SearchMethod: "
				    + searchMethod);
		    // break;

		}

		if (builder == null) {
		    throw new IllegalArgumentException(
			    "Invalid search algorithm");
		}

		// Fill in builder
		builder.setTiePriorityList(ambiguousCellStatus)
			.setOnEndModel(onEndModel)
			.setOnEndLevel(onEndLevel)
			.setOnEndAnalysis(onEndAnalysis)
			.setParallel(Console.console.isParallel())
			.setComputeAllModelsLandscape(computeAllModelsLandscape)
			.setTopModelsLandscapeSize(topModelsLandscapeSize);
		// Build analysis thread
		analysis = builder.build();

		lockdown(true);
		cmdRunAnalysis.setText(Frame.STOP_ANALYSIS);
		if (Frame.debugRunStopAnalysis) {
		    System.err.println("cmdRunAnalysis.setText()="
			    + cmdRunAnalysis.getText());
		}
		cmdRunAnalysis.setForeground(Color.RED);
		cmdRunAnalysis.setEnabled(true);
		cmdRunAnalysis.repaint();
		final boolean displayTestingColumn = (intervals > 1);
		final boolean displayCvcColumn = displayTestingColumn;
		setTestingAndCvcColumnsDisplay(displayTestingColumn,
			displayCvcColumn);
		tpnResults.setOrderedTabVisible(pnlTopModelsLandscape,
			topModelsLandscapeSize > 0);
		tpnResults.setOrderedTabVisible(pnlAllModelsLandscape,
			computeAllModelsLandscape);
		afm = null;
		Console.console.setSearchMethod(searchMethod);
		analysis.start();
		if (task != null) {
		    tmrProgress = new Timer(true);
		    tmrProgress.schedule(task, 1000, 1000);
		}
	    } else if (currentCmdText.equals(Frame.STOP_ANALYSIS)) {
		cmdRunAnalysis.setText(Frame.STOPPING_ANALYSIS);
		cmdRunAnalysis.repaint();
		if (Frame.debugRunStopAnalysis) {
		    System.err.println("cmdRunAnalysis.setText()="
			    + cmdRunAnalysis.getText());
		}
		analysis.interrupt();
	    }
	} catch (final Throwable throwable) {
	    throwable.printStackTrace();
	    JOptionPane.showMessageDialog(this, "Unexpected problem: "
		    + throwable.toString(), "Caught Exception",
		    JOptionPane.ERROR_MESSAGE);
	    resetToReadyToRunAnalysis();
	}
    }

    private void cmdSaveAnalysis() {
	final PrintWriter out = FileSaver.openFileWriter("Save Analysis",
		FileSuffixBeforeExtension._analysis, FileSaver.filtersText);
	try {
	    if (out != null) {
		final AnalysisFileManager tempAfm = new AnalysisFileManager();
		if (Console.console.isDatasetStackEmpty()) {
		    // not filtered
		    tempAfm.setAnalysis(Console.console.data, datafileName,
			    analysis.getMinAttr(), analysis.getMaxAttr(),
			    analysis.getCollectors(),
			    analysis.getAllModelsLandscape(), forced,
			    analysis.getSeed(), analysis.getTiePriority());
		} else {
		    // filtered
		    tempAfm.setAnalysis(Console.console.peekAtLastDataset(),
			    Console.console.data, rankerThread, datafileName,
			    analysis.getMinAttr(), analysis.getMaxAttr(),
			    analysis.getCollectors(),
			    analysis.getAllModelsLandscape(), forced,
			    analysis.getSeed(), analysis.getTiePriority());
		}

		// each analysis overrides saveAnalysis to do the correct thing
		analysis.saveAnalysis(tempAfm);
		tempAfm.write(out);
		out.flush();
	    }
	} finally {
	    if (out != null) {
		out.close();
	    }
	}
    }

    private RWRuntime createExpertKnowledgeRuntime() {
	ExpertKnowledge tempExpertKnowledege;
	ScalingMethod scalingMethod;
	WeightScheme weightScheme;
	double scalingParameter;
	int betaConstant;
	if (expertKnowledge != null) {
	    tempExpertKnowledege = expertKnowledge;
	    scalingMethod = getScalingMethod();
	    weightScheme = getWeightScheme();
	    betaConstant = ((SpinnerNumberModel) spnBeta.getModel())
		    .getNumber().intValue();
	    scalingParameter = getScalingParameter(scalingMethod);
	} else {
	    tempExpertKnowledege = new ExpertKnowledge(
		    Console.console.data.getLabels());
	    scalingMethod = null;
	    scalingParameter = Double.NaN;
	    weightScheme = null;
	    betaConstant = 0;
	}
	final RWRuntime currentRWRuntime = tempExpertKnowledege.new RWRuntime(
		weightScheme, scalingMethod, scalingParameter,
		((SpinnerNumberModel) spnAlpha.getModel()).getNumber()
			.intValue(), betaConstant,
		((SpinnerNumberModel) spnRetention.getModel()).getNumber()
			.doubleValue());
	return currentRWRuntime;
    }

    private void dataFileChange() {
	if (frmDatafile.isShowing()) {
	    frmDatafile.readDatafile(Console.console.data);
	}
	if (frmExpertKnowledge.isShowing()) {
	    frmExpertKnowledge.dispose();
	}
	setMetricUIItems();
	if (Main.isExperimental) {
	    if (Console.console.data.hasContinuousEndpoints()) {
		cboBestModelMetric.setModel(new DefaultComboBoxModel(
			ContinuousEndpointSignificanceMetric.getMenuItems()));
		cboBestModelMetric.setSelectedItem(Console.console
			.getContinuousEndpointSignificanceMetric());
	    } else {
		cboBestModelMetric.setModel(new DefaultComboBoxModel(
			DiscreteEndpointSignificanceMetric.getMenuItems()));
		cboBestModelMetric.setSelectedItem(Console.console
			.getDiscreteEndpointSignificanceMetric());
	    }
	}
	txtForcedAttributeCombination.setText("");
	forced = null;
	final Integer numAttributes = Console.console.data.getNumAttributes();
	final Integer numInstances = Console.console.data.getRows();
	lblDatafileValue.setText(datafileName);
	expertKnowledgeSetEnabled("", null);
	lblDatafileFiltered.setText(Console.console.isDatasetStackEmpty() ? ""
		: " (modified)");
	lblDatafileLoaded.setText(loadedCollectors == null ? ""
		: " (Saved Analysis)");
	lblAttributesValue.setText(numAttributes.toString());
	lblInstancesValue.setText(numInstances.toString());
	resetForm();
	clearFilterTabs();
	cmdRevertFilter.setEnabled(Console.console.datasetCanBeReverted());
	cmdRevert.setEnabled(Console.console.datasetCanBeReverted());
	pnlCovariateAdjustment.getCmdRevert().setEnabled(
		Console.console.datasetCanBeReverted());
	for (final String warningMessage : Dataset
		.getDatasetLoadingWarningMessages()) {
	    warn(warningMessage);
	}
	if (numInstances > 0) {
	    if (((Integer) spnAttributeCountMin.getValue())
		    .compareTo(numAttributes) > 0) {
		spnAttributeCountMin.setValue(numAttributes);
		warn("Attribute Count Minimum set to " + numAttributes
			+ " to accomodate data set.");
	    }
	    ((SpinnerNumberModel) spnAttributeCountMin.getModel())
		    .setMaximum(numAttributes);
	    if (((Integer) spnAttributeCountMax.getValue())
		    .compareTo(numAttributes) > 0) {
		spnAttributeCountMax.setValue(numAttributes);
		warn("Attribute Count Maximum set to " + numAttributes
			+ " to accomodate data set.");
	    }
	    ((SpinnerNumberModel) spnAttributeCountMax.getModel())
		    .setMaximum(numAttributes);
	    pnlNetworkAnalysis.setDataDependentItems();
	    if (forced != null) {
		try {
		    parseForcedSearchAttributes(false /* showDialog */);
		} catch (final IllegalArgumentException ex) {
		    forced = null;
		}
	    }
	    if (Main.defaultForcedAttributeCombination != null) {
		Main.defaultForcedAttributeCombination
			.setLabels(Console.console.data.getLabels());
	    }
	    ((SpinnerNumberModel) spnCrossValidationCount.getModel())
		    .setMaximum(numInstances);
	    if (((Integer) spnCrossValidationCount.getValue())
		    .compareTo(numInstances) > 0) {
		spnCrossValidationCount.setValue(numInstances);
		warn("Cross-Validation Count set to " + numInstances
			+ " to accomodate dataset.");
	    }
	    if ((spnCriterionFilter.getModel() == snmTopN)
		    && (((Number) snmTopN.getValue()).intValue() > numAttributes
			    .intValue())) {
		warn("Filter Top N set to " + numAttributes
			+ " to accomodate dataset.");
	    }
	    if (((Number) snmTopN.getValue()).intValue() > numAttributes
		    .intValue()) {
		snmTopN.setValue(numAttributes);
	    }
	    snmTopN.setMaximum(numAttributes);
	    if (((Integer) spnReliefFSampleSize.getValue())
		    .compareTo(numInstances) > 0) {
		spnReliefFSampleSize.setValue(numInstances);
		warn("ReliefF Sample Size set to " + numInstances
			+ " to accomodate dataset.");
	    }
	    ((SpinnerNumberModel) spnReliefFSampleSize.getModel())
		    .setMaximum(numInstances);
	    int maximumNeighbors;
	    if (Console.console.data.hasContinuousEndpoints()) {
		// continuous data is dichotomized by above or below the median
		// so
		// the counts are always balanced as close as possible
		maximumNeighbors = (Console.console.data.getRows() + 1) / 2;
	    } else if (Console.console.reliefFRebalancingMethod == Console.ReliefFRebalancingMethod.OVERSAMPLE_MINORITY) {
		maximumNeighbors = Console.console.data
			.getMajorityStatusCount() - 1;
	    } else {
		maximumNeighbors = Console.console.data
			.getMinorityStatusCount() - 1;
	    }
	    if (((Integer) spnReliefFNeighbors.getValue())
		    .compareTo(maximumNeighbors) > 0) {
		spnReliefFNeighbors.setValue(maximumNeighbors);
		warn("ReliefF Neighbors set to " + maximumNeighbors
			+ " to accomodate data set.");
	    }
	    ((SpinnerNumberModel) spnReliefFNeighbors.getModel())
		    .setMaximum(maximumNeighbors);
	    if (((Integer) spnTuRFSampleSize.getValue())
		    .compareTo(numInstances) > 0) {
		spnTuRFSampleSize.setValue(numInstances);
		warn("TuRF Sample Size set to " + numInstances
			+ " to accomodate data set.");
	    }
	    ((SpinnerNumberModel) spnTuRFSampleSize.getModel())
		    .setMaximum(numInstances);
	    if (((Integer) spnTuRFNeighbors.getValue())
		    .compareTo(maximumNeighbors) > 0) {
		spnTuRFNeighbors.setValue(maximumNeighbors);
		warn("TuRF Neighbors set to " + maximumNeighbors
			+ " to accomodate data set.");
	    }
	    ((SpinnerNumberModel) spnTuRFNeighbors.getModel())
		    .setMaximum(maximumNeighbors);
	    chkPairedAnalysis.setEnabled(Console.console.data.canBePaired());
	    if (!Console.console.data.canBePaired()
		    && chkPairedAnalysis.isSelected()) {
		chkPairedAnalysis.setSelected(false);
		warn("Matched Analysis set to false"
			+ " to accomodate dataset.");
	    }
	    // pnlGraphicalModel.setData(Console.console.data);
	    if (Console.console.data.hasContinuousEndpoints()) {
		lblRatio.setText(Console.console.data.getStatusColumnName());
		if (numInstances > 0) {
		    lblRatioValue.setText("");
		}
		lblRatioValue.setText("min:"
			+ Main.decimalUpToFourPrecision
				.format(Console.console.data
					.getMinimumEndpoint())
			+ "/max:"
			+ Main.decimalUpToFourPrecision
				.format(Console.console.data
					.getMaximumEndpoint())
			+ "/avg:"
			+ Main.decimalUpToFourPrecision
				.format(Console.console.data
					.getAverageEndpoint()));
	    } else {
		lblRatio.setText(Console.console.data.getStatusColumnName()
			+ " ratio "
			+ Console.console.data.getAffectedValuesString() + "/"
			+ Console.console.data.getUnaffectedValuesString()
			+ ":");
		lblRatioValue
			.setText((numInstances > 0) ? Main.decimalUpToFourPrecision
				.format(Console.console.data.getRatio()) : "");
	    }
	}
	pnlGraphicalModel.setDatasetAndModel((Dataset) null, (Model) null);
	setModelDependentItemsEnabled(false);
	pnlGraphicalModel.setEnabled(false);
	pnlConstruct.setData(Console.console.data);
	pnlCovariateAdjustment.setData(Console.console.data);
	setEnabledDataDependentGuiItems(true);
	setTestingAndCvcColumnsDisplay(true /* displayTestingColumn */, true /* displayCvcColumn */);
    }

    /**
     * Overridden so that when the program is closed, all the threads and
     * windows close with it.
     */
    @Override
    public void dispose() {
	System.exit(0);
    }

    private void expertKnowledgeSetEnabled(
	    final String expertKnowledgeFileName,
	    final ExpertKnowledge pExpertKnowledge) {
	lblExpertKnowledgeValue.setText(expertKnowledgeFileName);
	expertKnowledge = pExpertKnowledge;
	final boolean hasExpertKnowledge = pExpertKnowledge != null;
	cmdViewExpertKnowledge.setEnabled(hasExpertKnowledge);
	for (final Component component : pnlEDAEKConv.getComponents()) {
	    component.setEnabled(hasExpertKnowledge);
	}
    } // end expertKnowledgeSetEnabled()

    public AmbiguousCellStatus getAmbiguousStatusComboValue() {
	return getAmbiguousStatusComboValue(cboAmbiguousCellStatuses
		.getSelectedIndex());
    }

    private AmbiguousCellStatus getAmbiguousStatusComboValue(final int index) {
	final AmbiguousCellDynamicString ambiguousCellDynamicString = (AmbiguousCellDynamicString) cboAmbiguousCellStatuses
		.getItemAt(index);
	return ambiguousCellDynamicString.ambiguousCellStatus;
    }

    public String getDatasetName() {
	String returnValue = "MDR dataset";
	if ((datafileName != null) && (datafileName.length() > 0)) {
	    final File dataFile = new File(datafileName);
	    returnValue = dataFile.getName();
	}
	return returnValue;
    }

    private ScalingMethod getScalingMethod() {
	ScalingMethod scalingMethod = null;
	for (final AbstractButton abstractButton : new IterableEnumeration<AbstractButton>(
		bgrExpertKnowledgeScalingMethod.getElements())) {
	    if (abstractButton.isSelected()) {
		scalingMethod = ScalingMethod.getScalingMethod(abstractButton
			.getText());
		break;
	    }
	}
	return scalingMethod;
    }

    private double getScalingParameter(final ScalingMethod scalingMethod) {
	double scalingParameter;
	switch (scalingMethod) {
	case EXPONENTIAL:
	    scalingParameter = ((SpinnerNumberModel) spnExponentialTheta
		    .getModel()).getNumber().doubleValue();
	    break;
	case LINEAR:
	    scalingParameter = ((SpinnerNumberModel) spnLinearMaxPercent
		    .getModel()).getNumber().intValue() / 100.0;
	    break;
	default:
	    throw new RuntimeException("unhandled scalingMethod: "
		    + scalingMethod);
	    // break;
	}
	return scalingParameter;
    }

    private WeightScheme getWeightScheme() {
	WeightScheme weightScheme = null;
	for (final AbstractButton abstractButton : new IterableEnumeration<AbstractButton>(
		bgrExpertKnowledgeWeightingScheme.getElements())) {
	    if (abstractButton.isSelected()) {
		weightScheme = WeightScheme.getWeightScheme(abstractButton
			.getText());
		break;
	    }
	}
	return weightScheme;
    }

    private SwingInvoker indeterminateProgressUpdaterStart(
	    final String indeterminateMessage) {
	return Frame.indeterminateProgressUpdaterStart(prgProgress,
		indeterminateMessage);
    }

    private void indeterminateProgressUpdaterStop() {
	Frame.indeterminateProgressUpdaterStop(prgProgress);
    }

    private void init() {
	jbInit();
	pack();
	Frame.initializing = false;
	Toolkit.getDefaultToolkit().setDynamicLayout(true);
	new Thread(new Runnable() {

	    @Override
	    public void run() {
		pnlNetworkAnalysis.reinitialize();

	    }
	}, "LoadNetworkComponents").start();
    }

    private boolean isDefaultConfig() {
	return isDefaultConfig(false);
    }

    private boolean isDefaultConfig(final boolean reset) {
	if (Console.console.getRandomSeed("Frame isDefaultConfig") != Main.defaultRandomSeed) {
	    if (reset) {
		spnRandomSeed.setValue(Main.defaultRandomSeed);
	    } else {
		return false;
	    }
	}
	if (!spnAttributeCountMin.getValue().equals(
		new Integer(Main.defaultAttributeCountMin))) {
	    if (reset) {
		spnAttributeCountMin.setValue(Main.defaultAttributeCountMin);
	    } else {
		return false;
	    }
	}
	if (!spnAttributeCountMax.getValue().equals(
		new Integer(Main.defaultAttributeCountMax))) {
	    if (reset) {
		spnAttributeCountMax.setValue(Main.defaultAttributeCountMax);
	    } else {
		return false;
	    }
	}
	if ((Main.defaultForcedAttributeCombination == null)
		&& (txtForcedAttributeCombination.getText().length() > 0)) {
	    if (reset) {
		txtForcedAttributeCombination.setText("");
	    } else {
		return false;
	    }
	}
	if (chkPairedAnalysis.isSelected() != Main.defaultPairedAnalysis) {
	    if (reset) {
		chkPairedAnalysis.setSelected(Main.defaultPairedAnalysis);
	    } else {
		return false;
	    }
	}
	if ((Integer) spnTopModels.getValue() != Main.defaultTopModelsLandscapeSize) {
	    if (reset) {
		spnTopModels.setValue(Main.defaultTopModelsLandscapeSize);
	    } else {
		return false;
	    }
	}
	if (chkComputeAllModelsLandscape.isSelected() != Main.defaultComputeAllModelsLandscape) {
	    if (reset) {
		chkComputeAllModelsLandscape
			.setSelected(Main.defaultComputeAllModelsLandscape);
	    } else {
		return false;
	    }
	}
	if (!rdoAmbiguousCellCriteriaTieCells.isSelected()) {
	    if (reset) {
		rdoAmbiguousCellCriteriaTieCells.setSelected(true);
	    } else {
		return false;
	    }
	}
	if (getAmbiguousStatusComboValue() != Main.defaultAmbiguousCellStatus) {
	    if (reset) {
		setComboAmbiguousStatus(Main.defaultAmbiguousCellStatus);
	    } else {
		return false;
	    }
	}
	if (cboSearchType.getSelectedItem() != Main.defaultSearchType) {
	    if (reset) {
		cboSearchType.setSelectedItem(Main.defaultSearchType);
	    } else {
		return false;
	    }
	}
	if (rdoEvaluations.isSelected() != Main.defaultIsRandomSearchEvaluations) {
	    if (reset) {
		rdoEvaluations
			.setSelected(Main.defaultIsRandomSearchEvaluations);
	    } else {
		return false;
	    }
	}
	if (rdoRuntime.isSelected() != Main.defaultIsRandomSearchRuntime) {
	    if (reset) {
		rdoRuntime.setSelected(Main.defaultIsRandomSearchRuntime);
	    } else {
		return false;
	    }
	}
	if (!spnEvaluations.getValue().equals(
		new Integer(Main.defaultRandomSearchEvaluations))) {
	    if (reset) {
		spnEvaluations.setValue(Main.defaultRandomSearchEvaluations);
	    } else {
		return false;
	    }
	}
	if (!spnRuntime.getValue().equals(
		new Double(Main.defaultRandomSearchRuntime))) {
	    if (reset) {
		spnRuntime.setValue(Main.defaultRandomSearchRuntime);
	    } else {
		return false;
	    }
	}
	if (cboUnits.getSelectedItem() != Main.defaultRandomSearchRuntimeUnits) {
	    if (reset) {
		cboUnits.setSelectedItem(Main.defaultRandomSearchRuntimeUnits);
	    } else {
		return false;
	    }
	}
	if (txtForcedAttributeCombination.getText().length() != 0) {
	    if (reset) {
		txtForcedAttributeCombination.setText("");
	    } else {
		return false;
	    }
	}
	if (!spnCrossValidationCount.getValue().equals(
		new Integer(Main.defaultCrossValidationCount))) {
	    if (reset) {
		spnCrossValidationCount
			.setValue(Main.defaultCrossValidationCount);
	    } else {
		return false;
	    }
	}
	if (reset) {
	    final boolean isDefault = isDefaultConfig();
	    if (!isDefault) {
		System.out.println("isDefaultConfig with reset=true failed!");
	    }
	    return isDefault;
	}
	return true;
    }

    private boolean isDefaultFilter() {
	return isDefaultFilter(false);
    }

    private boolean isDefaultFilter(final boolean reset) {
	if (cboFilter.getSelectedItem() != Main.defaultFilterMethod) {
	    if (reset) {
		cboFilter.setSelectedItem(Main.defaultFilterMethod);
	    } else {
		return false;
	    }
	}
	if (cboFilterCriterion.getSelectedIndex() != Main.defaultCriterionIndex) {
	    if (reset) {
		cboFilterCriterion.setSelectedIndex(Main.defaultCriterionIndex);
	    } else {
		return false;
	    }
	}
	if (spnCriterionFilter.getModel() != snmTopN) {
	    if (reset) {
		spnCriterionFilter.setModel(snmTopN);
	    } else {
		return false;
	    }
	}
	if (chkChiSquaredPValue.isSelected() != Main.defaultChiSquaredPValue) {
	    if (reset) {
		chkChiSquaredPValue.setSelected(Main.defaultChiSquaredPValue);
	    } else {
		return false;
	    }
	}
	if (((Number) snmTopN.getValue()).intValue() != Main.defaultCriterionFilterTopN) {
	    if (reset) {
		snmTopN.setValue(Main.defaultCriterionFilterTopN);
	    } else {
		return false;
	    }
	}
	if (((Number) snmTopPct.getValue()).doubleValue() != Main.defaultCriterionFilterTopPct) {
	    if (reset) {
		snmTopPct.setValue(Main.defaultCriterionFilterTopPct);
	    } else {
		return false;
	    }
	}
	if (((Number) snmThreshold.getValue()).doubleValue() != Main.defaultCriterionFilterThreshold) {
	    if (reset) {
		snmThreshold.setValue(Main.defaultCriterionFilterThreshold);
	    } else {
		return false;
	    }
	}
	if (chkReliefFWholeDataset.isSelected() != Main.defaultReliefFWholeDataset) {
	    if (reset) {
		chkReliefFWholeDataset
			.setSelected(Main.defaultReliefFWholeDataset);
	    } else {
		return false;
	    }
	}
	if (((Number) spnReliefFNeighbors.getValue()).intValue() != Main.defaultReliefFNeighbors) {
	    if (reset) {
		spnReliefFNeighbors.setValue(Main.defaultReliefFNeighbors);
	    } else {
		return false;
	    }
	}
	if (((Number) spnReliefFSampleSize.getValue()).intValue() != Main.defaultReliefFSampleSize) {
	    if (reset) {
		spnReliefFSampleSize.setValue(Main.defaultReliefFSampleSize);
	    } else {
		return false;
	    }
	}
	if (chkTuRFWholeDataset.isSelected() != Main.defaultReliefFWholeDataset) {
	    if (reset) {
		chkTuRFWholeDataset
			.setSelected(Main.defaultReliefFWholeDataset);
	    } else {
		return false;
	    }
	}
	if (((Number) spnTuRFNeighbors.getValue()).intValue() != Main.defaultReliefFNeighbors) {
	    if (reset) {
		spnTuRFNeighbors.setValue(Main.defaultReliefFNeighbors);
	    } else {
		return false;
	    }
	}
	if (((Number) spnTuRFSampleSize.getValue()).intValue() != Main.defaultReliefFSampleSize) {
	    if (reset) {
		spnTuRFSampleSize.setValue(Main.defaultReliefFSampleSize);
	    } else {
		return false;
	    }
	}
	if (((Number) spnTuRFPercent.getValue()).intValue() != Main.defaultTuRFPct) {
	    if (reset) {
		spnTuRFPercent.setValue(Main.defaultTuRFPct);
	    } else {
		return false;
	    }
	}
	if (((Number) spnSURFnTuRFPercent.getValue()).intValue() != Main.defaultTuRFPct) {
	    if (reset) {
		spnSURFnTuRFPercent.setValue(Main.defaultTuRFPct);
	    } else {
		return false;
	    }
	}
	if (((Number) spnSURFStarnTuRFPercent.getValue()).intValue() != Main.defaultTuRFPct) {
	    if (reset) {
		spnSURFStarnTuRFPercent.setValue(Main.defaultTuRFPct);
	    } else {
		return false;
	    }
	}
	if (((Number) spnMultiSURFnTuRFPercent.getValue()).intValue() != Main.defaultTuRFPct) {
	    if (reset) {
		spnMultiSURFnTuRFPercent.setValue(Main.defaultTuRFPct);
	    } else {
		return false;
	    }
	}
	if (reset) {
	    final boolean isDefault = isDefaultFilter();
	    if (!isDefault) {
		System.out.println("isDefaultFilter with reset=true failed!");
	    }
	    return isDefault;
	}
	return true;
    }

    @SuppressWarnings("serial")
    private void jbInit() {
	getContentPane().setLayout(new BorderLayout());
	setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
	this.setSize(new Dimension(700, 600));
	scpMain.setBorder(null);
	pnlConstruct.setBorder(null);
	pnlConstruct.addChangeListener(new ChangeListener() {
	    @Override
	    public void stateChanged(final ChangeEvent e) {
		dataFileChange();
	    }
	});
	pnlCovariateAdjustment.setBorder(null);
	pnlCovariateAdjustment.addChangeListener(new ChangeListener() {
	    @Override
	    public void stateChanged(final ChangeEvent e) {
		dataFileChange();
	    }
	});
	scpBestModel.setBorder(BorderFactory.createLoweredBevelBorder());
	txaBestModel.setEditable(false);
	txaBestModel.setTabSize(Frame.CV_RESULTS_TAB_SIZE);
	chkBestModelVerbose.setText("Verbose");

	final ActionListener verboseCheckboxActionListener = new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		// force a list selection change event so that BestModel and
		// CVResults are regenerated
		final ListSelectionModel listSelectionModel = tblSummaryTable
			.getSelectionModel();
		final int currentSelection = listSelectionModel
			.getAnchorSelectionIndex();
		listSelectionModel.setAnchorSelectionIndex(-1);
		listSelectionModel.setAnchorSelectionIndex(currentSelection);
	    }
	};
	chkBestModelVerbose.addActionListener(verboseCheckboxActionListener);
	chkCVResultsVerbose.addActionListener(verboseCheckboxActionListener);
	chkCVResultsVerbose.setText("Verbose");

	cmdBestModelSave.setEnabled(false);
	cmdBestModelSave.setText("Save");
	cmdBestModelSave.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		final Pair<File, FileFilter> ff = FileSaver.getSaveFile(
			"Save Best Model Output",
			FileSuffixBeforeExtension._model_details,
			FileSaver.filtersText);
		if (ff == null) {
		    return;
		}
		try {
		    FileSaver.saveText(txaBestModel.getText(), ff.getFirst());
		} catch (final IOException ex) {
		    Utility.logException(ex);
		    JOptionPane.showMessageDialog(Frame.this, ex.getMessage(),
			    "I/O Error", JOptionPane.ERROR_MESSAGE);
		}
	    }
	});

	cmdCVResultsSave.setEnabled(false);
	cmdCVResultsSave.setText("Save");
	cmdCVResultsSave.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		final Pair<File, FileFilter> ff = FileSaver.getSaveFile(
			"Save CV Results Output",
			FileSuffixBeforeExtension._cross_validation_details,
			FileSaver.filtersText);
		if (ff == null) {
		    return;
		}
		try {
		    FileSaver.saveText(txaCVResults.getText(), ff.getFirst());
		} catch (final IOException ex) {
		    Utility.logException(ex);
		    JOptionPane.showMessageDialog(Frame.this, ex.getMessage(),
			    "I/O Error", JOptionPane.ERROR_MESSAGE);
		}
	    }
	});

	scpCVResults.setBorder(BorderFactory.createLoweredBevelBorder());
	txaCVResults.setEditable(false);
	txaCVResults.setTabSize(Frame.CV_RESULTS_TAB_SIZE);

	/* Create Configuration Tab frame */
	/* Build AnalysisConfiguration subpanel */
	/* Random Seed Label and Spinner */
	/* Attribute Count Range Labels and Spinners */
	/* Cross-Validation Count Label and Spinner */
	/* Compute Landscape Label and CheckBox */
	/* Paired Analysis Label and CheckBox */
	/* Ambiguous cell analysis */
	bgrAmbiguousCellCriteria = new ButtonGroup();
	final ActionListener ambiguousCellCriteriaActionListener = new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		spnFisherThreshold.setEnabled(!rdoAmbiguousCellCriteriaTieCells
			.isSelected());
		if (spnFisherThreshold.isEnabled()) {
		    Console.fishersThreshold = ((Double) spnFisherThreshold
			    .getValue()).floatValue();
		} else {
		    Console.fishersThreshold = Main.defaultFishersThreshold;
		}
	    }
	};
	/* Add AnalysisConfiguration Panel to Configuration Tab */
	/* Create SearchMethodConfiguration subpanel frame */
	/* Build SearchAlgorithm subpanel */
	/* Search Type Label and ComboBox */
	/* Add SearchAlgorithm Panel to SearchMethodConfiguration Panel */
	/* Create SearchOptions Frame */
	/*
	 * Define Search Options 1) Exhaustive 2) Forced 3) Random 4) Estimation
	 * of Distribution Algorithm (EDA)
	 */
	/* ExhaustiveSearchOptions Panel */
	/* ForcedSearchOptions Panel */
	/* ForcedAttributeCombination Label and TextBox */
	/* RandomSearchOptions Panel */
	/* Evaluations RadioButton and Spinner */
	/* Runtime RadioButton and Spinner */
	/* Units Label and Combobox */
	/* EDASearchOptions Panel */
	/* Number of Agents */
	/* Number of Updates */
	/* Create Expert Knowledge Interpretation Titled Sub-panel */
	/* Expert Knowledge Upload */
	bgrExpertKnowledgeWeightingScheme = new ButtonGroup();
	bgrExpertKnowledgeScalingMethod = new ButtonGroup();
	/* Add SearchOptions to SearchMethodConfiguration Panel */
	/* Add SearchMethodConfiguration to Configuration Panel */
	/* Add Defaults Button to Configuration Panel */
	pnlAllModelsLandscape.setXAxisLabel("Models");
	pnlTopModelsLandscape.setXAxisLabel("Models");
	snmTopN.addChangeListener(filterChangeListener);
	snmTopPct.addChangeListener(filterChangeListener);
	snmThreshold.addChangeListener(filterChangeListener);
	dcrRightJustified.setHorizontalAlignment(SwingConstants.RIGHT);
	dtmSummaryTable.addColumn("Model");
	dtmSummaryTable
		.addColumn("Training " + Console.console.metricShortText);
	dtmSummaryTable.addColumn("Testing " + Console.console.metricShortText);
	dtmSummaryTable.addColumn(Frame.CV_CONSISTENCY);
	pnlWarning.setTitle("Warnings");

	pnlGraphicalModel.setEnabled(false);
	cmdIfThenRulesSave.setText("Save");
	cmdIfThenRulesSave.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		final Pair<File, FileFilter> ff = FileSaver.getSaveFile(
			"Save If-Then Rules Output",
			FileSuffixBeforeExtension._if_then_rules,
			FileSaver.filtersText);
		if (ff != null) {
		    try {
			FileSaver.saveText(txaIfThenRules.getText(),
				ff.getFirst());
		    } catch (final IOException ex) {
			Utility.logException(ex);
			JOptionPane.showMessageDialog(Frame.this,
				ex.getMessage(), "I/O Error",
				JOptionPane.ERROR_MESSAGE);
		    }
		}
	    }
	});
	scpIfThenRules.setBorder(BorderFactory.createLoweredBevelBorder());
	scpMain.setViewportView(pnlMain);

	pnlBestModel.add(pnlBestModelButtons, java.awt.BorderLayout.SOUTH);
	pnlBestModelButtons.add(cmdBestModelSave, new GridBagConstraints(0, 0,
		1, 1, 1.0, 0.0, GridBagConstraints.EAST,
		GridBagConstraints.NONE, new Insets(5, 5, 5, 5), 0, 0));
	pnlBestModelButtons.add(chkBestModelVerbose, new GridBagConstraints(0,
		0, 1, 1, 1.0, 0.0, GridBagConstraints.WEST,
		GridBagConstraints.NONE, new Insets(5, 5, 5, 5), 0, 0));
	pnlBestModel.add(scpBestModel, java.awt.BorderLayout.CENTER);
	scpBestModel.setViewportView(txaBestModel);
	getContentPane().add(scpMain, BorderLayout.CENTER);
	pnlCVResults.add(pnlCVResultsButtons, java.awt.BorderLayout.SOUTH);
	pnlCVResultsButtons.add(cmdCVResultsSave, new GridBagConstraints(0, 0,
		1, 1, 1.0, 0.0, GridBagConstraints.EAST,
		GridBagConstraints.NONE, new Insets(5, 5, 5, 5), 0, 0));
	pnlCVResultsButtons.add(chkCVResultsVerbose, new GridBagConstraints(0,
		0, 1, 1, 1.0, 0.0, GridBagConstraints.WEST,
		GridBagConstraints.NONE, new Insets(5, 5, 5, 5), 0, 0));
	pnlCVResults.add(scpCVResults, java.awt.BorderLayout.CENTER);
	scpCVResults.setViewportView(txaCVResults);

	pnlAllModelsLandscape.setTextFont(Frame.fontFixed);
	pnlAllModelsLandscape.setEnabled(false);

	pnlTopModelsLandscape.setTextFont(Frame.fontFixed);
	pnlTopModelsLandscape.setEnabled(false);
	pnlIfThenRules.add(pnlIfThenRulesButtons, java.awt.BorderLayout.SOUTH);
	pnlIfThenRulesButtons.add(cmdIfThenRulesSave, new GridBagConstraints(0,
		0, 1, 1, 1.0, 0.0, GridBagConstraints.EAST,
		GridBagConstraints.NONE, new Insets(5, 5, 5, 5), 0, 0));
	pnlIfThenRules.add(scpIfThenRules, java.awt.BorderLayout.CENTER);
	scpIfThenRules.setViewportView(txaIfThenRules);
	cmdIfThenRulesSave.setEnabled(false);
	cmdIfThenRulesSave.setText("Save");

	txaIfThenRules.setEditable(false);

	final GridBagLayout gbl_pnlMain = new GridBagLayout();
	gbl_pnlMain.columnWidths = new int[] { 698, 0 };
	gbl_pnlMain.rowHeights = new int[] { 598, 0 };
	gbl_pnlMain.columnWeights = new double[] { 1.0, Double.MIN_VALUE };
	gbl_pnlMain.rowWeights = new double[] { 1.0, Double.MIN_VALUE };
	pnlMain.setLayout(gbl_pnlMain);
	pnlMain.setBorder(null);
	pnlMain.setPreferredSize(new Dimension(getSize().width - 2,
		getSize().height - 2));
	pnlAbout = new JPanel(new BorderLayout());
	scpAbout = new JScrollPane();
	pnlAbout.add(scpAbout, BorderLayout.CENTER);
	editorPaneAbout = new JEditorPane();
	scpAbout.setViewportView(editorPaneAbout);
	editorPaneAbout.setEditable(false);
	editorPaneAbout.addHyperlinkListener(new HyperlinkListener() {
	    @Override
	    public void hyperlinkUpdate(final HyperlinkEvent evt) {
		if (evt.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
		    // try {
		    // jEditorPaneAbout.setPage(evt.getURL());
		    BareBonesBrowserLaunch.openURL(evt.getURL()
			    .toExternalForm());
		    // } catch (final Exception e) {
		    // }
		}
	    }
	});
	pnlConstruct.addChangeListener(new ChangeListener() {
	    @Override
	    public void stateChanged(final ChangeEvent e) {
		dataFileChange();
	    }
	});
	pnlConfiguration.setBorder(null);
	final ActionListener expertKnowledgeMappingActionListener = new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		refreshExpertKnowledgeFileDisplay();
	    }
	};
	final ChangeListener expertFileParameterChangeListener = new ChangeListener() {
	    @Override
	    public void stateChanged(final ChangeEvent e) {
		refreshExpertKnowledgeFileDisplay();
	    }
	};
	final GridBagLayout gbl_pnlConfiguration = new GridBagLayout();
	gbl_pnlConfiguration.columnWidths = new int[] { 683, 0 };
	gbl_pnlConfiguration.rowHeights = new int[] { 201, 317, 23, 0 };
	gbl_pnlConfiguration.columnWeights = new double[] { 1.0,
		Double.MIN_VALUE };
	gbl_pnlConfiguration.rowWeights = new double[] { 0.0, 0.0, 0.0,
		Double.MIN_VALUE };
	pnlConfiguration.setLayout(gbl_pnlConfiguration);
	cmdDefaults = new JButton("Defaults");
	cmdDefaults.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		setConfigToDefaults();
	    }
	});
	pnlSearchMethodConfiguration = new TitledPanel(new BorderLayout());
	pnlSearchMethodConfiguration.setTitle("Search Method Configuration");
	pnlSearchMethodConfiguration.setTitleFont(Frame.fontBold);
	pnlSearchAlgorithm = new JPanel(new GridBagLayout());
	lblSearchType = new JLabel("Search Type:");

	pnlSearchAlgorithm.add(lblSearchType, new GridBagConstraints(0, 0, 1,
		1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE,
		new Insets(0, 5, 5, 0), 0, 0));
	cboSearchType = new JComboBox(SearchMethod.values());

	cboSearchType.addItemListener(new ItemListener() {
	    @Override
	    public void itemStateChanged(final ItemEvent e) {
		final SearchMethod selected = (SearchMethod) cboSearchType
			.getSelectedItem();
		crdSearchOptions.show(pnlSearchOptions, selected.toString());
		final boolean isForcedSearch = selected == SearchMethod.FORCED;
		setEnabledAttributeRangeDependentGuiComponents(!isForcedSearch);

		parseForcedSearchAttributes(true /* showDialog */);
	    }
	});
	cboSearchType.addItemListener(frameItemListener);
	pnlSearchAlgorithm.add(cboSearchType, new GridBagConstraints(1, 0, 1,
		1, 1.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE,
		new Insets(0, 5, 5, 5), 0, 0));
	pnlSearchMethodConfiguration.add(pnlSearchAlgorithm,
		java.awt.BorderLayout.NORTH);
	pnlSearchOptions = new JPanel(crdSearchOptions);
	pnlExhaustiveSearchOptions = new JPanel(new GridBagLayout());
	pnlSearchOptions.add(pnlExhaustiveSearchOptions,
		SearchMethod.EXHAUSTIVE.toString());
	pnlForcedSearchOptions = new JPanel(new GridBagLayout());
	lblForcedAttributeCombination = new JLabel(
		"Forced Attribute Combination:");

	pnlForcedSearchOptions.add(lblForcedAttributeCombination,
		new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0,
			GridBagConstraints.NORTH, GridBagConstraints.NONE,
			new Insets(0, 5, 5, 0), 0, 0));
	txtForcedAttributeCombination = new JTextField();
	txtForcedAttributeCombination
		.setText(Main.defaultForcedAttributeCombination == null ? ""
			: Main.defaultForcedAttributeCombination.toString());
	txtForcedAttributeCombination.addFocusListener(new FocusAdapter() {
	    @Override
	    public void focusLost(final FocusEvent e) {
		final Component componentGainingFocus = e
			.getOppositeComponent();
		if ((componentGainingFocus == null)
			|| (componentGainingFocus == cmdDefaults)) {
		    forced = null;
		} else {
		    parseForcedSearchAttributes(true /* showDialog */);
		}
	    }
	});
	pnlForcedSearchOptions.add(txtForcedAttributeCombination,
		new GridBagConstraints(1, 0, 1, 1, 1.0, 1.0,
			GridBagConstraints.NORTH,
			GridBagConstraints.HORIZONTAL, new Insets(0, 5, 5, 5),
			0, 0));
	pnlSearchOptions.add(pnlForcedSearchOptions,
		SearchMethod.FORCED.toString());
	pnlRandomSearchOptions = new JPanel();
	final GridBagLayout gbl_pnlRandomSearchOptions = new GridBagLayout();
	gbl_pnlRandomSearchOptions.columnWidths = new int[] { 85, 60, 53, 65, 0 };
	gbl_pnlRandomSearchOptions.rowHeights = new int[] { 23, 23, 0 };
	gbl_pnlRandomSearchOptions.columnWeights = new double[] { 0.0, 0.0,
		0.0, 0.0, Double.MIN_VALUE };
	gbl_pnlRandomSearchOptions.rowWeights = new double[] { 0.0, 0.0,
		Double.MIN_VALUE };
	pnlRandomSearchOptions.setLayout(gbl_pnlRandomSearchOptions);
	spnEvaluations = new JSpinner(new SpinnerNumberModel(new Integer(
		Main.defaultRandomSearchEvaluations), new Integer(1),
		new Integer(10000000), new Integer(100)));
	spnEvaluations.setMinimumSize(new Dimension(60, 20));
	spnEvaluations.setPreferredSize(new Dimension(60, 20));
	spnEvaluations.addChangeListener(frameChangeListener);
	rdoEvaluations = new JRadioButton("Evaluations:", true);

	rdoEvaluations.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		final boolean enabled = rdoEvaluations.isSelected();
		spnEvaluations.setEnabled(enabled);
		spnRuntime.setEnabled(!enabled);
		lblUnits.setEnabled(!enabled);
		cboUnits.setEnabled(!enabled);
	    }
	});
	rdoEvaluations.addChangeListener(frameChangeListener);
	final GridBagConstraints gbc_rdoEvaluations = new GridBagConstraints();
	gbc_rdoEvaluations.anchor = GridBagConstraints.NORTH;
	gbc_rdoEvaluations.insets = new Insets(0, 0, 5, 5);
	gbc_rdoEvaluations.gridx = 0;
	gbc_rdoEvaluations.gridy = 0;
	pnlRandomSearchOptions.add(rdoEvaluations, gbc_rdoEvaluations);
	bgrRandomOptions.add(rdoEvaluations);

	final GridBagConstraints gbc_spnEvaluations = new GridBagConstraints();
	gbc_spnEvaluations.anchor = GridBagConstraints.NORTH;
	gbc_spnEvaluations.insets = new Insets(0, 0, 5, 5);
	gbc_spnEvaluations.gridx = 1;
	gbc_spnEvaluations.gridy = 0;
	pnlRandomSearchOptions.add(spnEvaluations, gbc_spnEvaluations);
	rdoRuntime = new JRadioButton("Runtime:");

	rdoRuntime.addChangeListener(frameChangeListener);
	rdoRuntime.setEnabled(true);
	final GridBagConstraints gbc_rdoRuntime = new GridBagConstraints();
	gbc_rdoRuntime.anchor = GridBagConstraints.WEST;
	gbc_rdoRuntime.insets = new Insets(0, 0, 0, 5);
	gbc_rdoRuntime.gridx = 0;
	gbc_rdoRuntime.gridy = 1;
	pnlRandomSearchOptions.add(rdoRuntime, gbc_rdoRuntime);
	bgrRandomOptions.add(rdoRuntime);
	spnRuntime = new JSpinner(new SpinnerNumberModel(new Double(
		Main.defaultRandomSearchRuntime), new Double(Double.MIN_VALUE),
		new Double(Double.MAX_VALUE), new Double(1)));
	spnRuntime.setMinimumSize(new Dimension(60, 20));
	spnRuntime.setPreferredSize(new Dimension(60, 20));
	spnRuntime.addChangeListener(frameChangeListener);

	spnRuntime.setEnabled(false);
	final GridBagConstraints gbc_spnRuntime = new GridBagConstraints();
	gbc_spnRuntime.insets = new Insets(0, 0, 0, 5);
	gbc_spnRuntime.gridx = 1;
	gbc_spnRuntime.gridy = 1;
	pnlRandomSearchOptions.add(spnRuntime, gbc_spnRuntime);
	lblUnits = new JLabel("Units:");

	lblUnits.setEnabled(false);
	final GridBagConstraints gbc_lblUnits = new GridBagConstraints();
	gbc_lblUnits.anchor = GridBagConstraints.EAST;
	gbc_lblUnits.insets = new Insets(0, 0, 0, 5);
	gbc_lblUnits.gridx = 2;
	gbc_lblUnits.gridy = 1;
	pnlRandomSearchOptions.add(lblUnits, gbc_lblUnits);
	pnlSearchOptions.add(pnlRandomSearchOptions,
		SearchMethod.RANDOM.toString());
	cboUnits = new JComboBox(TimeUnits.values());

	cboUnits.setSelectedItem(TimeUnits.Minutes);
	cboUnits.addItemListener(frameItemListener);
	cboUnits.setEnabled(false);
	final GridBagConstraints gbc_cboUnits = new GridBagConstraints();
	gbc_cboUnits.anchor = GridBagConstraints.WEST;
	gbc_cboUnits.gridx = 3;
	gbc_cboUnits.gridy = 1;
	pnlRandomSearchOptions.add(cboUnits, gbc_cboUnits);
	final GridBagLayout pnlEDASearchOptionsLayout = new GridBagLayout();
	pnlEDASearchOptionsLayout.rowWeights = new double[] { 0.1, 0.0, 0.1 };
	pnlEDASearchOptionsLayout.rowHeights = new int[] { 1, 1, 1 };
	pnlEDASearchOptionsLayout.columnWeights = new double[] { 0, 0, 0.1, 0,
		1 };
	pnlEDASearchOptionsLayout.columnWidths = new int[] { 1, 1, 1, 1, 1 };
	pnlEDASearchOptions = new JPanel(pnlEDASearchOptionsLayout);
	lblNumAgents = new JLabel("Number of Agents:");

	pnlEDASearchOptions.add(lblNumAgents, new GridBagConstraints(0, 0, 1,
		1, 0.0, 0.0, GridBagConstraints.EAST, GridBagConstraints.NONE,
		new Insets(0, 5, 5, 0), 0, 0));
	spnNumAgents = new JSpinner(new SpinnerNumberModel(
		Main.defaultEDANumAgents, 1, null, 1));
	spnNumAgents.setMinimumSize(new Dimension(60, 20));
	spnNumAgents.setPreferredSize(new Dimension(60, 20));
	spnNumAgents.addChangeListener(frameChangeListener);

	pnlEDASearchOptions.add(spnNumAgents, new GridBagConstraints(1, 0, 1,
		1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE,
		new Insets(0, 5, 5, 0), 0, 0));
	lblNumUpdates = new JLabel("Number of Updates:");

	pnlEDASearchOptions.add(lblNumUpdates, new GridBagConstraints(2, 0, 1,
		1, 0.0, 0.0, GridBagConstraints.EAST, GridBagConstraints.NONE,
		new Insets(0, 5, 5, 0), 0, 0));
	spnNumUpdates = new JSpinner(new SpinnerNumberModel(new Integer(
		Main.defaultEDANumUpdates), new Integer(1), null, new Integer(
		50)));
	spnNumUpdates.setMinimumSize(new Dimension(60, 20));
	spnNumUpdates.setPreferredSize(new Dimension(60, 20));
	spnNumUpdates.addChangeListener(frameChangeListener);

	pnlEDASearchOptions.add(spnNumUpdates, new GridBagConstraints(3, 0, 1,
		1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE,
		new Insets(0, 5, 5, 0), 0, 0));
	// EDA Update Configuration Panel
	pnlEDAUpdate = new JPanel(new GridBagLayout());
	// Retention Constant
	lblRetention = new JLabel("Retention:");

	pnlEDAUpdate.add(lblRetention, new GridBagConstraints(0, 0, 1, 1, 0.0,
		0.0, GridBagConstraints.EAST, GridBagConstraints.NONE,
		new Insets(0, 5, 0, 5), 0, 0));
	spnRetention = new JSpinner(new SpinnerNumberModel(
		Main.defaultEDARetention, 0.1, 1.0, 0.01));
	spnRetention.setMinimumSize(new Dimension(60, 20));
	spnRetention.setPreferredSize(new Dimension(60, 20));
	spnRetention.addChangeListener(frameChangeListener);

	pnlEDAUpdate.add(spnRetention, new GridBagConstraints(1, 0, 1, 1, 0.0,
		0.0, GridBagConstraints.WEST, GridBagConstraints.NONE,
		new Insets(0, 5, 0, 5), 0, 0));
	// Alpha Constant
	lblAlpha = new JLabel("Alpha:");

	pnlEDAUpdate.add(lblAlpha, new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0,
		GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(0,
			5, 0, 5), 0, 0));
	spnAlpha = new JSpinner(new SpinnerNumberModel(Main.defaultEDAAlpha, 0,
		100, 1));
	spnAlpha.setMinimumSize(new Dimension(60, 20));
	spnAlpha.setPreferredSize(new Dimension(60, 20));
	spnAlpha.addChangeListener(frameChangeListener);

	pnlEDAUpdate.add(spnAlpha, new GridBagConstraints(3, 0, 1, 1, 0.0, 0.0,
		GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0,
			5, 0, 5), 0, 0));
	// Beta Constant
	lblBeta = new JLabel("Beta:");

	pnlEDAUpdate.add(lblBeta, new GridBagConstraints(4, 0, 1, 1, 0.0, 0.0,
		GridBagConstraints.EAST, GridBagConstraints.NONE, new Insets(0,
			5, 0, 5), 0, 0));
	spnBeta = new JSpinner(new SpinnerNumberModel(Main.defaultEDABeta, 0,
		100, 1));
	spnBeta.setMinimumSize(new Dimension(60, 20));
	spnBeta.setPreferredSize(new Dimension(60, 20));
	spnBeta.addChangeListener(frameChangeListener);

	pnlEDAUpdate.add(spnBeta, new GridBagConstraints(5, 0, 1, 1, 0.0, 0.0,
		GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0,
			5, 0, 0), 0, 0));
	pnlEDASearchOptions.add(pnlEDAUpdate, new GridBagConstraints(0, 1,
		GridBagConstraints.REMAINDER, 1, 0.0, 0.0,
		GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0,
			5, 5, 0), 0, 0));
	pnlEDAExpertKnowledge = new TitledPanel(new BorderLayout());
	pnlEDAExpertKnowledge.setTitle("Expert Knowledge");
	pnlEDAExpertKnowledge.setTitleFont(Frame.fontBold);
	// Create Panel to hold EK Configuration Information
	pnlEDAEKPanel = new JPanel(new GridBagLayout());
	// Expert Knowledge file loading/viewing
	pnlEDAEKInfo = new JPanel(new GridBagLayout());
	cmdLoadExpertKnowledge = new JButton("Load Scores");
	cmdLoadExpertKnowledge
		.setToolTipText("Expects a file similar to one from saved from the 'raw text' section of the 'Filter' tab. Format is two whitespace delimited columns of column identifier and scores");
	cmdLoadExpertKnowledge.addActionListener(new ActionListener() {

	    @Override
	    public void actionPerformed(final ActionEvent e) {
		cmdLoadScores();

	    }
	});

	pnlEDAEKInfo.add(cmdLoadExpertKnowledge, new GridBagConstraints(0, 0,
		1, 1, 0.0, 0.0, GridBagConstraints.EAST,
		GridBagConstraints.NONE, new Insets(0, 5, 5, 0), 0, 0));
	lblExpertKnowledgeValue = new JLabel();

	pnlEDAEKInfo.add(lblExpertKnowledgeValue, new GridBagConstraints(1, 0,
		GridBagConstraints.REMAINDER, 1, 1, 0.0,
		GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0,
			5, 0, 0), 0, 0));
	cmdViewExpertKnowledge = new JButton("View Scores");
	cmdViewExpertKnowledge.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		frmExpertKnowledge.setVisible(true);
		createExpertKnowledgeRuntime();
		frmExpertKnowledge.readDatafile(expertKnowledge);
		frmExpertKnowledge.toFront();
	    }
	});

	pnlEDAEKInfo.add(cmdViewExpertKnowledge, new GridBagConstraints(0, 1,
		1, 1, 0.0, 0.0, GridBagConstraints.EAST,
		GridBagConstraints.NONE, new Insets(0, 5, 5, 0), 0, 0));
	// Add pnlEDAEKUpdate to pnlEDAExpertKnowledge panel
	pnlEDAEKPanel.add(pnlEDAEKInfo, new GridBagConstraints(0, 0,
		GridBagConstraints.REMAINDER, 1, 0.0, 0.0,
		GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL,
		new Insets(0, 5, 5, 0), 0, 0));
	// EDA Expert Knowledge Conversion Panel
	pnlEDAEKConv = new JPanel(new GridBagLayout());
	rdoFitnessProportional = new JRadioButton(
		WeightScheme.PROPORTIONAL.getDisplayName());

	rdoFitnessProportional.addChangeListener(frameChangeListener);
	pnlEDAEKConv.add(rdoFitnessProportional, new GridBagConstraints(0, 0,
		1, 1, 0.0, 0.0, GridBagConstraints.WEST,
		GridBagConstraints.NONE, new Insets(0, 5, 0, 0), 0, 0));
	rdoRankedSelection = new JRadioButton(
		WeightScheme.RANK.getDisplayName());

	rdoRankedSelection
		.addActionListener(expertKnowledgeMappingActionListener);
	rdoFitnessProportional
		.addActionListener(expertKnowledgeMappingActionListener);
	rdoRankedSelection.addChangeListener(frameChangeListener);
	pnlEDAEKConv.add(rdoRankedSelection, new GridBagConstraints(0, 1, 1, 1,
		0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE,
		new Insets(0, 5, 0, 0), 0, 0));
	bgrExpertKnowledgeWeightingScheme.add(rdoRankedSelection);
	bgrExpertKnowledgeWeightingScheme.add(rdoFitnessProportional);
	rdoLinearKnowledge = new JRadioButton("Linear");

	rdoLinearKnowledge.addChangeListener(frameChangeListener);
	rdoLinearKnowledge.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		spnLinearMaxPercent.setEnabled(rdoLinearKnowledge.isSelected());
		lblLinearMax.setEnabled(rdoLinearKnowledge.isSelected());
	    }
	});
	pnlEDAEKConv.add(rdoLinearKnowledge, new GridBagConstraints(1, 0, 1, 1,
		0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE,
		new Insets(0, 5, 0, 0), 0, 0));
	lblLinearMax = new JLabel(" % Maximum Probability:");

	pnlEDAEKConv.add(lblLinearMax, new GridBagConstraints(0, 2, 1, 1, 0.0,
		0.0, GridBagConstraints.WEST, GridBagConstraints.NONE,
		new Insets(0, 5, 5, 0), 0, 0));
	spnLinearMaxPercent = new JSpinner(new SpinnerNumberModel(
		Main.defaultEDAPercentMaxAttributeRange, 0, 100, 1));
	spnLinearMaxPercent.setMinimumSize(new Dimension(60, 20));
	spnLinearMaxPercent.setPreferredSize(new Dimension(60, 20));
	spnLinearMaxPercent.addChangeListener(frameChangeListener);
	spnLinearMaxPercent
		.addChangeListener(expertFileParameterChangeListener);

	pnlEDAEKConv.add(spnLinearMaxPercent, new GridBagConstraints(1, 2, 1,
		1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE,
		new Insets(0, 5, 0, 0), 0, 0));
	rdoExponentialKnowledge = new JRadioButton("Exponential");

	rdoExponentialKnowledge.addChangeListener(frameChangeListener);
	rdoExponentialKnowledge.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		spnExponentialTheta.setEnabled(rdoExponentialKnowledge
			.isSelected());
		lblExponentialTheta.setEnabled(rdoExponentialKnowledge
			.isSelected());
	    }
	});
	pnlEDAEKConv.add(rdoExponentialKnowledge, new GridBagConstraints(1, 1,
		1, 1, 0.0, 0.0, GridBagConstraints.WEST,
		GridBagConstraints.NONE, new Insets(0, 5, 0, 0), 0, 0));
	rdoLinearKnowledge
		.addActionListener(expertKnowledgeMappingActionListener);
	rdoExponentialKnowledge
		.addActionListener(expertKnowledgeMappingActionListener);
	bgrExpertKnowledgeScalingMethod.add(rdoLinearKnowledge);
	bgrExpertKnowledgeScalingMethod.add(rdoExponentialKnowledge);
	lblExponentialTheta = new JLabel("Theta:");

	pnlEDAEKConv.add(lblExponentialTheta, new GridBagConstraints(0, 3, 1,
		1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE,
		new Insets(0, 5, 5, 0), 0, 0));
	spnExponentialTheta = new JSpinner(new SpinnerNumberModel(
		Main.defaultEDAExponentialTheta, 0.0, 1.0, 0.01));
	spnExponentialTheta.setMinimumSize(new Dimension(60, 20));
	spnExponentialTheta.setPreferredSize(new Dimension(60, 20));
	spnExponentialTheta.addChangeListener(frameChangeListener);
	spnExponentialTheta
		.addChangeListener(expertFileParameterChangeListener);
	pnlAnalysisConfiguration = new TitledPanel(new GridBagLayout());
	final GridBagLayout gridBagLayout_1 = (GridBagLayout) pnlAnalysisConfiguration
		.getLayout();
	gridBagLayout_1.rowHeights = new int[] { 0, 0, 0, 0, 0, 45, 50 };
	gridBagLayout_1.rowWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 0.0,
		1.0 };
	gridBagLayout_1.columnWeights = new double[] { 1.0, 0.0, 0.0, 0.0, 0.0,
		0.0 };
	pnlAnalysisConfiguration.setTitle("Configuration");
	pnlAnalysisConfiguration.setTitleFont(Frame.fontBold);
	lblRandomSeed = new JLabel("Random Seed:");

	pnlAnalysisConfiguration.add(lblRandomSeed, new GridBagConstraints(0,
		0, 1, 1, 0.0, 0.0, GridBagConstraints.WEST,
		GridBagConstraints.NONE, new Insets(0, 5, 5, 5), 0, 0));
	spnRandomSeed = new JSpinner(new SpinnerNumberModel(new Long(
		Main.defaultRandomSeed), new Long(Main.minimumRandomSeed),
		null, new Long(1)));
	spnRandomSeed.setMinimumSize(new Dimension(60, 20));
	spnRandomSeed.setPreferredSize(new Dimension(60, 20));
	spnRandomSeed.addChangeListener(frameChangeListener);
	spnRandomSeed.addChangeListener(new ChangeListener() {
	    @Override
	    public void stateChanged(final ChangeEvent e) {
		Console.console.setRandomSeed((Long) spnRandomSeed.getValue());
	    }
	});

	pnlAnalysisConfiguration.add(spnRandomSeed, new GridBagConstraints(1,
		0, 3, 1, 0.0, 0.0, GridBagConstraints.WEST,
		GridBagConstraints.NONE, new Insets(0, 5, 5, 5), 0, 0));
	lblAttributeCountRange = new JLabel("Attribute Count Range:");

	pnlAnalysisConfiguration.add(lblAttributeCountRange,
		new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0,
			GridBagConstraints.WEST, GridBagConstraints.NONE,
			new Insets(0, 5, 5, 5), 0, 0));
	spnAttributeCountMin = new JSpinner(new SpinnerNumberModel(new Integer(
		Main.defaultAttributeCountMin), new Integer(1), null,
		new Integer(1)));
	spnAttributeCountMin.setMinimumSize(new Dimension(60, 20));
	spnAttributeCountMin.setPreferredSize(new Dimension(60, 20));
	final ChangeListener spnAttributeCountChangeListener = new ChangeListener() {
	    @Override
	    public void stateChanged(final ChangeEvent e) {
		final Integer min = (Integer) spnAttributeCountMin.getValue();
		final Integer max = (Integer) spnAttributeCountMax.getValue();
		if (min.compareTo(max) > 0) {
		    if (e.getSource() == spnAttributeCountMin) {
			spnAttributeCountMax.setValue(min);
		    } else {
			spnAttributeCountMin.setValue(max);
		    }
		}
	    }
	};
	spnAttributeCountMin.addChangeListener(spnAttributeCountChangeListener);
	spnAttributeCountMin.addChangeListener(frameChangeListener);

	pnlAnalysisConfiguration.add(spnAttributeCountMin,
		new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0,
			GridBagConstraints.WEST, GridBagConstraints.NONE,
			new Insets(0, 5, 5, 5), 0, 0));
	lblAttributeCountRangeColon = new JLabel(":");

	pnlAnalysisConfiguration.add(lblAttributeCountRangeColon,
		new GridBagConstraints(2, 1, 1, 1, 0.0, 0.0,
			GridBagConstraints.WEST, GridBagConstraints.NONE,
			new Insets(0, 5, 5, 5), 0, 0));
	spnAttributeCountMax = new JSpinner(new SpinnerNumberModel(new Integer(
		Main.defaultAttributeCountMax), new Integer(1), null,
		new Integer(1)));
	spnAttributeCountMax.setMinimumSize(new Dimension(60, 20));
	spnAttributeCountMax.setPreferredSize(new Dimension(60, 20));
	spnAttributeCountMax.addChangeListener(spnAttributeCountChangeListener);
	spnAttributeCountMax.addChangeListener(frameChangeListener);

	pnlAnalysisConfiguration.add(spnAttributeCountMax,
		new GridBagConstraints(3, 1, 1, 1, 0.0, 0.0,
			GridBagConstraints.WEST, GridBagConstraints.NONE,
			new Insets(0, 5, 5, 5), 0, 0));
	lblCrossValidationCount = new JLabel("Cross-Validation Count:");

	pnlAnalysisConfiguration.add(lblCrossValidationCount,
		new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0,
			GridBagConstraints.WEST, GridBagConstraints.NONE,
			new Insets(0, 5, 5, 5), 0, 0));
	spnCrossValidationCount = new JSpinner(new SpinnerNumberModel(
		new Integer(Main.defaultCrossValidationCount), new Integer(1),
		null, new Integer(1)));
	spnCrossValidationCount.setMinimumSize(new Dimension(60, 20));
	spnCrossValidationCount.setPreferredSize(new Dimension(60, 20));
	spnCrossValidationCount.addChangeListener(frameChangeListener);

	pnlAnalysisConfiguration.add(spnCrossValidationCount,
		new GridBagConstraints(1, 2, 1, 1, 0.0, 0.0,
			GridBagConstraints.WEST, GridBagConstraints.NONE,
			new Insets(0, 5, 5, 5), 0, 0));
	lblComputeAllModelsLandscape = new JLabel("Compute Fitness Landscape:");

	pnlAnalysisConfiguration.add(lblComputeAllModelsLandscape,
		new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0,
			GridBagConstraints.WEST, GridBagConstraints.NONE,
			new Insets(0, 5, 5, 5), 0, 0));

	chkComputeAllModelsLandscape.addChangeListener(frameChangeListener);
	pnlAnalysisConfiguration.add(chkComputeAllModelsLandscape,
		new GridBagConstraints(1, 3, 1, 1, 0.0, 0.0,
			GridBagConstraints.WEST, GridBagConstraints.NONE,
			new Insets(0, 5, 5, 5), 0, 0));
	final JLabel lblTopModelsLandscapeSize = new JLabel("Track Top Models:");

	pnlAnalysisConfiguration.add(lblTopModelsLandscapeSize,
		new GridBagConstraints(0, 4, 1, 1, 0.0, 0.0,
			GridBagConstraints.WEST, GridBagConstraints.NONE,
			new Insets(0, 5, 5, 5), 0, 0));
	spnTopModels = new JSpinner(new SpinnerNumberModel(
		Main.defaultTopModelsLandscapeSize, 1, Integer.MAX_VALUE, 1) {
	    @Override
	    public Object getNextValue() {
		final int currentValue = Integer
			.parseInt(getValue().toString());
		final int stepSize = getStepSize(currentValue);
		final int nextValue = currentValue + stepSize;
		return nextValue;
	    }

	    @Override
	    public Object getPreviousValue() {
		final int currentValue = Integer
			.parseInt(getValue().toString());
		final int stepSize = getStepSize(currentValue - 1);
		final int previousValue = Math.max((Integer) getMinimum(),
			currentValue - stepSize);
		return previousValue;
	    }

	    private int getStepSize(final int rangeDeterminingValue) {
		int stepSize;
		if (rangeDeterminingValue >= 1000) {
		    stepSize = 100;
		} else if (rangeDeterminingValue >= 100) {
		    stepSize = 50;
		} else if (rangeDeterminingValue >= 50) {
		    stepSize = 10;
		} else if (rangeDeterminingValue >= 10) {
		    stepSize = 5;
		} else if (rangeDeterminingValue >= 0) {
		    stepSize = 1;
		} else {
		    stepSize = 0;
		}
		return stepSize;
	    }
	});
	spnTopModels.setMinimumSize(new Dimension(60, 20));
	spnTopModels.setPreferredSize(new Dimension(60, 20));

	spnTopModels.addChangeListener(frameChangeListener);
	pnlAnalysisConfiguration.add(spnTopModels, new GridBagConstraints(1, 4,
		1, 1, 0.0, 0.0, GridBagConstraints.WEST,
		GridBagConstraints.NONE, new Insets(0, 5, 5, 5), 0, 0));
	lblPairedAnalysis = new JLabel("Paired Analysis:");

	pnlAnalysisConfiguration.add(lblPairedAnalysis, new GridBagConstraints(
		4, 0, 1, 1, 0.0, 0.0, GridBagConstraints.WEST,
		GridBagConstraints.NONE, new Insets(0, 5, 5, 5), 0, 0));
	chkPairedAnalysis.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		if (Console.console.data != null) {
		    Console.console.data
			    .setMatchedPairsOrTriplets(chkPairedAnalysis
				    .isSelected());
		}
	    }
	});

	chkPairedAnalysis.addChangeListener(frameChangeListener);
	pnlAnalysisConfiguration.add(chkPairedAnalysis, new GridBagConstraints(
		5, 0, 1, 1, 0.0, 0.0, GridBagConstraints.WEST,
		GridBagConstraints.NONE, new Insets(0, 5, 5, 0), 0, 0));
	pnlAmbiguousCellAnalysis = new TitledPanel(new GridBagLayout());
	final GridBagLayout gridBagLayout = (GridBagLayout) pnlAmbiguousCellAnalysis
		.getLayout();
	gridBagLayout.columnWeights = new double[] { 0.0, 1.0 };
	pnlAmbiguousCellAnalysis.setTitle("Ambiguous Cell Analysis");
	rdoAmbiguousCellCriteriaTieCells = new JRadioButton("Tie Cells", true);

	pnlAmbiguousCellAnalysis.add(rdoAmbiguousCellCriteriaTieCells,
		new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0,
			GridBagConstraints.WEST, GridBagConstraints.NONE,
			new Insets(0, 5, 5, 0), 0, 0));
	rdoAmbiguousCellCriteriaFishersExact = new JRadioButton(
		"Fisher's Exact Test", true);

	pnlAmbiguousCellAnalysis.add(rdoAmbiguousCellCriteriaFishersExact,
		new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0,
			GridBagConstraints.WEST, GridBagConstraints.NONE,
			new Insets(0, 5, 5, 0), 0, 0));
	bgrAmbiguousCellCriteria.add(rdoAmbiguousCellCriteriaTieCells);
	bgrAmbiguousCellCriteria.add(rdoAmbiguousCellCriteriaFishersExact);
	bgrAmbiguousCellCriteria.setSelected(
		rdoAmbiguousCellCriteriaTieCells.getModel(), true);
	rdoAmbiguousCellCriteriaTieCells.addChangeListener(frameChangeListener);
	rdoAmbiguousCellCriteriaTieCells
		.addActionListener(ambiguousCellCriteriaActionListener);
	rdoAmbiguousCellCriteriaFishersExact
		.addChangeListener(frameChangeListener);
	rdoAmbiguousCellCriteriaFishersExact
		.addActionListener(ambiguousCellCriteriaActionListener);
	// lblTieCells = new JLabel("Tie Cells:");

	// pnlAmbiguousCellAnalysis.add(lblTieCells, new GridBagConstraints(0,
	// 0, 1,
	// 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE,
	// new Insets(0, 5, 5, 0), 0, 0));
	// final JLabel lblFisherExact = new JLabel("Fisher's Exact Test:");

	// pnlAmbiguousCellAnalysis.add(lblFisherExact, new
	// GridBagConstraints(0, 1,
	// 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE,
	// new Insets(0, 5, 5, 0), 0, 0));
	spnFisherThreshold = new JSpinner(new SpinnerNumberModel(0.05, 0.01,
		1.0, .01));
	spnFisherThreshold.setEnabled(false);
	spnFisherThreshold.setMinimumSize(new Dimension(60, 20));
	spnFisherThreshold.setPreferredSize(new Dimension(60, 20));

	spnFisherThreshold.addChangeListener(frameChangeListener);
	spnFisherThreshold.addChangeListener(new ChangeListener() {
	    @Override
	    public void stateChanged(final ChangeEvent e) {
		Console.fishersThreshold = ((Double) spnFisherThreshold
			.getValue()).floatValue();
	    }
	});
	pnlAmbiguousCellAnalysis.add(spnFisherThreshold,
		new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0,
			GridBagConstraints.WEST, GridBagConstraints.NONE,
			new Insets(0, 5, 5, 0), 0, 0));
	lblAmbiguousCellAssignment = new JLabel("Ambiguous cell assignment:");

	pnlAmbiguousCellAnalysis.add(lblAmbiguousCellAssignment,
		new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0,
			GridBagConstraints.WEST, GridBagConstraints.NONE,
			new Insets(0, 5, 5, 0), 0, 0));
	cboAmbiguousCellStatuses = new JComboBox();
	cboAmbiguousCellStatuses.setMaximumRowCount(3);

	cboAmbiguousCellStatuses.addItem(new AmbiguousCellDynamicString(
		AmbiguousCellStatus.AFFECTED));
	cboAmbiguousCellStatuses.addItem(new AmbiguousCellDynamicString(
		AmbiguousCellStatus.UNAFFECTED));
	cboAmbiguousCellStatuses.addItem(new AmbiguousCellDynamicString(
		AmbiguousCellStatus.UNCLASSIFIED));
	cboAmbiguousCellStatuses.addItemListener(frameItemListener);
	pnlAmbiguousCellAnalysis.add(cboAmbiguousCellStatuses,
		new GridBagConstraints(1, 2, 1, 1, 1.0, 0.0,
			GridBagConstraints.CENTER,
			GridBagConstraints.HORIZONTAL, new Insets(0, 5, 5, 5),
			0, 0));
	final GridBagConstraints gbc_pnlExperimental = new GridBagConstraints();
	gbc_pnlExperimental.gridheight = 4;
	gbc_pnlExperimental.gridwidth = 6;
	gbc_pnlExperimental.insets = new Insets(0, 0, 0, 5);
	gbc_pnlExperimental.fill = GridBagConstraints.BOTH;
	gbc_pnlExperimental.gridx = 0;
	gbc_pnlExperimental.gridy = 5;
	pnlAnalysisConfiguration.add(pnlExperimental, gbc_pnlExperimental);
	final GridBagLayout gbl_pnlExperimental = new GridBagLayout();
	gbl_pnlExperimental.columnWidths = new int[] { 0 };
	gbl_pnlExperimental.rowHeights = new int[] { 0 };
	gbl_pnlExperimental.columnWeights = new double[] { 0.0 };
	gbl_pnlExperimental.rowWeights = new double[] { Double.MIN_VALUE };
	pnlExperimental.setLayout(gbl_pnlExperimental);
	if (Main.isExperimental) {
	    lblTopModelsCriteria = new JLabel("Top Models Criteria:");

	    pnlExperimental.add(lblTopModelsCriteria, new GridBagConstraints(0,
		    0, 1, 1, 0.0, 0.0, GridBagConstraints.WEST,
		    GridBagConstraints.NONE, new Insets(0, 5, 5, 0), 0, 0));
	    cboTopModelsCriteria = new JComboBox(new DefaultComboBoxModel(
		    FitnessCriteriaOrder.topModelsCriteriaIndependentOfCVC));
	    cboTopModelsCriteria.setMinimumSize(new Dimension(280, 20));
	    cboTopModelsCriteria.setPreferredSize(new Dimension(280, 20));

	    cboTopModelsCriteria.addItemListener(new ItemListener() {
		@Override
		public void itemStateChanged(final ItemEvent e) {
		    Console.console.topModelsFitnessCriteriaOrder = FitnessCriteriaOrder
			    .lookup(cboTopModelsCriteria.getSelectedItem()
				    .toString());
		}
	    });
	    cboTopModelsCriteria.addItemListener(frameItemListener);
	    pnlExperimental.add(cboTopModelsCriteria,
		    new GridBagConstraints(1, 0, 2, 1, 0.0, 0.0,
			    GridBagConstraints.WEST,
			    GridBagConstraints.HORIZONTAL, new Insets(0, 5, 5,
				    0), 0, 0));

	    lblBestModelCriteria = new JLabel("Best Model Criteria:");

	    pnlExperimental.add(lblBestModelCriteria, new GridBagConstraints(0,
		    1, 1, 1, 0.0, 0.0, GridBagConstraints.WEST,
		    GridBagConstraints.NONE, new Insets(0, 5, 5, 0), 0, 0));
	    cboBestModelCriterionOrder = new JComboBox(
		    new DefaultComboBoxModel(
			    FitnessCriteriaOrder.bestModelCriteriaPossiblyDependentOnCVC));
	    cboBestModelCriterionOrder.setMinimumSize(new Dimension(280, 20));
	    cboBestModelCriterionOrder.setPreferredSize(new Dimension(280, 20));

	    cboBestModelCriterionOrder.addItemListener(new ItemListener() {
		@Override
		public void itemStateChanged(final ItemEvent e) {
		    Console.console.bestModelFitnessCriteriaOrder = FitnessCriteriaOrder
			    .lookup(cboBestModelCriterionOrder
				    .getSelectedItem().toString());
		}
	    });
	    cboBestModelCriterionOrder.addItemListener(frameItemListener);
	    pnlExperimental.add(cboBestModelCriterionOrder,
		    new GridBagConstraints(1, 1, 2, 1, 0.0, 0.0,
			    GridBagConstraints.WEST,
			    GridBagConstraints.HORIZONTAL, new Insets(0, 5, 5,
				    0), 0, 0));

	    lblBestModelMetric = new JLabel("Best Model Metric:");

	    pnlExperimental.add(lblBestModelMetric, new GridBagConstraints(0,
		    2, 1, 1, 0.0, 0.0, GridBagConstraints.WEST,
		    GridBagConstraints.NONE, new Insets(0, 5, 5, 0), 0, 0));
	    cboBestModelMetric = new JComboBox(new DefaultComboBoxModel(
		    DiscreteEndpointSignificanceMetric.getMenuItems()));
	    cboBestModelMetric.setMinimumSize(new Dimension(280, 20));
	    cboBestModelMetric.setPreferredSize(new Dimension(280, 20));

	    cboBestModelMetric.addItemListener(frameItemListener);
	    pnlExperimental.add(cboBestModelMetric,
		    new GridBagConstraints(1, 2, 2, 1, 0.0, 0.0,
			    GridBagConstraints.WEST,
			    GridBagConstraints.HORIZONTAL, new Insets(0, 5, 5,
				    0), 0, 0));
	    lblUseBestModelActualIntervals = new JLabel(
		    "Use Best Model Actual Intervals:");

	    pnlExperimental.add(lblUseBestModelActualIntervals,
		    new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0,
			    GridBagConstraints.WEST, GridBagConstraints.NONE,
			    new Insets(0, 5, 5, 0), 0, 0));
	    chkUseBestModelActualIntervals = new JCheckBox();

	    pnlExperimental.add(chkUseBestModelActualIntervals,
		    new GridBagConstraints(1, 3, 1, 1, 0.0, 0.0,
			    GridBagConstraints.WEST, GridBagConstraints.NONE,
			    new Insets(0, 5, 5, 0), 0, 0));
	    chkUseBestModelActualIntervals
		    .setSelected(Console.console.useBestModelActualIntervals);
	    chkUseBestModelActualIntervals.addItemListener(new ItemListener() {
		@Override
		public void itemStateChanged(final ItemEvent e) {
		    Console.console.useBestModelActualIntervals = chkUseBestModelActualIntervals
			    .isSelected();
		}
	    });
	    chkUseBestModelActualIntervals.addItemListener(frameItemListener);
	} // end if experimental
	pnlAnalysisConfiguration.add(pnlAmbiguousCellAnalysis,
		new GridBagConstraints(4, 1, 2, 4, 1.0, 0.0,
			GridBagConstraints.WEST, GridBagConstraints.BOTH,
			new Insets(0, 5, 5, 0), 0, 0));
	final GridBagConstraints gbc_pnlAnalysisConfiguration = new GridBagConstraints();
	gbc_pnlAnalysisConfiguration.fill = GridBagConstraints.BOTH;
	gbc_pnlAnalysisConfiguration.insets = new Insets(0, 0, 5, 0);
	gbc_pnlAnalysisConfiguration.gridx = 0;
	gbc_pnlAnalysisConfiguration.gridy = 0;
	pnlConfiguration.add(pnlAnalysisConfiguration,
		gbc_pnlAnalysisConfiguration);

	spnExponentialTheta.setEnabled(false);

	pnlEDAEKConv.add(spnExponentialTheta, new GridBagConstraints(1, 3, 1,
		1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE,
		new Insets(0, 5, 0, 0), 0, 0));
	// Add pnlEDAEKConv to pnlEDAExpertKnowledge panel
	pnlEDAEKPanel.add(pnlEDAEKConv, new GridBagConstraints(0, 1,
		GridBagConstraints.REMAINDER, 1, 0.0, 0.0,
		GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0,
			5, 5, 0), 0, 0));
	pnlEDAExpertKnowledge.add(pnlEDAEKPanel, java.awt.BorderLayout.WEST);
	// Add pnlEDAExpertKnowledge to pnlEDASearchOptions panel
	pnlEDASearchOptions.add(pnlEDAExpertKnowledge, new GridBagConstraints(
		0, 2, GridBagConstraints.REMAINDER,
		GridBagConstraints.REMAINDER, 0.0, 0.0,
		GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL,
		new Insets(0, 5, 0, 0), 0, 0));
	// Add EDASearchOptions to SearchOptions panel
	pnlSearchOptions.add(pnlEDASearchOptions, SearchMethod.EDA.toString());
	pnlSearchMethodConfiguration.add(pnlSearchOptions,
		java.awt.BorderLayout.CENTER);
	final GridBagConstraints gbc_pnlSearchMethodConfiguration = new GridBagConstraints();
	gbc_pnlSearchMethodConfiguration.anchor = GridBagConstraints.NORTH;
	gbc_pnlSearchMethodConfiguration.fill = GridBagConstraints.HORIZONTAL;
	gbc_pnlSearchMethodConfiguration.insets = new Insets(0, 0, 5, 0);
	gbc_pnlSearchMethodConfiguration.gridx = 0;
	gbc_pnlSearchMethodConfiguration.gridy = 1;
	pnlConfiguration.add(pnlSearchMethodConfiguration,
		gbc_pnlSearchMethodConfiguration);

	cmdDefaults.setEnabled(false);
	final GridBagConstraints gbc_cmdDefaults = new GridBagConstraints();
	gbc_cmdDefaults.anchor = GridBagConstraints.NORTHEAST;
	gbc_cmdDefaults.gridx = 0;
	gbc_cmdDefaults.gridy = 2;
	pnlConfiguration.add(cmdDefaults, gbc_cmdDefaults);
	tpnAnalysis.setBorder(null);
	pnlAnalysis.setBorder(null);
	tpnAnalysis.add(pnlAnalysis, "Analysis");

	tpnAnalysis.add(pnlConfiguration, "Configuration");
	pnlNetworkAnalysis.setBorder(null);
	tpnAnalysis.add(pnlNetworkAnalysis, "Network");
	final GridBagLayout gbl_pnlFilter = new GridBagLayout();
	gbl_pnlFilter.columnWidths = new int[] { 683, 0 };
	gbl_pnlFilter.rowHeights = new int[] { 76, 75, 60, 54, 274, 0 };
	gbl_pnlFilter.columnWeights = new double[] { 1.0, Double.MIN_VALUE };
	gbl_pnlFilter.rowWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 1.0,
		Double.MIN_VALUE };
	pnlFilter.setBorder(null);
	pnlFilter.setLayout(gbl_pnlFilter);
	pnlFilterLandscape.setXAxisLabel(MdrTableColumnName.MODEL_ATTRIBUTES
		.toString());
	pnlFilterLandscape.setYAxisLabel("Filter");
	cmdExportFiltered.setText(Main.EXPORT_DATAFILE);
	cmdExportFiltered.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		Frame.cmdExportData();
	    }
	});
	lblReliefFNeighbors.setText("Nearest Neighbors:");

	lblReliefFSampleSize.setText("Sample Size:");
	lblReliefFSampleSize.setEnabled(false);

	spnReliefFSampleSize.setEnabled(false);
	spnReliefFSampleSize.setMinimumSize(new Dimension(60, 20));
	spnReliefFSampleSize.setPreferredSize(new Dimension(60, 20));
	spnReliefFSampleSize
		.addPropertyChangeListener(filterPropertyChangeListener);
	spnReliefFSampleSize.setModel(new SpinnerNumberModel(new Integer(
		Main.defaultReliefFSampleSize), new Integer(1), new Integer(
		1000000), new Integer(50)));

	spnReliefFNeighbors.setMinimumSize(new Dimension(60, 20));
	spnReliefFNeighbors.setPreferredSize(new Dimension(60, 20));
	spnReliefFNeighbors.setModel(new SpinnerNumberModel(new Integer(
		Main.defaultReliefFNeighbors), new Integer(1), new Integer(
		1000000), new Integer(1)));
	spnReliefFNeighbors.getModel().addChangeListener(filterChangeListener);

	chkReliefFWholeDataset.setText("Whole Dataset");

	chkReliefFWholeDataset.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		final boolean enabled = !chkReliefFWholeDataset.isSelected();
		lblReliefFSampleSize.setEnabled(enabled);
		spnReliefFSampleSize.setEnabled(enabled);
	    }
	});
	chkReliefFWholeDataset.setSelected(Main.defaultReliefFWholeDataset);
	chkReliefFWholeDataset
		.addPropertyChangeListener(filterPropertyChangeListener);
	lblTuRFSampleSize.setText("Sample Size:");

	lblTuRFNeighbors.setText("Nearest Neighbors:");

	spnTuRFNeighbors.setMinimumSize(new Dimension(60, 20));
	spnTuRFNeighbors.setPreferredSize(new Dimension(60, 20));

	spnTuRFNeighbors
		.addPropertyChangeListener(filterPropertyChangeListener);
	spnTuRFSampleSize.setMinimumSize(new Dimension(60, 20));
	spnTuRFSampleSize.setPreferredSize(new Dimension(60, 20));

	spnTuRFSampleSize
		.addPropertyChangeListener(filterPropertyChangeListener);
	spnTuRFSampleSize.setModel(new SpinnerNumberModel(new Integer(
		Main.defaultReliefFSampleSize), new Integer(1), new Integer(
		1000000), new Integer(50)));
	spnTuRFSampleSize.getModel().addChangeListener(filterChangeListener);
	chkTuRFWholeDataset.setText("Whole Dataset");

	chkTuRFWholeDataset.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		final boolean enabled = !chkTuRFWholeDataset.isSelected();
		lblTuRFSampleSize.setEnabled(enabled);
		spnTuRFSampleSize.setEnabled(enabled);
	    }
	});
	chkTuRFWholeDataset.setSelected(Main.defaultReliefFWholeDataset);
	chkTuRFWholeDataset
		.addPropertyChangeListener(filterPropertyChangeListener);
	lblTuRFPercent.setText("Percent:");

	spnTuRFPercent.setMinimumSize(new Dimension(60, 20));
	spnTuRFPercent.setPreferredSize(new Dimension(60, 20));

	spnTuRFPercent.addPropertyChangeListener(filterPropertyChangeListener);
	spnTuRFPercent.setModel(new SpinnerNumberModel(new Integer(
		Main.defaultTuRFPct), new Integer(1), new Integer(100),
		new Integer(1)));
	spnTuRFPercent.getModel().addChangeListener(filterChangeListener);
	lblSURFnTuRFPercent.setText("Percent:");

	spnSURFnTuRFPercent.setMinimumSize(new Dimension(60, 20));
	spnSURFnTuRFPercent.setPreferredSize(new Dimension(60, 20));

	spnSURFnTuRFPercent
		.addPropertyChangeListener(filterPropertyChangeListener);
	spnSURFnTuRFPercent.setModel(new SpinnerNumberModel(new Integer(
		Main.defaultTuRFPct), new Integer(1), new Integer(100),
		new Integer(1)));
	spnSURFnTuRFPercent.getModel().addChangeListener(filterChangeListener);
	lblMultiSURFnTuRFPercent.setText("Percent:");

	spnMultiSURFnTuRFPercent.setMinimumSize(new Dimension(60, 20));
	spnMultiSURFnTuRFPercent.setPreferredSize(new Dimension(60, 20));

	spnMultiSURFnTuRFPercent
		.addPropertyChangeListener(filterPropertyChangeListener);
	spnMultiSURFnTuRFPercent.setModel(new SpinnerNumberModel(new Integer(
		Main.defaultTuRFPct), new Integer(1), new Integer(100),
		new Integer(1)));
	spnMultiSURFnTuRFPercent.getModel().addChangeListener(
		filterChangeListener);
	pnlFilterSelection.setTitleFont(Frame.fontBold);
	pnlFilterSelection.setTitle("Filter Selection");
	// cboFilter.addItem(new DisplayPair<FilterMethod,
	// Component>(FilterMethod.RELIEFF,
	// pnlReliefFOptions));
	// cboFilter.addItem(new DisplayPair<FilterMethod,
	// Component>(FilterMethod.TURF,
	// pnlTuRFOptions));
	// cboFilter.addItem(new DisplayPair<FilterMethod,
	// Component>(FilterMethod.CHISQUARED,
	// pnlChiSquaredOptions));
	// cboFilter.addItem(new DisplayPair<FilterMethod,
	// Component>(FilterMethod.ODDSRATIO,
	// pnlOddsRatioOptions));
	// cboFilter.addItem(new DisplayPair<FilterMethod,
	// Component>(FilterMethod.SURF,
	// pnlSURFOptions));
	// cboFilter.addItem(new DisplayPair<FilterMethod,
	// Component>(FilterMethod.SURFNTURF,
	// pnlSURFnTuRFOptions));
	// cboFilter.addItem(new DisplayPair<FilterMethod,
	// Component>(FilterMethod.SURFSTAR,
	// pnlSURFStarOptions));
	// cboFilter.addItem(new DisplayPair<FilterMethod,
	// Component>(FilterMethod.,
	// pnlSURFStarnTuRFOptions));
	// cboFilter.addItem(new DisplayPair<FilterMethod,
	// Component>("multiSURF",
	// pnlMultiSURFOptions));
	// cboFilter.addItem(new DisplayPair<FilterMethod,
	// Component>("multiSURFnTuRF",
	// pnlMultiSURFnTuRFOptions));
	final GridBagConstraints gbc_pnlFilterSelection = new GridBagConstraints();
	gbc_pnlFilterSelection.fill = GridBagConstraints.BOTH;
	gbc_pnlFilterSelection.insets = new Insets(0, 0, 5, 0);
	gbc_pnlFilterSelection.gridx = 0;
	gbc_pnlFilterSelection.gridy = 0;
	pnlFilter.add(pnlFilterSelection, gbc_pnlFilterSelection);
	pnlFilterSelection.setLayout(new BorderLayout(0, 0));
	pnlFilterSelection.add(pnlFilterCombo, BorderLayout.NORTH);
	final GridBagLayout gbl_pnlFilterCombo = new GridBagLayout();
	gbl_pnlFilterCombo.columnWidths = new int[] { 0, 0, 0 };
	gbl_pnlFilterCombo.rowHeights = new int[] { 0, 0 };
	gbl_pnlFilterCombo.columnWeights = new double[] { 0.0, 0.0,
		Double.MIN_VALUE };
	gbl_pnlFilterCombo.rowWeights = new double[] { 0.0, Double.MIN_VALUE };
	pnlFilterCombo.setLayout(gbl_pnlFilterCombo);
	final GridBagConstraints gbc_lblFilter = new GridBagConstraints();
	gbc_lblFilter.anchor = GridBagConstraints.WEST;
	gbc_lblFilter.insets = new Insets(0, 0, 0, 5);
	gbc_lblFilter.gridx = 0;
	gbc_lblFilter.gridy = 0;
	pnlFilterCombo.add(lblFilter, gbc_lblFilter);
	lblFilter.setText("Filter:");

	final GridBagConstraints gbc_cboFilter = new GridBagConstraints();
	gbc_cboFilter.anchor = GridBagConstraints.WEST;
	gbc_cboFilter.gridx = 1;
	gbc_cboFilter.gridy = 0;
	pnlFilterCombo.add(cboFilter, gbc_cboFilter);

	cboFilter.setMaximumRowCount(cboFilter.getItemCount());

	cboFilter.addItemListener(new ItemListener() {
	    @Override
	    public void itemStateChanged(final ItemEvent e) {
		if (Frame.initializing) {
		    return;
		}
		final FilterMethod filterMethod = (FilterMethod) cboFilter
			.getSelectedItem();
		if (filterMethod == FilterMethod.ATTRIBUTE_FILE) {
		    attributeNameFilterFile = null;
		    lblAttributesFilterFile.setText("");
		}
		crdFilterOptions.show(pnlFilterOptions, filterMethod.toString());
		pnlSubsetCriterion
			.setVisible(filterMethod != FilterMethod.ATTRIBUTE_FILE);
		cmdDefaultFilter.setEnabled(!isDefaultFilter());
	    }
	});
	pnlFilterSelection.add(pnlSubsetCriterion);
	pnlSubsetCriterion.setLayout(new FlowLayout(FlowLayout.LEFT, 5, 5));
	pnlSubsetCriterion.add(lblCriterion);
	lblCriterion.setText("Attribute Subset Criterion:");

	pnlSubsetCriterion.add(cboFilterCriterion);

	cboFilterCriterion.addItemListener(new ItemListener() {
	    @Override
	    public void itemStateChanged(final ItemEvent e) {
		switch (cboFilterCriterion.getSelectedIndex()) {
		case 0:
		    spnCriterionFilter.setModel(snmTopN);
		    break;
		case 1:
		    spnCriterionFilter.setModel(snmTopPct);
		    break;
		case 2:
		    spnCriterionFilter.setModel(snmThreshold);
		    break;
		default:
		    throw new RuntimeException("Unhandled switch on: "
			    + cboFilterCriterion.getSelectedIndex());
		}
		cmdDefaultFilter.setEnabled(!isDefaultFilter());
	    }
	});
	cboFilterCriterion.addItem("Top N");
	cboFilterCriterion.addItem("Top %");
	cboFilterCriterion.addItem("Threshold");
	pnlSubsetCriterion.add(lblCriterionValue);
	lblCriterionValue.setText("Value:");

	pnlSubsetCriterion.add(spnCriterionFilter);
	spnCriterionFilter.setMinimumSize(new Dimension(60, 20));
	spnCriterionFilter.setPreferredSize(new Dimension(60, 20));
	spnCriterionFilter
		.addPropertyChangeListener(filterPropertyChangeListener);

	pnlFilterOptions.setLayout(crdFilterOptions);
	pnlFilterOptions.setTitle("Filter Options");
	pnlFilterOptions.setTitleFont(Frame.fontBold);
	chkChiSquaredPValue.setText("P-Values");
	final GridBagConstraints gbc_pnlFilterOptions = new GridBagConstraints();
	gbc_pnlFilterOptions.fill = GridBagConstraints.BOTH;
	gbc_pnlFilterOptions.insets = new Insets(0, 0, 5, 0);
	gbc_pnlFilterOptions.gridx = 0;
	gbc_pnlFilterOptions.gridy = 1;
	pnlFilter.add(pnlFilterOptions, gbc_pnlFilterOptions);
	pnlFilterOptions
		.add(pnlReliefFOptions, FilterMethod.RELIEFF.toString());
	pnlReliefFOptions.add(lblReliefFSampleSize, new GridBagConstraints(0,
		1, 1, 1, 0.0, 0.0, GridBagConstraints.NORTHWEST,
		GridBagConstraints.NONE, new Insets(5, 5, 0, 0), 0, 0));
	pnlReliefFOptions.add(lblReliefFNeighbors, new GridBagConstraints(0, 0,
		1, 1, 0.0, 0.0, GridBagConstraints.WEST,
		GridBagConstraints.NONE, new Insets(0, 5, 0, 0), 0, 0));
	pnlReliefFOptions.add(spnReliefFSampleSize, new GridBagConstraints(1,
		1, 1, 1, 0.0, 0.0, GridBagConstraints.NORTHWEST,
		GridBagConstraints.NONE, new Insets(5, 5, 0, 0), 0, 0));
	pnlReliefFOptions.add(spnReliefFNeighbors, new GridBagConstraints(1, 0,
		1, 1, 0.0, 0.0, GridBagConstraints.WEST,
		GridBagConstraints.NONE, new Insets(0, 5, 0, 0), 0, 0));
	pnlReliefFOptions.add(chkReliefFWholeDataset, new GridBagConstraints(2,
		1, 1, 1, 1.0, 1.0, GridBagConstraints.NORTHWEST,
		GridBagConstraints.NONE, new Insets(5, 5, 0, 0), 0, 0));

	pnlFilterOptions.add(pnlAttributesFileFilter,
		FilterMethod.ATTRIBUTE_FILE.toString());
	final GridBagLayout gbl_pnlAttributesFileFilter = new GridBagLayout();
	gbl_pnlAttributesFileFilter.columnWidths = new int[] { 0, 0 };
	gbl_pnlAttributesFileFilter.rowHeights = new int[] { 0, 0, 0 };
	gbl_pnlAttributesFileFilter.columnWeights = new double[] { 1.0,
		Double.MIN_VALUE };
	gbl_pnlAttributesFileFilter.rowWeights = new double[] { 0.0, 0.0,
		Double.MIN_VALUE };
	pnlAttributesFileFilter.setLayout(gbl_pnlAttributesFileFilter);

	final GridBagConstraints gbc_btnChooseAttributesFilterFile = new GridBagConstraints();
	gbc_btnChooseAttributesFilterFile.insets = new Insets(0, 0, 5, 0);
	gbc_btnChooseAttributesFilterFile.fill = GridBagConstraints.HORIZONTAL;
	gbc_btnChooseAttributesFilterFile.gridx = 0;
	gbc_btnChooseAttributesFilterFile.gridy = 0;
	btnChooseAttributesFilterFile.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		final Pair<File, FileFilter> openFileWithExtension = FileSaver
			.getOpenFile("Open attribute names filter file", null,
				FileSaver.filtersText);
		if (openFileWithExtension != null) {
		    attributeNameFilterFile = openFileWithExtension.getFirst();
		    lblAttributesFilterFile.setText(attributeNameFilterFile
			    .getName()
			    + "'s contents will be used to find column names to keep.");
		} // if user chose file
	    }
	});
	pnlAttributesFileFilter.add(btnChooseAttributesFilterFile,
		gbc_btnChooseAttributesFilterFile);

	final GridBagConstraints gbc_lblAttributesFilterFile = new GridBagConstraints();
	gbc_lblAttributesFilterFile.gridx = 0;
	gbc_lblAttributesFilterFile.gridy = 1;
	lblAttributesFilterFile
		.setToolTipText("No special format required -- all words will found will be checked as column names.");
	pnlAttributesFileFilter.add(lblAttributesFilterFile,
		gbc_lblAttributesFilterFile);
	pnlFilterOptions.add(pnlChiSquaredOptions,
		FilterMethod.CHISQUARED.toString());
	pnlChiSquaredOptions.add(chkChiSquaredPValue, new GridBagConstraints(0,
		0, 1, 1, 1.0, 1.0, GridBagConstraints.NORTHWEST,
		GridBagConstraints.NONE, new Insets(0, 5, 0, 0), 0, 0));

	chkChiSquaredPValue
		.addPropertyChangeListener(filterPropertyChangeListener);
	pnlFilterOptions.add(pnlOddsRatioOptions,
		FilterMethod.ODDSRATIO.toString());
	pnlFilterOptions.add(pnlTuRFOptions, FilterMethod.TURF.toString());
	pnlTuRFOptions.add(lblTuRFSampleSize, new GridBagConstraints(0, 1, 1,
		1, 0.0, 0.0, GridBagConstraints.NORTHWEST,
		GridBagConstraints.NONE, new Insets(5, 5, 0, 0), 0, 0));
	pnlTuRFOptions.add(spnTuRFSampleSize, new GridBagConstraints(1, 1, 1,
		1, 0.0, 0.0, GridBagConstraints.NORTHWEST,
		GridBagConstraints.NONE, new Insets(5, 5, 0, 0), 0, 0));
	pnlTuRFOptions.add(lblTuRFNeighbors, new GridBagConstraints(0, 0, 1, 1,
		0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE,
		new Insets(0, 5, 0, 0), 0, 0));
	pnlTuRFOptions.add(spnTuRFNeighbors, new GridBagConstraints(1, 0, 1, 1,
		0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE,
		new Insets(0, 5, 0, 0), 0, 0));
	pnlTuRFOptions.add(lblTuRFPercent, new GridBagConstraints(2, 0, 1, 1,
		0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE,
		new Insets(0, 5, 0, 0), 0, 0));
	pnlTuRFOptions.add(spnTuRFPercent, new GridBagConstraints(3, 0, 1, 1,
		0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE,
		new Insets(0, 5, 0, 0), 0, 0));
	pnlTuRFOptions.add(chkTuRFWholeDataset, new GridBagConstraints(2, 1, 2,
		1, 1.0, 1.0, GridBagConstraints.NORTHWEST,
		GridBagConstraints.NONE, new Insets(5, 5, 0, 0), 0, 0));
	pnlFilterOptions.add(pnlSURFOptions, FilterMethod.SURF.toString());
	pnlFilterOptions.add(pnlSURFStarOptions,
		FilterMethod.SURFSTAR.toString());
	pnlFilterOptions.add(pnlSURFnTuRFOptions,
		FilterMethod.SURFNTURF.toString());
	lblSURFStarnTuRFPercent.setText("Percent:");

	spnSURFStarnTuRFPercent.setMinimumSize(new Dimension(60, 20));
	spnSURFStarnTuRFPercent.setPreferredSize(new Dimension(60, 20));

	spnSURFStarnTuRFPercent
		.addPropertyChangeListener(filterPropertyChangeListener);
	spnSURFStarnTuRFPercent.setModel(new SpinnerNumberModel(new Integer(
		Main.defaultTuRFPct), new Integer(1), new Integer(100),
		new Integer(1)));
	spnSURFStarnTuRFPercent.getModel().addChangeListener(
		filterChangeListener);
	pnlFilterOptions.add(pnlSURFStarnTuRFOptions,
		FilterMethod.SURFSTARNTURF.toString());
	pnlSURFStarnTuRFOptions.add(lblSURFStarnTuRFPercent,
		new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0,
			GridBagConstraints.NORTHWEST, GridBagConstraints.NONE,
			new Insets(0, 5, 0, 0), 0, 0));
	pnlSURFStarnTuRFOptions.add(spnSURFStarnTuRFPercent,
		new GridBagConstraints(1, 0, 1, 1, 1.0, 1.0,
			GridBagConstraints.WEST, GridBagConstraints.NONE,
			new Insets(0, 5, 0, 0), 0, 0));
	pnlFilterOptions.add(pnlMultiSURFOptions,
		FilterMethod.MULTISURF.toString());
	pnlFilterOptions.add(pnlMultiSURFnTuRFOptions,
		FilterMethod.MULTISURFNTURF.toString());
	pnlSURFnTuRFOptions.add(lblSURFnTuRFPercent, new GridBagConstraints(0,
		0, 1, 1, 1.0, 1.0, GridBagConstraints.WEST,
		GridBagConstraints.NONE, new Insets(0, 5, 0, 0), 0, 0));
	pnlSURFnTuRFOptions.add(spnSURFnTuRFPercent, new GridBagConstraints(1,
		0, 1, 1, 1.0, 1.0, GridBagConstraints.WEST,
		GridBagConstraints.NONE, new Insets(0, 5, 0, 0), 0, 0));
	pnlMultiSURFnTuRFOptions.add(lblMultiSURFnTuRFPercent,
		new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0,
			GridBagConstraints.NORTHWEST, GridBagConstraints.NONE,
			new Insets(0, 5, 0, 0), 0, 0));
	pnlMultiSURFnTuRFOptions.add(spnMultiSURFnTuRFPercent,
		new GridBagConstraints(1, 0, 1, 1, 1.0, 1.0,
			GridBagConstraints.WEST, GridBagConstraints.NONE,
			new Insets(0, 5, 0, 0), 0, 0));
	pnlFilterControls.setTitleFont(Frame.fontBold);
	pnlFilterControls.setTitle("Filter Controls");
	cmdDefaultFilter.setText("Defaults");
	cmdDefaultFilter.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		setFilterToDefaults();
	    }
	});
	cmdDefaultFilter.setEnabled(false);

	cmdLoadExpertKnowledge
		.setToolTipText("<html>Expects a file similar to one from saved from the '<i>raw text<i/>' section of the '<i>Filter<i/>' tab.<br>Format is two whitespace delimited columns of column identifier and scores</html>");
	cmdRevertFilter.setText(Main.REVERT_DATAFILE);
	final ActionListener cmdRevertActionListener = new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		prgFilterProgress.setFractionComplete(0);
		rankerThread = null;
		Frame.cmdRevertData();
	    }
	};
	cmdRevertFilter.addActionListener(cmdRevertActionListener);
	cmdRevertFilter.setEnabled(false);

	cmdFilter.setText("Apply");
	cmdFilter.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		cmdFilter();
	    }
	});
	cmdFilter.setEnabled(false);

	pnlFilterControls.add(cmdFilter, new GridBagConstraints(0, 0, 1, 1,
		0.0, 0.0, GridBagConstraints.CENTER,
		GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 0), 0, 0));
	pnlFilterControls.add(cmdDefaultFilter, new GridBagConstraints(2, 0, 1,
		1, 1.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE,
		new Insets(5, 5, 5, 5), 0, 0));
	pnlFilterControls.add(cmdRevertFilter, new GridBagConstraints(1, 0, 1,
		1, 0.0, 0.0, GridBagConstraints.CENTER,
		GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 0), 0, 0));
	final GridBagConstraints gbc_pnlFilterControls = new GridBagConstraints();
	gbc_pnlFilterControls.fill = GridBagConstraints.BOTH;
	gbc_pnlFilterControls.insets = new Insets(0, 0, 5, 0);
	gbc_pnlFilterControls.gridx = 0;
	gbc_pnlFilterControls.gridy = 2;
	pnlFilter.add(pnlFilterControls, gbc_pnlFilterControls);
	prgFilterProgress.setTitleFont(Frame.fontBold);
	final GridBagConstraints gbc_prgFilterProgress = new GridBagConstraints();
	gbc_prgFilterProgress.fill = GridBagConstraints.BOTH;
	gbc_prgFilterProgress.insets = new Insets(0, 0, 5, 0);
	gbc_prgFilterProgress.gridx = 0;
	gbc_prgFilterProgress.gridy = 3;
	pnlFilter.add(prgFilterProgress, gbc_prgFilterProgress);
	cmdExportFiltered.setEnabled(false);

	pnlDatafileTable.setBorder(BorderFactory.createLoweredBevelBorder());

	tpnFilter.add(pnlFilterLandscape, "Landscape");
	tpnFilter.add(pnlDatasetView, "Filtered Datafile");
	pnlDatasetView.add(pnlDatafileTable, java.awt.BorderLayout.CENTER);
	pnlDatasetView.add(pnlDatafileViewButtons, java.awt.BorderLayout.SOUTH);
	pnlDatafileViewButtons.add(cmdExportFiltered, new GridBagConstraints(0,
		0, 1, 1, 1.0, 0.0, GridBagConstraints.EAST,
		GridBagConstraints.NONE, new Insets(5, 5, 5, 5), 0, 0));
	final GridBagConstraints gbc_tpnFilter = new GridBagConstraints();
	gbc_tpnFilter.fill = GridBagConstraints.BOTH;
	gbc_tpnFilter.gridx = 0;
	gbc_tpnFilter.gridy = 4;
	pnlFilter.add(tpnFilter, gbc_tpnFilter);

	pnlFilterLandscape.setTextFont(Frame.fontFixed);
	pnlFilterLandscape.setEnabled(false);
	tpnAnalysis.add(pnlFilter, "Filter");
	final GridBagConstraints gbc_tpnAnalysis = new GridBagConstraints();
	gbc_tpnAnalysis.fill = GridBagConstraints.BOTH;
	gbc_tpnAnalysis.gridx = 0;
	gbc_tpnAnalysis.gridy = 0;
	pnlMain.add(tpnAnalysis, gbc_tpnAnalysis);
	tpnAnalysis.add(pnlConstruct, "Attribute Construction");
	tpnAnalysis.add(pnlCovariateAdjustment, "Covariate Adjustment");
	// load the page asynchronously because otherwise if there is a
	// connection
	// problem the entire gui stops entire the url times out (30+ seconds)
	final Thread loadAboutPanelThread = new Thread(new Runnable() {
	    @Override
	    public void run() {
		try {
		    // editorPaneAbout.setPage("http://discovery.dartmouth.edu");
		    editorPaneAbout.setPage(MDRProperties.get("about.url"));
		    tpnAnalysis.addTab("About MDR", null, pnlAbout, null);
		} catch (final IOException ex) {
		    // MDR url could not be read so no tab shown
		}
	    }
	}, "About Pane loader");
	loadAboutPanelThread.setDaemon(true); // kill this thread when program
					      // ends if still running
	loadAboutPanelThread.start();
	final GridBagLayout gbl_pnlAnalysis = new GridBagLayout();
	gbl_pnlAnalysis.columnWidths = new int[] { 683, 0 };
	gbl_pnlAnalysis.rowHeights = new int[] { 98, 60, 54, 125, 202, 0 };
	gbl_pnlAnalysis.columnWeights = new double[] { 1.0, Double.MIN_VALUE };
	gbl_pnlAnalysis.rowWeights = new double[] { 0.0, 0.0, 0.0, 0.0, 1.0,
		Double.MIN_VALUE };
	pnlAnalysis.setLayout(gbl_pnlAnalysis);
	pnlWarning.setTabPane(tpnResults);

	tpnResults.addOrderedTab(pnlGraphicalModel, "Graphical Model");
	tpnResults.addOrderedTab(pnlBestModel, "Best Model");
	tpnResults.addOrderedTab(pnlIfThenRules, "If-Then Rules");
	tpnResults.addOrderedTab(pnlCVResults, "CV Results");
	tpnResults.addOrderedTab(pnlEntropy, "Entropy");
	tpnResults.addOrderedTab(pnlTopModelsLandscape, "Top Models");
	tpnResults.setOrderedTabVisible(pnlTopModelsLandscape, false);
	tpnResults.addOrderedTab(pnlAllModelsLandscape, "Landscape");
	tpnResults.setOrderedTabVisible(pnlAllModelsLandscape, false);
	final GridBagConstraints gbc_panelTop = new GridBagConstraints();
	gbc_panelTop.anchor = GridBagConstraints.NORTH;
	gbc_panelTop.fill = GridBagConstraints.HORIZONTAL;
	gbc_panelTop.insets = new Insets(0, 0, 5, 0);
	gbc_panelTop.gridx = 0;
	gbc_panelTop.gridy = 0;
	pnlAnalysis.add(panelTop, gbc_panelTop);
	final GridBagLayout gbl_panelTop = new GridBagLayout();
	gbl_panelTop.columnWidths = new int[] { 0, 683, 0 };
	gbl_panelTop.rowHeights = new int[] { 98, 0 };
	gbl_panelTop.columnWeights = new double[] { 0.0, 1.0, Double.MIN_VALUE };
	gbl_panelTop.rowWeights = new double[] { 0.0, Double.MIN_VALUE };
	panelTop.setLayout(gbl_panelTop);
	final GridBagConstraints gbc_lblMdrIcon = new GridBagConstraints();
	gbc_lblMdrIcon.insets = new Insets(0, 0, 0, 5);
	gbc_lblMdrIcon.gridx = 0;
	gbc_lblMdrIcon.gridy = 0;
	lblMdrIcon.setIcon(new ImageIcon(Frame.class
		.getResource("/images/mdrlogo.png")));
	lblMdrIcon
		.setToolTipText("http://www.multifactordimensionalityreduction.org/");
	panelTop.add(lblMdrIcon, gbc_lblMdrIcon);
	final GridBagConstraints gbc_pnlDatafileInformation = new GridBagConstraints();
	gbc_pnlDatafileInformation.anchor = GridBagConstraints.NORTH;
	gbc_pnlDatafileInformation.fill = GridBagConstraints.HORIZONTAL;
	gbc_pnlDatafileInformation.gridx = 1;
	gbc_pnlDatafileInformation.gridy = 0;
	panelTop.add(pnlDatafileInformation, gbc_pnlDatafileInformation);
	pnlDatafileInformation.setTitle("Datafile Information");
	pnlDatafileInformation.setTitleFont(Frame.fontBold);
	cmdLoadDatafile.setText("Load Datafile");
	cmdLoadDatafile.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		cmdLoadDataset();
	    }

	});

	cmdViewDatafile.setText("View Datafile");
	cmdViewDatafile.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		frmDatafile.setVisible(true);
		frmDatafile.readDatafile(Console.console.data);
		frmDatafile.toFront();
	    }
	});
	cmdViewDatafile.setEnabled(false);

	lblDatafile.setText("Datafile:");

	lblAttributes.setText("Attributes:");

	lblInstances.setText("Instances:");

	lblRatio.setText("Ratio:");

	pnlDatafileInformation.add(pnlDatafile, new GridBagConstraints(0, 0, 3,
		1, 1.0, 0.0, GridBagConstraints.CENTER,
		GridBagConstraints.HORIZONTAL, new Insets(0, 5, 0, 0), 0, 0));
	pnlDatafileInformation.add(cmdLoadDatafile, new GridBagConstraints(3,
		0, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER,
		GridBagConstraints.HORIZONTAL, new Insets(0, 5, 0, 5), 0, 0));
	pnlDatafileInformation.add(pnlInstances, new GridBagConstraints(0, 1,
		1, 1, 1.0, 0.0, GridBagConstraints.CENTER,
		GridBagConstraints.HORIZONTAL, new Insets(0, 5, 0, 0), 0, 0));
	pnlInstances.add(lblInstances, new GridBagConstraints(0, 0, 1, 1, 0.0,
		0.0, GridBagConstraints.CENTER, GridBagConstraints.NONE,
		new Insets(0, 0, 0, 0), 0, 0));
	pnlInstances.add(lblInstancesValue, new GridBagConstraints(1, 0, 1, 1,
		1.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE,
		new Insets(0, 5, 0, 0), 0, 0));
	pnlDatafileInformation.add(pnlAttributes, new GridBagConstraints(1, 1,
		1, 1, 1.0, 0.0, GridBagConstraints.CENTER,
		GridBagConstraints.HORIZONTAL, new Insets(0, 5, 0, 0), 0, 0));
	pnlAttributes.add(lblAttributes, new GridBagConstraints(0, 0, 1, 1,
		0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.NONE,
		new Insets(0, 0, 0, 0), 0, 0));
	pnlAttributes.add(lblAttributesValue, new GridBagConstraints(1, 0, 1,
		1, 1.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE,
		new Insets(0, 5, 0, 0), 0, 0));
	pnlDatafileInformation.add(pnlRatio, new GridBagConstraints(2, 1, 1, 1,
		1.0, 0.0, GridBagConstraints.CENTER,
		GridBagConstraints.HORIZONTAL, new Insets(0, 5, 0, 0), 0, 0));
	pnlRatio.add(lblRatio, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0,
		GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(
			0, 0, 0, 0), 0, 0));
	pnlRatio.add(lblRatioValue, new GridBagConstraints(1, 0, 1, 1, 1.0,
		0.0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL,
		new Insets(0, 5, 0, 0), 0, 0));
	pnlDatafileInformation.add(cmdViewDatafile, new GridBagConstraints(3,
		1, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER,
		GridBagConstraints.HORIZONTAL, new Insets(5, 5, 5, 5), 0, 0));
	pnlDatafileInformation.add(pnlUsedMem, new GridBagConstraints(0, 2, 1,
		1, 1.0, 0.0, GridBagConstraints.CENTER,
		GridBagConstraints.HORIZONTAL, new Insets(0, 5, 0, 0), 0, 0));
	pnlUsedMem.add(lblUsedMemLabel, new GridBagConstraints(0, 0, 1, 1, 0.0,
		0.0, GridBagConstraints.CENTER, GridBagConstraints.NONE,
		new Insets(0, 0, 0, 0), 0, 0));
	pnlUsedMem.add(lblUsedMem, new GridBagConstraints(1, 0, 1, 1, 1.0, 0.0,
		GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0,
			5, 0, 0), 0, 0));
	pnlDatafileInformation.add(pnlTotalMem, new GridBagConstraints(1, 2, 1,
		1, 1.0, 0.0, GridBagConstraints.CENTER,
		GridBagConstraints.HORIZONTAL, new Insets(0, 5, 0, 0), 0, 0));
	pnlTotalMem.add(lblTotalMemLabel, new GridBagConstraints(0, 0, 1, 1,
		0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.NONE,
		new Insets(0, 0, 0, 0), 0, 0));
	pnlTotalMem.add(lblTotalMem, new GridBagConstraints(1, 0, 1, 1, 1.0,
		0.0, GridBagConstraints.WEST, GridBagConstraints.NONE,
		new Insets(0, 5, 0, 0), 0, 0));
	pnlDatafileInformation.add(pnlMaxMem, new GridBagConstraints(2, 2, 1,
		1, 1.0, 0.0, GridBagConstraints.CENTER,
		GridBagConstraints.HORIZONTAL, new Insets(0, 5, 0, 0), 0, 0));
	pnlMaxMem.add(lblMaxMemLabel, new GridBagConstraints(0, 0, 1, 1, 0.0,
		0.0, GridBagConstraints.CENTER, GridBagConstraints.NONE,
		new Insets(0, 0, 0, 0), 0, 0));
	pnlMaxMem.add(lblMaxMem, new GridBagConstraints(1, 0, 1, 1, 1.0, 0.0,
		GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(0,
			5, 0, 0), 0, 0));
	pnlDatafile.add(lblDatafile, new GridBagConstraints(0, 0, 1, 1, 0.0,
		0.0, GridBagConstraints.CENTER, GridBagConstraints.NONE,
		new Insets(0, 0, 0, 0), 0, 0));
	pnlDatafile.add(lblDatafileFiltered, new GridBagConstraints(3, 0, 1, 1,
		1.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE,
		new Insets(0, 0, 0, 0), 0, 0));
	pnlDatafile.add(lblDatafileValue, new GridBagConstraints(1, 0, 1, 1,
		0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE,
		new Insets(0, 5, 0, 0), 0, 0));
	pnlDatafile.add(lblDatafileLoaded, new GridBagConstraints(2, 0, 1, 1,
		0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE,
		new Insets(0, 0, 0, 0), 0, 0));
	pnlSummaryTable.setMinimumSize(new Dimension(16, 125));
	pnlSummaryTable.setPreferredSize(new Dimension(0, 125));
	pnlSummaryTable.setTitle("Summary Table");
	pnlSummaryTable.setTitleFont(Frame.fontBold);
	scpSummaryTable.setBorder(BorderFactory.createLoweredBevelBorder());
	tblSummaryTable.setModel(dtmSummaryTable);
	// tblSummaryTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
	tblSummaryTable.getTableHeader().setReorderingAllowed(false);
	tblSummaryTable.getSelectionModel().setSelectionMode(
		ListSelectionModel.SINGLE_SELECTION);
	tblSummaryTable.getSelectionModel().addListSelectionListener(
		new ListSelectionListener() {
		    @Override
		    public void valueChanged(final ListSelectionEvent e) {
			if (e.getValueIsAdjusting()) {
			    return;
			}
			final List<Collector> collectors = loadedCollectors == null ? (analysis == null ? null
				: analysis.getCollectors())
				: loadedCollectors;
			if (collectors == null) {
			    return;
			}
			AmbiguousCellStatus tiePriority;
			if (analysis == null) {
			    tiePriority = Main.defaultAmbiguousCellStatus;
			} else {
			    tiePriority = analysis.getTiePriority();
			}
			final int row = tblSummaryTable.getSelectedRow();
			if (row < 0) {
			    clearTabs(true);
			} else {
			    final Collector rowCollector = collectors.get(row);
			    // System.err.println("clicked on row index: " + row
			    // + " which is collector: " + rowCollector);
			    new Thread(new Runnable() {

				@Override
				public void run() {
				    tpnResults.setOrderedTabVisible(
					    pnlTopModelsLandscape, true);
				    final TopModelsLandscape landscape = new TopModelsLandscape(
					    rowCollector);
				    pnlTopModelsLandscape.setLandscape(
					    landscape, true);
				    pnlTopModelsLandscape.setEnabled(true);
				}

			    }, "TopModelsLandscapeThread").start();
			    final int intervals = rowCollector
				    .getNumIntervals();
			    new TextComponentUpdaterThread(
				    txaBestModel,
				    new BestModelTextGenerator(
					    Console.console.data, tiePriority,
					    rowCollector.getBestModel(),
					    intervals,
					    Main.decimalUpToFourPrecision,
					    Main.pValueTol, chkBestModelVerbose
						    .isSelected()),
				    new ComponentEnabler(cmdBestModelSave, true))
				    .start();
			    if (intervals > 1) {
				new TextComponentUpdaterThread(txaCVResults,
					new CVResultsTextGenerator(
						Console.console.data,
						rowCollector, tiePriority,
						Console.console.data
							.getAffectedStatus(),
						Main.decimalUpToFourPrecision,
						Main.pValueTol,
						chkCVResultsVerbose
							.isSelected()),
					new ComponentEnabler(cmdCVResultsSave,
						true)).start();
			    }
			    new TextComponentUpdaterThread(txaIfThenRules,
				    new IfThenRulesTextGenerator(
					    Console.console.data, rowCollector
						    .getBestModel()),
				    new ComponentEnabler(cmdIfThenRulesSave,
					    true)).start();
			    pnlGraphicalModel.setDatasetAndModel(
				    Console.console.data, rowCollector
					    .getBestModel().getModel());
			    setModelDependentItemsEnabled(true);
			    pnlGraphicalModel.setEnabled(true);
			}
		    }
		});
	tbcModel = tblSummaryTable.getColumnModel().getColumn(0);
	tbcModel.setPreferredWidth(125);
	tbcTrainingValue = tblSummaryTable.getColumnModel().getColumn(1);
	tbcTestingValue = tblSummaryTable.getColumnModel().getColumn(2);
	tbcCVConsistency = tblSummaryTable.getColumnModel().getColumn(3);
	tbcTrainingValue.setPreferredWidth(125);
	tbcTrainingValue.setCellRenderer(dcrRightJustified);
	tbcTestingValue.setPreferredWidth(125);
	tbcTestingValue.setCellRenderer(dcrRightJustified);
	tbcCVConsistency.setPreferredWidth(125);
	tbcCVConsistency.setCellRenderer(dcrRightJustified);
	pnlSummaryTable.add(scpSummaryTable, java.awt.BorderLayout.CENTER);
	tblSummaryTable.setVisible(true);
	cmdRunAnalysis.setText(Frame.RUN_ANALYSIS);
	cmdRunAnalysis.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		cmdRunAnalysis();
	    }
	});
	cmdRunAnalysis.setEnabled(false);

	cmdLoadAnalysis.setText("Load Analysis");
	cmdLoadAnalysis.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		cmdLoadAnalysis();
	    }

	});
	cmdLoadAnalysis.setEnabled(true);

	cmdSaveAnalysis.setText("Save Analysis");
	cmdSaveAnalysis.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		cmdSaveAnalysis();
	    }
	});
	cmdSaveAnalysis.setEnabled(false);

	cmdExport.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		Frame.cmdExportData();
	    }
	});

	final GridBagLayout gridBagLayout_2 = (GridBagLayout) pnlAnalysisControls
		.getLayout();
	gridBagLayout_2.columnWeights = new double[] { 0.0, 0.0, 0.0, 1.0, 0.0,
		0.0 };
	gridBagLayout_2.columnWidths = new int[] { 0, 0, 80, 133, 98, 0 };

	pnlAnalysisControls.setTitle("Analysis Controls");
	pnlAnalysisControls.setTitleFont(Frame.fontBold);
	pnlAnalysisControls.add(cmdRunAnalysis, new GridBagConstraints(0, 0, 1,
		1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE,
		new Insets(5, 5, 0, 5), 0, 0));
	pnlAnalysisControls.add(cmdLoadAnalysis, new GridBagConstraints(1, 0,
		1, 1, 0.0, 0.0, GridBagConstraints.CENTER,
		GridBagConstraints.NONE, new Insets(5, 5, 0, 5), 0, 0));
	pnlAnalysisControls.add(cmdSaveAnalysis, new GridBagConstraints(2, 0,
		1, 1, 0.0, 0.0, GridBagConstraints.WEST,
		GridBagConstraints.NONE, new Insets(5, 5, 0, 5), 0, 0));

	cmdRevert
		.setToolTipText("<html>Whenever filtering or covariate adjustment is done<br>a snapshot of the data is saved. This will change<br>the datafile to the most recent snapshot.</html>");
	cmdRevert.setEnabled(false);

	cmdRevert.addActionListener(cmdRevertActionListener);

	final GridBagConstraints gbc_lblLowMemory = new GridBagConstraints();
	gbc_lblLowMemory.fill = GridBagConstraints.BOTH;
	gbc_lblLowMemory.insets = new Insets(0, 0, 0, 5);
	gbc_lblLowMemory.gridx = 3;
	gbc_lblLowMemory.gridy = 0;
	lblLowMemory.setVisible(false);
	lblLowMemory.setOpaque(true);
	lblLowMemory.setHorizontalAlignment(SwingConstants.CENTER);
	lblLowMemory.setFont(new Font("Tahoma", Font.BOLD, 14));
	lblLowMemory.setForeground(Color.BLACK);
	lblLowMemory.setBackground(Color.RED);
	pnlAnalysisControls.add(lblLowMemory, gbc_lblLowMemory);
	pnlAnalysisControls.add(cmdRevert, new GridBagConstraints(4, 0, 1, 1,
		1.0, 0.0, GridBagConstraints.EAST, GridBagConstraints.NONE,
		new Insets(5, 5, 0, 5), 0, 0));
	pnlAnalysisControls.add(cmdExport, new GridBagConstraints(5, 0, 1, 1,
		1.0, 0.0, GridBagConstraints.EAST, GridBagConstraints.NONE,
		new Insets(5, 5, 0, 0), 0, 0));
	final GridBagConstraints gbc_pnlAnalysisControls = new GridBagConstraints();
	gbc_pnlAnalysisControls.anchor = GridBagConstraints.NORTH;
	gbc_pnlAnalysisControls.fill = GridBagConstraints.HORIZONTAL;
	gbc_pnlAnalysisControls.insets = new Insets(0, 0, 5, 0);
	gbc_pnlAnalysisControls.gridx = 0;
	gbc_pnlAnalysisControls.gridy = 1;
	pnlAnalysis.add(pnlAnalysisControls, gbc_pnlAnalysisControls);
	prgProgress.setTitleFont(Frame.fontBold);
	final GridBagConstraints gbc_prgProgress = new GridBagConstraints();
	gbc_prgProgress.anchor = GridBagConstraints.NORTH;
	gbc_prgProgress.fill = GridBagConstraints.HORIZONTAL;
	gbc_prgProgress.insets = new Insets(0, 0, 5, 0);
	gbc_prgProgress.gridx = 0;
	gbc_prgProgress.gridy = 2;
	pnlAnalysis.add(prgProgress, gbc_prgProgress);
	scpSummaryTable.setViewportView(tblSummaryTable);
	final GridBagConstraints gbc_pnlSummaryTable = new GridBagConstraints();
	gbc_pnlSummaryTable.fill = GridBagConstraints.HORIZONTAL;
	gbc_pnlSummaryTable.insets = new Insets(0, 0, 5, 0);
	gbc_pnlSummaryTable.gridx = 0;
	gbc_pnlSummaryTable.gridy = 3;
	pnlAnalysis.add(pnlSummaryTable, gbc_pnlSummaryTable);
	final GridBagConstraints gbc_tpnResults = new GridBagConstraints();
	gbc_tpnResults.fill = GridBagConstraints.BOTH;
	gbc_tpnResults.gridx = 0;
	gbc_tpnResults.gridy = 4;
	pnlAnalysis.add(tpnResults, gbc_tpnResults);
	setConfigToDefaults();
	setFilterToDefaults();
	setEnabledDataDependentGuiItems(false);
	setModelDependentItemsEnabled(false);
	pack(); // layout components
    }

    public void loadAnalysis(final File savedAnalysisFile) {
	final Thread loadThread = new Thread(new Runnable() {
	    @Override
	    public void run() {
		try {
		    final SwingInvoker progressUpdater = indeterminateProgressUpdaterStart("Loading saved analysis: "
			    + savedAnalysisFile.getName());
		    lockdown(true);
		    // create a blank placeholder dataset since code
		    // doesn't deal well with no dataset
		    Console.console.setDataset(
			    Dataset.createPlaceholderDataset(),
			    Console.DatasetStackAction.CLEAR_STACK);
		    datafileName = "";
		    Dataset unfiltered = null;
		    loadedCollectors = null;
		    dataFileChange();
		    try {
			afm = new AnalysisFileManager();
			final LineNumberReader lnr = new LineNumberReader(
				new FileReader(savedAnalysisFile));
			afm.read(lnr, progressUpdater);
			lnr.close();
			Console.console.setDataset(afm.getDataset(),
				Console.DatasetStackAction.CLEAR_STACK);

			if (afm.getFiltered() != null) {
			    unfiltered = afm.getDataset();
			    Console.console.setDataset(afm.getFiltered(),
				    Console.DatasetStackAction.PUSH_ONTO_STACK);
			}
			spnAttributeCountMin
				.setValue(new Integer(afm.getMin()));
			spnAttributeCountMax
				.setValue(new Integer(afm.getMax()));
			spnCrossValidationCount.setValue(new Integer(afm
				.getIntervals()));
			chkPairedAnalysis.setSelected(afm.isPaired());
			spnRandomSeed.setValue(afm.getRandomSeed());
			chkComputeAllModelsLandscape.setSelected(afm
				.getAllModelsLandscape() != null);
			final AmbiguousCellStatus tiePriority = afm
				.getTiePriority();
			setComboAmbiguousStatus(tiePriority);
			datafileName = afm.getDatafileName();

			dataFileChange();

			forced = afm.getForced();
			if (forced != null) {
			    txtForcedAttributeCombination.setText(afm
				    .getForced() == null ? "" : Utility.join(
				    afm.getForced(), " "));
			}

			if ((afm.getAllModelsLandscape() != null)
				&& !afm.getAllModelsLandscape().isEmpty()) {
			    pnlAllModelsLandscape.setLandscape(
				    afm.getAllModelsLandscape(), true);
			    pnlAllModelsLandscape.setEnabled(true);
			    tpnResults.setOrderedTabVisible(
				    pnlAllModelsLandscape, true);
			} else {
			    tpnResults.setOrderedTabVisible(
				    pnlAllModelsLandscape, false);
			}
			loadedCollectors = afm.getCollectors();
			final Collector lastCollector = loadedCollectors
				.get(loadedCollectors.size() - 1);
			pnlTopModelsLandscape.setLandscape(null, true);
			spnTopModels.setValue(lastCollector.size());
			tpnResults.setOrderedTabVisible(pnlTopModelsLandscape,
				true);
			pnlTopModelsLandscape.setEnabled(true);
			for (final Collector coll : loadedCollectors) {
			    addTableRow(coll.getBestModel(), afm.getIntervals());
			}
			final String wrapper = afm
				.getCfg(AnalysisFileManager.cfgWrapper);
			if ((wrapper == null)
				|| wrapper
					.equalsIgnoreCase(AnalysisFileManager.cfgValExhaustive)) {
			    cboSearchType
				    .setSelectedItem(SearchMethod.EXHAUSTIVE);
			} else if (wrapper
				.equalsIgnoreCase(AnalysisFileManager.cfgValForced)) {
			    cboSearchType.setSelectedItem(SearchMethod.FORCED);
			} else if (wrapper
				.equalsIgnoreCase(AnalysisFileManager.cfgValRandom)) {
			    cboSearchType.setSelectedItem(SearchMethod.RANDOM);
			    String s = afm
				    .getCfg(AnalysisFileManager.cfgEvaluations);
			    if (s != null) {
				rdoEvaluations.setSelected(true);
				spnEvaluations.setValue(Integer.valueOf(s));
			    } else {
				s = afm.getCfg(AnalysisFileManager.cfgRuntime);
				rdoRuntime.setSelected(true);
				spnRuntime.setValue(Double.valueOf(s));
				s = afm.getCfg(AnalysisFileManager.cfgRuntimeUnits);
				TimeUnits timeUnit;
				try {
				    timeUnit = Enum.valueOf(TimeUnits.class, s);
				} catch (final IllegalArgumentException ex) {
				    timeUnit = TimeUnits.Minutes;
				}
				cboUnits.setSelectedItem(timeUnit);
			    }
			} else if (wrapper
				.equalsIgnoreCase(AnalysisFileManager.cfgValEDA)) {
			    cboSearchType.setSelectedItem(SearchMethod.EDA);
			    spnNumAgents.getModel().setValue(
				    Integer.valueOf(afm
					    .getCfg(EDAVariables.numAgents)));
			    spnNumUpdates.getModel().setValue(
				    Integer.valueOf(afm
					    .getCfg(EDAVariables.numUpdates)));
			    final String scores = afm
				    .getCfg(EDAVariables.scores);

			    spnBeta.setEnabled(scores != null);
			    cmdViewExpertKnowledge.setEnabled(scores != null);

			    ExpertKnowledge newExpertKnowledge;
			    String scoreFileName;
			    if (scores != null) {
				newExpertKnowledge = new ExpertKnowledge(
					scores,
					afm.getDataset().getLabels(),
					ExpertKnowledge.SAVED_ANALYSIS_SCORES_DELIMITER_PATTERN,
					ExpertKnowledge.SAVED_ANALYSIS_LABEL_SCORE_SEPARATOR_PATTERN);
				scoreFileName = "<scores from saved analysis>";
			    } else {
				newExpertKnowledge = null;
				scoreFileName = "";
			    }
			    expertKnowledgeSetEnabled(scoreFileName,
				    newExpertKnowledge);
			    final ScalingMethod scalingMethod = Enum.valueOf(
				    ScalingMethod.class,
				    afm.getCfg(EDAVariables.scalingMethod));
			    final double scalingParameter = Double.valueOf(afm
				    .getCfg(EDAVariables.scalingpParameter));
			    setEDAScalingUIElements(scalingMethod,
				    scalingParameter);

			    final WeightScheme weightScheme = Enum.valueOf(
				    WeightScheme.class,
				    afm.getCfg(EDAVariables.weightScheme));
			    setEDAWeightSchemeUIElements(weightScheme,
				    scalingParameter);
			    spnAlpha.getModel().setValue(
				    Double.valueOf(afm
					    .getCfg(EDAVariables.alpha)));
			    spnBeta.getModel().setValue(
				    Integer.valueOf(afm
					    .getCfg(EDAVariables.beta)));
			    spnRetention.getModel().setValue(
				    Double.valueOf(afm
					    .getCfg(EDAVariables.decay)));
			    refreshExpertKnowledgeFileDisplay();

			} else {
			    throw new RuntimeException(
				    "DO NOT RECOGNIZE SEARCH TYPE FROM SAVED ANALYSIS: "
					    + wrapper);
			}
			if (unfiltered != null) {
			    final String filtername = afm.getFilterConfig()
				    .get("FILTER");
			    FilterMethod filterMethod = null;
			    try {
				filterMethod = Enum.valueOf(FilterMethod.class,
					filtername.toUpperCase());
			    } catch (final IllegalArgumentException ex) {
				// if not one of the enums should be
				// a file containing attributes
				JOptionPane
					.showMessageDialog(
						Frame.this,
						"Unable to open analysis '"
							+ savedAnalysisFile
							+ "'. Unrecognized filter type: "
							+ filtername,
						"Datafile Error",
						JOptionPane.ERROR_MESSAGE);
			    }
			    switch (filterMethod) {
			    case RELIEFF: {
				cboFilter.setSelectedItem(FilterMethod.RELIEFF);
				pnlFilterLandscape
					.setYAxisLabel(FilterMethod.RELIEFF
						.toString());
				final String samples = afm.getFilterConfig()
					.get("SAMPLES");
				if (samples.equalsIgnoreCase("ALL")) {
				    chkReliefFWholeDataset.setSelected(true);
				} else {
				    chkReliefFWholeDataset.setSelected(false);
				    spnReliefFSampleSize.setValue(Integer
					    .valueOf(samples));
				}
				if (afm.getFilterConfig().containsKey(
					"NEIGHBORS")) {
				    spnReliefFNeighbors.setValue(Integer
					    .valueOf(afm.getFilterConfig().get(
						    "NEIGHBORS")));
				}
			    }
				break;
			    case TURF: {
				cboFilter.setSelectedItem(FilterMethod.TURF);
				pnlFilterLandscape
					.setYAxisLabel(FilterMethod.TURF
						.toString());
				final String samples = afm.getFilterConfig()
					.get("SAMPLES");
				if (samples.equalsIgnoreCase("ALL")) {
				    chkTuRFWholeDataset.setSelected(true);
				} else {
				    chkTuRFWholeDataset.setSelected(false);
				    spnTuRFSampleSize.setValue(Integer
					    .valueOf(samples));
				}
				if (afm.getFilterConfig().containsKey(
					"NEIGHBORS")) {
				    spnTuRFNeighbors.setValue(Integer
					    .valueOf(afm.getFilterConfig().get(
						    "NEIGHBORS")));
				}
				if (afm.getFilterConfig().containsKey("PCT")) {
				    spnTuRFPercent
					    .setValue(Float.valueOf(afm
						    .getFilterConfig().get(
							    "PCT")) * 100);
				}
			    }
				break;
			    case CHISQUARED: {
				cboFilter
					.setSelectedItem(FilterMethod.CHISQUARED);
				pnlFilterLandscape
					.setYAxisLabel(FilterMethod.CHISQUARED
						.toString());
				if (afm.getFilterConfig().containsKey("PVALUE")) {
				    chkChiSquaredPValue.setSelected(Boolean
					    .valueOf(
						    afm.getFilterConfig().get(
							    "PVALUE"))
					    .booleanValue());
				}
			    }
				break;
			    case ATTRIBUTE_FILE:
				cboFilter
					.setSelectedItem(FilterMethod.ATTRIBUTE_FILE);
				pnlFilterLandscape
					.setYAxisLabel(FilterMethod.ATTRIBUTE_FILE
						.toString());
				break;
			    case MULTISURF: {
				cboFilter
					.setSelectedItem(FilterMethod.MULTISURF);
				pnlFilterLandscape
					.setYAxisLabel(FilterMethod.MULTISURF
						.toString());
			    }
				break;
			    case MULTISURFNTURF: {
				cboFilter
					.setSelectedItem(FilterMethod.MULTISURFNTURF);
				pnlFilterLandscape
					.setYAxisLabel(FilterMethod.MULTISURFNTURF
						.toString());
				if (afm.getFilterConfig().containsKey("PCT")) {
				    spnMultiSURFnTuRFPercent.setValue(Float
					    .valueOf(afm.getFilterConfig().get(
						    "PCT")) * 100);
				}
			    }
				break;
			    case ODDSRATIO: {
				cboFilter
					.setSelectedItem(FilterMethod.ODDSRATIO);
				pnlFilterLandscape
					.setYAxisLabel(FilterMethod.ODDSRATIO
						.toString());
			    }
				break;
			    case SURF: {
				cboFilter.setSelectedItem(FilterMethod.SURF);
				pnlFilterLandscape
					.setYAxisLabel(FilterMethod.SURF
						.toString());
			    }
				break;
			    case SURFNTURF: {
				cboFilter
					.setSelectedItem(FilterMethod.SURFNTURF);
				pnlFilterLandscape
					.setYAxisLabel(FilterMethod.SURFNTURF
						.toString());
				if (afm.getFilterConfig().containsKey("PCT")) {
				    spnSURFnTuRFPercent.setValue(Float
					    .valueOf(afm.getFilterConfig().get(
						    "PCT")) * 100);
				}
			    }
				break;
			    case SURFSTAR: {
				cboFilter
					.setSelectedItem(FilterMethod.SURFSTAR);
				pnlFilterLandscape
					.setYAxisLabel(FilterMethod.SURFSTAR
						.toString());
			    }
				break;
			    case SURFSTARNTURF: {
				cboFilter
					.setSelectedItem(FilterMethod.SURFSTARNTURF);
				pnlFilterLandscape
					.setYAxisLabel(FilterMethod.SURFSTARNTURF
						.toString());
				if (afm.getFilterConfig().containsKey("PCT")) {
				    spnSURFStarnTuRFPercent.setValue(Float
					    .valueOf(afm.getFilterConfig().get(
						    "PCT")) * 100);
				}
			    }
				break;
			    default:
				JOptionPane.showMessageDialog(Frame.this,
					"Unable to open analysis '"
						+ savedAnalysisFile
						+ "'. Unhandled filter type: "
						+ filtername, "Datafile Error",
					JOptionPane.ERROR_MESSAGE);
				break;

			    } // end FilterMethod switch

			    final String selection = afm.getFilterConfig().get(
				    "SELECTION");
			    final String selectionvalue = afm.getFilterConfig()
				    .get("SELECTIONVALUE");
			    if (selection != null) {
				if (selection.equalsIgnoreCase("TOPN")) {
				    cboFilterCriterion.setSelectedIndex(0);
				    if (selectionvalue != null) {
					spnCriterionFilter.setValue(Integer
						.valueOf(selectionvalue));
				    }
				} else if (selection.equalsIgnoreCase("TOP%")) {
				    cboFilterCriterion.setSelectedIndex(1);
				    if (selectionvalue != null) {
					spnCriterionFilter.setValue(Double
						.valueOf(selectionvalue));
				    }
				} else if (selection
					.equalsIgnoreCase("THRESHOLD")) {
				    cboFilterCriterion.setSelectedIndex(2);
				    if (selectionvalue != null) {
					spnCriterionFilter.setValue(Double
						.valueOf(selectionvalue));
				    }
				}
			    }
			    final List<String> labels = unfiltered.getLabels();
			    final List<Pair<Integer, Float>> scores = afm
				    .getFilterScores();
			    final List<LabeledFloatInterface> landscapeList = new ArrayList<LabeledFloatInterface>(
				    scores.size());
			    for (final Pair<Integer, Float> p : scores) {
				final LabeledFloat labeledFloat = new LabeledFloat(
					labels.get(p.getFirst()), p.getSecond());
				landscapeList.add(labeledFloat);
			    }
			    pnlFilterLandscape
				    .setLandscape(new LabeledFloatListLandscape(
					    landscapeList));
			    pnlFilterLandscape.setEnabled(true);
			    cmdExportFiltered.setEnabled(true);
			}
			pnlEntropy.updateEntropyDisplay(afm.getDataset(),
				afm.getCollectors(), afm.getMin(),
				afm.getMax(), afm.getTiePriority());
			final boolean displayTestingColumn = (afm
				.getIntervals() > 1);
			final boolean displayCvcColumn = displayTestingColumn
				&& !AnalysisFileManager.cfgValForced
					.equalsIgnoreCase(afm
						.getCfg(AnalysisFileManager.cfgWrapper));
			setTestingAndCvcColumnsDisplay(displayTestingColumn,
				displayCvcColumn);
			analysis = null;
		    } catch (final Exception ex) {
			Utility.logException(ex);
			JOptionPane
				.showMessageDialog(
					Frame.this,
					"Unable to open analysis '"
						+ savedAnalysisFile
						+ "' or unrecognized file format.\n\nIs it possible you meant to use 'Load Datafile'?\n\nMessage:\n"
						+ ex, "Datafile Error",
					JOptionPane.ERROR_MESSAGE);
			// create a blank placeholder dataset since
			// code doesn't deal well with no dataset
			Console.console.setDataset(
				Dataset.createPlaceholderDataset(),
				Console.DatasetStackAction.CLEAR_STACK);
			datafileName = "";
			unfiltered = null;
			loadedCollectors = null;
			analysis = null;
		    }
		} finally {
		    indeterminateProgressUpdaterStop();
		    lockdown(false);
		}
	    } // end run

	    private void setEDAScalingUIElements(
		    final ScalingMethod scalingMethod,
		    final double scalingParameter) {
		rdoLinearKnowledge.setSelected(scalingMethod
			.equals(ScalingMethod.LINEAR));
		spnExponentialTheta
			.setEnabled(scalingMethod == ScalingMethod.EXPONENTIAL);
		spnLinearMaxPercent
			.setEnabled(scalingMethod == ScalingMethod.LINEAR);
		switch (scalingMethod) {
		case EXPONENTIAL:
		    spnExponentialTheta.getModel().setValue(scalingParameter);
		    spnLinearMaxPercent.getModel().setValue(
			    Main.defaultEDAPercentMaxAttributeRange);
		    break;
		case LINEAR:
		    spnLinearMaxPercent.getModel().setValue(
			    scalingParameter * 100.0);
		    spnExponentialTheta.getModel().setValue(
			    Main.defaultEDAExponentialTheta);
		    break;
		default:
		    throw new RuntimeException("unhandled scalingMethod: "
			    + scalingMethod);
		    // break;
		}
	    }

	    private void setEDAWeightSchemeUIElements(
		    final WeightScheme weightScheme,
		    final double scalingParameter) {
		rdoRankedSelection.setSelected(weightScheme
			.equals(WeightScheme.RANK));

	    }

	}, "LoadSavedAnalysisThread");
	loadThread.start();
    }

    private void lockdown(final boolean lock) {
	System.gc();
	if (lock) {
	    setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
	}
	pnlConstruct.setWarnOnChange(!lock);
	pnlCovariateAdjustment.setWarnOnChange(!lock);
	cmdFilter.setEnabled(!lock);
	cmdLoadDatafile.setEnabled(!lock);
	cmdLoadAnalysis.setEnabled(!lock);
	lblRandomSeed.setEnabled(!lock);
	spnRandomSeed.setEnabled(!lock);
	lblForcedAttributeCombination.setEnabled(!lock);
	txtForcedAttributeCombination.setEnabled(!lock);
	rdoAmbiguousCellCriteriaTieCells.setEnabled(!lock);
	rdoAmbiguousCellCriteriaFishersExact.setEnabled(!lock);
	lblAmbiguousCellAssignment.setEnabled(!lock);
	cboAmbiguousCellStatuses.setEnabled(!lock);
	lblPairedAnalysis.setEnabled(!lock);
	lblComputeAllModelsLandscape.setEnabled(!lock);
	spnTopModels.setEnabled(!lock);
	lblFilter.setEnabled(!lock);
	cboFilter.setEnabled(!lock);
	lblCriterion.setEnabled(!lock);
	cboFilterCriterion.setEnabled(!lock);
	lblCriterionValue.setEnabled(!lock);
	spnCriterionFilter.setEnabled(!lock);
	chkChiSquaredPValue.setEnabled(!lock);
	lblReliefFNeighbors.setEnabled(!lock);
	spnReliefFNeighbors.setEnabled(!lock);
	chkReliefFWholeDataset.setEnabled(!lock);
	lblTuRFNeighbors.setEnabled(!lock);
	spnTuRFNeighbors.setEnabled(!lock);
	chkTuRFWholeDataset.setEnabled(!lock);
	chkTuRFWholeDataset.setEnabled(!lock);
	lblSearchType.setEnabled(!lock);
	cboSearchType.setEnabled(!lock);
	rdoEvaluations.setEnabled(!lock);
	rdoRuntime.setEnabled(!lock);
	lblCrossValidationCount.setEnabled(!lock);
	spnCrossValidationCount.setEnabled(!lock);
	pnlConstruct.setEnabled(!lock);
	pnlNetworkAnalysis.setEnabled(!lock);
	pnlCovariateAdjustment.setEnabled(!lock);
	setEnabledDataDependentGuiItems(!lock);
	setEnabledAttributeRangeDependentGuiComponents(!lock
		&& (forced == null));
	if (lock) {
	    cmdRunAnalysis.setEnabled(false);
	    cmdViewDatafile.setEnabled(false);
	    cmdSaveAnalysis.setEnabled(false);
	    cmdDefaultFilter.setEnabled(false);
	    cmdDefaults.setEnabled(false);
	    cmdRevert.setEnabled(false);
	    cmdRevertFilter.setEnabled(false);
	    cmdExportFiltered.setEnabled(false);
	    lblReliefFSampleSize.setEnabled(false);
	    spnReliefFSampleSize.setEnabled(false);
	    spnEvaluations.setEnabled(false);
	    spnRuntime.setEnabled(false);
	    chkPairedAnalysis.setEnabled(false);
	    lblUnits.setEnabled(false);
	    cboUnits.setEnabled(false);
	} else {
	    cmdRunAnalysis.setEnabled(datafileName.length() > 0);
	    cmdViewDatafile.setEnabled(datafileName.length() > 0);
	    cmdSaveAnalysis.setEnabled((datafileName.length() > 0)
		    && (analysis != null) && analysis.isComplete());
	    cmdDefaultFilter.setEnabled(!isDefaultFilter());
	    cmdDefaults.setEnabled(!isDefaultConfig());
	    cmdRevert.setEnabled(!Console.console.isDatasetStackEmpty());
	    cmdRevertFilter.setEnabled(!Console.console.isDatasetStackEmpty());
	    cmdExportFiltered.setEnabled(true);
	    lblReliefFSampleSize.setEnabled(!chkReliefFWholeDataset
		    .isSelected());
	    spnReliefFSampleSize.setEnabled(!chkReliefFWholeDataset
		    .isSelected());
	    spnEvaluations.setEnabled(rdoEvaluations.isSelected());
	    spnRuntime.setEnabled(rdoRuntime.isSelected());
	    chkPairedAnalysis.setEnabled(Console.console.data.canBePaired());
	    lblUnits.setEnabled(rdoRuntime.isSelected());
	    cboUnits.setEnabled(rdoRuntime.isSelected());
	    setCursor(Cursor.getDefaultCursor());
	}
	// pnlEntropy.lockdown(lock);
    }

    private void parseForcedSearchAttributes(final boolean showDialog) {
	final SearchMethod selected = (SearchMethod) cboSearchType
		.getSelectedItem();
	final boolean isForcedSearch = selected == SearchMethod.FORCED;
	if (!isForcedSearch
		|| (txtForcedAttributeCombination.getText().trim().length() == 0)) {
	    forced = null;
	} else {
	    try {
		forced = AttributeCombinationWithWildcards
			.parseComboWithPossibilityOfWildcards(
				txtForcedAttributeCombination.getText(),
				Console.console.data.getNumAttributes(),
				Console.console.data.getLabels());
		txtForcedAttributeCombination
			.setText(Utility.join(forced, " "));
	    } catch (final IllegalArgumentException ex) {
		if (showDialog) {
		    ex.printStackTrace();
		    JOptionPane
			    .showMessageDialog(
				    Frame.this,
				    "Forced search accepts "
					    + "lists of attribute labels or attribute column indices."
					    + ((!Console.console
						    .isDatasetStackEmpty()) ? " Perhaps attributes are currently filtered out?"
						    : "") + " Exception: "
					    + ex.toString(),
				    "Invalid Attribute Combination",
				    JOptionPane.ERROR_MESSAGE);
		}
	    }
	}
    }

    private void refreshExpertKnowledgeFileDisplay() {
	if (frmExpertKnowledge.isVisible()) {
	    createExpertKnowledgeRuntime();
	    frmExpertKnowledge.readDatafile(expertKnowledge);
	}
    }

    private void resetForm() {
	analysis = null;

	// System.err.println("reset form called from "
	// + Utility.stackTraceToString());
	dtmSummaryTable.setRowCount(0);
	prgProgress.setFractionComplete(0.0);
	prgFilterProgress.setFractionComplete(Console.console
		.isDatasetStackEmpty() ? 0 : 1);
	clearTabs(false);
	tpnResults.setSelectedComponent(pnlGraphicalModel);
	pnlConstruct.setWarnOnChange(false);
    }

    private void resetToReadyToRunAnalysis() {
	cmdRunAnalysis.setText(Frame.RUN_ANALYSIS);
	if (Frame.debugRunStopAnalysis) {
	    System.err.println("cmdRunAnalysis.setText()="
		    + cmdRunAnalysis.getText());
	}
	cmdRunAnalysis.setForeground(cmdLoadDatafile.getForeground());
	cmdRunAnalysis.repaint();
	prgProgress.setFractionComplete(1);
    }

    private void setComboAmbiguousStatus(final AmbiguousCellStatus tiePriority) {
	for (int index = 0; index < cboAmbiguousCellStatuses.getItemCount(); ++index) {
	    final AmbiguousCellStatus cboItemTiePriority = getAmbiguousStatusComboValue(index);
	    if (tiePriority == cboItemTiePriority) {
		cboAmbiguousCellStatuses.setSelectedIndex(index);
		break;
	    }
	}
    }

    public void setConfigToDefaults() {
	cmdDefaults.setEnabled(!isDefaultConfig(true));
    }

    private void setEnabledAttributeRangeDependentGuiComponents(
	    final boolean enable) {
	lblAttributeCountRange.setEnabled(enable);
	spnAttributeCountMin.setEnabled(enable);
	lblAttributeCountRangeColon.setEnabled(enable);
	spnAttributeCountMax.setEnabled(enable);
    }

    private void setEnabledDataDependentGuiItems(final boolean enable) {
	final boolean hasData = datafileName.length() > 0;
	final boolean hasDiscreteData = hasData
		&& !Console.console.data.hasContinuousEndpoints();
	// first panel always enabled
	tpnAnalysis.setEnabledAt(0, hasData);
	for (int componentIndex = 0; componentIndex < tpnAnalysis
		.getComponentCount(); ++componentIndex) {
	    final Component component = tpnAnalysis
		    .getComponentAt(componentIndex);
	    final boolean needsData = dataDependentPanels.contains(component);
	    final boolean disableBecauseNeedsData = needsData && !hasData;
	    final boolean needsDiscreteData = discreteEndpointDependentPanels
		    .contains(component);

	    final boolean disableBecauseNeedsDiscreteData = needsDiscreteData
		    && !hasDiscreteData;
	    if (!enable || disableBecauseNeedsData
		    || disableBecauseNeedsDiscreteData) {
		tpnAnalysis.setEnabledAt(componentIndex, false);
	    } else {
		tpnAnalysis.setEnabledAt(componentIndex, true);
		if (component.equals(pnlNetworkAnalysis)) {
		    pnlNetworkAnalysis.reinitialize();
		}
	    }
	} // end loop over tabs

	// no ambiguous cell/ robust MDR for continuous data
	for (final Component component : pnlAmbiguousCellAnalysis
		.getComponents()) {
	    component.setEnabled(!enable || hasDiscreteData);
	}

    }

    public void setFilterToDefaults() {
	cmdFilter.setEnabled(!isDefaultFilter(true));
	// cboFilter.setSelectedObject(Main.defaultFilterMethod);
	// cboCriterion.setSelectedIndex(Main.defaultCriterionIndex);
	// snmTopN.setValue(new Integer(Main.defaultCriterionFilterTopN));
	// snmTopPct.setValue(new Double(Main.defaultCriterionFilterTopPct));
	// snmThreshold.setValue(new
	// Double(Main.defaultCriterionFilterThreshold));
	// chkChiSquaredPValue.setSelected(Main.defaultChiSquaredPValue);
	// spnCriterionFilter.setModel(snmTopN);
	// chkReliefFWholeDataset.setSelected(Main.defaultReliefFWholeDataset);
	// spnReliefFNeighbors.setValue(new
	// Integer(Main.defaultReliefFNeighbors));
	// spnReliefFSampleSize.setValue(new
	// Integer(Main.defaultReliefFSampleSize));
	// chkTuRFWholeDataset.setSelected(Main.defaultReliefFWholeDataset);
	// spnTuRFNeighbors.setValue(new Integer(Main.defaultReliefFNeighbors));
	// spnTuRFSampleSize.setValue(new
	// Integer(Main.defaultReliefFSampleSize));
	// spnTuRFPercent.setValue(new Integer(Main.defaultTuRFPct));
	// chkSURFWholeDataset.setSelected(Main.defaultReliefFWholeDataset);
	// spnSURFSampleSize.setValue(new
	// Integer(Main.defaultReliefFSampleSize));
	// chkSURFStarWholeDataset.setSelected(Main.defaultReliefFWholeDataset);
	// spnSURFStarSampleSize.setValue(new
	// Integer(Main.defaultReliefFSampleSize));
	// chkSURFnTuRFWholeDataset.setSelected(Main.defaultReliefFWholeDataset);
	// spnSURFnTuRFSampleSize.setValue(new
	// Integer(Main.defaultReliefFSampleSize));
	// spnSURFnTuRFPercent.setValue(new Integer(Main.defaultTuRFPct));
    }

    private void setMetricUIItems() {
	Console.console.setMetricDisplayText();
	final String yAxisLabel = Console.console.topModelsFitnessCriteriaOrder
		.getPrimaryTest().getMdrTableColumnName().toString();
	pnlAllModelsLandscape.setYAxisLabel(yAxisLabel);
	pnlTopModelsLandscape.setYAxisLabel(yAxisLabel);
	// setTestingAndCvcColumnsDisplay() also uses metricShortText
    }

    private void setModelDependentItemsEnabled(final boolean enabled) {
	tpnResults.setEnabled(enabled);
    }

    private void setTestingAndCvcColumnsDisplay(
	    final boolean displayTestingColumn, final boolean displayCvcColumn) {
	// redraw column headers
	tblSummaryTable.getTableHeader().resizeAndRepaint();
	if (displayTestingColumn) {
	    if ((tblSummaryTable.getColumnCount() <= 2)
		    || (tblSummaryTable.getColumnName(2).indexOf("Testing") == -1)) {
		tblSummaryTable.getColumnModel().addColumn(tbcTestingValue);
		tpnResults.setOrderedTabVisible(pnlCVResults, true);
	    }
	    tbcTrainingValue.setHeaderValue(MdrTableColumnName.CV_TRAINING
		    .capitalized());
	    tbcTestingValue.setHeaderValue(MdrTableColumnName.CV_TESTING
		    .capitalized());
	} else {
	    tblSummaryTable.getColumnModel().removeColumn(tbcTestingValue);
	    tpnResults.setOrderedTabVisible(pnlCVResults, false);
	    tbcTrainingValue.setHeaderValue(MdrTableColumnName.OVERALL_SCORE
		    .capitalized());
	}
	if (displayCvcColumn) {
	    if (tblSummaryTable
		    .getColumnName(tblSummaryTable.getColumnCount() - 1) != Frame.CV_CONSISTENCY) {
		tblSummaryTable.getColumnModel().addColumn(tbcCVConsistency);
	    }
	} else {
	    tblSummaryTable.getColumnModel().removeColumn(tbcCVConsistency);
	}
    }

    private void warn(final String warningMessage) {
	pnlWarning.warn(warningMessage);
    }

    private static class AmbiguousCellDynamicString {
	private final AmbiguousCellStatus ambiguousCellStatus;

	public AmbiguousCellDynamicString(
		final AmbiguousCellStatus ambiguousCellStatus) {
	    this.ambiguousCellStatus = ambiguousCellStatus;
	}

	@Override
	public String toString() {
	    String returnValue = "";
	    if ((Console.console != null) && (Console.console.data != null)) {
		switch (ambiguousCellStatus) {
		case AFFECTED:
		    returnValue = "'"
			    + Console.console.data.getStatusColumnName() + " "
			    + Console.console.data.getAffectedValuesString()
			    + "'";
		    break;
		case UNAFFECTED:
		    returnValue = "'"
			    + Console.console.data.getStatusColumnName() + " "
			    + Console.console.data.getUnaffectedValuesString()
			    + "'";
		    break;
		case UNCLASSIFIED:
		    returnValue = AmbiguousCellStatus.UNCLASSIFIED
			    .getDisplayName();
		    break;
		default:
		    throw new RuntimeException(
			    "Unhandled AmbiguousCellStatus: "
				    + ambiguousCellStatus);
		    // break;

		}
	    }
	    return returnValue;
	}
    }

    private class MemoryDisplay implements MemoryWarningSystem.Listener,
	    ActionListener {

	private final MemoryWarningSystem mws;

	/** Maximum heap size in bytes. */
	private long max;

	/** Current heap size in bytes. */
	private long total;
	/** Number of bytes used. */
	private long used;

	private final javax.swing.Timer swingTimer;
	private boolean lowMemory = false;

	public MemoryDisplay() {
	    mws = new MemoryWarningSystem();
	    mws.addListener(this);
	    MemoryWarningSystem.setRequiredMemoryThreshold(0.10,
		    100 * Frame.BytesPerMegabyte);
	    swingTimer = new javax.swing.Timer(3000, this);
	    swingTimer.start();

	}

	/**
	 * Update the memory usage fields.
	 */
	@Override
	public void actionPerformed(final ActionEvent e) {
	    final Runtime rt = Runtime.getRuntime();
	    total = rt.totalMemory();
	    max = rt.maxMemory();
	    used = total - rt.freeMemory();
	    lblUsedMem.setText(Main.decimalUpToOnePrecision.format(used
		    / Frame.BytesPerMegabyte)
		    + " MB");
	    lblTotalMem.setText(Main.decimalUpToOnePrecision.format(total
		    / Frame.BytesPerMegabyte)
		    + " MB");
	    lblMaxMem.setText(Main.decimalUpToOnePrecision.format(max
		    / Frame.BytesPerMegabyte)
		    + " MB");
	    if (lowMemory) {
		// toggle low memory label
		lblLowMemory.setVisible(!lblLowMemory.isVisible());
	    }

	}

	/** NumberFormat used to add commas in the appropriate places. */

	@Override
	public void memoryUsageLow(final long usedMemory, final long maxMemory) {
	    warn("MDR does not have enough memory and results are not reliable. Close and re-start from the command line using instructions in the RELEASE_NOTES.txt");
	    pnlAnalysis.setBackground(Color.red);
	    lowMemory = true;
	}
    }

    private class OnEndAnalysis implements Runnable {
	@Override
	public void run() {
	    if (tmrProgress != null) {
		tmrProgress.cancel();
		tmrProgress = null;
	    }
	    if (analysis == null) {
		throw new RuntimeException(
			"OnEndAnalysis called with analysis set to null");
	    } else if (!analysis.isComplete()) {
		throw new RuntimeException(
			"OnEndAnalysis called with analysis.isComplete() returning false");
	    }
	    if ((analysis != null) && analysis.isComplete()) {
		resetToReadyToRunAnalysis();
		// if there are no results...
		if (tblSummaryTable.getRowCount() == 0) {
		    dataFileChange();
		    analysis = null;
		} else {
		    new Thread(new Runnable() {
			@Override
			public void run() {
			    pnlEntropy.updateEntropyDisplay(
				    Console.console.data, analysis
					    .getCollectors(), analysis
					    .getMinAttr(), (analysis
					    .getMinAttr() + tblSummaryTable
					    .getRowCount()) - 1, analysis
					    .getTiePriority());
			}

		    }, "UpdateEntropyDisplayThread").start();
		    if (analysis.getAllModelsLandscape() != null) {
			new Thread(new Runnable() {
			    @Override
			    public void run() {
				tpnResults.setOrderedTabVisible(
					pnlAllModelsLandscape, true);
				pnlAllModelsLandscape.setEnabled(true);
				pnlAllModelsLandscape.setLandscape(
					analysis.getAllModelsLandscape(), true);
			    }

			}, "AllModelsLandscapeThread").start();
		    } else {
			tpnResults.setOrderedTabVisible(pnlAllModelsLandscape,
				false);
		    }
		}
		lockdown(false);
	    } // end if complete
	} // end run()
    } // end OnEndAnalysis class

    private class OnEndLevel implements Runnable {
	@Override
	public void run() {
	    final Collector currentCollector = analysis.getCollectors().get(
		    tblSummaryTable.getRowCount());
	    addTableRow(currentCollector.getBestModel(),
		    ((Number) spnCrossValidationCount.getValue()).intValue());

	    System.gc();
	}
    }

    private class OnFilterEnd implements Runnable {
	private final boolean ascending;

	public OnFilterEnd(final boolean ascending) {
	    this.ascending = ascending;
	}

	@Override
	public void run() {
	    if (!isVisible()) {
		return;
	    }
	    final AttributeCombination combo = rankerThread.getCombo();
	    Frame.indeterminateProgressUpdaterStop(prgFilterProgress);
	    lockdown(false);
	    cmdFilter.setText("Apply");
	    cmdFilter.setForeground(getForeground());
	    if ((combo == null) || (combo.size() == 0)) {
		JOptionPane.showMessageDialog(Frame.this,
			"Current filter criteria selected zero attributes "
				+ "-- not applying.", "Error",
			JOptionPane.ERROR_MESSAGE);

	    } else {
		final List<String> labels = Console.console.data.getLabels();
		Console.console.setDataset(Console.console.data.filter(combo
			.getAttributeIndices()),
			DatasetStackAction.PUSH_ONTO_STACK);
		dataFileChange();
		prgFilterProgress.setFractionComplete(1);
		cmdRevertFilter.setEnabled(true);
		cmdRevert.setEnabled(true);
		final FilterMethod filterMethod = (FilterMethod) cboFilter
			.getSelectedItem();
		if ((filterMethod == FilterMethod.CHISQUARED)
			&& chkChiSquaredPValue.isSelected()) {
		    pnlFilterLandscape.setYAxisLabel(filterMethod.toString()
			    + " P-Value");
		    pnlFilterLandscape.setYAxisExportableName(filterMethod
			    .getExportableAlternateName() + " P-Value");
		} else {
		    pnlFilterLandscape.setYAxisLabel(filterMethod.toString());
		    pnlFilterLandscape.setYAxisExportableName(filterMethod
			    .getExportableAlternateName());
		}
		pnlFilterLandscape.setEnabled(true);
		Comparator<Pair<String, Float>> cmp = new Pair.SecondComparator<String, Float>();
		if (!ascending) {
		    cmp = Collections.reverseOrder(cmp);
		}
		final List<Pair<Integer, Double>> scores = rankerThread
			.getRanker().getSortedScores();
		final List<LabeledFloatInterface> landscapeList = new ArrayList<LabeledFloatInterface>(
			scores.size());
		for (final Pair<Integer, Double> p : scores) {
		    final LabeledFloat labeledFloat = new LabeledFloat(
			    labels.get(p.getFirst()), new Float(p.getSecond()));
		    landscapeList.add(labeledFloat);
		}
		pnlFilterLandscape.setLandscape(new LabeledFloatListLandscape(
			landscapeList), LabeledFloat.floatMaximizerComparator);
		pnlDatafileTable.readDatafile(Console.console.data);
	    } // end if some attributes remain
	} // end run()
    } // end class OnFilterEnd
} // end Frame
