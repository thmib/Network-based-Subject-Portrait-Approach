package org.epistasis.mdr.api;

import java.util.ArrayList;
import java.util.List;

import org.epistasis.mdr.enums.MdrTableColumnName;
import org.epistasis.mdr.newengine.Collector;
import org.epistasis.mdr.newengine.Collector.ModelComparisonInfo;

public class MDRLevelResult {
    private final Collector collector;

    /**
     * Creates a blank {@code MDRLevelResult} with parent {@code parent}. The
     * caller is responsible for filling this class before distributing it.
     */
    MDRLevelResult(final Collector collector) {
	this.collector = collector;
    }

    /**
     * Generates an array of Strings representing the most "important" aspects
     * of this result. The column names are given by {@link #getHeaders()}.
     * 
     * @see #getHeaders()
     */
    public String[] asStringArray() {
	String[] stringArray;
	final ModelComparisonInfo bestModel = collector.getBestModel();
	if (collector.hasTesting()) {
	    stringArray = new String[] {
		    String.valueOf(bestModel.getModelName()),
		    String.valueOf(bestModel.getCVC()) + "/"
			    + bestModel.getCollector().getNumIntervals(),
		    String.valueOf(bestModel.getCVAverageTrainingFitness()),
		    String.valueOf(bestModel.getCVAggregateTestingFitness()),
		    String.valueOf(bestModel.getAverageTrainingFitness()),
		    String.valueOf(bestModel.getAggregateTestingFitness()),
		    String.valueOf(bestModel.getOverallFitness()) };

	} else {
	    stringArray = new String[] {
		    String.valueOf(bestModel.getModelName()),
		    String.valueOf(bestModel.getOverallFitness()) };
	}
	return stringArray;
    }

    public ModelComparisonInfo getBestModel() {
	return collector.getBestModel();
    }

    /**
     * Gives the column names when generating an {@code MDRLevelResult} as an
     * array (i.e. {@link #asStringArray()}).
     * 
     * @see #asStringArray()
     */
    public String[] getHeaders() {
	String[] stringArray;
	if (collector.hasTesting()) {
	    stringArray = new String[] {
		    MdrTableColumnName.MODEL_ATTRIBUTES.capitalized(),
		    MdrTableColumnName.CVC.capitalized(),
		    MdrTableColumnName.CV_TRAINING.capitalized(),
		    MdrTableColumnName.CV_TESTING.capitalized(),
		    MdrTableColumnName.MODEL_TRAINING.capitalized(),
		    MdrTableColumnName.MODEL_TESTING.capitalized(),
		    MdrTableColumnName.OVERALL_SCORE.capitalized() };

	} else {
	    stringArray = new String[] {
		    MdrTableColumnName.MODEL_ATTRIBUTES.capitalized(),
		    MdrTableColumnName.OVERALL_SCORE.capitalized() };
	}
	return stringArray;
    }

    public List<ModelComparisonInfo> getTopModels() {
	return new ArrayList<ModelComparisonInfo>(collector);
    }

    @Override
    public String toString() {
	return collector.toString();
    }
}
