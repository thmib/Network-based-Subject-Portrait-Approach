package org.epistasis.mdr.api;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JScrollPane;

import org.epistasis.mdr.Main;
import org.epistasis.mdr.api.MDRExecutor.MDRParameters;
import org.epistasis.mdr.enums.FitnessCriteriaOrder;
import org.epistasis.mdr.gui.EntropyPanel;
import org.epistasis.mdr.gui.EntropyPanel.DisplayType;
import org.epistasis.mdr.gui.GraphicalModelControls;
import org.epistasis.mdr.gui.GraphicalModelPanel;
import org.epistasis.mdr.gui.InteractionGraph;
import org.epistasis.mdr.gui.InteractionGraph.JungLayoutType;
import org.epistasis.mdr.newengine.Collector;
import org.epistasis.mdr.newengine.Dataset;
import org.epistasis.mdr.newengine.Model;
import org.epistasis.mdr.newengine.ModelInfoInterface;
import org.epistasis.mdr.newengine.ModelInfoInterfaceComparator;

public class MDRResult implements Iterable<MDRLevelResult> {

    private final List<MDRLevelResult> resultList;
    private final MDRParameters source;

    public static ModelInfoInterface getBestModelOfWinningLevel(
	    final List<ModelInfoInterface> levelResults,
	    final ModelInfoInterfaceComparator interLevelComparator) {
	return MDRResult.getModelsInDescendingQualityOrder(levelResults,
		interLevelComparator).get(0);
    }

    /**
     * 
     * @param levelResults
     * @param interLevelComparator
     * @return makes a copy of list and sorts it with best model first
     */
    public static List<ModelInfoInterface> getModelsInDescendingQualityOrder(
	    final List<ModelInfoInterface> levelResults,
	    final ModelInfoInterfaceComparator interLevelComparator) {
	assert levelResults.size() > 0;

	final List<ModelInfoInterface> sortedModelsList = new ArrayList<ModelInfoInterface>(
		levelResults.size());
	for (final ModelInfoInterface levelResult : levelResults) {
	    sortedModelsList.add(levelResult);
	}
	Collections.sort(sortedModelsList, interLevelComparator);

	return sortedModelsList;
    }

    /**
     * Trims an image of its background
     * 
     * @param img
     *            The image
     * @param bg
     *            The background RGB, usually obtain through
     *            {@link Color#getRGB()}.
     * @see Color
     */
    private static BufferedImage trim(final BufferedImage img, final int bg) {
	int minX = img.getWidth();
	int minY = img.getHeight();
	int maxY;
	int maxX = maxY = 0;
	boolean flag = false;
	for (int x = 0; x < img.getWidth(); x++) {
	    for (int y = 0; y < img.getHeight(); y++) {
		final int color = img.getRGB(x, y);
		if (color != bg) {
		    minX = Math.min(minX, x);
		    maxX = Math.max(maxX, x);
		    minY = Math.min(minY, y);
		    maxY = Math.max(maxY, y);
		    flag = true;
		}
	    }
	}
	if (!flag) {
	    return null; // can't trim; all background color
	}
	return img
		.getSubimage(minX, minY, (maxX - minX) + 1, (maxY - minY) + 1);
    }

    /**
     * Generates an MDRResult from an executor
     * 
     * @param param
     *            An MDRExecutor that has completed and its thread (
     *            {@link MDRExecutor#getThread()}) is ready for processing.
     */
    MDRResult(final MDRParameters param) // package private
    {
	if (!param.status.equals(Status.COMPLETED)) {
	    throw new UnsupportedOperationException(
		    "Cannot generate results from an exector with status: "
			    + param.status);
	}
	source = param;
	final List<Collector> collectors = param.thread.getCollectors();
	resultList = new ArrayList<MDRLevelResult>(collectors.size());
	for (final Collector collector : collectors) {
	    resultList.add(new MDRLevelResult(collector));
	}
    }

    /**
     * Generates a table of results. {@code asTable()[n]} is equivalent to
     * {@code getResultList().get(n).asStringArray()}
     * 
     * @return A String table of results
     * @see #toString()
     */
    public String[][] asTable() {
	final String[][] ret = new String[resultList.size()][];
	int idx = 0;
	for (final MDRLevelResult result : resultList) {
	    ret[idx++] = result.asStringArray();
	}
	return ret;
    }

    /* advanced getters */
    /**
     * Generates an case/control histogram for a specific attribute set. This is
     * equivalent to:{@code generateImageByRow(level - getMinLevel())}
     * 
     * @param level
     *            An int such that minAttributes <= level <= maxAttributes
     * @see #generateImageByRow(int)
     */
    public BufferedImage generateImageByLevel(final Dataset data,
	    final int level) {
	return generateImageByRow(data, level - getMinLevel());
    }

    /**
     * Generates a case/control histogram for a selected row (collector).
     * 
     * @param row
     *            The row, starting at 0
     * @return The histogram
     */
    public BufferedImage generateImageByRow(final Dataset data, final int row) {
	final GraphicalModelControls gmp = new GraphicalModelControls();
	final Model model = source.thread.getCollectors().get(row)
		.getBestModel().getModel();
	gmp.setDatasetAndModel(data, model);
	final Component[] components = gmp.getComponents();
	GraphicalModelPanel panel = null;
	for (final Component component : components) {
	    if (component instanceof JScrollPane) {
		for (final Component c : ((JScrollPane) component)
			.getViewport().getComponents()) {
		    if (c instanceof GraphicalModelPanel) {
			panel = (GraphicalModelPanel) c;
			panel.setMaxDim(0);
			break;
		    }
		}
	    }
	}
	if (panel == null) {
	    throw new RuntimeException(
		    "Cannot find any instances of GraphicalModelPanel.");
	}
	final BufferedImage ret = new BufferedImage(
		panel.getPreferredSize().width,
		panel.getPreferredSize().height, BufferedImage.TYPE_INT_RGB);
	final Graphics2D g2 = ret.createGraphics();
	g2.setBackground(Color.WHITE);
	g2.clearRect(0, 0, panel.getPreferredSize().width,
		panel.getPreferredSize().height);
	panel.paint(g2);
	g2.dispose();
	return ret;
    }

    /**
     * Creates an array of the case/control histograms for all rows/levels
     * 
     * @return The array
     */
    public BufferedImage[] generateImages(final Dataset data) {
	final BufferedImage[] ret = new BufferedImage[source.thread
		.getCollectors().size()];
	for (int i = 0; i < ret.length; i++) {
	    ret[i] = generateImageByRow(data, i);
	}
	return ret;
    }

    public ModelInfoInterface getBestModelOfWinningLevel(
	    final FitnessCriteriaOrder fitnessCriteriaOrder) {
	return getBestModelOfWinningLevel(new ModelInfoInterfaceComparator(
		fitnessCriteriaOrder));
    }

    public ModelInfoInterface getBestModelOfWinningLevel(
	    final ModelInfoInterfaceComparator interLevelComparator) {

	return MDRResult.getBestModelOfWinningLevel(getLevelResults(),
		interLevelComparator);
    }

    /* simple getters */
    public int getCases() {
	return source.data.getAffectedStatusCount();
    }

    public List<Collector> getCollectors() {
	return new ArrayList<Collector>(source.thread.getCollectors());
    } // clone collectors so the user can't mess it up

    public int getControls() {
	return source.data.getUnaffectedStatusCount();
    }

    public int getCVPartitions() {
	return source.cv;
    }

    /**
     * Equivalent to {@code getEntropyGraph(new Dimension(1000, 1000))}.
     * 
     * @see #getEntropyGraph(Dimension)
     */
    public BufferedImage getEntropyGraph() {
	return this.getEntropyGraph(new Dimension(500, 250));
    }

    /**
     * Generates a network graph
     * 
     * @return The graph
     */
    public BufferedImage getEntropyGraph(final Dimension maxSize) {

	/* FIXME this is a really nasty workaround */
	final JFrame frame = new JFrame();
	final InteractionGraph panel = getEntropyGraphPanel(maxSize);
	frame.add(panel);
	frame.pack();

	final BufferedImage img = new BufferedImage(panel.getWidth(),
		panel.getHeight(), BufferedImage.TYPE_INT_RGB);
	final Graphics2D g = img.createGraphics();
	panel.paint(g);
	g.dispose();
	frame.dispose();
	return MDRResult.trim(img, Color.WHITE.getRGB());
    }

    /* entropy graphs */
    /**
     * Generates the {@link InteractionGraph} which houses the entropy panel
     */
    private InteractionGraph getEntropyGraphPanel(final Dimension maximumSize) {

	final EntropyPanel panel = new EntropyPanel();
	panel.updateEntropyDisplay(source.data, source.thread.getCollectors(),
		getMinLevel(), getMaxLevel(), Main.defaultAmbiguousCellStatus);

	final DisplayType t = DisplayType.FRUCHTERMAN_RHEINGOLD;
	panel.setSize(maximumSize);
	panel.updateSelection(t);
	final InteractionGraph graph = (InteractionGraph) panel
		.getEntropyPanelDisplay(t);
	graph.setJungLayoutType(JungLayoutType.lookup(t.toString()));
	graph.setSize(maximumSize);

	return graph;
    }

    public List<ModelInfoInterface> getLevelResults() {
	final List<ModelInfoInterface> levelResults = new ArrayList<ModelInfoInterface>(
		source.thread.getCollectors().size());
	for (final Collector collector : source.thread.getCollectors()) {
	    levelResults.add(collector.getBestModel().getModelInfo());
	}
	return levelResults;
    }

    public int getMaxLevel() {
	return source.maxLevel;
    }

    public int getMinLevel() {
	return source.minLevel;
    }

    public List<MDRLevelResult> getResults() {
	return new ArrayList<MDRLevelResult>(resultList);
    }

    public MDRLevelResult getResultsByLevel(final int level) {
	return resultList.get(level - getMinLevel());
    }

    /* to allow foreach iteration over level results */
    @Override
    public Iterator<MDRLevelResult> iterator() {
	return resultList.iterator();
    }

    public void saveAnalysis(final String analysisSavePath)
	    throws FileNotFoundException {
	source.thread.saveAnalysis(analysisSavePath);
    }

    /**
     * Generates a table of the level results. This calls
     * {@code MDRLevelResult#asStringArray()} on each level result. The columns
     * are based on the default level headers,
     * {@code MDRLevelResult#getHeaders()}.
     * 
     * @return A table of the level results
     * @see MDRLevelResult#asStringArray()
     * @see MDRLevelResult#getHeaders()
     * @see #asTable()
     */
    @Override
    public String toString() {
	final StringBuffer buf = new StringBuffer();
	if (!resultList.isEmpty()) {
	    for (final String s : resultList.get(0).getHeaders()) {
		buf.append(s).append('\t');
	    }
	    for (final String[] s : asTable()) {
		buf.append('\n');
		for (final String t : s) {
		    buf.append(t).append('\t');
		}
	    }
	}
	return buf.toString();

    }
}
