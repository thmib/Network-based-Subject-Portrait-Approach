package org.epistasis.mdr.api;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.math.BigInteger;

import javax.swing.JApplet;
import javax.swing.JFrame;
import javax.swing.WindowConstants;

public class TestClass {
    public static void main(final String[] args) throws IOException {

	final MDRExecutor executor = new MDRExecutor("data\\MDR-SampleData.txt")
		.setMinLevel(1).setMaxLevel(4);

	executor.filterData(true /* throwExceptionOnUnknownAttributes */,
		new String[] { "X15", "X13", "X2", "X5", "X8" });
	final BigInteger totalCalculations = executor.getNumberOfModelTests();
	executor.setOnEndModel(new Runnable() {
	    BigInteger count = BigInteger.ZERO;
	    BigInteger oneHundred = BigInteger.TEN.multiply(BigInteger.TEN);

	    @Override
	    public void run() {
		count = count.add(BigInteger.ONE);
		final int percent = count.multiply(oneHundred)
			.divide(totalCalculations).intValue();
		System.out.println(count + " / " + totalCalculations + " = "
			+ percent + "%");
	    }
	});
	final MDRResult result = executor.runInCurrentThread().getResult();
	System.out.println(result);
	final JFrame imageFrame = new JFrame();
	final BufferedImage img = result.getEntropyGraph();
	imageFrame.add(new JApplet() {
	    private static final long serialVersionUID = 1L;

	    @Override
	    public void paint(final Graphics g) {
		super.paint(g);
		g.drawImage(img, 0, 0, null);
	    }
	});
	// imageFrame.add(result.getEntropyGraph());
	imageFrame.setVisible(true);
	imageFrame.setSize(img.getWidth(), img.getHeight());
	imageFrame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
    }
}
