package org.epistasis.mdr.api;

public enum Status {
    UNCOMPLETED(-1), COMPLETED(1), FAILED(0);
    private int value;

    private Status(final int value) {
	this.value = value;
    }

    public int asInt() {
	return value;
    }
}
