package org.epistasis.mdr.newengine;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.RandomAccess;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import org.epistasis.Utility;

public class AttributeCombination implements RandomAccess,
	Comparable<AttributeCombination> {
    public static final char MODEL_DELIMITER_CHAR = ',';
    public static final String MODEL_DELIMITER_STRING = String
	    .valueOf(AttributeCombination.MODEL_DELIMITER_CHAR);
    public static final AttributeCombination EMPTY = new AttributeCombination(
	    Arrays.asList(0), Arrays.asList("{EMPTY}"));
    protected int[] combo;
    private final List<String> labels;

    public static int compareAttributeLabels(final List<String> labels1,
	    final List<String> labels2) {
	int compareResult;
	compareResult = (labels1 == labels2) ? 0 : 1;
	if (compareResult != 0) {
	    // this won't usually happen because attributes are drawn from the
	    // same dataset which will have the same labels array. However,
	    // for Parabon distributed computing used in
	    // org.epistasis.combinatoric.mdr.crush.MDRFunction we use
	    // numerous datasets
	    // across one search. In that case the labels are actually the
	    // attribute indices so comparing them will pick the earlier
	    // combination which is how we are supposed to break ties
	    compareResult = labels1.size() - labels2.size();
	    if (compareResult == 0) {
		for (int labelIndex = 0; labelIndex < labels1.size(); ++labelIndex) {
		    if ((compareResult = labels1.get(labelIndex).compareTo(
			    labels2.get(labelIndex))) != 0) {
			break;
		    }
		} // end for loop over labels
	    } // end if compareResult != 0
	} // end if compareResult == 0
	return compareResult;
    }

    public static int compareAttributeLabels(final String modelCombo1,
	    final String modelCombo2) {
	return AttributeCombination
		.compareAttributeLabels(Arrays.asList(AttributeCombination
			.splitAttributes(modelCombo1)), Arrays
			.asList(AttributeCombination
				.splitAttributes(modelCombo2)));
    }

    public static SortedSet<Integer> getCombinationSizes(
	    final List<AttributeCombination> forced) {
	final SortedSet<Integer> comboSizes = new TreeSet<Integer>();
	if (forced != null) {
	    for (final AttributeCombination combo : forced) {
		final int forcedComboMax = combo.getMax();
		comboSizes.add(forcedComboMax);
	    }
	}
	return comboSizes;
    }

    public static Set<String> readAttributeNamesFile(final File attributesFile)
	    throws FileNotFoundException, IOException {
	final Set<String> allowedAttributes = new HashSet<String>();
	LineNumberReader allowedAttributesOnlyReader = null;
	try {
	    allowedAttributesOnlyReader = new LineNumberReader(new FileReader(
		    attributesFile));
	    String line;
	    while ((line = allowedAttributesOnlyReader.readLine()) != null) {
		for (String attributeName : AttributeCombination
			.splitAttributes(line)) {
		    attributeName = attributeName.trim();
		    // if label is surrounded by quotation marks, remove
		    // them
		    if ((attributeName.length() > 2)
			    && attributeName.startsWith("\"")
			    && attributeName.endsWith("\"")) {
			attributeName = attributeName.substring(1,
				attributeName.length() - 1).trim();
		    }
		    if (attributeName.length() > 1) {
			// if (attributeName.contains(" ")) {
			// errPrintStream
			// .println("Error: allowed_attributes has an attribute name with a space in it which is not allowed: "
			// + attributeName + ".");
			// return -1;
			// }
			if (!allowedAttributes.add(attributeName.trim())) {
			    // duplicates are fine -- it may be convenient
			    // to use programmatically generated lists or
			    // perhaps pairs of interactions
			    // console.errPrintStream
			    // .println("Error: allowed_attributes appears to have a duplicate on line "
			    // + allowedAttributesOnlyReader.getLineNumber()
			    // + " '"
			    // + attributeName.trim() +
			    // "' was previously found.");
			    // return -1;
			}
		    } // end if not zero length
		} // end loop on split of line into attributes
	    }
	} finally {
	    if (allowedAttributesOnlyReader != null) {
		allowedAttributesOnlyReader.close();
	    }
	}
	return allowedAttributes;
    }

    /**
     * Split a string using regex [, \t;:]+
     * 
     * @param comboString
     * @return
     */
    public static String[] splitAttributes(final String comboString) {
	final String[] fields = comboString.split("[, \t;:]+");
	return fields;
    }

    /**
     * 
     * @param forced
     * @param combo
     *            -- if forced == null this will be kept and SHOULD NOT BE
     *            MODIFIED
     * @param labels
     */
    public AttributeCombination(final AttributeCombination forced,
	    final int[] combo, final List<String> labels) {
	this(labels);
	if (forced != null) {
	    this.combo = Utility.mergeTwoSortedArrays(forced.combo, combo);
	} else {
	    this.combo = combo;
	}
    }

    // public AttributeCombination(
    // final AttributeCombination attrCombinationWithRestrictedIndices,
    // final int[] restrictedSearchAttributes) {
    // this(attrCombinationWithRestrictedIndices.labels);
    // final int[] attributeIndicesInRestrictedScale =
    // attrCombinationWithRestrictedIndices
    // .getAttributeIndices();
    // combo = new int[attributeIndicesInRestrictedScale.length];
    // for (int attributeIndex = 0; attributeIndex < combo.length;
    // ++attributeIndex) {
    // final int restrictedSearchAttributeIndex =
    // attributeIndicesInRestrictedScale[attributeIndex];
    // final int unrestrictedSearchAttributeIndex =
    // restrictedSearchAttributes[restrictedSearchAttributeIndex];
    // if (attributeIndex > 0) {
    // // enforce rule that attribute indices must be in ascending
    // // order
    // assert combo[attributeIndex - 1] < unrestrictedSearchAttributeIndex;
    // }
    // combo[attributeIndex] = unrestrictedSearchAttributeIndex;
    // }
    // }

    /**
     * 
     * @param incomingCombo
     *            -- this will be kept and SHOULD NOT BE MODIFIED
     * @param labels
     */
    public AttributeCombination(final int[] incomingCombo,
	    final List<String> labels) {
	this(labels);
	// combo = incomingCombo.clone();
	// DO NOT CLONE FOR EFFICIENCY BECAUSE USED DURING EXHAUSTIVE SEARCH
	combo = incomingCombo;
    }

    /**
     * 
     * @param incomingCombo
     *            -- this will be kept and SHOULD NOT BE MODIFIED
     * @param labels
     */
    public AttributeCombination(final int[] incomingCombo, final String[] labels) {
	this(Arrays.asList(labels));
	// combo = incomingCombo.clone();
	// DO NOT CLONE FOR EFFICIENCY BECAUSE USED DURING EXHAUSTIVE SEARCH
	combo = incomingCombo;
    }

    public AttributeCombination(final List<Integer> comboList,
	    final List<String> labels) {
	this(labels);
	combo = new int[comboList.size()];
	boolean needsToBeSorted = false;
	for (int attributeIndex = 0; attributeIndex < combo.length; ++attributeIndex) {
	    combo[attributeIndex] = comboList.get(attributeIndex);
	    if (attributeIndex > 0) {
		// if current index < previous index array needs to be sorted
		needsToBeSorted |= combo[attributeIndex] <= combo[attributeIndex - 1];
	    }
	} // end loop
	if (needsToBeSorted) {
	    Arrays.sort(combo);
	    // need to check for duplicates
	    for (int attributeIndex = 1; attributeIndex < combo.length; ++attributeIndex) {
		if (combo[attributeIndex] == combo[attributeIndex - 1]) {
		    throw new IllegalArgumentException(
			    "AttributeCombination has duplicate attributes!");
		}
	    } // end duplicate checking for loop
	} // end if needs to be sorted
    }

    protected AttributeCombination(final List<String> labels) {
	this.labels = labels;
    }

    public AttributeCombination(final String comboString,
	    final int numAttributes, final List<String> labels) {
	this(AttributeCombination.splitAttributes(comboString), numAttributes,
		labels);
    } // end constructor

    public AttributeCombination(final String[] attributeNames,
	    final int numAttributes, final List<String> labels) {
	this(labels);
	combo = Dataset.attributeNameListToAscendingIndicesArray(
		true /* throwExceptionOnUnknownAttributes */, attributeNames,
		numAttributes, labels);
    }

    /**
     * check that this AttributeCombination is within the
     * restrictedSearchAttributes
     * 
     * @param restrictedSearchAttributes
     * @return
     */
    public boolean checkRestrictedAttributes(
	    final int[] restrictedSearchAttributes) {
	boolean isOkay = true;
	if (restrictedSearchAttributes != null) {
	    isOkay = restrictedSearchAttributes.length >= getMax();
	    if (isOkay) {
		// must check that each forced attribute index is in the
		// restricted search attributes
		for (final int attributeIndex : combo) {
		    isOkay = false;
		    for (final int restrictedSearchAttributeIndex : restrictedSearchAttributes) {
			if (restrictedSearchAttributeIndex == attributeIndex) {
			    isOkay = true;
			    break;
			}
		    } // end loop over restricted attributes
		    if (!isOkay) {
			break;
		    }
		} // end loop over forced attributes
	    }
	}
	return isOkay;
    } // end checkRestrictedAttributes

    @Override
    public int compareTo(final AttributeCombination other) {
	int compareResult = Utility.compareIndexArrays(combo, other.combo);
	if (compareResult == 0) {
	    compareResult = AttributeCombination.compareAttributeLabels(labels,
		    other.labels);
	} // end if compareResult == 0

	return compareResult;
    }

    public int get(final int index) {
	return combo[index];
    }

    public int[] getAttributeIndices() {
	return combo;
    }

    public String getLabel(final int index) {
	return labels.get(combo[index]);
    }

    public List<String> getLabels() {
	return labels;
    }

    public int getMax() {
	return size();
    }

    public int getMin() {
	return size();
    }

    @Override
    public int hashCode() {
	return combo.hashCode();
    }

    public Iterator<AttributeCombination> iterator() {
	return new AttributeCombinationIterator();

    }

    public void setLabels(final List<String> labels) {
	this.labels.clear();
	this.labels.addAll(labels);
    }

    public int size() {
	return combo.length;
    }

    @Override
    public String toString() {
	return toString(AttributeCombination.MODEL_DELIMITER_CHAR);
    }

    private String toString(final char delimiter) {
	final StringBuffer b = new StringBuffer();
	for (int comboAttributeIndex = 0; comboAttributeIndex < size(); ++comboAttributeIndex) {
	    if (comboAttributeIndex != 0) {
		b.append(delimiter);
	    }
	    final int attributeIndex = combo[comboAttributeIndex];
	    if ((labels == null) || (attributeIndex >= labels.size())) {
		b.append(attributeIndex + 1);
	    } else {
		b.append(labels.get(attributeIndex));
	    }
	}
	return b.toString();
    }

    public class AttributeCombinationIterator implements
	    Iterator<AttributeCombination> {
	boolean done = false;

	@Override
	public boolean hasNext() {
	    return !done;
	}

	@Override
	public AttributeCombination next() {
	    AttributeCombination attributeCombination;
	    if (!done) {
		attributeCombination = AttributeCombination.this;
		done = true;
	    } else {
		attributeCombination = null;
	    }
	    return attributeCombination;
	}

	@Override
	public void remove() {
	    throw new UnsupportedOperationException();

	}

    }
} // end AttributeCombination

