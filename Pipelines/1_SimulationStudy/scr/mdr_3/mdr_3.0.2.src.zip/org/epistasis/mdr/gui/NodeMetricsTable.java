package org.epistasis.mdr.gui;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;
import org.epistasis.mdr.Main;
import org.epistasis.mdr.networkEntropy.GraphLevelMetrics;
import org.epistasis.mdr.networkEntropy.NetworkGraph;

import edu.uci.ics.jung.graph.UndirectedGraph;

public class NodeMetricsTable extends JTable {
    private static final long serialVersionUID = 1L;
    private static final boolean debug = false;
    private final NodeMetricsTableModel nodeMetricsTableModel;

    public NodeMetricsTable() {

	nodeMetricsTableModel = new NodeMetricsTableModel();
	// wish to disable selection
	// http://www.exampledepot.com/egs/javax.swing.table/NoSel.html
	setFocusable(false);
	// setFillsViewportHeight(true);
	setAutoCreateColumnsFromModel(false);
	setModel(nodeMetricsTableModel);
    } // end constructor

    public void reset() {
	nodeMetricsTableModel.reset();
    }

    public void updateGraph(final NetworkGraph networkGraph) {
	if (networkGraph == null) {
	    reset();
	} else {
	    final ExecutorService graphMetricsExecutorService = Executors
		    .newFixedThreadPool(Math.max(1, Runtime.getRuntime()
			    .availableProcessors() - 1));
	    try {
		final UndirectedGraph<Integer, Integer> jungGraph = networkGraph
			.getJungGraph();
		final List<Future<GraphLevelMetrics<Integer, Integer>>> metricResults = new ArrayList<Future<GraphLevelMetrics<Integer, Integer>>>();
		// tableModel.setRowCount(0);
		if (jungGraph.getVertexCount() > 0) {
		    metricResults
			    .add(graphMetricsExecutorService
				    .submit(new Callable<GraphLevelMetrics<Integer, Integer>>() {
					@Override
					public GraphLevelMetrics<Integer, Integer> call()
						throws Exception {
					    return networkGraph
						    .getGraphLevelMetricsNode();
					}
				    }));
		    metricResults
			    .add(graphMetricsExecutorService
				    .submit(new Callable<GraphLevelMetrics<Integer, Integer>>() {
					@Override
					public GraphLevelMetrics<Integer, Integer> call()
						throws Exception {
					    return networkGraph
						    .getGraphLevelMetricsEdge();
					}
				    }));

		    metricResults
			    .add(graphMetricsExecutorService
				    .submit(new Callable<GraphLevelMetrics<Integer, Integer>>() {
					@Override
					public GraphLevelMetrics<Integer, Integer> call()
						throws Exception {
					    return GraphLevelMetrics
						    .getGraphLevelMetricsFromJungScorer(
							    jungGraph,
							    new edu.uci.ics.jung.algorithms.scoring.DegreeScorer<Integer>(
								    jungGraph),
							    "Vertex Degree");
					}
				    }));
		    // metricResults
		    // .add(graphMetricsExecutorService
		    // .submit(new Callable<GraphLevelMetrics<Integer,
		    // Integer>>() {
		    // @Override
		    // public GraphLevelMetrics<Integer, Integer> call()
		    // throws Exception {
		    // return (GraphLevelMetrics
		    // .getGraphLevelMetricsFromJungClusteringCoefficients(jungGraph));
		    // }
		    // }));
		    // metricResults
		    // .add(graphMetricsExecutorService
		    // .submit(new Callable<GraphLevelMetrics<Integer,
		    // Integer>>() {
		    // @Override
		    // public GraphLevelMetrics<Integer, Integer> call()
		    // throws Exception {
		    // return GraphLevelMetrics
		    // .getGraphLevelMetricsFromJungScorer(
		    // jungGraph,
		    // new
		    // edu.uci.ics.jung.algorithms.scoring.EigenvectorCentrality<Integer,
		    // Integer>(
		    // jungGraph));
		    // }
		    // }));
		    // metricResults
		    // .add(graphMetricsExecutorService
		    // .submit(new Callable<GraphLevelMetrics<Integer,
		    // Integer>>() {
		    // @Override
		    // public GraphLevelMetrics<Integer, Integer> call()
		    // throws Exception {
		    // return GraphLevelMetrics
		    // .getGraphLevelMetricsFromJungScorer(
		    // jungGraph,
		    // new
		    // edu.uci.ics.jung.algorithms.scoring.KStepMarkov<Integer,
		    // Integer>(
		    // jungGraph,
		    // Math.max(
		    // 500,
		    // jungGraph
		    // .getVertexCount())));
		    // }
		    // }));
		    // metricResults
		    // .add(graphMetricsExecutorService
		    // .submit(new Callable<GraphLevelMetrics<Integer,
		    // Integer>>() {
		    // @Override
		    // public GraphLevelMetrics<Integer, Integer> call()
		    // throws Exception {
		    // return GraphLevelMetrics
		    // .getGraphLevelMetricsFromJungScorer(
		    // jungGraph,
		    // new edu.uci.ics.jung.algorithms.scoring.PageRank<Integer,
		    // Integer>(
		    // jungGraph, 0.85 /*
		    // * alpha
		    // * which
		    // * Google
		    // * uses
		    // */));
		    // }
		    // }));
		    metricResults
			    .add(graphMetricsExecutorService
				    .submit(new Callable<GraphLevelMetrics<Integer, Integer>>() {
					@Override
					public GraphLevelMetrics<Integer, Integer> call()
						throws Exception {
					    return GraphLevelMetrics
						    .getGraphLevelMetricsFromJungScorer(
							    jungGraph,
							    new edu.uci.ics.jung.algorithms.scoring.BetweennessCentrality<Integer, Integer>(
								    jungGraph),
							    "Betweenness Centrality");
					}
				    }));
		    metricResults
			    .add(graphMetricsExecutorService
				    .submit(new Callable<GraphLevelMetrics<Integer, Integer>>() {
					@Override
					public GraphLevelMetrics<Integer, Integer> call()
						throws Exception {
					    return GraphLevelMetrics
						    .getGraphLevelMetricsFromJungScorer(
							    jungGraph,
							    new edu.uci.ics.jung.algorithms.scoring.ClosenessCentrality<Integer, Integer>(
								    jungGraph),
							    "Closeness Centrality");
					}
				    }));
		    // metricResults
		    // .add(graphMetricsExecutorService
		    // .submit(new Callable<GraphLevelMetrics<Integer,
		    // Integer>>() {
		    // @Override
		    // public GraphLevelMetrics<Integer, Integer> call()
		    // throws Exception {
		    // return GraphLevelMetrics
		    // .getGraphLevelMetricsFromJungScorer(
		    // jungGraph,
		    // new
		    // edu.uci.ics.jung.algorithms.scoring.BarycenterScorer<Integer,
		    // Integer>(
		    // jungGraph));
		    // }
		    // }));
		    // metricResults
		    // .add(graphMetricsExecutorService
		    // .submit(new Callable<GraphLevelMetrics<Integer,
		    // Integer>>() {
		    // @Override
		    // public GraphLevelMetrics<Integer, Integer> call()
		    // throws Exception {
		    // return GraphLevelMetrics
		    // .getGraphLevelMetricsFromJungScorer(
		    // jungGraph,
		    // new
		    // edu.uci.ics.jung.algorithms.scoring.DistanceCentralityScorer<Integer,
		    // Integer>(
		    // jungGraph,
		    // true /* averaging */),
		    // "Distance Centrality");
		    // }
		    // }));
		    nodeMetricsTableModel.setMetricResults(metricResults);
		} // end if any vertices
	    } catch (final Exception ex) {
		System.err.println("updateGraphInternal caught exception: "
			+ ex.toString());
		ex.printStackTrace();
	    } finally {
		if (NodeMetricsTable.debug) {
		    System.err
			    .println("updateGraphInternal finally{} executing");
		}
		try {
		    graphMetricsExecutorService.shutdown();
		} catch (final Exception ex) {
		    System.err
			    .println("graphMetricsExecutorService.shutdown() caught an exception: "
				    + ex);
		    ex.printStackTrace();
		}
		if (NodeMetricsTable.debug) {
		    System.err
			    .println("updateGraphInternal finally{} after call to graphMetricsExecutorService.shutdown()");
		}
	    }
	}
    } // end updateGraph

    private class NodeMetricsTableModel extends DefaultTableModel {
	private static final long serialVersionUID = 1L;
	private final List<GraphLevelMetrics<Integer, Integer>> graphLevelMetricColumnsList = new ArrayList<GraphLevelMetrics<Integer, Integer>>();

	public NodeMetricsTableModel() {
	    final TableColumn tableColumn = new TableColumn(getColumnModel()
		    .getColumnCount());
	    tableColumn.setHeaderValue("Metrics");
	    getColumnModel().addColumn(tableColumn);
	}

	@Override
	public int getColumnCount() {
	    return getColumnModel().getColumnCount();
	}

	@Override
	public int getRowCount() {
	    return TABLE_ROWS.values().length;
	}

	@Override
	public Object getValueAt(final int row, final int column) {
	    String cellString = null;
	    if (row >= TABLE_ROWS.values().length) {
		throw new RuntimeException(
			"table row requested larger than expected. expected maximum: "
				+ (TABLE_ROWS.values().length - 1)
				+ " parameter received: " + row);
	    }
	    final TABLE_ROWS tableRow = TABLE_ROWS.values()[row];
	    if (column == 0) {
		cellString = tableRow.toString();
	    } else {
		final int metricIndex = column - 1;
		if (metricIndex >= graphLevelMetricColumnsList.size()) {
		    cellString = "";
		} else {
		    final GraphLevelMetrics<Integer, Integer> graphLevelMetrics = graphLevelMetricColumnsList
			    .get(metricIndex);
		    if (graphLevelMetrics == null) {
			cellString = ""; // data not finished being calculated
					 // in thread
		    } else {
			Double cellValue = null;
			final DescriptiveStatistics descriptiveStatistics = graphLevelMetrics
				.getDescriptiveStatistics();
			switch (tableRow) {
			// case sparkline:
			// return graphLevelMetrics.getSparklineJLabel(
			// NodeMetricsTable.this.getRowHeight() - 1,
			// getColumnModel().getColumn(column)
			// .getWidth() - 1);
			// // break;
			case min:
			    cellValue = descriptiveStatistics.getMin();
			    break;
			case Q1:
			    cellValue = descriptiveStatistics
				    .getPercentile(0.25);
			    break;
			case median:
			    cellValue = descriptiveStatistics
				    .getPercentile(0.5);
			    break;
			case Q3:
			    cellValue = descriptiveStatistics
				    .getPercentile(0.75);
			    break;
			case max:
			    cellValue = descriptiveStatistics.getMax();
			    break;
			case mean:
			    cellValue = descriptiveStatistics.getMean();
			    break;
			case SD:
			    cellValue = descriptiveStatistics
				    .getStandardDeviation();
			    break;
			case variance:
			    cellValue = descriptiveStatistics.getVariance();
			    break;
			default:
			    throw new RuntimeException("Unhandled table row: "
				    + tableRow);
			    // break;

			}
			if (cellString == null) {
			    cellString = Main.decimalUpToFourPrecision
				    .format(cellValue);
			}
		    }
		}
		return cellString;
	    } // end if not first (header) column
	    return cellString;
	} // end getValueAt

	public void reset() {
	    // setColumnCount(1);
	    // graphLevelMetricColumnsList.clear();
	}

	public void setMetricResults(
		final List<Future<GraphLevelMetrics<Integer, Integer>>> metricResults) {
	    // must set up the array with empty objects in it since we don't
	    // know the order the
	    // threading tasks will finish in and want to maintain the same
	    // column order regardless

	    // make sure that there is a slot for every result
	    while (graphLevelMetricColumnsList.size() != metricResults.size()) {
		if (graphLevelMetricColumnsList.size() > metricResults.size()) {
		    graphLevelMetricColumnsList.remove(0);
		} else {
		    graphLevelMetricColumnsList.add(null);
		    getColumnModel().addColumn(
			    new TableColumn(getColumnModel().getColumnCount()));
		}
	    }
	    // set all data to null
	    for (int rowIndex = 0; rowIndex < metricResults.size(); ++rowIndex) {
		graphLevelMetricColumnsList.set(rowIndex, null);
	    }
	    fireTableDataChanged();
	    final int totalTasks = metricResults.size();
	    final Thread pollingThread = new Thread(new Runnable() {

		@Override
		public void run() {
		    try {
			int numTasksLeftToProcess = totalTasks;
			while (numTasksLeftToProcess > 0) {
			    for (int metricIndex = 0; metricIndex < metricResults
				    .size(); ++metricIndex) {
				final Future<GraphLevelMetrics<Integer, Integer>> future = metricResults
					.get(metricIndex);
				if ((future != null) && future.isDone()) {
				    GraphLevelMetrics<Integer, Integer> graphLevelMetrics;
				    graphLevelMetrics = future.get();
				    metricResults.set(metricIndex, null);
				    graphLevelMetricColumnsList.set(
					    metricIndex, graphLevelMetrics);
				    getColumnModel().getColumn(metricIndex + 1)
					    .setHeaderValue(
						    graphLevelMetrics
							    .getMetricName());
				    fireTableDataChanged();
				    getTableHeader().resizeAndRepaint();
				    --numTasksLeftToProcess;
				} // end if task is done
			    } // end for loop
			    Thread.sleep(500);
			    Thread.yield();
			} // end polling loop
		    } catch (final Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		    }

		} // end run
	    } // end runnable
	    , "NodeMetrics_polling");
	    pollingThread.start();
	} // end setMetricResults

    } // end private class MetricsTableModel

    enum TABLE_ROWS {
	// sparkline,
	min, Q1, median, Q3, max, mean, SD, variance
    }

} // end class NodeMetricsTable
