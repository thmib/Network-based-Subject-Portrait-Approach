package org.epistasis.mdr.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JSplitPane;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import org.epistasis.Utility;
import org.epistasis.gui.ProgressPanel;
import org.epistasis.gui.ProgressPanelUpdater;
import org.epistasis.gui.SwingInvoker;
import org.epistasis.mdr.Console;
import org.epistasis.mdr.Main;
import org.epistasis.mdr.entropy.EntropyAnalysis;
import org.epistasis.mdr.entropy.EntropyAnalysis.NetworkDataType;
import org.epistasis.mdr.networkEntropy.NetworkDisplayModel;
import org.epistasis.mdr.networkEntropy.NetworkGraph;

@SuppressWarnings("serial")
public class NetworkDisplay extends JPanel implements PropertyChangeListener {
    private static final String CONNECTED_COMPONENTS = "Connected Components";
    private final boolean debug = false;
    final NetworkDisplayModel networkDisplayModel = new NetworkDisplayModel();
    private final ProgressPanel progressPanel;
    private NetworkGraph networkGraph = null;
    private final JButton btnCalculateMdrCombined;
    private final JButton btnCalculateCartesianProduct;
    private final JPanel pnlCalculateButtons;
    private final JSplitPane splitPaneVerticalEntropyPanelAndSplitPane;
    private final EntropyAnalysis entropyAnalysis = new EntropyAnalysis();
    private final EntropyPanel entropyPanel;
    public Thread updateGraphDisplayInternalThread;
    private int updateGraphDisplayInternalThreadCtr = 0;
    private final JPanel pnlJTableAndText;
    private final JScrollPane scrollPaneGraphTableSummary;
    private final PercentageSliderWithSpinnerAndText nodeSlider;
    private final JPanel pnlGraphMetricsTable;
    private final GraphMetricsTable graphMetricsTable;
    private final JPanel pnlNodeMetricsTable;
    private final NodeMetricsTable nodeMetricsTable;
    private final JPanel pnlEntropyPanelAndNodeSlider;
    private final JLabel lblGlobalNetworkProperties;
    private final JLabel lblLocalNetworkProperties;
    private final JLabel lblMaximumVertices;
    private final JSpinner spnMaximumVertices;

    /**
     * Create the panel.
     */
    public NetworkDisplay() {
	final GridBagLayout gridBagLayout_1 = new GridBagLayout();
	gridBagLayout_1.columnWeights = new double[] { 1.0 };
	gridBagLayout_1.rowWeights = new double[] { 0.0, 0.0, 1.0 };
	setLayout(gridBagLayout_1);
	pnlCalculateButtons = new JPanel();
	final GridBagConstraints gbc_pnlCalculateButtons = new GridBagConstraints();
	gbc_pnlCalculateButtons.anchor = GridBagConstraints.NORTH;
	gbc_pnlCalculateButtons.insets = new Insets(10, 0, 10, 0);
	gbc_pnlCalculateButtons.fill = GridBagConstraints.HORIZONTAL;
	gbc_pnlCalculateButtons.gridx = 0;
	gbc_pnlCalculateButtons.gridy = 0;
	add(pnlCalculateButtons, gbc_pnlCalculateButtons);
	final GridBagLayout gbl_pnlCalculateButtons = new GridBagLayout();
	gbl_pnlCalculateButtons.columnWidths = new int[] { 0, 0, 70, 177, 0 };
	gbl_pnlCalculateButtons.rowHeights = new int[] { 0, 0 };
	gbl_pnlCalculateButtons.columnWeights = new double[] { 1.0, 0.0, 0.0,
		1.0, Double.MIN_VALUE };
	gbl_pnlCalculateButtons.rowWeights = new double[] { 0.0,
		Double.MIN_VALUE };
	pnlCalculateButtons.setLayout(gbl_pnlCalculateButtons);
	btnCalculateMdrCombined = new JButton(
		"Calculate MDR combined attribute network");
	final GridBagConstraints gbc_btnCalculateMdrCombined = new GridBagConstraints();
	gbc_btnCalculateMdrCombined.insets = new Insets(0, 0, 0, 5);
	gbc_btnCalculateMdrCombined.gridx = 0;
	gbc_btnCalculateMdrCombined.gridy = 0;
	pnlCalculateButtons.add(btnCalculateMdrCombined,
		gbc_btnCalculateMdrCombined);

	lblMaximumVertices = new JLabel("Top " + EntropyAnalysis.I_A_C
		+ " vertices:");
	final GridBagConstraints gbc_lblMaximumVertices = new GridBagConstraints();
	gbc_lblMaximumVertices.anchor = GridBagConstraints.EAST;
	gbc_lblMaximumVertices.insets = new Insets(0, 0, 0, 5);
	gbc_lblMaximumVertices.gridx = 1;
	gbc_lblMaximumVertices.gridy = 0;
	pnlCalculateButtons.add(lblMaximumVertices, gbc_lblMaximumVertices);

	spnMaximumVertices = new JSpinner();
	spnMaximumVertices.addChangeListener(new ChangeListener() {
	    @Override
	    public void stateChanged(final ChangeEvent e) {
		networkDisplayModel
			.setGraphMaximumVertices((Integer) spnMaximumVertices
				.getValue());
	    }
	});
	spnMaximumVertices.setModel(new SpinnerNumberModel(new Integer(100),
		new Integer(2), null, new Integer(1)));
	final GridBagConstraints gbc_spnMaximumVertices = new GridBagConstraints();
	gbc_spnMaximumVertices.fill = GridBagConstraints.HORIZONTAL;
	gbc_spnMaximumVertices.insets = new Insets(0, 0, 0, 5);
	gbc_spnMaximumVertices.gridx = 2;
	gbc_spnMaximumVertices.gridy = 0;
	pnlCalculateButtons.add(spnMaximumVertices, gbc_spnMaximumVertices);
	btnCalculateCartesianProduct = new JButton(
		"Calculate Cartesian Product network");
	final GridBagConstraints gbc_btnCalculateCartesianProduct = new GridBagConstraints();
	gbc_btnCalculateCartesianProduct.gridx = 3;
	gbc_btnCalculateCartesianProduct.gridy = 0;
	pnlCalculateButtons.add(btnCalculateCartesianProduct,
		gbc_btnCalculateCartesianProduct);
	btnCalculateCartesianProduct.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		networkDisplayModel
			.setNetworkDataType(NetworkDataType.CARTESIAN_PRODUCT);
		startNetworkBuilding();
	    }
	});
	btnCalculateMdrCombined.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent arg0) {
		networkDisplayModel
			.setNetworkDataType(NetworkDataType.MDR_ATTRIBUTE);
		startNetworkBuilding();
	    }
	});
	progressPanel = new ProgressPanel();
	final GridBagLayout gridBagLayout = (GridBagLayout) progressPanel
		.getLayout();
	gridBagLayout.rowWeights = new double[] { 0.0 };
	gridBagLayout.rowHeights = new int[] { 0 };
	gridBagLayout.columnWeights = new double[] { 0.0 };
	gridBagLayout.columnWidths = new int[] { 0 };
	progressPanel.setTitleFont(new Font("Dialog", Font.BOLD, 11));
	final GridBagConstraints gbc_progressPanel = new GridBagConstraints();
	gbc_progressPanel.insets = new Insets(0, 0, 5, 0);
	gbc_progressPanel.fill = GridBagConstraints.HORIZONTAL;
	gbc_progressPanel.anchor = GridBagConstraints.NORTH;
	gbc_progressPanel.gridx = 0;
	gbc_progressPanel.gridy = 1;
	add(progressPanel, gbc_progressPanel);
	splitPaneVerticalEntropyPanelAndSplitPane = new JSplitPane();
	splitPaneVerticalEntropyPanelAndSplitPane.setResizeWeight(0.5);
	splitPaneVerticalEntropyPanelAndSplitPane.setOneTouchExpandable(true);
	splitPaneVerticalEntropyPanelAndSplitPane
		.setOrientation(JSplitPane.VERTICAL_SPLIT);
	final GridBagConstraints gbc_splitPaneVerticalEntropyPanelAndSplitPane = new GridBagConstraints();
	gbc_splitPaneVerticalEntropyPanelAndSplitPane.anchor = GridBagConstraints.NORTH;
	gbc_splitPaneVerticalEntropyPanelAndSplitPane.fill = GridBagConstraints.BOTH;
	gbc_splitPaneVerticalEntropyPanelAndSplitPane.gridx = 0;
	gbc_splitPaneVerticalEntropyPanelAndSplitPane.gridy = 2;
	add(splitPaneVerticalEntropyPanelAndSplitPane,
		gbc_splitPaneVerticalEntropyPanelAndSplitPane);

	pnlEntropyPanelAndNodeSlider = new JPanel();
	entropyPanel = new EntropyPanel(entropyAnalysis, 1, 9, 10,
		EntropyPanel.DisplayType.FRUCHTERMAN_RHEINGOLD,
		pnlEntropyPanelAndNodeSlider);
	final GridBagLayout gbl_pnlEntropyPanelAndNodeSlider = new GridBagLayout();
	gbl_pnlEntropyPanelAndNodeSlider.columnWidths = new int[] { 795, 0 };
	gbl_pnlEntropyPanelAndNodeSlider.rowHeights = new int[] { 157, 27, 0 };
	gbl_pnlEntropyPanelAndNodeSlider.columnWeights = new double[] { 1.0,
		Double.MIN_VALUE };
	gbl_pnlEntropyPanelAndNodeSlider.rowWeights = new double[] { 1.0, 0.0,
		Double.MIN_VALUE };
	pnlEntropyPanelAndNodeSlider
		.setLayout(gbl_pnlEntropyPanelAndNodeSlider);
	final GridBagConstraints gbc_entropyPanel = new GridBagConstraints();
	gbc_entropyPanel.fill = GridBagConstraints.BOTH;
	gbc_entropyPanel.insets = new Insets(0, 0, 5, 0);
	gbc_entropyPanel.gridx = 0;
	gbc_entropyPanel.gridy = 0;
	pnlEntropyPanelAndNodeSlider.add(entropyPanel, gbc_entropyPanel);
	nodeSlider = new PercentageSliderWithSpinnerAndText("Node",
		"Node visibility threshold: ");
	final GridBagConstraints gbc_nodeSlider = new GridBagConstraints();
	gbc_nodeSlider.anchor = GridBagConstraints.SOUTH;
	gbc_nodeSlider.fill = GridBagConstraints.HORIZONTAL;
	gbc_nodeSlider.gridx = 0;
	gbc_nodeSlider.gridy = 1;
	pnlEntropyPanelAndNodeSlider.add(nodeSlider, gbc_nodeSlider);
	nodeSlider.setSliderPercentage(100);
	splitPaneVerticalEntropyPanelAndSplitPane
		.setTopComponent(pnlEntropyPanelAndNodeSlider);

	scrollPaneGraphTableSummary = new JScrollPane();
	splitPaneVerticalEntropyPanelAndSplitPane
		.setBottomComponent(scrollPaneGraphTableSummary);
	pnlJTableAndText = new JPanel();
	scrollPaneGraphTableSummary.setViewportView(pnlJTableAndText);
	final GridBagLayout gbl_pnlJTableAndText = new GridBagLayout();
	gbl_pnlJTableAndText.rowHeights = new int[] { 0, 40, 0, 0 };
	gbl_pnlJTableAndText.columnWidths = new int[] { 0 };
	gbl_pnlJTableAndText.columnWeights = new double[] { 1.0 };
	gbl_pnlJTableAndText.rowWeights = new double[] { 0.0, 1.0, 0.0, 1.0 };
	pnlJTableAndText.setLayout(gbl_pnlJTableAndText);

	lblGlobalNetworkProperties = new JLabel(
		NetworkDisplay.CONNECTED_COMPONENTS);
	lblGlobalNetworkProperties.setAlignmentX(Component.CENTER_ALIGNMENT);
	final GridBagConstraints gbc_lblGlobalNetworkProperties = new GridBagConstraints();
	gbc_lblGlobalNetworkProperties.anchor = GridBagConstraints.NORTH;
	gbc_lblGlobalNetworkProperties.fill = GridBagConstraints.HORIZONTAL;
	gbc_lblGlobalNetworkProperties.insets = new Insets(0, 0, 0, 5);
	gbc_lblGlobalNetworkProperties.gridx = 0;
	gbc_lblGlobalNetworkProperties.gridy = 0;
	pnlJTableAndText.add(lblGlobalNetworkProperties,
		gbc_lblGlobalNetworkProperties);
	lblGlobalNetworkProperties
		.setHorizontalAlignment(SwingConstants.CENTER);
	lblGlobalNetworkProperties.setFont(new Font(getFont().getFamily(),
		Font.BOLD, 14));
	pnlGraphMetricsTable = new JPanel();
	pnlGraphMetricsTable.setForeground(Color.YELLOW);
	final GridBagConstraints gbc_pnlGraphMetricsTable = new GridBagConstraints();
	gbc_pnlGraphMetricsTable.fill = GridBagConstraints.BOTH;
	gbc_pnlGraphMetricsTable.insets = new Insets(0, 0, 0, 5);
	gbc_pnlGraphMetricsTable.gridx = 0;
	gbc_pnlGraphMetricsTable.gridy = 1;
	pnlJTableAndText.add(pnlGraphMetricsTable, gbc_pnlGraphMetricsTable);
	pnlGraphMetricsTable.setLayout(new BorderLayout());
	nodeMetricsTable = new NodeMetricsTable();
	graphMetricsTable = new GraphMetricsTable(nodeMetricsTable,
		entropyPanel.getPnlInteractionGraph());
	pnlGraphMetricsTable.add(graphMetricsTable.getTableHeader(),
		BorderLayout.NORTH);
	pnlGraphMetricsTable.add(graphMetricsTable, BorderLayout.CENTER);

	lblLocalNetworkProperties = new JLabel("Local Network Properties");
	lblLocalNetworkProperties.setAlignmentX(Component.CENTER_ALIGNMENT);
	final GridBagConstraints gbc_lblLocalNetworkProperties = new GridBagConstraints();
	gbc_lblLocalNetworkProperties.fill = GridBagConstraints.HORIZONTAL;
	gbc_lblLocalNetworkProperties.insets = new Insets(0, 0, 0, 5);
	gbc_lblLocalNetworkProperties.gridx = 0;
	gbc_lblLocalNetworkProperties.gridy = 2;
	pnlJTableAndText.add(lblLocalNetworkProperties,
		gbc_lblLocalNetworkProperties);
	lblLocalNetworkProperties.setHorizontalAlignment(SwingConstants.CENTER);
	lblLocalNetworkProperties.setFont(new Font(getFont().getFamily(),
		Font.BOLD, 14));

	pnlNodeMetricsTable = new JPanel();
	pnlNodeMetricsTable.setForeground(Color.YELLOW);
	final GridBagConstraints gbc_pnlNodeMetricsTable = new GridBagConstraints();
	gbc_pnlNodeMetricsTable.fill = GridBagConstraints.HORIZONTAL;
	gbc_pnlNodeMetricsTable.anchor = GridBagConstraints.NORTH;
	gbc_pnlNodeMetricsTable.gridx = 0;
	gbc_pnlNodeMetricsTable.gridy = 3;
	pnlJTableAndText.add(pnlNodeMetricsTable, gbc_pnlNodeMetricsTable);
	pnlNodeMetricsTable.setLayout(new BorderLayout());
	pnlNodeMetricsTable.add(nodeMetricsTable.getTableHeader(),
		BorderLayout.NORTH);
	pnlNodeMetricsTable.add(nodeMetricsTable, BorderLayout.CENTER);

	initDataBindings();
	setPropertyChangeListener(true /* add */);
    }

    protected void initDataBindings() {
    }

    @Override
    public void propertyChange(final PropertyChangeEvent evt) {
	final String propertyName = evt.getPropertyName();
	if (debug) {
	    System.out.println("NetworkDisplay propertyChange. property: "
		    + propertyName + " evt.oldValue: " + evt.getOldValue()
		    + " new value: " + evt.getNewValue());
	}
	if (propertyName.equals("graphAvailableForDisplay")) {
	    // splitPaneVerticalEntropyPanelAndSplitPane.setVisible((Boolean)
	    // evt.getNewValue());
	    if (debug) {
		System.out
			.println("Setting splitPaneVisibility. evt.oldValue: "
				+ evt.getOldValue() + " new value: "
				+ evt.getNewValue());
		// if (evt.getNewValue() != evt.getOldValue()) {
		// if (evt.getNewValue().equals(Boolean.FALSE)) {
		// entropyPanel.pnlEntropy_clearTabs();
		// } else {
		// splitPaneVerticalEntropyPanelAndSplitPane.setVisible(true);
		// }
		// }
	    }
	} else if (propertyName.equals("isBusy")) {
	    final boolean isBusy = evt.getNewValue().equals(Boolean.TRUE);
	    if (evt.getNewValue() != evt.getOldValue()) {
		if (isBusy) {
		    graphMetricsTable.reset();
		}
	    }
	    if (!isBusy) {
		progressPanel.setVisible(false);
	    }

	} else if (propertyName.equals("networkDataType")) {
	    return;

	} else if (propertyName.equals("graphMaximumVertices")) {
	    setControlsEnabled();
	    return;
	} else if (propertyName.equals("nodeThreshold")) {
	    updateGraphDisplay();
	    return;
	} else if (propertyName.equals("edgeThreshold")) {
	    updateGraphDisplay();
	    return;
	    // } else if (propertyName.equals("allSummaryData")) {
	    // textAreaSummaryGraphMetrics.setText((String) evt.getNewValue());
	    // // nothing to do
	} else if (propertyName.equals("ancestor")) {
	    // nothing to do
	} else if (propertyName.equals("EntropyPanel_enabled")) {
	    // nothing to do
	} else if (propertyName
		.startsWith("EntropyPanel_Edge_PercentageSliderWithSpinnerAndText_value")) {
	    if (debug) {
		System.out.println(evt.getPropertyName() + " changing from "
			+ evt.getOldValue() + " to " + evt.getNewValue());
	    }
	    if (!propertyName.endsWith("_while_adjusting")) {
		networkDisplayModel
			.setEdgeThreshold((Double) evt.getNewValue());
	    }
	} else if (propertyName
		.startsWith("EntropyPanel_Node_PercentageSliderWithSpinnerAndText_value")) {
	    if (debug) {
		System.out.println(evt.getPropertyName() + " changing from "
			+ evt.getOldValue() + " to " + evt.getNewValue());
	    }
	    if (!propertyName.endsWith("_while_adjusting")) {
		networkDisplayModel
			.setNodeThreshold((Double) evt.getNewValue());
	    }
	} else {
	    if (Main.isExperimental) {
		System.err
			.println("NetworkDisplay received unexpected property change evt: "
				+ evt.getPropertyName()
				+ " changing from "
				+ evt.getOldValue()
				+ " to "
				+ evt.getNewValue());
	    }
	}
	setControlsEnabled();
    } // end propertyChange

    public void reinitialize() {
	// splitPaneVerticalEntropyPanelAndSplitPane.setVisible(false);
	// progressPanel.setVisible(false);
	networkDisplayModel.setNetworkDataType(null);
	graphMetricsTable.reset();
	entropyAnalysis.clear();
	nodeMetricsTable.reset();
	entropyPanel.pnlEntropy_clearTabs();
	setControlsEnabled();
    }

    private void setControlsEnabled() {
	final boolean readyForNewAnalysis = !entropyAnalysis.hasData();

	final boolean maximumVerticesChanged = entropyAnalysis.hasData()
		&& (entropyAnalysis.size() != networkDisplayModel
			.getGraphMaximumVertices());
	btnCalculateMdrCombined.setEnabled(readyForNewAnalysis
		|| maximumVerticesChanged
		// && !networkDisplayModel.getIsBusy()
		|| (NetworkDataType.MDR_ATTRIBUTE != networkDisplayModel
			.getNetworkDataType()));
	btnCalculateCartesianProduct.setEnabled(readyForNewAnalysis
		|| maximumVerticesChanged
		// && !networkDisplayModel.getIsBusy()
		|| (NetworkDataType.CARTESIAN_PRODUCT != networkDisplayModel
			.getNetworkDataType()));
	final boolean enableControls = entropyAnalysis.hasData()
		&& !networkDisplayModel.getIsBusy()
		&& networkDisplayModel.getGraphAvailableForDisplay();
	entropyPanel.setPercentageSliderSpinnerPanelEnabled(enableControls);
    }

    public void setDataDependentItems() {
	final Integer numAttributes = Console.console.data.getNumAttributes();
	final SpinnerNumberModel numberModel = (SpinnerNumberModel) spnMaximumVertices
		.getModel();
	numberModel.setMaximum(numAttributes);
	numberModel.setValue(Math.min(numAttributes,
		(Integer) numberModel.getValue()));
    }

    private void setPropertyChangeListener(final boolean add) {
	if (add) {
	    networkDisplayModel.addPropertyChangeListener(this);
	    nodeSlider.addPropertyChangeListener(entropyPanel);
	    entropyPanel.addPropertyChangeListener(this);
	} else {
	    networkDisplayModel.removePropertyChangeListener(this);
	    nodeSlider.removePropertyChangeListener(entropyPanel);
	    entropyPanel.removePropertyChangeListener(this);
	}
    }

    private void startNetworkBuilding() {
	if (networkDisplayModel.getNetworkDataType() == null) {
	    return;
	}
	final ProgressPanelUpdater progressPanelUpdater = new ProgressPanelUpdater(
		progressPanel);
	// progressPanel.setVisible(true);
	SwingInvoker.runInEventDispathThread(new Runnable() {
	    @Override
	    public void run() {
		progressPanel.setString(null);
		progressPanel.setFractionComplete(0);
		progressPanel.repaint();
		// final boolean usingAllVertices = networkDisplayModel
		// .getGraphMaximumVertices() == Console.console.data
		// .getNumAttributes();
		// lblGlobalNetworkProperties
		// .setText(NetworkDisplay.CONNECTED_COMPONENTS
		// + " (for "
		// + (usingAllVertices ? "all" : String
		// .valueOf(networkDisplayModel
		// .getGraphMaximumVertices()))
		// + " vertices)");
		networkDisplayModel.setGraphAvailableForDisplay(false);
		networkDisplayModel.setIsBusy(true);
		progressPanel.setVisible(true);
		graphMetricsTable.reset();
		entropyPanel.pnlEntropy_clearTabs();
		setPropertyChangeListener(false /* add */);
	    }
	}, true /* wait */);
	entropyAnalysis.set(Console.console.data,
		networkDisplayModel.getNetworkDataType(),
		Console.console.ambiguousCellStatus, true /* parallel */,
		progressPanelUpdater, false /* waitForCalculationToComplete */,
		true /* calculateAllEntropyMetrics */,
		(Integer) spnMaximumVertices.getValue());
	final Thread waitForEntropyCalculationFinishThread = new Thread(
		"networkDisplayWaitForEntropyCalculationFinishThread") {
	    @Override
	    public void run() {
		entropyAnalysis.waitUntilEntropyCalculationFinished();
		SwingInvoker.runInEventDispathThread(new Runnable() {
		    @Override
		    public void run() {
			progressPanel.setIndeterminate(true);
			progressPanel
				.setString("Building network from attribute interactions...");
		    }
		}, true /* wait */);
		networkGraph = entropyAnalysis.buildGraph(null /* jungGraph */);
		SwingInvoker.runInEventDispathThread(new Runnable() {
		    @Override
		    public void run() {
			progressPanel.setIndeterminate(false);
			progressPanel.setString(null);
		    }
		}, false /* wait */);
		entropyPanel.updateEntropyDisplay(networkGraph);
		nodeSlider
			.setSpinnerListModel(networkGraph
				.getNodeThresholdList(EntropyAnalysis.DEFAULT_DIGITS_OF_PRECISION));
		setPropertyChangeListener(true);
		networkDisplayModel.setGraphAvailableForDisplay(true);
		networkDisplayModel.setIsBusy(false);
		updateGraphDisplay();
	    }
	};
	waitForEntropyCalculationFinishThread.start();
    } // startNetworkBuilding

    private void updateGraphDisplay() {
	if (networkGraph == null) {
	    return;
	}
	if (updateGraphDisplayInternalThread != null) {
	    final Thread.State threadState = updateGraphDisplayInternalThread
		    .getState();
	    if (debug) {
		System.out
			.println("updateGraphDisplayInternalThread is in state: "
				+ threadState.toString());
	    }
	    if (Thread.currentThread() == updateGraphDisplayInternalThread) {
		System.out
			.println("updateGraphDisplay called from within itself. Returning without action.");
		return;
	    }
	    if (updateGraphDisplayInternalThread.isAlive()) {
		System.out
			.println("updateGraphDisplay called when updateGraphDisplayInternal is already running. Will try to interrupt.\n"
				+ Utility.getAllStackTraces());
		updateGraphDisplayInternalThread.interrupt();
		while (networkDisplayModel.getIsBusy()) {
		    System.out
			    .println("still busy after interrupting!  updateGraphDisplayInternalThread.isAlive()= "
				    + updateGraphDisplayInternalThread
					    .isAlive());
		    try {
			Thread.sleep(500);
		    } catch (final InterruptedException ex) {
			System.err
				.println("still busy sleep caught exception: "
					+ ex);
			System.err.flush();
		    }
		}
	    }
	}
	if (networkDisplayModel.getIsBusy()) {
	    System.out
		    .println("Ignoring call to updateGraphDisplay because isBusy already. Returning without action.");
	    return;
	}
	networkDisplayModel.setIsBusy(true);
	updateGraphDisplayInternalThread = new Thread(
		"updateGraphDisplayInternal_"
			+ ++updateGraphDisplayInternalThreadCtr) {
	    @Override
	    public void run() {
		updateGraphDisplayInternal();
	    }
	};
	updateGraphDisplayInternalThread.start();
    } // end updateGraphDisplay()

    private void updateGraphDisplayInternal() {
	try {
	    SwingInvoker.runInEventDispathThread(new Runnable() {
		@Override
		public void run() {
		    progressPanel.setIndeterminate(true);
		    progressPanel.setString("Calculating network statistics "
			    + networkDisplayModel.getNetworkDataType()
			    + " graph");
		}
	    }, false /* wait */);
	    // networkGraph.filterGraph(networkDisplayModel.getNodeThreshold(),
	    // networkDisplayModel.getEdgeThreshold());
	    graphMetricsTable.setData(networkGraph);
	    Thread.yield(); // allow ui a chance to update/disable controls.
	    // final StringBuilder sb = new StringBuilder();
	    // sb.append("Unfiltered graph:\n");
	    // sb.append(networkGraph.toString());
	    // sb.append("\n===========================================\nFiltered to edge value median graph:\n");
	    // final NetworkGraph filteredGraph = new
	    // NetworkGraph.NetworkSubGraph(
	    // networkGraph, null /* activeNodes */,
	    // Double.NEGATIVE_INFINITY /* nodeValidityThreshold */,
	    // networkGraph
	    // .getEdgeValueFrequencies().getMedian());
	    // sb.append(filteredGraph.toString());
	    // sb.append("\n===========================================\n#2 Filtered (again) to already filtered edge value median graph:\n");
	    // final NetworkGraph filteredGraph2 = new
	    // NetworkGraph.NetworkSubGraph(
	    // networkGraph, null /* activeNodes */,
	    // Double.NEGATIVE_INFINITY /* nodeValidityThreshold */,
	    // filteredGraph
	    // .getEdgeValueFrequencies().getMedian());
	    // sb.append(filteredGraph2.toString());
	    // sb.append("\n===========================================\n#3 Filtered to node value median graph:\n");
	    // final NetworkGraph filteredGraph3 = new
	    // NetworkGraph.NetworkSubGraph(
	    // networkGraph,
	    // null /* activeNodes */,
	    // networkGraph.getNodeValueFrequencies().getMedian() /*
	    // nodeValidityThreshold */,
	    // Double.NEGATIVE_INFINITY /* edgeValidityThreshold */);
	    // sb.append(filteredGraph3.toString());
	    // sb.append("\n===========================================\n#4 Filtered (again) to already filtered node value median graph:\n");
	    // final NetworkGraph filteredGraph4 = new
	    // NetworkGraph.NetworkSubGraph(
	    // filteredGraph3,
	    // null /* activeNodes */,
	    // filteredGraph3.getNodeValueFrequencies().getMedian() /*
	    // nodeValidityThreshold */,
	    // Double.NEGATIVE_INFINITY /* edgeValidityThreshold */);
	    // sb.append(filteredGraph4.toString());
	} catch (final Exception ex) {
	    System.err.println("updateGraphInternal caught exception: "
		    + ex.toString());
	    ex.printStackTrace();
	} finally {
	    if (debug) {
		System.err.println("updateGraphInternal finally{} executing");
	    }
	    try {
		SwingInvoker.runInEventDispathThread(new Runnable() {
		    @Override
		    public void run() {
			progressPanel.setIndeterminate(false);
			progressPanel.setString(null);
		    }
		}, false /* wait */);
	    } catch (final Exception ex) {
		System.err
			.println("updateGraphInternal finally with progress bar caught an exception: "
				+ ex);
	    }
	    if (debug) {
		System.err
			.println("updateGraphInternal finally{} after call to progress panel stuff");
	    }
	    networkDisplayModel.setIsBusy(false);
	    if (debug) {
		System.err
			.println("updateGraphInternal finally{} after call networkDisplayModel.setIsBusy(false);");
	    }
	    if (networkDisplayModel.getIsBusy() != false) {
		System.err
			.println("updateGraphInternal finally call to networkDisplayModel.setIsBusy(false); seems not to have worked!");
	    }
	    if (debug) {
		System.err
			.println("updateGraphInternal finally{} finished. (networkDisplayModel.getIsBusy() = "
				+ networkDisplayModel.getIsBusy());
	    }
	}
    } // end updateGraphInternal

    // private void updateProgressPanelDuringNetworkMetricsCalculation(
    // final List<Future<GraphLevelMetrics<Integer, Integer>>> rowResults,
    // final int numTasksInitially) {
    // SwingInvoker.runInEventDispathThread(new Runnable() {
    // @Override
    // public void run() {
    // progressPanel.setString("Calculating network statistics "
    // + networkDisplayModel.getNetworkDataType() + " graph. "
    // + (numTasksInitially - rowResults.size()) + " of "
    // + numTasksInitially + " metrics calculated.");
    // }
    // }, false /* wait */);
    // }
} // end class NetworkDisplay
