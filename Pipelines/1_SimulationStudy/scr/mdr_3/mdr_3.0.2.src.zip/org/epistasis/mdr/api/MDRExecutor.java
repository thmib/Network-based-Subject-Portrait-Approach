package org.epistasis.mdr.api;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.io.PrintWriter;
import java.io.Reader;
import java.math.BigInteger;
import java.net.URL;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.math3.exception.OutOfRangeException;
import org.epistasis.Utility;
import org.epistasis.mdr.AmbiguousCellStatus;
import org.epistasis.mdr.Console;
import org.epistasis.mdr.Main;
import org.epistasis.mdr.analysis.AnalysisThread;
import org.epistasis.mdr.analysis.AnalysisThread.AnalysisThreadBuilder;
import org.epistasis.mdr.analysis.ExhaustiveAnalysisThread.ExhaustiveAnalysisThreadBuilder;
import org.epistasis.mdr.enums.FitnessCriteriaOrder;
import org.epistasis.mdr.newengine.AttributeCombination;
import org.epistasis.mdr.newengine.AttributeCombinationWithWildcards;
import org.epistasis.mdr.newengine.Dataset;
import org.epistasis.mdr.newengine.Dataset.PermutationSupport;

public class MDRExecutor implements Runnable {
    private AmbiguousCellStatus ambiguousCellStatus = Main.defaultAmbiguousCellStatus;

    private final boolean computeAllModelsLandscape = Main.defaultComputeAllModelsLandscape;
    /* required parameters */
    private int cv = Main.defaultCrossValidationCount;
    /* optional parameters */
    private Dataset data;
    private final String dataFile;
    private int distributedNodeCount = Main.defaultDistributedNodeCount;
    private int distributedNodeNumber = Main.defaultDistributedNodeNumber;

    private List<AttributeCombination> forcedSearchAttributes = null;

    private int maxLevel = Main.defaultAttributeCountMax;

    private int minLevel = Main.defaultAttributeCountMin;
    private Runnable onEndAnalysis;

    private Runnable onEndLevel;
    private Runnable onEndModel;
    // like batch mode this should default to not parallel rather
    // thanMain.defaultParallel;
    private boolean parallel = false;
    private Dataset permutationDataset = null;
    private Dataset.PermutationSupport permutationSupport = null;
    private int[] restrictedSearchAttributes;
    private MDRResult result;
    private long seed = Main.defaultRandomSeed;

    /* results */
    private Status status = Status.UNCOMPLETED;

    private AnalysisThread thread;

    private final int topModelsLandscapeSize = Main.defaultTopModelsLandscapeSize;

    private FitnessCriteriaOrder topModelsFitnessCriteriaOrder = Main.defaultTopModelsFitnessCriteriaOrder;

    private FitnessCriteriaOrder bestModelFitnessCriteriaOrder = Main.defaultBestModelsFitnessCriteriaOrder;

    private PermutationResults permutationResults = null;

    /**
     * Specify a custom Dataset.
     */
    public MDRExecutor(final Dataset data) {
	setData(data);
	dataFile = "<programatically set data>";
    }

    /**
     * MDRExecutor will automatically generate a Dataset from this URL, URI, or
     * local filesystem location
     * 
     * @param dataFile
     *            A URL, URI, or file path pointing to the desired file
     * @throws IllegalArgumentException
     *             If the resource cannot be found.
     */
    public MDRExecutor(final String dataFile) throws IOException {
	this.dataFile = dataFile;
	Reader dataFileReader = null;
	// try as file
	try {
	    final File f = new File(dataFile);
	    if (f.exists()) {
		dataFileReader = new FileReader(f);
	    }
	} catch (final Throwable t) {
	}
	try {
	    final URL url = new URL(dataFile);
	    dataFileReader = new InputStreamReader(url.openConnection()
		    .getInputStream());
	} catch (final Throwable t) {
	}
	if (dataFileReader == null) {
	    throw new IllegalArgumentException(
		    "Cannot locate or identify resource: " + dataFile);
	}
	setData(new Dataset("MDRExecutor_" + dataFile, new LineNumberReader(
		dataFileReader)));
    }

    /**
     * Calls {@link Dataset#adjustForCovariate(long, String)} for the specified
     * attributes.
     * 
     * Note: this uses the current {@link #seed} since there is a randomness in
     * picking which rows to oversample in order to make the case control count
     * in each genotype the same Replaces {@link #data} with the result.
     * 
     * Cannot be undone!
     * 
     * @param attributeNamesToKeep
     * @throws Exception
     */
    public void adjustForCovariate(final String attributeNameToAdjustFor)
	    throws Exception {
	setData(data.adjustForCovariate(getSeed(), attributeNameToAdjustFor));
    }

    public MDRExecutor clearRestrictedSearchAttributes() {
	restrictedSearchAttributes = null;
	return this;

    }

    /**
     * Uses {@link #data} and {@link #ambiguousCellStatus} in constructing
     * attribute
     * 
     * @param constructedAttributeName
     *            -- Must not already exist. If null a name will be created by
     *            joining the attributeNames with underscores.
     * @param throwExceptionOnUnknownAttributes
     * @param attributeNamesToSearch
     * @returns the name of the constructed attribute in case you did not
     *          specify it
     */
    public String constructAttribute(
	    final boolean throwExceptionOnUnknownAttributes,
	    String constructedAttributeName,
	    final String... attributeNamesToSearch) {
	if ((constructedAttributeName == null)
		|| (constructedAttributeName.trim().length() == 0)) {
	    constructedAttributeName = Utility
		    .join(attributeNamesToSearch, '_');
	}
	data.constructAndAddAttribute(attributeNamesToSearch,
		constructedAttributeName, ambiguousCellStatus);
	return constructedAttributeName;
    }

    private AnalysisThread createThread() {
	/*
	 * return new ExhaustiveAnalysisThread(data, partition, tiePriorityList,
	 * scoringMethod, seed, onEndModel, onEndLevel, onEndAnalysis, parallel,
	 * topModelsLandscapeSize, computeAllModelsLandscape, minLevel, //
	 * ((min|max) + Attr) == ((min|max) + Level) ? happy() // : sad()
	 * maxLevel);
	 */
	// Console.console.setDataset(data, DatasetStackAction.DO_NOTHING);

	if (data == null) {
	    throw new IllegalArgumentException(
		    "Data is null! Must be set before running MDR.");
	}
	AnalysisThreadBuilder<? extends AnalysisThread> analysisThreadBuilder;
	final ExhaustiveAnalysisThreadBuilder threadBuilder = new ExhaustiveAnalysisThreadBuilder(
		data, cv, seed);
	analysisThreadBuilder = threadBuilder;
	threadBuilder.setForced(forcedSearchAttributes).setMinAttr(minLevel)
		.setMaxAttr(maxLevel);

	return analysisThreadBuilder
		.setTiePriorityList(ambiguousCellStatus)
		.setParallel(parallel)
		.setTopModelsLandscapeSize(topModelsLandscapeSize)
		.setComputeAllModelsLandscape(computeAllModelsLandscape)
		.setOnEndAnalysis(onEndAnalysis)
		.setOnEndLevel(onEndLevel)
		.setOnEndModel(onEndModel)
		.setRestrictedSearchAttributes(restrictedSearchAttributes)
		.setDistributedNodeCount(distributedNodeCount)
		.setDistributedNodeNumber(distributedNodeNumber)
		.setTopModelsFitnessCriteriaOrder(topModelsFitnessCriteriaOrder)
		.setBestModelFitnessCriteriaOrder(bestModelFitnessCriteriaOrder)
		.build();

    }

    public PermutationResults enterPermutationMode(
	    final FitnessCriteriaOrder permutationFitnessCriteriaOrder,
	    final MDRResult originalResult, final long permutationRandomSeed) {
	return enterPermutationMode(permutationFitnessCriteriaOrder,
		originalResult, permutationRandomSeed,
		/* useExplicitTestOfInteraction */false,
		PermutationSupport.PERMUTATION_DEFAULT_START_INDEX);

    }

    /**
     * Set up permutation for the current dataset
     * 
     * @param permutationRandomSeed
     * @param useExplicitTestOfInteraction
     * @param permutationStartIndex
     *            this is used to advance the random seed used to permute
     *            datasets. The purpose is for distributed permutation across
     *            machines and reproducibility. When I permute 1000 times
     *            ideally it would be nice to get the identical answer
     *            regardless of whether I did it on one machine or 1000
     *            machines. For the 1000 machine case, passing this value to
     *            each instance running a permutation will make it so that the
     *            seed used is the same as used in the single machine case.
     *            Internally, each permutation uses a distinct random number
     *            generator. The permutationSeed is used to create a master
     *            generator which in turn is used to seed the individual
     *            permutation generators. So this parameter is used to advance
     *            the master generator to the same place it would be if this was
     *            being run on a single machine.
     * 
     * @return
     */
    public PermutationResults enterPermutationMode(
	    final FitnessCriteriaOrder permutationFitnessCriteriaOrder,
	    final MDRResult originalResult, final long permutationRandomSeed,
	    final boolean useExplicitTestOfInteraction,
	    final int permutationStartIndex) {
	if (inPermutationMode()) {
	    throw new IllegalArgumentException(
		    "enterPermutationMode called but already in permutation mode. Call exitPermutationMode first.");
	}
	permutationDataset = data;
	permutationResults = new PermutationResults(
		permutationFitnessCriteriaOrder,
		(originalResult == null) ? null : originalResult
			.getLevelResults());
	permutationSupport = permutationDataset.new PermutationSupport(
		permutationRandomSeed, useExplicitTestOfInteraction,
		permutationStartIndex);
	return permutationResults;
    }

    public PermutationResults enterPermutationMode(
	    final long permutationRandomSeed,
	    final boolean useExplicitTestOfInteraction) {
	return enterPermutationMode(Main.defaultInterLevelFitnessCriteriaOrder,
		(MDRResult) null, permutationRandomSeed,
		useExplicitTestOfInteraction,
		PermutationSupport.PERMUTATION_DEFAULT_START_INDEX);
    }

    /**
     * Before calling this, if keepPermutationResults was set to true, you
     * should call getPermutationBestModelResults or (less likely)
     * getPermutationAllLevelsResults
     */
    public void exitPermutationMode() {
	if (!inPermutationMode()) {
	    throw new IllegalArgumentException(
		    "exitPermutationMode called but not in permutation mode!");
	}
	permutationDataset = null;
	permutationSupport = null;
	permutationResults = null;
    }

    /**
     * Calls {@link Dataset#filter(int[])} on the specified attributes. The
     * filtered dataset will only contain the attributes passed in. If either no
     * attributes are passed in or none are found the resulting dataset will
     * have zero attributes. Does nothing if none of the given attributes exist
     * in the file, and consequently if the length of {@code attrName} is 0.
     * Note -- the order of attributes in the returned dataset is the order of
     * the original dataset -- not the order of the passed in attribute names
     * Replaces {@link #data} with the result. Cannot be undone!
     * 
     * If you just wish to search on a subset of a dataset, use
     * setRestrictedSearchAttributes instead
     * 
     * @param throwExceptionOnUnknownAttributes
     * @param attributeNamesToKeep
     *            -- list of names or indices in any order
     * @return the newly created dataset (which also is made the current dataset
     *         for the MDRExecutor)
     */
    public Dataset filterData(final boolean throwExceptionOnUnknownAttributes,
	    final String... attributeNamesToKeep) {
	final int[] attributeIndicesInAscendingOrder = data
		.attributeNameListToAscendingIndicesArray(
			throwExceptionOnUnknownAttributes, attributeNamesToKeep);
	setData(data.filter(attributeIndicesInAscendingOrder));
	return data;
    }

    public AmbiguousCellStatus getAmbiguousCellStatus() {
	return ambiguousCellStatus;
    }

    /* getters and setters */
    public int getCv() {
	return cv;
    }

    public String getDataFile() {
	return dataFile;
    }

    public Dataset getDataset() {
	return data;
    }

    public int getDistributedNodeCount() {
	return distributedNodeCount;
    }

    public int getDistributedNodeNumber() {
	return distributedNodeNumber;
    }

    public List<AttributeCombination> getForcedSearchAttributes() {
	return forcedSearchAttributes;
    }

    public int getMaxLevel() {
	return maxLevel;
    }

    public int getMinLevel() {
	return minLevel;
    }

    /**
     * @see Console#getNumberOfModelCombinations(int, int, int)
     */
    public BigInteger getNumberOfModelCombinations() {
	final int numberOfAttributes = data.getCols() - 1;
	final int minModelSize = minLevel;
	final int maxModelSize = maxLevel;
	return Console.getNumberOfModelCombinations(numberOfAttributes,
		minModelSize, maxModelSize);
    }

    /**
     * @see MDRExecutor#getNumberOfModelCombinations() * crossValidationCount
     */
    public BigInteger getNumberOfModelTests() {
	final int numberOfAttributes = data.getCols() - 1;
	final int minModelSize = minLevel;
	final int maxModelSize = maxLevel;
	final int crossValidationCount = cv;
	return Console.getNumberOfModelTests(numberOfAttributes, minModelSize,
		maxModelSize, crossValidationCount);
    }

    /**
     * @return the same object returned by enterPermutationMode
     */
    public PermutationResults getPermutationResults() {
	if (!inPermutationMode()) {
	    throw new IllegalArgumentException(
		    "getPermutationAllLevelsResults called but not in permutation mode!");
	} else if (permutationResults == null) {
	    throw new IllegalArgumentException(
		    "getPermutationAllLevelsResults called but results were not requested to be kept in call to enterPermutationMode");
	}
	return permutationResults;
    }

    public MDRResult getResult() {
	return result;
    }

    public long getSeed() {
	return seed;
    }

    public Status getStatus() {
	return status;
    }

    public int getStatusAsInt() {
	return status.asInt();
    }

    public boolean inPermutationMode() {
	return permutationSupport != null;
    }

    /**
     * By default parallel is false. Parallel controls how many threads MDR
     * uses. If set to true then MDR will run each level of analysis in separate
     * threads. Additionally, within each level, multiple threads will be used
     * to evaluate the combinations. MDR will use as many processors as exist.
     * The number to use cannot be specified
     * 
     * @return
     */
    public boolean isParallel() {
	return parallel;
    }

    public MDRExecutor permuteDataset() {
	if (!inPermutationMode()) {
	    throw new IllegalArgumentException(
		    "permuteDataset called but not in permutation mode (enterPermutationMode needs to be called).");
	}
	if (data != permutationDataset) {
	    throw new IllegalArgumentException(
		    "permuteDataset called but internal dataset object not the same as when enterPermutationMode was called");
	}
	permutationSupport.permuteData();
	return this;
    }

    /**
     * Sets the seed to the current time, i.e.
     * {@link java.lang.System#currentTimeMillis()} This is equivalent to:
     * {@code
     * setSeed(System.currentTimeMillis());
     * }
     */
    public MDRExecutor randomizeSeed() {
	seed = System.currentTimeMillis();
	return this;
    }

    /**
     * This method can be used for custom execution. Upon completion, check the
     * {@link Status} of the executor. A status of {@link Status#COMPLETED}
     * indicates the results are available through {@link #getResult()}.
     * 
     * @throws RuntimeException
     *             When there is an exception in execution
     * @see #getStatus()
     * @see #getStatusAsInt()
     * @see #getResult()
     */
    @Override
    public void run() {
	final MDRParameters param = new MDRParameters();
	param.computeAllModelsLandscape = computeAllModelsLandscape;
	param.cv = cv;
	param.data = data;
	param.maxLevel = maxLevel;
	param.minLevel = minLevel;
	param.parallel = parallel;
	param.seed = seed;
	param.tiePriorityList = ambiguousCellStatus;
	param.topModelsLandscapeSize = topModelsLandscapeSize;
	param.distributedNodeCount = distributedNodeCount;
	param.distributedNodeNumber = distributedNodeNumber;
	param.topModelsFitnessCriteriaOrder = topModelsFitnessCriteriaOrder;
	param.bestModelFitnessCriteriaOrder = bestModelFitnessCriteriaOrder;
	try {
	    thread = createThread();
	    param.thread = thread;
	    thread.run();
	} catch (final Throwable t) {
	    t.printStackTrace();
	    status = Status.FAILED;
	    param.status = status;
	    throw new RuntimeException(t.getMessage() + " " + param.toString(),
		    t);
	}
	status = Status.COMPLETED;
	param.status = status;
	result = new MDRResult(param);
	if (inPermutationMode() && (permutationResults != null)) {

	    permutationResults.addPermutationResult(result.getLevelResults());
	}
    }

    /**
     * This method will use the current thread to execute MDR
     * 
     * @see #run()
     */
    public MDRExecutor runInCurrentThread() {
	run();
	return this;
    }

    /**
     * This creates a thread in which MDR can run and starts it. This is
     * equivalent to: {@code
     * Thread t = new Thread(mdrExecutorInstance);
     * t.start();
     * }
     * 
     * @return The thread in which MDR is running
     * @see #run()
     */
    public Thread runParallel() {
	final Thread t = new Thread(this, "MDRExecutor_runParallel");
	t.start();
	return t;
    }

    public MDRExecutor setAmbiguousCellStatus(
	    final AmbiguousCellStatus ambiguousCellStatus) {
	this.ambiguousCellStatus = ambiguousCellStatus;
	return this;
    }

    public MDRExecutor setBestModelFitnessCriteriaOrder(
	    final FitnessCriteriaOrder bestModelFitnessCriteriaOrder) {
	this.bestModelFitnessCriteriaOrder = bestModelFitnessCriteriaOrder;
	return this;
    }

    /* setters */
    public MDRExecutor setCv(final int cv) {
	this.cv = cv;
	return this;
    }

    public MDRExecutor setData(final Dataset newDataset) {
	data = newDataset;
	return this;
    }

    public MDRExecutor setDistributedNodeCount(final int distributedNodeCount) {
	this.distributedNodeCount = distributedNodeCount;
	return this;
    }

    public MDRExecutor setDistributedNodeNumber(final int distributedNodeNumber) {
	this.distributedNodeNumber = distributedNodeNumber;
	return this;
    }

    public MDRExecutor setForcedSearchAttributes(
	    final List<AttributeCombination> list) {
	forcedSearchAttributes = list;
	return this;
    }

    public MDRExecutor setForcedSearchAttributes(final String comboString) {
	setForcedSearchAttributes(AttributeCombinationWithWildcards
		.parseComboWithPossibilityOfWildcards(comboString,
			data.getNumAttributes(), data.getLabels()));
	return this;
    }

    public MDRExecutor setMaxLevel(final int maxLevel) {
	this.maxLevel = maxLevel;
	return this;
    }

    public MDRExecutor setMinLevel(final int minLevel) {
	this.minLevel = minLevel;
	return this;
    }

    public MDRExecutor setOnEndAnalysis(final Runnable onEndAnalysis) {
	this.onEndAnalysis = onEndAnalysis;
	return this;
    }

    public MDRExecutor setOnEndLevel(final Runnable onEndLevel) {
	this.onEndLevel = onEndLevel;
	return this;
    }

    public MDRExecutor setOnEndModel(final Runnable onEndModel) {
	this.onEndModel = onEndModel;
	return this;
    }

    public MDRExecutor setParallel(final boolean parallel) {
	this.parallel = parallel;
	return this;
    }

    /**
     * 
     * @param throwExceptionOnUnknownAttributes
     * @param attributeNamesToSearch
     *            -- list of names or indices in any order
     * @return
     */
    public MDRExecutor setRestrictedSearchAttributes(
	    final boolean throwExceptionOnUnknownAttributes,
	    final String... attributeNamesToSearch) {
	if (attributeNamesToSearch == null) {
	    clearRestrictedSearchAttributes();
	} else {
	    setRestrictedSearchAttributes(
		    data.attributeNameListToAscendingIndicesArray(
			    throwExceptionOnUnknownAttributes,
			    attributeNamesToSearch), true /* skipSortAndSanityChecks */);
	}
	return this;

    }

    /**
     * 
     * @param attributeIndicesToSearch
     *            -- note this passed copy is kept and used. This is an
     *            optimization and can cause errors if you expect this change
     *            this while running asynchronously
     * @param skipSortAndSanityChecks
     *            normally defensive programming would dictate that we check the
     *            input to make sure it is sorted order and does not contain
     *            duplicates or out of range values. This will prevent those
     *            checks from being performed
     * @return
     */
    public MDRExecutor setRestrictedSearchAttributes(
	    final int[] attributeIndicesToSearch,
	    final boolean skipSortAndSanityChecks) {
	if (attributeIndicesToSearch == null) {
	    clearRestrictedSearchAttributes();
	} else {
	    if (!skipSortAndSanityChecks) {
		Arrays.sort(attributeIndicesToSearch);
		final int numAttributes = data.getNumAttributes();
		for (int attributeListIndex = 0; attributeListIndex < attributeIndicesToSearch.length; ++attributeListIndex) {
		    final int attributeIndex = attributeIndicesToSearch[attributeListIndex];
		    if (attributeListIndex > 0) {
			// make sure there are no duplicates
			if (attributeIndex == attributeIndicesToSearch[attributeListIndex - 1]) {
			    throw new RuntimeException("Index "
				    + attributeIndex
				    + " is duplicated at least once");
			}
		    }
		    if ((attributeIndex < 0)
			    || (attributeIndex >= numAttributes)) {
			throw new OutOfRangeException(attributeIndex, 0,
				numAttributes - 1);
		    }
		}
	    }
	    restrictedSearchAttributes = attributeIndicesToSearch;
	}
	return this;

    }

    public MDRExecutor setSeed(final long seed) {
	this.seed = seed;
	return this;
    }

    public MDRExecutor setTopModelsFitnessCriteriaOrder(
	    final FitnessCriteriaOrder topModelsFitnessCriteriaOrder) {
	this.topModelsFitnessCriteriaOrder = topModelsFitnessCriteriaOrder;
	return this;
    }

    /**
     * This will write the current dataset with all attribute columns and the
     * status column
     * 
     * @param datasetPath
     */
    public void writeDataset(final PrintWriter datasetWriter) {
	data.write(datasetWriter);
    }

    /**
     * 
     * @param datasetPath
     * @param throwExceptionOnUnknownAttributes
     * @param attributeNamesToWrite
     *            -- list of names or indices in any order
     */
    public void writeDataset(final PrintWriter datasetWriter,
	    final boolean throwExceptionOnUnknownAttributes,
	    final String... attributeNamesToWrite) {
	final int[] attributeIndicesInAscendingOrder = data
		.attributeNameListToAscendingIndicesArray(
			throwExceptionOnUnknownAttributes,
			attributeNamesToWrite);
	data.write(datasetWriter, attributeIndicesInAscendingOrder);
    }

    static class MDRParameters {
	public FitnessCriteriaOrder bestModelFitnessCriteriaOrder;
	public FitnessCriteriaOrder topModelsFitnessCriteriaOrder;
	public boolean computeAllModelsLandscape;
	public int cv;
	public Dataset data;
	public int distributedNodeCount;
	public int distributedNodeNumber;
	public int maxLevel;
	public int minLevel;
	public boolean parallel;
	public long seed = 0;
	public Status status;
	public AnalysisThread thread;
	public AmbiguousCellStatus tiePriorityList;
	public int topModelsLandscapeSize;

	@Override
	public String toString() {
	    return "MDRParameters: cv=" + cv + " minLevel=" + minLevel
		    + " maxLevel=" + maxLevel + " seed=" + seed
		    + " ambiguousCellStatus=" + tiePriorityList
		    + " topModelsLandscapeSize=" + topModelsLandscapeSize
		    + " parallel=" + parallel + " computeAllModelsLandscape="
		    + computeAllModelsLandscape;
	}
    }

}
