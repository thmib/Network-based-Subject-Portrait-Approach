package org.epistasis.mdr.networkEntropy;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.SystemColor;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.Vector;

import javax.swing.Icon;
import javax.swing.JLabel;

import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;

import edu.uci.ics.jung.algorithms.importance.AbstractRanker;
import edu.uci.ics.jung.algorithms.metrics.Metrics;
import edu.uci.ics.jung.algorithms.scoring.AbstractIterativeScorer;
import edu.uci.ics.jung.algorithms.scoring.VertexScorer;
import edu.uci.ics.jung.graph.Graph;

public class GraphLevelMetrics<V, E> {
    private final String metricName;
    private Exception exception = null;
    DescriptiveStatistics descriptiveStatistics = new DescriptiveStatistics();

    private final JLabel sparklineJLabel = new JLabel();

    public static <V, E> GraphLevelMetrics<V, E> getGraphLevelMetricsFromJungClusteringCoefficients(
	    final Graph<V, E> jungGraph) {
	final long startTime = System.currentTimeMillis();
	Exception exception = null;
	final Vector<Double> scores = new Vector<Double>(
		jungGraph.getVertexCount());
	final String metricName = "ClusteringCoefficents";
	try {
	    final Map<V, Double> clusteringCoefficients = Metrics
		    .clusteringCoefficients(jungGraph);
	    scores.addAll(clusteringCoefficients.values());
	} catch (final Exception ex) {
	    exception = ex;
	}
	final GraphLevelMetrics<V, E> graphLevelMetrics = new GraphLevelMetrics<V, E>(
		jungGraph, metricName, scores, System.currentTimeMillis()
			- startTime, exception);
	return graphLevelMetrics;
    }

    public static <V, E> GraphLevelMetrics<V, E> getGraphLevelMetricsFromJungRanker(
	    final Graph<V, E> jungGraph, final AbstractRanker<V, E> ranker) {
	final long startTime = System.currentTimeMillis();
	Exception exception = null;
	final Vector<Double> scores = new Vector<Double>(
		jungGraph.getVertexCount());
	String metricName = ranker.getRankScoreKey().toString();
	final int simpleNameStartPos = metricName.lastIndexOf('.');
	if (simpleNameStartPos != -1) {
	    metricName = metricName.substring(simpleNameStartPos + 1);
	}
	try {
	    ranker.setRemoveRankScoresOnFinalize(false /* removeRankScoresOnFinalize */);
	    ranker.evaluate();
	    for (final V vertex : jungGraph.getVertices()) {
		scores.add(ranker.getVertexRankScore(vertex));
	    }
	} catch (final Exception ex) {
	    exception = ex;
	}
	final GraphLevelMetrics<V, E> graphLevelMetrics = new GraphLevelMetrics<V, E>(
		jungGraph, metricName, scores, System.currentTimeMillis()
			- startTime, exception);
	return graphLevelMetrics;
    }

    public static <V, E> GraphLevelMetrics<V, E> getGraphLevelMetricsFromJungScorer(
	    final Graph<V, E> jungGraph,
	    final VertexScorer<V, ? extends Number> scorer) {
	return GraphLevelMetrics.getGraphLevelMetricsFromJungScorer(jungGraph,
		scorer, scorer.getClass().getSimpleName());
    }

    public static <V, E> GraphLevelMetrics<V, E> getGraphLevelMetricsFromJungScorer(
	    final Graph<V, E> jungGraph,
	    final VertexScorer<V, ? extends Number> scorer,
	    final String metricName) {
	final long startTime = System.currentTimeMillis();
	Exception exception = null;
	final Vector<Double> scores = new Vector<Double>(
		jungGraph.getVertexCount());
	try {
	    if (scorer instanceof AbstractIterativeScorer<?, ?, ?>) {
		final AbstractIterativeScorer<?, ?, ?> abstractIterativeScorer = (AbstractIterativeScorer<?, ?, ?>) scorer;
		abstractIterativeScorer.setMaxIterations(Math.max(25000,
			jungGraph.getVertexCount()));
		// abstractIterativeScorer.acceptDisconnectedGraph(true);
		// abstractIterativeScorer.setTolerance(0.001);
		// System.out.println("Calling evaluate for " + metricName);
		abstractIterativeScorer.evaluate();
		// System.out.println("Finished evaluation for " + metricName +
		// " took "
		// + (System.currentTimeMillis() - startTime) + "ms., done: "
		// + abstractIterativeScorer.done() + " total iterations: "
		// + abstractIterativeScorer.getIterations() + ", out of max: "
		// + abstractIterativeScorer.getMaxIterations()
		// + ", isDisconnectedGraphOK: "
		// + abstractIterativeScorer.isDisconnectedGraphOK()
		// + ", getTolerance(): " +
		// abstractIterativeScorer.getTolerance());
	    }
	    for (final V vertex : jungGraph.getVertices()) {
		scores.add(scorer.getVertexScore(vertex).doubleValue());
	    }
	} catch (final Exception ex) {
	    exception = ex;
	}
	final GraphLevelMetrics<V, E> graphLevelMetrics = new GraphLevelMetrics<V, E>(
		jungGraph, metricName, scores, System.currentTimeMillis()
			- startTime, exception);
	return graphLevelMetrics;
    }

    GraphLevelMetrics(final Graph<V, E> jungGraph, final String metricName,
	    final Vector<Double> scores, final long millisecondsToCalculate,
	    final Exception exception) {
	this.metricName = metricName;
	this.exception = exception;
	if (exception == null) {
	    try {
		for (final Double score : scores) {
		    descriptiveStatistics.addValue(score);
		}
		// if (jungGraph.getVertexCount() != scores.size()) {
		// final String errorMessage =
		// "GraphLevelMetrics:  the number of scores passed in ("
		// + scores.size()
		// + ") does not equal the number of vertices ("
		// + jungGraph.getVertexCount() + ") ! ";
		// System.err.println(errorMessage);
		// throw new IllegalArgumentException(errorMessage);
		// }
		// final int numVertices = jungGraph.getVertexCount();
		// double sumOfScores = 0;
		// final double[] vertexScoresSquared = new
		// double[scores.size()];
		// int vertexCtr = 0;
		// for (final Double score : scores) {
		// descriptiveStatistics.addValue(score);
		// if (!Double.isNaN(score)) {
		//
		// maxScore = Math.max(maxScore, score);
		// minScore = Math.min(minScore, score);
		// sumOfScores += score;
		// vertexScoresSquared[vertexCtr] = score * score;
		// }
		// ++vertexCtr;
		// }
		// averageScore = sumOfScores / scores.size();
		// double sumOfProductOfEdgeVertexScores = 0;
		// double sumOfAdditionOfEdgeVertexScores = 0;
		// double sumOfAdditionOfEdgeVertexSquaredScores = 0;
		// final Vector<V> vertices = new Vector<V>(
		// jungGraph.getVertices());
		// final Collection<E> edges = jungGraph.getEdges();
		// for (final E edge : edges) {
		// final edu.uci.ics.jung.graph.util.Pair<V> endPoints =
		// jungGraph
		// .getEndpoints(edge);
		// final V vertex1 = endPoints.getFirst();
		// final V vertex2 = endPoints.getSecond();
		// final int vertex1LoopupIndex = vertices.indexOf(vertex1);
		// final int vertex2LoopupIndex = vertices.indexOf(vertex2);
		// final double vertex1Score = scores.get(vertex1LoopupIndex);
		// final double vertex2Score = scores.get(vertex2LoopupIndex);
		// sumOfProductOfEdgeVertexScores += vertex1Score
		// * vertex2Score;
		// sumOfAdditionOfEdgeVertexScores += vertex1Score
		// + vertex2Score;
		// sumOfAdditionOfEdgeVertexSquaredScores +=
		// vertexScoresSquared[vertex1LoopupIndex]
		// + vertexScoresSquared[vertex2LoopupIndex];
		// } // end edge loop
		// final int numEdges = edges.size();
		// // ................averageProductOfVertexScores -
		// // squaredAverageVertexScore
		// // assortativity =
		// //
		// --------------------------------------------------------------------------------------
		// // ..................averageVertexSquaredScore. -
		// // squaredAverageVertexScore
		// final double averageProductOfVertexScores =
		// sumOfProductOfEdgeVertexScores
		// / numEdges;
		// final double averageVertexSquaredScore =
		// sumOfAdditionOfEdgeVertexSquaredScores
		// / (2 * numEdges);
		// final double averageVertexScore =
		// sumOfAdditionOfEdgeVertexScores
		// / (2 * numEdges);
		// final double squareOfAverageVertexScore = averageVertexScore
		// * averageVertexScore;
		// final double numerator = averageProductOfVertexScores
		// - squareOfAverageVertexScore;
		// final double denominator = averageVertexSquaredScore
		// - squareOfAverageVertexScore;
		// // division by zero results in NaN but a fully connected
		// graph
		// // will have zero variability and therefore result in
		// zero/zero.
		// // In this
		// // special case the correlation is perfect and therefore the
		// // assortativity is one
		// if (!Double.isNaN(numerator)
		// && (Double.compare(numerator, denominator) == 0)) {
		// assortativity = 1.0;
		// } else {
		// assortativity = numerator / denominator;
		// }
	    } catch (final Exception ex) {
		this.exception = ex;
	    }
	} // end if no exception passed in
    } // end constructor

    // public double getAssortativity() {
    // return assortativity;
    // }
    //
    public double getAverageScore() {
	return descriptiveStatistics.getMean();
    }

    public DescriptiveStatistics getDescriptiveStatistics() {
	return descriptiveStatistics;
    }

    public Exception getException() {
	return exception;
    }

    public double getMaxScore() {
	return descriptiveStatistics.getMax();
    }

    public String getMetricName() {
	return metricName;
    }

    public double getMinScore() {
	return descriptiveStatistics.getMin();
    }

    public Double getNodeScore(final int nodeIndex) {
	return descriptiveStatistics.getElement(nodeIndex);
    }

    public double[] getScores() {
	// this is a fresh copy
	return descriptiveStatistics.getValues();
    }

    public double[] getSortedScores() {
	// this is a fresh copy
	return descriptiveStatistics.getSortedValues();
    }

    public Double[] getSortedSetOfScores() {
	final double[] sortedScores = getSortedScores();

	final SortedSet<Double> sortedSet = new TreeSet<Double>();
	for (final double score : sortedScores) {
	    sortedSet.add(score);
	}
	final Double[] sortedSetArray = new Double[sortedSet.size()];
	sortedSet.toArray(sortedSetArray);

	return sortedSetArray;
    }

    public Component getSparklineJLabel(final int height, final int width) {
	final Icon icon = sparklineJLabel.getIcon();
	if ((icon == null) || (icon.getIconHeight() != height)
		|| (icon.getIconWidth() != width)) {
	    final Double[] sortedSet = getSortedSetOfScores();
	    if (sortedSet != null) {
		sparklineJLabel.setIcon(new SparklineIcon(height, width,
			sortedSet, true /* doReverse */));
	    } else {
		sparklineJLabel.setIcon(null);
	    }
	}
	return sparklineJLabel;
    } // end getSparklineJLabel // end class GraphLevelMetrics

    public boolean isValid() {
	return descriptiveStatistics.getN() > 0;
    }

    @Override
    public String toString() {
	return "metricName: " + metricName + "\n"
		+ descriptiveStatistics.toString();

    }

    /**
     * Utility class. Given a list of values figure out min and max without
     * counting infinite and Nan values
     * 
     * @author pandrews
     */
    public static class MinimumMaximum {
	public double minimum = Double.POSITIVE_INFINITY;
	public double maximum = Double.NEGATIVE_INFINITY;

	public MinimumMaximum(final Double[] values) {
	    for (final Double value : values) {
		if (!(Double.isInfinite(value) || Double.isNaN(value))) {
		    minimum = Math.min(minimum, value);
		    maximum = Math.max(maximum, value);
		}
	    } // end loop
	} // end constructor
    } // end MinimumMaximum class

    public final static class SparklineIcon implements Icon {
	private final int height;
	private final int width;
	private final Double[] values;
	private final boolean doReverse;

	/**
	 * @param g
	 * @param reverseOrder
	 * @param trackRect
	 * @param spinnerValuesArray
	 *            this must be sorted ascending
	 */
	public static void drawSparkline(final Graphics g,
		final Rectangle rect, final Double[] values,
		final Color drawColor, final Integer fillValueIndex,
		final boolean reverseOrder) {
	    if ((values == null) || (values.length == 1)) {
		return;
	    }
	    final MinimumMaximum minMax = new MinimumMaximum(values);
	    final double totalRange = minMax.maximum - minMax.minimum;
	    if (totalRange > 0) {
		final double indicesPerHorizontalPixel = (values.length - 1)
			/ (double) rect.width;
		final int[] xPoints = new int[rect.width + 2];
		final int[] yPoints = new int[rect.width + 2];
		int fillValueXPosition = -1;
		int fillValuePointIndex = -1;
		for (int xOffset = 0; xOffset < rect.width; ++xOffset) {
		    final int currentPointIndex = xOffset;
		    final int xPosition = rect.x + xOffset;
		    xPoints[currentPointIndex] = xPosition;
		    int valuesListIndex = (int) Math.ceil(xOffset
			    * indicesPerHorizontalPixel) - 1;
		    if ((valuesListIndex + 1) == fillValueIndex) {
			fillValueXPosition = xPosition;
			fillValuePointIndex = currentPointIndex;
		    }
		    if (reverseOrder) {
			final int reversedValueListIndex = (values.length - 1)
				- valuesListIndex;
			// System.out.println("valuesListIndex: " +
			// valuesListIndex
			// + " reversed to " + reversedValueListIndex);
			valuesListIndex = reversedValueListIndex;
		    }
		    // final int sliderValueAtX = valueForXPosition(xPosition);
		    final double value = ((valuesListIndex >= 0) && (valuesListIndex < values.length)) ? values[valuesListIndex]
			    : Double.POSITIVE_INFINITY;
		    final double valuePercentOfRange = Math.min(100.0,
			    ((value - minMax.minimum) / totalRange));
		    yPoints[currentPointIndex] = (int) (((rect.y + rect.height) - 1) - (valuePercentOfRange * rect.height));
		} // end for loop for each point
		final Color oldColor = g.getColor();
		g.setColor(drawColor);
		xPoints[rect.width + 0] = rect.x + (rect.width - 1);
		xPoints[rect.width + 1] = rect.x;
		yPoints[rect.width + 0] = yPoints[rect.width + 1] = rect.y
			+ rect.height;
		g.fillPolygon(xPoints, yPoints, xPoints.length);
		g.drawPolyline(xPoints, yPoints, rect.width - 1);
		if (fillValueIndex != null) {
		    g.setColor(Color.lightGray);
		    xPoints[fillValuePointIndex + 1] = fillValueXPosition;
		    xPoints[fillValuePointIndex + 2] = rect.x;
		    yPoints[fillValuePointIndex + 1] = yPoints[fillValuePointIndex + 2] = rect.y
			    + rect.height;
		    g.fillPolygon(xPoints, yPoints, fillValuePointIndex + 3);
		}
		g.setColor(oldColor);
	    } // end if min and max are different
	} // end drawSparkline

	public SparklineIcon(final int height, final int width,
		final Double[] values, final boolean doReverse) {
	    this.height = height;
	    this.width = width;
	    this.values = values;
	    this.doReverse = doReverse;
	}

	@Override
	public int getIconHeight() {
	    return height;
	}

	@Override
	public int getIconWidth() {
	    return width;
	}

	@Override
	public void paintIcon(final Component c, final Graphics g, final int x,
		final int y) {
	    if (values != null) {
		SparklineIcon.drawSparkline(g, new Rectangle(x, y, width,
			height), values, SystemColor.textHighlight,
			values.length, doReverse);
	    }
	} // end paintIcon
    } // end class SparklineIcon
} // end class GraphLevelMetrics
