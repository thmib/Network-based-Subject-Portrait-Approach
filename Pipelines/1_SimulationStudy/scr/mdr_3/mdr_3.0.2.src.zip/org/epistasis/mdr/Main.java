package org.epistasis.mdr;

import java.awt.Dimension;
import java.awt.GraphicsEnvironment;
import java.awt.Toolkit;
import java.io.File;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.util.Locale;

import javax.swing.UIManager;

import org.epistasis.Utility;
import org.epistasis.gui.SwingPropUtils;
import org.epistasis.mdr.Console.STATUS;
import org.epistasis.mdr.enums.FilterMethod;
import org.epistasis.mdr.enums.FitnessCriteriaOrder;
import org.epistasis.mdr.enums.SearchMethod;
import org.epistasis.mdr.enums.TimeUnits;
import org.epistasis.mdr.enums.WeightScheme;
import org.epistasis.mdr.gui.Frame;
import org.epistasis.mdr.newengine.AttributeCombination;

public class Main {
    public static final String EXPORT_DATAFILE = "Export Datafile";
    public static final String REVERT_DATAFILE = "Revert Datafile";
    public static final String NAN = "NaN";
    public static boolean isExperimental = false;
    public static int minimumRandomSeed;
    public static final boolean defaultComputeAllModelsLandscape = false;
    public static final boolean defaultPreserveTuRFRemovalOrder = false;
    public static final long defaultRandomSeed = 0;
    public static final int defaultAttributeCountMin = 1;
    public static final int defaultAttributeCountMax = 3;
    public static final AttributeCombination defaultForcedAttributeCombination = null;
    public static final double defaultRatioThreshold = 1.0;
    public static final boolean defaultAutoRatioThreshold = false;
    public static final int defaultCrossValidationCount = 10;
    public static final int defaultTopModelsLandscapeSize = 500;
    public static final boolean defaultPairedAnalysis = false;
    public static final AmbiguousCellStatus defaultAmbiguousCellStatus = AmbiguousCellStatus.AFFECTED;
    public static final SearchMethod defaultSearchType = SearchMethod.EXHAUSTIVE;
    public static final boolean defaultIsRandomSearchEvaluations = true;
    public static final boolean defaultIsRandomSearchRuntime = false;
    public static final int defaultRandomSearchEvaluations = 1000;
    public static final double defaultRandomSearchRuntime = 10.0;
    public static final TimeUnits defaultRandomSearchRuntimeUnits = TimeUnits.Minutes;
    public static final int defaultEDANumUpdates = 100;
    public static final int defaultEDANumAgents = 100;
    public static final double defaultEDARetention = 0.5;
    public static final int defaultEDAAlpha = 1;
    public static final int defaultEDABeta = 1;
    public static final double defaultEDAPercentMaxAttributeRange = 100.0;
    public static final double defaultEDAExponentialTheta = 0.85;
    public static final WeightScheme defaultEDAWeightingMethod = WeightScheme.PROPORTIONAL;
    public static final FilterMethod defaultFilterMethod = FilterMethod.RELIEFF;
    public static final int defaultCriterionIndex = 0;
    public static final int defaultCriterionFilterTopN = 5;
    public static final double defaultCriterionFilterTopPct = 5.0;
    public static final double defaultCriterionFilterThreshold = 0.0;
    public static final boolean defaultChiSquaredPValue = false;
    public static final boolean defaultReliefFWholeDataset = true;
    public static final int defaultReliefFNeighbors = 10;
    public static final int defaultReliefFSampleSize = 100;
    public static final int defaultTuRFPct = 10;
    public static final int defaultEntropyGraphLineThickness = 5;
    public static final int defaultEntropyGraphTextSize = 16;
    public static final double pValueTol = 0.0001;

    public static final DecimalFormatSymbols decimalFormatSymbols = new DecimalFormatSymbols();
    public static final FitnessCriteriaOrder defaultTopModelsFitnessCriteriaOrder = FitnessCriteriaOrder.MODEL_OVERALL;
    public static final FitnessCriteriaOrder defaultBestModelsFitnessCriteriaOrder = FitnessCriteriaOrder.CVC_MODEL_WINNERS_TESTING;
    public static final FitnessCriteriaOrder defaultInterLevelFitnessCriteriaOrder = FitnessCriteriaOrder.CV_TESTING_CVC;
    static {
	// this must be set before being used in the DecimalFormatConstructors
	Main.decimalFormatSymbols.setNaN(Main.NAN);
    }
    public static final NumberFormat decimalUpToOnePrecision = new DecimalFormat(
	    "#,##0.0", Main.decimalFormatSymbols);
    public static final NumberFormat decimalUpToTwoPrecision = new DecimalFormat(
	    "#,##0.0#", Main.decimalFormatSymbols);
    public static final NumberFormat decimalUpToThreePrecision = new DecimalFormat(
	    "#,##0.0##", Main.decimalFormatSymbols);
    public static final NumberFormat decimalUpToFourPrecision = new DecimalFormat(
	    "#,##0.0###", Main.decimalFormatSymbols);
    public static final NumberFormat decimalUpToSixPrecision = new DecimalFormat(
	    "#,##0.0#####", Main.decimalFormatSymbols);
    public static final NumberFormat decimalManyPrecision = new DecimalFormat(
	    "#,##0.0##############################", Main.decimalFormatSymbols);
    static {
	Main.decimalUpToTwoPrecision.setGroupingUsed(true);
	Main.decimalUpToThreePrecision.setGroupingUsed(true);
	Main.decimalUpToFourPrecision.setGroupingUsed(true);
	Main.decimalUpToSixPrecision.setGroupingUsed(true);
    }
    public static final String defaultMissing = "";
    public static final int defaultDistributedNodeCount = 1;
    public static final int defaultDistributedNodeNumber = 1;
    public static final boolean defaultUseBestModelActualIntervals = false;
    public static final boolean defaultUseExplicitTestOfInteraction = false;
    public static final int defaultPermutations = 0;
    public static final String missingRepresentation = "{MISSING}";
    public static final String unknownRepresentation = "{UNASSIGNED}";
    public static final float defaultFishersThreshold = 1.0f;
    public static final boolean defaultPrintDetailedConfusionMatrix = false;
    public static final float defaultLackOfCoveragePenaltyExponent = 0.5f;
    // must be explicitly requested. Turned on explicitly when running in GUI
    public static final boolean defaultParallel = false;
    public static final boolean defaultUseAIC = false;

    private static void determineIfExperimentalFeaturesEnabled() {
	final String experimentalTest = MDRProperties.get("experimental.test");
	if (experimentalTest != null) {
	    final String[] propertyAndPossibleValues = experimentalTest
		    .split(" ");
	    if (propertyAndPossibleValues.length >= 2) {
		final String[] propertyNames = propertyAndPossibleValues[0]
			.split("[|]");
		for (final String propertyName : propertyNames) {
		    final String propertyValue = System
			    .getProperty(propertyName);
		    if ((propertyValue != null) && (propertyValue.length() > 0)) {
			for (int index = 1; index < propertyAndPossibleValues.length; ++index) {
			    if (propertyValue
				    .equalsIgnoreCase(propertyAndPossibleValues[index])) {
				Main.isExperimental = true;
				break;
			    }
			}
			if (Main.isExperimental) {
			    break;
			}
		    }
		} // end propertyNames
	    }
	}
    }

    public static boolean isOSX() {
	final String osName = System.getProperty("os.name");
	return osName.contains("OS X");
    }

    public static void main(final String[] args) throws Exception {
	Main.determineIfExperimentalFeaturesEnabled();
	Main.printVersionHeader();
	final String applicationTitle = "Multifactor Dimensionality Reduction "
		+ MDRProperties.get("release.name");

	final boolean inBatchMode = (args.length > 0)
		&& !args[0].contains(Console.LOAD_ANALYSIS_CMD);
	System.setProperty("java.awt.headless", String.valueOf(inBatchMode));
	if (!inBatchMode) {
	    if (Main.isOSX()) {
		// take the menu bar off the jframe
		System.setProperty("apple.laf.useScreenMenuBar", "true");
		// set the name of the application menu item
		System.setProperty(
			"com.apple.mrj.application.apple.menu.about.name",
			applicationTitle);
	    }

	    if (Main.isOSX()) {
		com.apple.eawt.Application.getApplication().setDockIconImage(
			Toolkit.getDefaultToolkit().getImage(
				Main.class.getResource("/images/mdrlogo.png")));

	    }
	}
	Locale.setDefault(Locale.US);
	SwingPropUtils.setProperty("swing.aatext", "true", false);

	if (Main.isExperimental) {
	    Main.minimumRandomSeed = -1;
	} else {
	    Main.minimumRandomSeed = 0;
	}

	try {
	    if (args.length > 0) {
		final STATUS status = Console
			.parseCommandLineAndRun(args, System.out, System.err,
				(Runnable) null /* onEndModel */,
				(Runnable) null /* onEndLevel */,
				(Runnable) null /* onEndAnalysis */);
		if (status == STATUS.LOAD_ANALYSIS) {
		    Main.startGUI(applicationTitle);
		    final String passedInFileName = args[args.length - 1];
		    final String localDatasetFileName = Utility
			    .getLocalFileOrURL(passedInFileName);
		    Frame.getFrame().loadAnalysis(
			    new File(localDatasetFileName));
		} else {
		    System.exit(status.isAnErrorStatus() ? -1 : 0);
		}
	    } else {
		Main.startGUI(applicationTitle);
	    }
	} catch (final Exception ex) {
	    System.err.println("Caught an exception in Main() method: " + ex);
	    try {
		throw (ex);
	    } catch (final Exception ex1) {
		ex1.printStackTrace();
	    }
	}
    }

    private static void printVersionHeader() {
	System.out.println("Java version: "
		+ System.getProperty("java.version"));
	System.out.println("MDR Version " + " "
		+ MDRProperties.get("release.name") + " build date: "
		+ MDRProperties.get("build.date"));
	if (Main.isExperimental) {
	    System.out.println("Experimental features are enabled.");
	}
	System.out.println();
	System.out.flush();
    }

    public static void startGUI(final String applicationTitle) throws Exception {
	// set the look and feel
	UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
	final Frame runFrame = new Frame(GraphicsEnvironment
		.getLocalGraphicsEnvironment().getDefaultScreenDevice()
		.getDefaultConfiguration(), applicationTitle);
	runFrame.setSize(new Dimension(1024, 800));
	runFrame.setVisible(true);
    }

}
