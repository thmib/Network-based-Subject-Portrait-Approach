package org.epistasis.mdr.analysis;

import org.epistasis.exceptions.IncompleteBuildException;
import org.epistasis.mdr.AmbiguousCellStatus;
import org.epistasis.mdr.AnalysisFileManager;
import org.epistasis.mdr.enums.FitnessCriteriaOrder;
import org.epistasis.mdr.enums.TimeUnits;
import org.epistasis.mdr.newengine.Dataset;

public class TimedRandomAnalysisThread extends RandomAnalysisThread {

    private final TimeUnits timeUnit;
    private final double timeAmount;

    private TimedRandomAnalysisThread(final Dataset data,
	    final FitnessCriteriaOrder topModelsFitnessCriteriaOrder,
	    final FitnessCriteriaOrder bestModelFitnessCriteriaOrder,
	    final int numCrossValidationIntervals,
	    final AmbiguousCellStatus tiePriorityList, final long seed,
	    final Runnable onEndModel, final Runnable onEndLevel,
	    final Runnable onEndAnalysis, final boolean parallel,
	    final int topModelsLandscapeSize,
	    final boolean computeAllModelsLandscape, final int minAttr,
	    final int maxAttr, final TimeUnits timeUnit, final double timeAmount) {
	super(data, topModelsFitnessCriteriaOrder,
		bestModelFitnessCriteriaOrder, numCrossValidationIntervals,
		tiePriorityList, seed, onEndModel, onEndLevel, onEndAnalysis,
		parallel, topModelsLandscapeSize, computeAllModelsLandscape,
		minAttr, maxAttr);
	this.timeUnit = timeUnit;
	this.timeAmount = timeAmount;
	final long milliseconds = (long) (timeUnit.getMillis() * timeAmount);
	for (int nAttr = minAttr; nAttr <= maxAttr; ++nAttr) {
	    addProducer(new RandomProducer(new TimedRandomCombinationGenerator(
		    data.getLabels(), nAttr, seed, milliseconds),
		    getIntervals()));
	}
    }

    @Override
    public void saveAnalysis(final AnalysisFileManager analysisFileManager) {
	analysisFileManager.putCfg(AnalysisFileManager.cfgWrapper,
		AnalysisFileManager.cfgValRandom);
	analysisFileManager.putCfg(AnalysisFileManager.cfgRuntime,
		String.valueOf(timeAmount));
	analysisFileManager.putCfg(AnalysisFileManager.cfgRuntimeUnits,
		timeUnit.toString());
    }

    public static class TimedRandomAnalysisThreadBuilder extends
	    RandomAnalysisThreadBuilder<TimedRandomAnalysisThread> {

	private double timeAmount = Double.NaN;
	private TimeUnits timeUnit = null;

	public TimedRandomAnalysisThreadBuilder(final Dataset data,
		final int intervals, final long seed) {
	    super(data, intervals, seed);
	}

	@Override
	public TimedRandomAnalysisThread build() {
	    if ((minAttr == -1) || (timeUnit == null)
		    || (Double.isNaN(timeAmount)) || (maxAttr == -1)) {
		throw new IncompleteBuildException(
			"Random (timed) field not set.");
	    }
	    return new TimedRandomAnalysisThread(data,
		    topModelsFitnessCriteriaOrder,
		    bestModelFitnessCriteriaOrder, numCrossValidationIntervals,
		    tiePriorityList, seed, onEndModel, onEndLevel,
		    onEndAnalysis, parallel, topModelsLandscapeSize,
		    computeAllModelsLandscape, minAttr, maxAttr, timeUnit,
		    timeAmount);
	}

	public TimedRandomAnalysisThreadBuilder setTimeAmount(
		final double timeAmount) {
	    this.timeAmount = timeAmount;
	    return this;
	}

	public TimedRandomAnalysisThreadBuilder setTimeUnits(
		final TimeUnits timeUnit) {
	    this.timeUnit = timeUnit;
	    return this;
	}
    }
}
