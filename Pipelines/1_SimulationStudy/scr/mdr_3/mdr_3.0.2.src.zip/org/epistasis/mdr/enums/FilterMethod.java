package org.epistasis.mdr.enums;

public enum FilterMethod {
    RELIEFF("ReliefF"), TURF("TuRF"), ATTRIBUTE_FILE("AttributeFile"), CHISQUARED(
	    "\u03a7\u00b2", "chi-squared"), ODDSRATIO("OddsRatio"), SURF("SURF"), SURFNTURF(
	    "SURFnTuRF"), SURFSTAR("SURF*"), SURFSTARNTURF("SURF*nTuRF"), MULTISURF(
	    "multiSURF"), MULTISURFNTURF("multiSURFnTuRF");

    private final String displayName;

    private final String exportableAlternateName;

    private FilterMethod(final String displayName) {
	this(displayName, displayName);
    }

    private FilterMethod(final String displayName,
	    final String exportableAlternateName) {
	this.displayName = displayName;
	this.exportableAlternateName = exportableAlternateName;
    }

    public String getExportableAlternateName() {
	return exportableAlternateName;
    }

    @Override
    public String toString() {
	return displayName;
    }
}
