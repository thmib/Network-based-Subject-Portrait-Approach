package org.epistasis.mdr.newengine;

import java.io.IOException;
import java.io.LineNumberReader;
import java.lang.ref.SoftReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;

import org.epistasis.LabeledFloat;
import org.epistasis.LabeledFloatInterface;

public class AllModelsLandscape extends Landscape {
    // if computeAllModelsLandscape is true we will fill in
    // softReferenceToAllModels as
    // long as we can but it it gets garbage collected the softReference will be
    // changed to null and we will leave it that way
    // since we do not want an incomplete landscape
    private final SoftReference<List<LabeledFloatInterface>> softReferenceToAllModels = new SoftReference<List<LabeledFloatInterface>>(
	    new ArrayList<LabeledFloatInterface>());

    public void addLabeledFloat(final LabeledFloat labeledFloat) {
	assert labeledFloat != null : "labeledFloat is null!";
	List<LabeledFloatInterface> allModelsList = softReferenceToAllModels
		.get();
	if (allModelsList != null) {
	    try {
		synchronized (allModelsList) {
		    allModelsList.add(labeledFloat);
		}
	    } catch (final OutOfMemoryError outOfMemory) {
		allModelsList = null;
		softReferenceToAllModels.clear();
		System.gc();
	    }

	} // end if the allModelsList has not been garbageCollected or
	  // otherwise run out of memory
    }

    @Override
    public LabeledFloatInterface first() {
	return get(0);
    }

    @Override
    public LabeledFloatInterface get(final int index) {
	final List<LabeledFloatInterface> allModelsList = softReferenceToAllModels
		.get();
	if (allModelsList != null) {
	    final LabeledFloatInterface labeledFloatInterface = allModelsList
		    .get(index);
	    if (labeledFloatInterface == null) {
		throw new RuntimeException(
			"labeledFloatInterface in AllModelsLandscape is null!");
	    }
	    return labeledFloatInterface;
	}
	throw new ArrayIndexOutOfBoundsException(index);
    }

    @Override
    public Iterator<LabeledFloatInterface> iterator() {
	final List<LabeledFloatInterface> allModelsList = softReferenceToAllModels
		.get();
	if (allModelsList != null) {
	    // for (int index = 0; index < allModelsList.size(); ++index) {
	    // if (allModelsList.get(index) == null) {
	    // throw new RuntimeException("found null element at index "
	    // + index);
	    // }
	    // }
	    return allModelsList.iterator();
	}
	return Collections.<LabeledFloatInterface> emptyList().iterator();
    }

    @Override
    public LabeledFloatInterface last() {
	return get(size() - 1);
    }

    public String read(final LineNumberReader lnr, final Pattern endPattern)
	    throws IOException {
	String line;
	try {
	    while (((line = lnr.readLine()) != null)
		    && ((endPattern == null) || !endPattern.matcher(line)
			    .matches())) {
		final String[] fields = line.split("\t");
		if (fields.length != 2) {
		    throw new IOException(lnr.getLineNumber()
			    + " Expected 2 fields, delimited by a tab, got "
			    + fields.length + " fields.");
		}
		addLabeledFloat(new LabeledFloat(fields[0],
			Float.parseFloat(fields[1])));
	    }
	} catch (final NumberFormatException e) {
	    throw new IOException(Integer.toString(lnr.getLineNumber()) + ':'
		    + e.getMessage());
	}
	return line;
    }

    @Override
    public int size() {
	final List<LabeledFloatInterface> allModelsList = softReferenceToAllModels
		.get();
	if (allModelsList != null) {
	    return allModelsList.size();
	}
	return 0;
    }

}
