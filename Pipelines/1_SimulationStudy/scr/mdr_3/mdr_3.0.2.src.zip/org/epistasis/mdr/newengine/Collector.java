package org.epistasis.mdr.newengine;

import java.io.IOException;
import java.io.LineNumberReader;
import java.io.PrintWriter;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.SortedMap;

import org.apache.commons.math3.stat.descriptive.SummaryStatistics;
import org.epistasis.Annotator;
import org.epistasis.LabeledFloat;
import org.epistasis.LabeledFloatInterface;
import org.epistasis.Pair;
import org.epistasis.PriorityList;
import org.epistasis.Utility;
import org.epistasis.mdr.AmbiguousCellStatus;
import org.epistasis.mdr.Console;
import org.epistasis.mdr.Main;
import org.epistasis.mdr.enums.FitnessCriteriaOrder;
import org.epistasis.mdr.enums.FitnessCriterion;
import org.epistasis.mdr.enums.MdrTableColumnName;
import org.epistasis.mdr.newengine.Collector.ModelComparisonInfo;
import org.epistasis.mdr.newengine.Collector.ModelComparisonInfo.ModelIntervalInfo;
import org.epistasis.mdr.newengine.Model.AggregatedTestingData;
import org.epistasis.mdr.newengine.Model.Cell;
import org.epistasis.mdr.newengine.Model.StatisticAndPValue;

public class Collector extends PriorityList<ModelComparisonInfo> {

    private static final long serialVersionUID = 1L;
    private Dataset data;
    private int numIntervals;
    private IntervalDatasets[] intervals;

    private int[] statusCounts;
    private final boolean topModelsDependentOnCVC;
    private final boolean topModelsDependentOnCrossValidation;
    private boolean hasTesting;
    private final FitnessCriteriaOrder bestModelFitnessCriteriaOrder;
    private final AllModelsLandscape allModelsLandscape;

    private ModelComparisonInfo bestModelComparisonInfo = null;
    private final FitnessCriteriaOrder topModelsFitnessCriteriaOrder;

    public Collector(final Dataset data,
	    final Pair<List<Dataset>, List<Dataset>> partitions,
	    final int numTopModels,
	    final AllModelsLandscape allModelsLandscape,
	    final FitnessCriteriaOrder topModelsFitnessCriteriaOrder,
	    final FitnessCriteriaOrder bestModelFitnessCriteriaOrder) {
	this(numTopModels, allModelsLandscape, topModelsFitnessCriteriaOrder,
		bestModelFitnessCriteriaOrder);
	// NOTE: the status counts here are for the ENTIRE dataset -- not
	// the training dataset. Jason thinks this is correct since by
	// analogy,
	// we often use allele frequency estimates from the data but if we
	// have better allele frequency estimates from the world we use
	// those.
	// In this case the whole dataset is a better estimate of the
	// case/control ratio than just the training dataset
	this.data = data;
	statusCounts = data.getStatusCounts();
	List<Dataset> trainingDatasets;
	List<Dataset> testingDatasets = null;
	if (partitions != null) {
	    trainingDatasets = partitions.getFirst();
	    testingDatasets = partitions.getSecond();
	} else {
	    trainingDatasets = new ArrayList<Dataset>(1);
	    trainingDatasets.add(data);
	}
	numIntervals = trainingDatasets.size();
	intervals = new IntervalDatasets[numIntervals];
	Dataset testingDataset = null;
	hasTesting = testingDatasets != null;
	for (final int intervalIndex : Utility.range(numIntervals)) {
	    if (hasTesting) {
		testingDataset = testingDatasets.get(intervalIndex);
	    }
	    intervals[intervalIndex] = new IntervalDatasets(intervalIndex,
		    1 /* numIntervalTopModels */,
		    trainingDatasets.get(intervalIndex), testingDataset);
	} // end loop over intervals

    }

    private Collector(final int numTopModels,
	    final AllModelsLandscape allModelsLandscape,
	    final FitnessCriteriaOrder topModelsFitnessCriteriaOrder,
	    final FitnessCriteriaOrder bestModelFitnessCriteriaOrder) {

	super(numTopModels, new ModelInfoInterfaceComparator(
		topModelsFitnessCriteriaOrder));
	this.allModelsLandscape = allModelsLandscape;
	topModelsDependentOnCrossValidation = topModelsFitnessCriteriaOrder
		.isDependentOnCrossValidation();
	topModelsDependentOnCVC = topModelsFitnessCriteriaOrder
		.isDependentOnCVC();
	if (topModelsDependentOnCVC) {
	    throw new IllegalArgumentException(
		    "PriorityListOfModels topModelsFitnessCriteriaOrder MUST NOT INCLUDE CVC DEPENDENT TESTS: topModelsFitnessCriteriaOrder: "
			    + topModelsFitnessCriteriaOrder);
	}
	this.topModelsFitnessCriteriaOrder = topModelsFitnessCriteriaOrder;
	this.bestModelFitnessCriteriaOrder = bestModelFitnessCriteriaOrder;
	assert bestModelFitnessCriteriaOrder != null;
    } // end PriortyListOfModels constructors

    private void calculateIntervalRanks() {
	// // force computation of things I will shortly need (reduces
	// multithreading synchronization)
	// bestModelComparisonInfo.getAggregateTestingConfusionMatrix();
	// bestModelComparisonInfo.getModelOverallConfusionMatrix();
	// prepare to calculate ranks - so need to increase capacity of
	// interval
	// priority list to keep track of all top models
	// next add in all other top models
	for (final IntervalDatasets intervalDatasets : intervals) {
	    intervalDatasets.clear(); // remove the current best intervals
	    intervalDatasets.setCapacity(capacity);
	}
	// next, need to re-add all top models so we can make sure
	// they are
	// in
	// each
	// interval's list
	for (final ModelComparisonInfo modelComparisonInfo : this) {
	    modelComparisonInfo.addIntervalsIntoIntervalDatasets();
	}
    }

    public ModelComparisonInfo consider(final Model model) {
	assert bestModelComparisonInfo == null : "consider called after bestModelComparisonInfo already set";
	ModelComparisonInfo modelComparisonInfo;
	modelComparisonInfo = new ModelComparisonInfo(model);

	if (topModelsDependentOnCrossValidation) {
	    if (!topModelsDependentOnCVC) {
		modelComparisonInfo.addIntervalsIntoIntervalDatasets();

	    } else { // isDependentOnCVC
		     // WEIRD: because CVC is not a fixed attribute of a model,
		     // when
		     // we
		     // add a new model it
		     // may become a winner for some intervals. This will lower
		     // the
		     // cvc
		     // score for the
		     // winners it displaces. The TreeSet does not expect
		     // comparison
		     // values to change on
		     // the fly so we need to force the changed items to be
		     // newly
		     // placed
		     // in the correct sort order
		     // the only way I know how to do that is to remove and
		     // re-add
		     // the
		     // items whose CVC scores changed.
		final boolean debug = true;
		// need to find out if new model changes CVC count at all
		int cvc = 0;
		final Set<ModelComparisonInfo> topModelsNeedingToBeResorted = new HashSet<ModelComparisonInfo>();
		for (final int intervalIndex : Utility.range(numIntervals)) {
		    final IntervalDatasets intervalDatasets = intervals[intervalIndex];
		    final ModelIntervalInfo previousWinningModelIntervalInfo = intervalDatasets
			    .getBestTraining();
		    final ModelIntervalInfo newModelIntervalInfo = modelComparisonInfo.intervalsInfo[intervalIndex];
		    final boolean newModelIsBestInInterval = (previousWinningModelIntervalInfo == null)
			    || (newModelIntervalInfo
				    .compareTo(previousWinningModelIntervalInfo) < 0);
		    if (newModelIsBestInInterval) {
			++cvc;
			if (previousWinningModelIntervalInfo != null) {
			    topModelsNeedingToBeResorted
				    .add(previousWinningModelIntervalInfo
					    .getModelComparisonInfo());
			} // end if there was already
		    } // end if newModelIntervalInfo is best in interval
		} // end loop over all intervals

		if (debug && (cvc > 0)) {
		    System.out.println("Added new model which won " + cvc
			    + " interval(s): " + modelComparisonInfo.model);
		}
		if (topModelsNeedingToBeResorted.size() > 0) {
		    if (debug) {
			System.out.println("topModelsNeedingToBeResorted: "
				+ topModelsNeedingToBeResorted);
		    }
		    for (final ModelComparisonInfo topModelNeedingToBeResorted : topModelsNeedingToBeResorted) {
			final boolean wasRemoved = remove(topModelNeedingToBeResorted);
			if (debug && !wasRemoved) {
			    System.out
				    .println("topModelNeedingToBeResorted because of CVC change was not found in top models list! "
					    + topModelNeedingToBeResorted);
			}
		    }
		} // end if topModelsNeedingToBeResorted.size() > 0)

		// after removal, and before adding, add the new model so that
		// CVC
		// changes will occur and items re-added will be placed in their
		// new
		// positions
		modelComparisonInfo.addIntervalsIntoIntervalDatasets();

		for (final ModelComparisonInfo topModelNeedingToBeResorted : topModelsNeedingToBeResorted) {
		    final boolean added = add(topModelNeedingToBeResorted);
		    if (debug && !added) {
			System.out
				.println("topModelNeedingToBeResorted because of CVC change was not added! "
					+ topModelNeedingToBeResorted);
		    }
		}
	    } // end if dependent on CVC
	} // end if dependent on cross validation

	add(modelComparisonInfo);
	if (allModelsLandscape != null) {
	    allModelsLandscape.addLabeledFloat(modelComparisonInfo
		    .getLabeledFloat());
	}

	return modelComparisonInfo;
    }

    private ConfusionMatrix getAverageFitnessConfusionMatrix(
	    final ModelIntervalInfo[] modelIntervals, final boolean useTesting) {
	assert modelIntervals.length > 0 : "getAverageFitnessConfusionMatrix was passed a zero length modelIntervals array!";
	ConfusionMatrix averageConfusionMatrix = ConfusionMatrix.EMPTY;
	if (useTesting && !hasTesting) {
	    // nothing to do
	} else {
	    final List<ConfusionMatrix> confusionMatrices = getIntervalsConfusionMatrices(
		    modelIntervals, useTesting);
	    averageConfusionMatrix = ConfusionMatrix
		    .getAverage(confusionMatrices);
	    if (useTesting) {
		final AggregatedTestingData aggregatedData = averageConfusionMatrix
			.getAggregateData();
		if (aggregatedData != null) {
		    // for continuous testing data, Jiang Gui wanted to not
		    // use
		    // the average of the testing intervals but instead
		    // calculate the t-statistic on the aggregated data.
		    averageConfusionMatrix.setScoreOverrideValue(aggregatedData
			    .getSignificanceMetric());
		}

	    }

	    final boolean showDebug = false;
	    if (showDebug) {
		float totalTotal = 0;
		float totalFP = 0;
		float totalTP = 0;
		float totalFN = 0;
		float totalTN = 0;
		for (final ConfusionMatrix conf : confusionMatrices) {
		    totalTotal += conf.getTotalCount();
		    totalTP += conf.numTruePositives();
		    totalFP += conf.numFalsePositives();
		    totalTN += conf.numTrueNegatives();
		    totalFN += conf.numFalseNegatives();
		}
		System.out.println(useTesting + " totalTotal: " + totalTotal);
		System.out.println(useTesting + " totalTP: " + totalTP);
		System.out.println(useTesting + " totalFP: " + totalFP);
		System.out.println(useTesting + " totalTN: " + totalTN);
		System.out.println(useTesting + " totalFN: " + totalFN);
	    }
	} // end if not requested testing results when no testSets exist
	return averageConfusionMatrix;
    }// end getAverageFitnessConfusionMatrix

    public ModelComparisonInfo getBestModel() {
	if (bestModelComparisonInfo == null) {
	    final boolean dependentOnCrossValidation = topModelsDependentOnCrossValidation
		    || bestModelFitnessCriteriaOrder
			    .isDependentOnCrossValidation();
	    if (size() == 0) {
		throw new RuntimeException(
			"PriorityListOfModels.getBestModel() called before any models were considered.");
	    }
	    // if bestModel metric same as top models then best is the same as
	    // the top model
	    if (bestModelFitnessCriteriaOrder == topModelsFitnessCriteriaOrder) {
		bestModelComparisonInfo = first();
		if (dependentOnCrossValidation) {
		    calculateIntervalRanks();
		}
	    } else {
		final boolean modelsNeedCrossvalidationInitialization = !topModelsDependentOnCrossValidation
			&& bestModelFitnessCriteriaOrder
				.isDependentOnCrossValidation();

		final ModelInfoInterfaceComparator bestModelFitnessCriteriaOrderComparator = new ModelInfoInterfaceComparator(
			bestModelFitnessCriteriaOrder);
		final PriorityList<ModelComparisonInfo> bestModelList = new PriorityList<ModelComparisonInfo>(
			1, bestModelFitnessCriteriaOrderComparator);
		// if interval information already gathered look then make sure
		// best training models added into list of candidate best
		// overall models
		if (topModelsDependentOnCrossValidation) {
		    // first add in the likeliest best models -- the one that
		    // are
		    // currently winning any intervals
		    for (final int intervalIndex : Utility.range(numIntervals)) {
			final IntervalDatasets intervalDatasets = intervals[intervalIndex];
			final ModelIntervalInfo intervalBestModel = intervalDatasets
				.getBestTraining();
			final ModelComparisonInfo modelComparisonInfo = intervalBestModel
				.getModelComparisonInfo();
			bestModelList.add(modelComparisonInfo);
		    }
		} // end if already calculated interval data
		else if (modelsNeedCrossvalidationInitialization) {
		    for (final ModelComparisonInfo modelComparisonInfo : this) {
			modelComparisonInfo.initializeCrossValidationData();
		    }
		}
		calculateIntervalRanks();
		bestModelList.addAll(this);
		// finally take the first one and it is the best
		bestModelComparisonInfo = bestModelList.first();
	    } // end if bestModelFitnessCriteriaOrder !=
	      // topModelsFitnessCriteriaOrder
	      // calculate things soon to be requested to reduce threading
	      // issues
	    bestModelComparisonInfo.getOverallFitness();
	    if (dependentOnCrossValidation) {
		bestModelComparisonInfo.getAverageTrainingFitness();
		bestModelComparisonInfo.getAggregateTestingFitness();
	    }
	}
	return bestModelComparisonInfo;
    }

    public Dataset getData() {

	return data;
    }

    private List<ConfusionMatrix> getIntervalsConfusionMatrices(
	    final ModelIntervalInfo[] modelIntervals, final boolean useTesting) {
	final List<ConfusionMatrix> confusionMatrices = new ArrayList<ConfusionMatrix>(
		modelIntervals.length);
	for (final ModelIntervalInfo interval : modelIntervals) {
	    if (interval == null) {
		throw new RuntimeException(
			"ModelComparisonInfo.getAverageFitnessConfusionMatrix() found a null interval!");
	    }
	    if (useTesting) {
		confusionMatrices.add(interval.getTestingConfusionMatrix());
	    } // end if testing
	    else { // not testing so must be training
		confusionMatrices.add(interval.getTrainingConfusionMatrix());
	    } // end if training
	} // end interval loop
	return confusionMatrices;
    }

    public PriorityList<LabeledFloat> getLabeledFloatPriorityList() {
	final PriorityList<LabeledFloat> labeledFloatList = new PriorityList<LabeledFloat>(
		getCapacity(), LabeledFloat.floatMaximizerComparator);
	for (final ModelComparisonInfo modelComparisonInfo : this) {
	    labeledFloatList.add(modelComparisonInfo.getLabeledFloat());
	}
	return labeledFloatList;
    }

    /**
     * Companion method to match non-static method
     * PriorityListOfModels.ModelComparisonInfo
     * .ModelInvervalDetails.getRowValues
     * 
     * @param verbose
     * @param hasTesting
     * @return
     */
    public List<String> getModelIntervalDetailsHeaderString(
	    final boolean verbose, final boolean hasTesting) {
	final List<String> columnHeaders = new ArrayList<String>();
	if (hasTesting) {
	    columnHeaders.add(MdrTableColumnName.MODEL_TRAINING.toString());
	    if (verbose) {
		columnHeaders.add("training_cross_validation_scores");
		// columnHeaders.add("training_mean");
		// columnHeaders.add("training_standard_deviation");
		// columnHeaders.add("training_coeff_of_variance");
	    } // end if verbose

	    columnHeaders.add("training_cross_validation_ranks");
	    if (verbose) {
		// columnHeaders.add("ranks_mean");
		// columnHeaders.add("ranks_standard_deviation");
		// columnHeaders.add("ranks_coeff_of_variance");
	    }
	    columnHeaders.add(MdrTableColumnName.MODEL_TESTING.toString());
	    if (verbose) {
		columnHeaders.add("testing_cross_validation_scores");
		// columnHeaders.add("testing_mean");
		// columnHeaders.add("testing_standard_deviation");
		// columnHeaders.add("testing_coeff_of_variance");
	    } // end if verbose
	} // end if hasTesting
	if (!data.hasContinuousEndpoints()) {
	    columnHeaders.add(MdrTableColumnName.MAXIMUM_LIKELIHOOD.toString());
	    columnHeaders.add(MdrTableColumnName.MAXIMUM_LIKELIHOOD.toString()
		    + " p-value");
	    columnHeaders.add(MdrTableColumnName.CHISQUARED.toString());
	    columnHeaders.add(MdrTableColumnName.CHISQUARED.toString()
		    + " p-value");
	    columnHeaders.add(MdrTableColumnName.LOOCV_TESTING.toString());
	}
	return columnHeaders;
    } // end getHeaderString()

    public int getNumIntervals() {
	return numIntervals;
    }

    Iterator<LabeledFloatInterface> getTopModelsLabeledFloatIterator() {
	return new LabeledFloatIterfaceIterator(this);
    }

    private ConfusionMatrix getWinningIntervalsAggregateTestingConfusionMatrix() {
	final ModelIntervalInfo[] winningIntervalsModelInfo = getWinningIntervalsModelInfo();
	final ConfusionMatrix winningIntervalsAggregateTestingConfusionMatrix = getAverageFitnessConfusionMatrix(
		winningIntervalsModelInfo, true /* useTesting */);
	// System.err.println("winningIntervalsAggregateTestingConfusionMatrix="
	// + winningIntervalsAggregateTestingConfusionMatrix);
	return winningIntervalsAggregateTestingConfusionMatrix;
    }

    private ConfusionMatrix getWinningIntervalsAverageTrainingConfusionMatrix() {
	final ModelIntervalInfo[] winningIntervalsModelInfo = getWinningIntervalsModelInfo();
	final ConfusionMatrix winningIntervalsAverageTrainingConfusionMatrix = getAverageFitnessConfusionMatrix(
		winningIntervalsModelInfo, false /* useTesting */);
	// System.err.println("winningIntervalsAverageTrainingConfusionMatrix="
	// + winningIntervalsAverageTrainingConfusionMatrix);
	return winningIntervalsAverageTrainingConfusionMatrix;
    }

    public ModelIntervalInfo[] getWinningIntervalsModelInfo() {
	final ModelIntervalInfo[] winningIntervalsModelInfo = new ModelIntervalInfo[numIntervals];
	for (final int intervalIndex : Utility.range(numIntervals)) {
	    winningIntervalsModelInfo[intervalIndex] = intervals[intervalIndex]
		    .getBestTraining();
	}
	return winningIntervalsModelInfo;
    }

    public boolean hasTesting() {
	return hasTesting;
    }

    /**
     * true if either
     * topModelsFitnessCriteriaOrder.isDependentOnCrossValidation() OR
     * bestModelFitnessCriteriaOrder.isDependentOnCrossValidation()
     * 
     * @return
     */
    public boolean isDependentOnCrossValidation() {
	final boolean dependentOnCrossValidation = topModelsDependentOnCrossValidation
		|| bestModelFitnessCriteriaOrder.isDependentOnCrossValidation();
	return dependentOnCrossValidation;
    }

    public void read(final AmbiguousCellStatus ambiguousCellType,
	    final LineNumberReader lnr) throws IOException {
	String line = lnr.readLine();
	if (!line.equals("BeginTopModels")) {
	    throw new RuntimeException("At line number " + lnr.getLineNumber()
		    + " expected 'BeginTopModels' but found '" + line
		    + "' instead.");
	}
	final List<Model> topModels = readListOfModels(lnr, ambiguousCellType,
		"EndTopModels");
	// assume that the number of top models was the top models size
	setCapacity(topModels.size());

	// call consider on all saved models so that they will be re-evaluated
	for (final Model model : topModels) {
	    consider(model);
	}

	// now read in the models for each of the intervals.
	// don't care about the numbers -- just want to make sure that the
	// models
	// are all considered
	for (int i = 0; i < numIntervals; ++i) {
	    line = lnr.readLine();
	    final String[] fields = line.split("\\s+");
	    int index = 0;
	    if (!fields[index++].equals("Attr")) {
		throw new IOException(lnr.getLineNumber()
			+ " Expected line starting with 'Attr' but got '"
			+ line + "' instead.");
	    }
	    final Model model = new Model(
		    new AttributeCombination(fields[index++],
			    data.getNumAttributes(), data.getLabels()),
		    ambiguousCellType);
	    consider(model);
	    // throw away the rest of the line
	}
	// read and ignore the summary line and the BestModel Detail since by
	// recreating the priority list we can regenerate that at will
	while (!(line = lnr.readLine()).equals("EndModelDetail")) {
	    // do nothing -- since we called consider() on all models, the model
	    // details are already known
	}
	// System.err.println("after read in PriorityListOfModels line=" + line
	// + " object=" + this);
    } // end read

    public final List<Model> readListOfModels(final LineNumberReader lnr,
	    final AmbiguousCellStatus ambiguousCellType, final String endString)
	    throws IOException {
	final List<Model> models = new ArrayList<Model>();
	String line;
	while (((line = lnr.readLine()) != null)
		&& ((endString == null) || !endString.equals(line))) {
	    final String[] fields = line.split("\t");
	    if (fields.length != 2) {
		throw new IOException(lnr.getLineNumber()
			+ " Expected 2 fields, delimited by a tab, got "
			+ fields.length + " fields.");
	    }
	    final AttributeCombination combo = new AttributeCombination(
		    fields[0], data.getNumAttributes(), data.getLabels());
	    final Model model = new Model(combo, ambiguousCellType);
	    models.add(model);
	}
	return models;
    }

    public void write(final PrintWriter p) {
	final ModelComparisonInfo bestModel = getBestModel();
	p.println("BeginTopModels");
	for (final ModelComparisonInfo modelComparisonInfo : this) {
	    p.print(modelComparisonInfo.getModelName());
	    p.print('\t');
	    p.println(modelComparisonInfo.getPrimaryFitnessCriterionValue());
	}
	p.println("EndTopModels");
	for (final IntervalDatasets interval : intervals) {
	    p.print("Attr ");
	    final ModelIntervalInfo modelIntervalInfo = interval
		    .getBestTraining();
	    p.print(modelIntervalInfo.getModelName());
	    p.print(" Train");
	    modelIntervalInfo.getTrainingConfusionMatrix().write(p);
	    p.print(' ');
	    p.print(0.0f);
	    if (hasTesting) {
		p.print(" Test");
		modelIntervalInfo.getTestingConfusionMatrix().write(p);
		p.print(' ');
		p.print(0.0f);
	    }
	    p.println();
	}
	p.print("Attr ");
	p.print(bestModel.getModelName());
	p.print(" AvgTrain");
	bestModel.getCVAverageTrainingConfusionMatrix().write(p);
	p.print(' ');
	p.print(0.0f);
	if (bestModel.getCVAggregateTestingConfusionMatrix() != null) {
	    p.print(" AvgTest");
	    bestModel.getCVAggregateTestingConfusionMatrix().write(p);
	    p.print(' ');
	    p.print(0.0f);
	}
	p.print(" Train");
	bestModel.getOverallConfusionMatrix().write(p);
	p.print(' ');
	p.print(0.0f);
	p.print(" Summary ");
	p.print(bestModel.getCVC());
	p.println();
	bestModel.getModel().write(p, data);
	p.flush();
    }

    public class IntervalDatasets extends PriorityList<ModelIntervalInfo> {
	private static final long serialVersionUID = 1L;
	private final Dataset trainingDataset;
	private final Dataset testingDataset;
	private final int intervalIndex;

	IntervalDatasets(final int intervalIndex,
		final int numIntervalTopModels, final Dataset trainingDataset,
		final Dataset testingDataset) {
	    super(numIntervalTopModels);
	    this.intervalIndex = intervalIndex;
	    this.trainingDataset = trainingDataset;
	    this.testingDataset = testingDataset;
	}

	public ModelIntervalInfo getBestTraining() {
	    final int size = size();
	    assert size > 0 : " size == 0 but what about size(): " + size();
	    return (size > 0) ? first() : null;
	}

	// private Dataset getTestingDataset() {
	// return testingDataset;
	// }
	//
	// public Dataset getTrainingDataset() {
	// return trainingDataset;
	// }

	@Override
	public String toString() {
	    return "Interval " + intervalIndex + " current best: "
		    + getBestTraining();
	}
    }

    private static class LabeledFloatIterfaceIterator implements
	    Iterator<LabeledFloatInterface> {

	private final Iterator<? extends LabeledFloatInterface> iteratorForLabeledFloatInterface;

	public LabeledFloatIterfaceIterator(
		final Iterable<? extends LabeledFloatInterface> iterableForLabeledFloatInterface) {
	    iteratorForLabeledFloatInterface = iterableForLabeledFloatInterface
		    .iterator();
	}

	@Override
	public boolean hasNext() {
	    return iteratorForLabeledFloatInterface.hasNext();
	}

	@Override
	public LabeledFloatInterface next() {
	    return iteratorForLabeledFloatInterface.next();
	}

	@Override
	public void remove() {
	    iteratorForLabeledFloatInterface.remove();

	}

    }

    public class ModelComparisonInfo implements LabeledFloatInterface,
	    ModelInfoInterface, Annotator {
	private final Model model;
	private ModelIntervalInfo[] intervalsInfo = null;
	private ConfusionMatrix averageTrainingConfusionMatrix = null;
	private ConfusionMatrix aggregateTestingConfusionMatrix = null;
	private ConfusionMatrix overallConfusionMatrix = null;
	private Pair<ConfusionMatrix, ConfusionMatrix> leaveOneOutCrossValidationTrainingAndTestingFitness = null;

	ModelComparisonInfo(final Model model) {
	    this.model = model;
	    if (topModelsDependentOnCrossValidation) {
		initializeCrossValidationData();
	    }
	}

	public void addIntervalsIntoIntervalDatasets() {
	    for (final int intervalIndex : Utility.range(numIntervals)) {
		intervalsInfo[intervalIndex].addSelfToPriorityListOfIntervals();
	    }
	}

	@Override
	public String[] asStringArray() {
	    return ModelInfo.asStringArray(this);
	}

	@Override
	public String[] asStringArray(final NumberFormat numberFormatter) {
	    return ModelInfo.asStringArray(this, numberFormatter);
	}

	public ConfusionMatrix countTrainAndTestOnDataset(
		final Dataset datasetToTrainAndTestOn) {

	    final SortedMap<byte[], Cell> cells = model
		    .buildCounts(datasetToTrainAndTestOn);
	    model.buildStatuses(datasetToTrainAndTestOn, statusCounts, cells);
	    final ConfusionMatrix trainingConfusionMatrix = model.test(
		    datasetToTrainAndTestOn, cells);
	    return trainingConfusionMatrix;

	}

	@Override
	public float getAdjustedTesting() {
	    return Console.getAdjustedTesting(getAverageTrainingFitness(),
		    getAggregateTestingFitness());
	}

	@Override
	public ConfusionMatrix getAggregateTestingConfusionMatrix() {
	    if (aggregateTestingConfusionMatrix == null) {
		aggregateTestingConfusionMatrix = getAggregateTestingConfusionMatrix(intervalsInfo);
	    }
	    return aggregateTestingConfusionMatrix;
	}

	public ConfusionMatrix getAggregateTestingConfusionMatrix(
		final ModelIntervalInfo[] modelIntervals) {
	    return getAverageFitnessConfusionMatrix(modelIntervals, true /* useTesting */);
	}

	@Override
	public float getAggregateTestingFitness() {
	    return getAggregateTestingConfusionMatrix().getFitness();
	}

	public float getAggregateTestingFitness(
		final ModelIntervalInfo[] modelIntervals) {
	    return getAggregateTestingConfusionMatrix(modelIntervals)
		    .getFitness();
	}

	@Override
	public List<String> getAnnotationFields(final boolean verbose) {
	    final ModelIntervalDetails intervalDetails = new ModelIntervalDetails(
		    verbose);
	    return intervalDetails.getRowValues();
	}

	@Override
	public List<String> getAnnotationHeader(final boolean verbose) {

	    return getModelIntervalDetailsHeaderString(verbose, hasTesting);
	}

	@Override
	public ConfusionMatrix getAverageTrainingConfusionMatrix() {
	    if (averageTrainingConfusionMatrix == null) {
		averageTrainingConfusionMatrix = getAverageTrainingConfusionMatrix(intervalsInfo);
	    }
	    return averageTrainingConfusionMatrix;
	}

	public ConfusionMatrix getAverageTrainingConfusionMatrix(
		final ModelIntervalInfo[] modelIntervals) {
	    return getAverageFitnessConfusionMatrix(modelIntervals, false /* useTesting */);
	}

	@Override
	public float getAverageTrainingFitness() {
	    return getAverageTrainingConfusionMatrix().getFitness();
	}

	public float getAverageTrainingFitness(
		final ModelIntervalInfo[] modelIntervals) {
	    return getAverageTrainingConfusionMatrix(modelIntervals)
		    .getFitness();
	}

	public Collector getCollector() {
	    return Collector.this;
	}

	@Override
	public ConfusionMatrix getCVAggregateTestingConfusionMatrix() {
	    ConfusionMatrix result;
	    if (Console.console.useBestModelActualIntervals) {
		result = getAggregateTestingConfusionMatrix();
	    } else {
		result = getWinningIntervalsAggregateTestingConfusionMatrix();

	    }
	    return result;
	}

	@Override
	public float getCVAggregateTestingFitness() {
	    return getCVAggregateTestingConfusionMatrix().getFitness();
	}

	@Override
	public ConfusionMatrix getCVAverageTrainingConfusionMatrix() {
	    ConfusionMatrix result;
	    if (Console.console.useBestModelActualIntervals) {
		result = getAverageTrainingConfusionMatrix();
	    } else {
		result = getWinningIntervalsAverageTrainingConfusionMatrix();

	    }
	    return result;
	}

	@Override
	public float getCVAverageTrainingFitness() {
	    return getCVAverageTrainingConfusionMatrix().getFitness();
	}

	@Override
	public int getCVC() {
	    int cvc = 0;
	    for (final ModelIntervalInfo intervalInfo : intervalsInfo) {
		if (intervalInfo.isIntervalWinner()) {
		    ++cvc;
		}
	    }
	    return cvc;
	}

	@Override
	public float getFloat() {
	    return getPrimaryFitnessCriterionValue();
	}

	@Override
	public String[] getHeaders() {
	    return ModelInfo.getHeaders(this);
	}

	ModelIntervalInfo[] getIntervalWinners() {
	    final List<ModelIntervalInfo> intervalWinners = new ArrayList<Collector.ModelComparisonInfo.ModelIntervalInfo>();
	    for (final ModelIntervalInfo intervalInfo : intervalsInfo) {
		if (intervalInfo.isIntervalWinner()) {
		    intervalWinners.add(intervalInfo);
		}
	    }
	    ModelIntervalInfo[] modelIntervalInfoArray = new ModelIntervalInfo[intervalWinners
		    .size()];
	    return modelIntervalInfoArray = intervalWinners
		    .toArray(modelIntervalInfoArray);
	}

	@Override
	public String getLabel() {
	    return getModelName();
	}

	public LabeledFloat getLabeledFloat() {
	    return new LabeledFloat(getLabel(), getFloat());
	}

	public float getLeaveOneOutCrossValidationTestingFitness() {
	    return getModelLeaveOneOutCrossValidationTrainingAndTestingFitness()
		    .getSecond().getFitness();
	}

	public float getLeaveOneOutCrossValidationTrainingFitness() {
	    return getModelLeaveOneOutCrossValidationTrainingAndTestingFitness()
		    .getFirst().getFitness();
	}

	@Override
	public Model getModel() {
	    return model;
	}

	public ModelInfoInterface getModelInfo() {
	    return new ModelInfo(this);
	}

	private List<Integer> getModelIntervalRanks() {
	    final List<Integer> ranks = new ArrayList<Integer>(intervals.length);
	    for (final ModelIntervalInfo modelIntervalInfo : intervalsInfo) {
		ranks.add(modelIntervalInfo.getRank());
	    }
	    return ranks;
	} // end getModelIntervalRanks

	private List<Float> getModelIntervalTestingFitnesses() {
	    final List<ConfusionMatrix> confusionMatrices = getIntervalsConfusionMatrices(
		    intervalsInfo, true /* useTesting */);
	    final List<Float> testingFitnesses = new ArrayList<Float>(
		    intervals.length);
	    for (final ConfusionMatrix confusionMatrix : confusionMatrices) {
		testingFitnesses.add(confusionMatrix.getFitness());
	    }
	    return testingFitnesses;
	} // end getModelIntervalTestingFitnesses

	private List<Float> getModelIntervalTrainingFitnesses() {
	    final List<ConfusionMatrix> confusionMatrices = getIntervalsConfusionMatrices(
		    intervalsInfo, false /* useTesting */);
	    final List<Float> trainingFitnesses = new ArrayList<Float>(
		    intervals.length);
	    for (final ConfusionMatrix confusionMatrix : confusionMatrices) {
		trainingFitnesses.add(confusionMatrix.getFitness());
	    }
	    return trainingFitnesses;
	} // end getModelIntervalTrainingFitnesses

	public Pair<ConfusionMatrix, ConfusionMatrix> getModelLeaveOneOutCrossValidationTrainingAndTestingFitness() {
	    if (leaveOneOutCrossValidationTrainingAndTestingFitness == null) {
		leaveOneOutCrossValidationTrainingAndTestingFitness = model
			.getLeaveOneOutTrainingAndTesting(data);
	    }
	    return leaveOneOutCrossValidationTrainingAndTestingFitness;
	}

	@Override
	public String getModelName() {
	    return model.getModelName();
	}

	/**
	 * Very specialized - this is only used to pick which model is better if
	 * the CVC count is tied This gets the testing aggregate just on those
	 * intervals which are the best (i.e. are part of the CVC winners)
	 * 
	 * @return
	 */
	@Override
	public float getModelWinnersAggregateTestingFitness() {
	    float modelWinnersAggregateTestingFitness;
	    final ModelIntervalInfo[] modelIntervals = getIntervalWinners();
	    if (modelIntervals.length > 0) {
		modelWinnersAggregateTestingFitness = getAggregateTestingFitness(modelIntervals);
		// final String modelAttributes = model.getCombo().toString();
		// if (modelAttributes.equals("X4 X8")
		// || modelAttributes.equals("X1 X8")
		// || modelAttributes.equals("X1 X6")) {
		// System.out
		// .println("getModelWinnersAggregateTestingFitness for "
		// + modelAttributes
		// + " calculated: "
		// + getAggregateTestingConfusionMatrix(modelIntervals));
		// getIntervalWinners();
		// }
	    } else {
		modelWinnersAggregateTestingFitness = 0.0f;
	    }

	    return modelWinnersAggregateTestingFitness;
	}

	@Override
	public int getNumCrossValidations() {
	    return numIntervals;
	}

	@Override
	public ConfusionMatrix getOverallConfusionMatrix() {
	    if (overallConfusionMatrix == null) {
		overallConfusionMatrix = countTrainAndTestOnDataset(data);
	    }
	    return overallConfusionMatrix;
	}

	@Override
	public float getOverallFitness() {
	    return getOverallConfusionMatrix().getFitness();
	}

	public FitnessCriterion getPrimaryFitnessCriterion() {
	    return topModelsFitnessCriteriaOrder.getPrimaryTest();
	}

	@Override
	public float getPrimaryFitnessCriterionValue() {
	    float result;
	    switch (topModelsFitnessCriteriaOrder.getPrimaryTest()) {
	    case MODEL_ADJUSTED_TESTING:
		result = getAdjustedTesting();
		break;
	    case MODEL_OVERALL:
		result = getOverallFitness();
		break;
	    case MODEL_TESTING:
		result = getAggregateTestingFitness();
		break;
	    case MODEL_TRAINING:
		result = getAverageTrainingFitness();
		break;
	    // case LEAVE_ONE_OUT_CROSS_VALIDATION_TESTING:
	    // result = getLeaveOneOutCrossValidationTestingFitness();
	    // break;
	    // case LEAVE_ONE_OUT_CROSS_VALIDATION_TRAINING:
	    // result = getLeaveOneOutCrossValidationTrainingFitness();
	    // break;
	    default:
		throw new RuntimeException(
			"Unhandled topModelsFitnessCriteriaOrder.getPrimaryTest(): "
				+ topModelsFitnessCriteriaOrder
					.getPrimaryTest());
		// break;
	    }
	    return result;
	}

	@Override
	public boolean hasTesting() {

	    return hasTesting;
	}

	public void initializeCrossValidationData() {
	    intervalsInfo = new ModelIntervalInfo[numIntervals];
	    for (final int intervalIndex : Utility.range(numIntervals)) {
		intervalsInfo[intervalIndex] = new ModelIntervalInfo(
			intervals[intervalIndex]);
	    }
	}

	public void removeIntervalsFromIntervalDatasets() {
	    for (final int intervalIndex : Utility.range(numIntervals)) {
		intervals[intervalIndex].remove(intervalsInfo[intervalIndex]);
	    }
	}

	@Override
	public int size() {

	    return model.size();
	}

	@Override
	public String toString() {
	    // return getModelName() + " " + getPrimaryFitnessCriterion() + "="
	    // + getPrimaryFitnessCriterionValue();
	    return ModelInfo.toTable(this);
	}

	public class ModelIntervalDetails {
	    SummaryStatistics ranksSummaryStatistics;
	    List<Integer> intervalRanks;
	    SummaryStatistics trainingSummaryStats;
	    List<Float> intervalTrainingFitnesses;
	    SummaryStatistics testingSummaryStats;
	    List<Float> intervalTestingFitnesses;
	    private final boolean verbose;

	    public ModelIntervalDetails(final boolean verbose) {
		this.verbose = verbose;
		intervalRanks = getModelIntervalRanks();
		if (verbose) {
		    ranksSummaryStatistics = new SummaryStatistics();
		    for (final Integer rank : intervalRanks) {
			ranksSummaryStatistics.addValue(rank);
		    }
		    trainingSummaryStats = new SummaryStatistics();
		    intervalTrainingFitnesses = getModelIntervalTrainingFitnesses();
		    for (final Float intervalTrainingFitness : intervalTrainingFitnesses) {
			trainingSummaryStats.addValue(intervalTrainingFitness);
		    }
		    if (hasTesting) {
			testingSummaryStats = new SummaryStatistics();
			intervalTestingFitnesses = getModelIntervalTestingFitnesses();
			for (final Float intervalTestingFitness : intervalTestingFitnesses) {
			    testingSummaryStats
				    .addValue(intervalTestingFitness);
			}
		    } else {
			testingSummaryStats = null;
			intervalTestingFitnesses = null;
		    }
		}
	    } // end constructor

	    /**
	     * Companion method to match static method
	     * PriorityListOfModels.getModelIntervalDetailsHeaderString (which
	     * would be here if static methods allowed inside local classes)
	     * 
	     * @param verbose
	     * @return
	     */
	    // if (hasTesting) {
	    // columnHeaders.add(MdrTableColumnName.MODEL_TRAINING.toString());
	    // if (verbose) {
	    // columnHeaders.add("training_cross_validation_scores");
	    // // columnHeaders.add("training_mean");
	    // // columnHeaders.add("training_standard_deviation");
	    // // columnHeaders.add("training_coeff_of_variance");
	    // } // end if verbose
	    //
	    // columnHeaders.add("training_cross_validation_ranks");
	    // if (verbose) {
	    // // columnHeaders.add("ranks_mean");
	    // // columnHeaders.add("ranks_standard_deviation");
	    // // columnHeaders.add("ranks_coeff_of_variance");
	    // }
	    // columnHeaders.add(MdrTableColumnName.MODEL_TESTING.toString());
	    // if (verbose) {
	    // columnHeaders.add("testing_cross_validation_scores");
	    // // columnHeaders.add("testing_mean");
	    // // columnHeaders.add("testing_standard_deviation");
	    // // columnHeaders.add("testing_coeff_of_variance");
	    // } // end if verbose
	    // } // end if hasTesting
	    // if (!data.hasContinuousEndpoints()) {
	    // columnHeaders.add(MdrTableColumnName.MAXIMUM_LIKELIHOOD.toString());
	    // columnHeaders.add(MdrTableColumnName.MAXIMUM_LIKELIHOOD.toString()
	    // + " p-value");
	    // columnHeaders.add(MdrTableColumnName.CHISQUARED.toString());
	    // columnHeaders.add(MdrTableColumnName.CHISQUARED.toString()
	    // + " p-value");
	    // columnHeaders.add(MdrTableColumnName.LOOCV_TESTING.toString());
	    // }
	    public List<String> getRowValues() {
		final List<String> columnValues = new ArrayList<String>();
		if (hasTesting) {
		    columnValues.add(Main.decimalUpToSixPrecision
			    .format(getAverageTrainingFitness()));
		    if (verbose) {
			columnValues.add(Utility.join(
				intervalTrainingFitnesses, ',',
				Main.decimalUpToFourPrecision));
			// final double trainingMean =
			// trainingSummaryStats.getMean();
			// final double trainingStandardDeviation =
			// trainingSummaryStats
			// .getStandardDeviation();
			// final double trainingCoefficientOfVariance =
			// trainingMean
			// / trainingStandardDeviation;
			// columnValues.add(Main.decimalSixPrecision
			// .format(trainingMean));
			// columnValues.add(Main.decimalUpToFourPrecision
			// .format(trainingStandardDeviation));
			// columnValues.add(Main.decimalUpToFourPrecision
			// .format(trainingCoefficientOfVariance));
		    } // end if verbose
		    columnValues.add(intervalRanks.toString());
		    if (verbose) {
			// final double ranksMean =
			// ranksSummaryStatistics.getMean();
			// final double ranksStandardDeviation =
			// ranksSummaryStatistics
			// .getStandardDeviation();
			// final double ranksCoefficientOfVariance = ranksMean
			// / ranksStandardDeviation;
			// columnValues.add(Main.decimalUpToFourPrecision
			// .format(ranksMean));
			// columnValues.add(Main.decimalUpToFourPrecision
			// .format(ranksStandardDeviation));
			// columnValues.add(Main.decimalUpToFourPrecision
			// .format(ranksCoefficientOfVariance));
		    } // end if verbose
		    columnValues.add(Main.decimalUpToSixPrecision
			    .format(getAggregateTestingFitness()));
		    if (verbose) {
			columnValues.add(Utility.join(intervalTestingFitnesses,
				',', Main.decimalUpToFourPrecision));
			// final double testingMean = testingSummaryStats
			// .getMean();
			// final double testingStandardDeviation =
			// testingSummaryStats
			// .getStandardDeviation();
			// final double testingCoefficientOfVariance =
			// testingMean
			// / testingStandardDeviation;
			// columnValues.add(Main.decimalSixPrecision
			// .format(testingMean));
			// columnValues.add(Main.decimalUpToFourPrecision
			// .format(testingStandardDeviation));
			// columnValues.add(Main.decimalUpToFourPrecision
			// .format(testingCoefficientOfVariance));
		    } // end if verbose
		} // end if hasTesting
		if (!data.hasContinuousEndpoints()) {
		    StatisticAndPValue statisticAndPValue = model
			    .getSignificanceMetricMaximumLikelihood(data);
		    columnValues.add(Main.decimalManyPrecision
			    .format(statisticAndPValue.getStatistic()));
		    columnValues.add(Main.decimalManyPrecision
			    .format(statisticAndPValue.getPValue()));
		    statisticAndPValue = model
			    .getSignificanceMetricChiSquared(data);
		    columnValues.add(Main.decimalManyPrecision
			    .format(statisticAndPValue.getStatistic()));
		    columnValues.add(Main.decimalManyPrecision
			    .format(statisticAndPValue.getPValue()));
		    columnValues.add(Main.decimalManyPrecision.format(model
			    .getLeaveOneOutTrainingAndTesting(data).getSecond()
			    .getFitness()));
		}
		return columnValues;
	    } // end getRowValues()
	} // end local class ModelIntervalDetails

	public class ModelIntervalInfo implements Comparable<ModelIntervalInfo> {

	    private final ConfusionMatrix trainingConfusionMatrix;
	    private ConfusionMatrix testingConfusionMatrix;
	    private final IntervalDatasets intervalDatasets;

	    public ModelIntervalInfo(final IntervalDatasets intervalDatasets) {
		this.intervalDatasets = intervalDatasets;
		trainingConfusionMatrix = countTrainAndTestOnDataset(intervalDatasets.trainingDataset);
	    }

	    public void addSelfToPriorityListOfIntervals() {
		intervalDatasets.add(this);
	    }

	    @Override
	    public int compareTo(final ModelIntervalInfo other) {
		int compareResult = 0;
		if (this != other) {
		    // first compare fitness. Since bigger is better, reverse
		    // sign
		    // of Float.compare to make DESCENDING
		    // bigger is better so order of comparison is reversed
		    compareResult = Utility.compareFloatsHandlingNan(
			    other.trainingConfusionMatrix.getFitness(),
			    trainingConfusionMatrix.getFitness());
		    if (compareResult == 0) {
			compareResult = model.getCombo().compareTo(
				other.getModel().getCombo());
		    }
		}
		// System.err.println("ModelIntervalInfo compare: " + this +
		// " versus " +
		// o);
		return compareResult;
	    }

	    public Model getModel() {
		return model;
	    }

	    ModelComparisonInfo getModelComparisonInfo() {
		return ModelComparisonInfo.this;
	    }

	    public String getModelName() {
		return ModelComparisonInfo.this.getModelName();
	    }

	    public Integer getRank() {
		int rank = 1;
		for (final ModelIntervalInfo modelIntervalInfo : intervalDatasets) {
		    if (equals(modelIntervalInfo)) {
			return rank;
		    } else {
			rank++;
		    }
		}
		throw new RuntimeException("ModelIntervalInfo not ranked!");
		// return rank;
	    }

	    public ConfusionMatrix getTestingConfusionMatrix() {
		if (testingConfusionMatrix == null) {
		    synchronized (this) {
			if (testingConfusionMatrix == null) {
			    assert hasTesting;
			    // need to redo the training to re-establish the
			    // statuses
			    final SortedMap<byte[], Cell> cells = model
				    .buildCounts(intervalDatasets.trainingDataset);
			    model.buildStatuses(
				    intervalDatasets.trainingDataset,
				    statusCounts, cells);

			    // then count and test the testing
			    model.buildCounts(intervalDatasets.testingDataset,
				    cells);
			    // use the statuses created with the training data
			    testingConfusionMatrix = model.test(
				    intervalDatasets.testingDataset, cells);
			} // end second test for null testingConfusionMatrix
		    } // end synchronization
		} // end first test for null testingConfusionMatrix
		return testingConfusionMatrix;
	    }

	    public float getTestingFitness() {
		float testingFitness;
		if (hasTesting) {
		    testingFitness = getTestingConfusionMatrix().getFitness();
		} else {
		    testingFitness = Float.NaN;
		}
		return testingFitness;
	    }

	    public ConfusionMatrix getTrainingConfusionMatrix() {
		return trainingConfusionMatrix;
	    }

	    public float getTrainingFitness() {
		return getTrainingConfusionMatrix().getFitness();
	    }

	    public boolean hasTesting() {
		return hasTesting;
	    }

	    public boolean isIntervalWinner() {
		return equals(intervalDatasets.getBestTraining());
	    }

	    public int size() {
		return model.size();
	    }

	    @Override
	    public String toString() {
		return model.toString() + " interval "
			+ intervalDatasets.intervalIndex + " training: "
			+ trainingConfusionMatrix + " testing: "
			+ getTestingConfusionMatrix();
	    }
	} // end class ModelIntervalInfo
    } // end class ModelComparisonInfo

} // end class PriortyListOfModels
