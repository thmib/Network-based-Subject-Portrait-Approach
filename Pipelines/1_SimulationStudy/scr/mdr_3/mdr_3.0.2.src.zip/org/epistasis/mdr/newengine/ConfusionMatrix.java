package org.epistasis.mdr.newengine;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.epistasis.Pair;
import org.epistasis.Utility;
import org.epistasis.mdr.Console;
import org.epistasis.mdr.Main;
import org.epistasis.mdr.newengine.Model.AggregatedTestingData;

import edu.northwestern.at.utils.math.matrix.MatrixFactory;
import edu.northwestern.at.utils.math.statistics.ContingencyTable;

public class ConfusionMatrix {
    private final List<String> statuses;
    private final float[][] matrix;
    private float totalCount;
    private float unknownCount;
    private double scoreOverrideValue = Double.NaN;
    // private Float balancedAccuracy = null;
    private final byte affectedStatusIndex;
    private AggregatedTestingData aggregatedData = null;

    public final static ConfusionMatrix EMPTY = new ConfusionMatrix(
	    Arrays.asList("empty status1", "empty status2"), (byte) 0);
    private static final String PLACEHOLDER_VALUE = "-1";

    public static ConfusionMatrix getAverage(
	    final List<ConfusionMatrix> matrices) {
	if (matrices.isEmpty()) {
	    return null;
	}

	final ConfusionMatrix firstItem = matrices.get(0);
	final ConfusionMatrix ret = new ConfusionMatrix(firstItem.statuses,
		firstItem.affectedStatusIndex);
	for (int i = 0; i < ret.matrix.length; ++i) {
	    for (int j = 0; j < ret.matrix.length; ++j) {
		for (final ConfusionMatrix x : matrices) {
		    ret.matrix[i][j] += x.matrix[i][j];
		}
		ret.matrix[i][j] /= matrices.size();
	    }
	}
	float sumUnknown = 0;
	float sumTotal = 0;
	double sumOverride = 0;
	for (final ConfusionMatrix x : matrices) {
	    sumUnknown += x.unknownCount;
	    sumTotal += x.totalCount;
	    sumOverride += x.scoreOverrideValue;
	}
	ret.unknownCount = sumUnknown / matrices.size();
	ret.totalCount = sumTotal / matrices.size();
	ret.scoreOverrideValue = sumOverride / matrices.size();
	final boolean hasAggregatedData = firstItem.aggregatedData != null;
	if (hasAggregatedData) {
	    final Collection<AggregatedTestingData> partitionsEndpointData = new ArrayList<Model.AggregatedTestingData>(
		    matrices.size());
	    for (final ConfusionMatrix x : matrices) {
		if (hasAggregatedData) {
		    assert x.aggregatedData != null;
		    partitionsEndpointData.add(x.aggregatedData);
		}
	    }
	    final AggregatedTestingData newAggregatedTestingData = new AggregatedTestingData(
		    partitionsEndpointData);
	    // assert newAggregatedTestingData.getTotalN() == sumTotal :
	    // "newAggregatedTestingData.getTotalN() "
	    // + newAggregatedTestingData.getTotalN()
	    // + " != sumTotal "
	    // + sumTotal;
	    ret.setAggregatedData(newAggregatedTestingData);
	}
	return ret;
    }

    public static ConfusionMatrix readConfusionMatrix(final Dataset d,
	    final String[] fields, int index) {
	final ConfusionMatrix m = new ConfusionMatrix(d.getLevels().get(
		d.getCols() - 1), d.getAffectedStatus());
	final String firstValue = fields[index];
	if (firstValue.equals(ConfusionMatrix.PLACEHOLDER_VALUE)) {
	    for (int i = 0; i < 3; ++i) {
		index++; // skip over placeholder values
	    }
	    m.setScoreOverrideValue(Double.parseDouble(fields[index++]));
	} else {
	    for (int i = 0; i < m.size(); ++i) {
		for (int j = 0; j < m.size(); ++j) {
		    m.add(i, j, Float.parseFloat(fields[index++]));
		}
	    }
	}
	return m;
    }

    public ConfusionMatrix(final List<String> statuses,
	    final byte affectedStatusIndex) {
	this.statuses = statuses;
	matrix = new float[statuses.size()][statuses.size()];
	this.affectedStatusIndex = affectedStatusIndex;
    }

    public void add(final int actual, final int predicted, final float count) {
	totalCount += count;
	if (predicted == Model.UNKNOWN_STATUS) {
	    unknownCount += count;
	} else {
	    matrix[actual][predicted] += count;
	}
    }

    // public void add(final String actual, final String predicted) {
    // final int iActual = statuses.indexOf(actual);
    // if (iActual < 0) {
    // throw new IndexOutOfBoundsException("Unknown status '" + actual + "'.");
    // }
    // final int iPredicted = statuses.indexOf(predicted);
    // if (iPredicted < 0) {
    // throw new IndexOutOfBoundsException("Unknown status '" + predicted +
    // "'.");
    // }
    // add(iActual, iPredicted);
    // }
    public float get(final int actual, final int predicted) {
	return matrix[actual][predicted];
    }

    // public float get(final String actual, final String predicted) {
    // final int iActual = statuses.indexOf(actual);
    // if (iActual < 0) {
    // throw new IndexOutOfBoundsException("Unknown class '" + actual + "'.");
    // }
    // final int iPredicted = statuses.indexOf(predicted);
    // if (iPredicted < 0) {
    // throw new IndexOutOfBoundsException("Unknown class '" + predicted +
    // "'.");
    // }
    // return matrix[iActual][iPredicted];
    // }
    public float getAccuracy() {
	float correct = 0;
	float total = 0;
	for (int i = 0; i < matrix.length; ++i) {
	    for (int j = 0; j < matrix[i].length; ++j) {
		if (i == j) {
		    correct += matrix[i][j];
		}
		total += matrix[i][j];
	    }
	}
	return correct / total;
    }

    public AggregatedTestingData getAggregateData() {
	return aggregatedData;
    }

    public float getBalancedAccuracy() {
	float balancedAccuracy;
	float sum = 0;
	for (int i = 0; i < matrix.length; ++i) {
	    final float[] row = matrix[i];
	    float total = 0;
	    float correct = 0;
	    for (int j = 0; j < row.length; ++j) {
		if (i == j) {
		    correct += row[j];
		}
		total += row[j];
	    }
	    sum += correct / total;
	}
	balancedAccuracy = sum / matrix.length;
	return balancedAccuracy;
    }

    public float getChiSquared() {
	return Utility.computeChiSquared(matrix);
    }

    public int getChiSquaredDF() {
	return (matrix.length - 1) * (matrix.length - 1);
    }

    public float getClassifiedCount() {
	return totalCount - unknownCount;
    }

    public float getCoverageRatio() {
	final float predicted = totalCount - unknownCount;
	final float coverage = predicted / totalCount;
	return coverage;
    }

    public double getFishersExact() {
	final edu.northwestern.at.utils.math.matrix.Matrix northwesternMatrix = MatrixFactory
		.createMatrix(2, 2);
	northwesternMatrix.set(1, 1, matrix[0][0]);
	northwesternMatrix.set(1, 2, matrix[0][1]);
	northwesternMatrix.set(2, 1, matrix[1][0]);
	northwesternMatrix.set(2, 2, matrix[1][1]);
	// // double vector with three entries. [0] = two-sided Fisher's exact
	// // test. [1] = left-tail Fisher's exact test. [2] =
	// // right-tail
	// // Fisher's exact test.
	final double[] fisherExactTestResults = ContingencyTable
		.fishersExactTest(northwesternMatrix);
	final double twoTailedFisherExact = fisherExactTestResults[0];
	return -twoTailedFisherExact;
    }

    public float getFitness() {
	final float fitness = getScore(Console.lackOfCoveragePenaltyExponent);
	return fitness;
    }

    public float getFMeasure() {
	final float tp = numTruePositives();
	final float fn = numFalseNegatives();
	final float fp = numFalsePositives();
	return (2.0f * tp) / ((2.0f * tp) + fp + fn);
    }

    public double getKappa() {
	return Utility.computeKappaStatistic(matrix);
    }

    public float getLogORStdErr() {
	final float tp = numTruePositives();
	final float fn = numFalseNegatives();
	final float fp = numFalsePositives();
	final float tn = numTrueNegatives();
	return (float) Math.sqrt((1.0f / tp) + (1.0f / fp) + (1.0f / tn)
		+ (1.0f / fn));
    }

    public float getOddsRatio() {
	final float tp = numTruePositives();
	final float fn = numFalseNegatives();
	final float fp = numFalsePositives();
	final float tn = numTrueNegatives();
	return (tp * tn) / (fp * fn);
    }

    public Pair<Float, Float> getORConfInt() {
	final float lor = (float) Math.log(getOddsRatio());
	final float lorse = getLogORStdErr();
	return new Pair<Float, Float>((float) Math.exp(lor - (1.96f * lorse)),
		(float) Math.exp(lor + (1.96 * lorse)));
    }

    public double getPrecision() {
	final float tp = numTruePositives();
	final float fp = numFalsePositives();
	return tp / (tp + fp);
    }

    public Float getScore(final float lackOfCoveragePenaltyExponent) {
	float score;
	if (!Double.isNaN(scoreOverrideValue)) {
	    score = (float) scoreOverrideValue;
	} else {
	    final float balAccuracy = getBalancedAccuracy();
	    if (unknownCount == 0.0f) {
		score = balAccuracy;
	    } else {
		final float coverage = getCoverageRatio();
		// =(ba - 0.5)*POW(coverage,exponent) + 0.5
		score = (float) (((balAccuracy - 0.5f) * Math.pow(coverage,
			lackOfCoveragePenaltyExponent)) + 0.5f);
		// NOTE it is possible that coverage can be 0 and therefore
		// score will be NaN
	    }
	}
	return score;
    }

    public double getScoreOverrideValue() {
	return scoreOverrideValue;
    }

    public float getSensitivity() {
	final float tp = numTruePositives();
	final float fn = numFalseNegatives();
	// don't worry about divide by zero -- will create NaN which is correct
	final float sensitivity = tp / (tp + fn);
	return sensitivity;
    }

    public float getSpecificity() {
	final float fp = numFalsePositives();
	final float tn = numTrueNegatives();
	// don't worry about divide by zero -- will create NaN which is correct
	final float specificity = tn / (tn + fp);
	return specificity;
    }

    public float getTotalCount() {
	return totalCount;
    }

    public float getUnknownCount() {
	return unknownCount;
    }

    public boolean hasAggregateData() {
	return aggregatedData != null;
    }

    public float numFalseNegatives() {
	float incorrect = 0;
	for (int i = 0; i < matrix.length; i++) {
	    if (i == affectedStatusIndex) {
		for (int j = 0; j < matrix.length; j++) {
		    if (j != affectedStatusIndex) {
			incorrect += matrix[i][j];
		    }
		}
	    }
	}
	return incorrect;
    }

    public float numFalsePositives() {
	float incorrect = 0;
	for (int i = 0; i < matrix.length; i++) {
	    if (i != affectedStatusIndex) {
		for (int j = 0; j < matrix.length; j++) {
		    if (j == affectedStatusIndex) {
			incorrect += matrix[i][j];
		    }
		}
	    }
	}
	return incorrect;
    }

    public float numTrueNegatives() {
	float correct = 0;
	for (int i = 0; i < matrix.length; i++) {
	    if (i != affectedStatusIndex) {
		for (int j = 0; j < matrix.length; j++) {
		    if (j != affectedStatusIndex) {
			correct += matrix[i][j];
		    }
		}
	    }
	}
	return correct;
    }

    public float numTruePositives() {
	float correct = 0;
	for (int j = 0; j < matrix.length; j++) {
	    if (j == affectedStatusIndex) {
		correct += matrix[affectedStatusIndex][j];
	    }
	}
	return correct;
    }

    public void setAggregatedData(
	    final AggregatedTestingData continuousEndpointsSignificanceTestingData) {
	aggregatedData = continuousEndpointsSignificanceTestingData;

    }

    public void setScoreOverrideValue(final double pScoreOverrideValue) {
	// this can be a legitimate case -- especially in high order model using
	// fisher's exact
	// if (Double.isNaN(pScoreOverrideValue)) {
	// throw new RuntimeException("setScoreOverride called with NaN!");
	// }
	scoreOverrideValue = pScoreOverrideValue;
    }

    public int size() {
	return matrix.length;
    }

    public String toMatrixString() {
	final StringBuffer b = new StringBuffer();
	final int width[] = new int[matrix.length];
	int labelwidth = 0;
	for (final float[] row : matrix) {
	    for (int j = 0; j < row.length; ++j) {
		final int len = (int) Math.ceil(Math.log10(row[j]));
		if (len > width[j]) {
		    width[j] = len;
		}
	    }
	}
	for (int i = 0; i < matrix.length; ++i) {
	    final int len = statuses.get(i).length();
	    if (len > width[i]) {
		width[i] = len;
	    }
	    if (len > labelwidth) {
		labelwidth = len;
	    }
	}
	b.append(Utility.chrdup(' ', labelwidth + 2));
	for (int i = 0; i < matrix.length; ++i) {
	    b.append(' ');
	    b.append(Utility.padRight(statuses.get(i), width[i]));
	}
	b.append(Utility.NEWLINE);
	b.append(Utility.chrdup(' ', labelwidth + 2));
	for (int i = 0; i < matrix.length; ++i) {
	    b.append(' ');
	    b.append(Utility.chrdup('-', width[i]));
	}
	b.append(Utility.NEWLINE);
	for (int i = 0; i < matrix.length; ++i) {
	    b.append(Utility.padRight(statuses.get(i), labelwidth));
	    b.append(" | ");
	    final float[] row = matrix[i];
	    for (int j = 0; j < matrix.length; ++j) {
		if (j != 0) {
		    b.append(' ');
		}
		b.append(Utility.padLeft(Float.toString(row[j]), width[j]));
	    }
	    b.append(Utility.NEWLINE);
	}
	return b.toString();
    }

    @Override
    public String toString() {
	return toString(Console.lackOfCoveragePenaltyExponent);
    }

    public String toString(final float lackOfCoveragePenaltyExponent) {
	final StringBuffer sb = new StringBuffer();
	sb.append("total: "
		+ Main.decimalUpToFourPrecision.format(getTotalCount()));
	sb.append(" unknown: "
		+ Main.decimalUpToFourPrecision.format(getUnknownCount()));
	if (getUnknownCount() > 0) {
	    sb.append(" coverage: " + (int) (getCoverageRatio() * 100) + "%");
	}
	sb.append(" TP: "
		+ Main.decimalUpToFourPrecision.format(numTruePositives()));
	sb.append(" FP: "
		+ Main.decimalUpToFourPrecision.format(numFalsePositives()));
	sb.append(" TN: "
		+ Main.decimalUpToFourPrecision.format(numTrueNegatives()));
	sb.append(" FN: "
		+ Main.decimalUpToFourPrecision.format(numFalseNegatives()));
	sb.append(" accuracy: "
		+ Main.decimalUpToFourPrecision.format(getAccuracy()));
	sb.append(" "
		+ Console.console.metricShortText
		+ ": "
		+ Main.decimalUpToFourPrecision
			.format(getScore(lackOfCoveragePenaltyExponent)));
	return sb.toString();
    }

    public void write(final PrintWriter p) {
	if (!Double.isNaN(getScoreOverrideValue())) {
	    // print four placeholder values so this takes up same number of
	    // fields as regular confusion matrix
	    for (int i = 0; i < 3; ++i) {
		p.print(' ');
		p.print(ConfusionMatrix.PLACEHOLDER_VALUE);
	    }
	    p.print(' ');
	    p.print(Main.decimalUpToFourPrecision
		    .format(getScoreOverrideValue()));

	} else {
	    for (int i = 0; i < size(); ++i) {
		for (int j = 0; j < size(); ++j) {
		    p.print(' ');
		    p.print(get(i, j));
		}
	    }
	} // end if not score override
    } // end write()
}
