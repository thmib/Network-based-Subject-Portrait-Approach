package org.epistasis.mdr.gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.EventListener;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import org.epistasis.mdr.Console;
import org.epistasis.mdr.Main;
import org.epistasis.mdr.newengine.Dataset;

public class AttributeConstructionPanel extends JComponent {
    /**
	 * 
	 */
    private static final long serialVersionUID = 1L;
    private final GridBagLayout gblThis = new GridBagLayout();
    private final JButton cmdConstruct = new JButton();
    private final JButton cmdDelete = new JButton();
    private final JScrollPane scpAttributes = new JScrollPane();
    private final JButton cmdExport = new JButton();
    private final JLabel lblName = new JLabel();
    private final JTextField txtName = new JTextField();
    private final JList lstAttributes = new JList();
    private final JButton cmdSort = new JButton();
    private final JLabel lblAttributes = new JLabel();
    private ChangeEvent changeEvent;
    private boolean warnOnChange = false;
    private final JLabel lblUseControlKey = new JLabel(
	    "<html><p>Use control key to select/deselect attributes</p></html>");

    public AttributeConstructionPanel() {
	jbInit();
    }

    public void addChangeListener(final ChangeListener l) {
	listenerList.add(ChangeListener.class, l);
    }

    protected void fireChangeEvent() {
	final EventListener[] listeners = listenerList
		.getListeners(ChangeListener.class);
	cmdSort.setEnabled((lstAttributes.getModel().getSize() > 1)
		&& isEnabled());
	for (final EventListener element : listeners) {
	    if (changeEvent == null) {
		changeEvent = new ChangeEvent(this);
	    }
	    ((ChangeListener) element).stateChanged(changeEvent);
	}
    }

    public boolean isWarnOnChange() {
	return warnOnChange;
    }

    private void jbInit() {
	setBackground(UIManager.getColor("control"));
	setLayout(gblThis);
	cmdConstruct.setText("Construct");
	cmdConstruct.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		final DefaultListModel listModel = (DefaultListModel) lstAttributes
			.getModel();
		final String contructedAttributeName = txtName.getText();
		if (listModel.contains(contructedAttributeName)) {
		    JOptionPane.showMessageDialog(
			    AttributeConstructionPanel.this, "Attribute '"
				    + contructedAttributeName
				    + "' already exists.",
			    "Duplicate Attribute", JOptionPane.ERROR_MESSAGE);
		    return;
		}
		if (warnOnChange) {
		    if (!warn("Constructing an attribute will clear the current "
			    + "analysis pane.  Continue?")) {
			return;
		    }
		    warnOnChange = false;
		}
		final Object[] attributeNamesToSearchObjects = lstAttributes
			.getSelectedValues();
		final String[] attributeNamesToSearch = new String[attributeNamesToSearchObjects.length];
		for (int i = 0; i < attributeNamesToSearch.length; ++i) {
		    attributeNamesToSearch[i] = attributeNamesToSearchObjects[i]
			    .toString();
		}
		Console.console.data.constructAndAddAttribute(
			attributeNamesToSearch, contructedAttributeName,
			Console.console.ambiguousCellStatus);
		listModel.addElement(contructedAttributeName);
		fireChangeEvent();
	    }
	});
	cmdConstruct.setEnabled(false);
	cmdDelete.setText("Delete");
	cmdDelete.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		if (JOptionPane.showConfirmDialog(
			AttributeConstructionPanel.this,
			"Really delete selected attribute(s)?",
			"Delete Attribute(s)", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
		    if (warnOnChange) {
			if (!warn("Deleting an attribute will clear the current analysis pane.  Continue?")) {
			    return;
			}
			warnOnChange = false;
		    }
		    final Object[] attrs = lstAttributes.getSelectedValues();
		    for (final Object attr : attrs) {
			Console.console.data.removeColumn(Console.console.data
				.getLabels().indexOf(attr.toString()));
			((DefaultListModel) lstAttributes.getModel())
				.removeElement(attr);
		    }
		    fireChangeEvent();
		}

	    }
	});
	cmdDelete.setEnabled(false);
	cmdExport.setEnabled(false);
	cmdExport.setText(Main.EXPORT_DATAFILE);
	cmdExport.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		Frame.cmdExportData();
	    }
	});
	scpAttributes.setBorder(BorderFactory.createLoweredBevelBorder());
	scpAttributes.setMinimumSize(new Dimension(200, 0));
	scpAttributes.setPreferredSize(new Dimension(200, 0));
	lblName.setToolTipText("");
	lblName.setText("Constructed Attribute Name:");
	txtName.getDocument().addDocumentListener(new DocumentListener() {
	    @Override
	    public void changedUpdate(final DocumentEvent e) {
		txtName_textChanged(e);
	    }

	    @Override
	    public void insertUpdate(final DocumentEvent e) {
		txtName_textChanged(e);
	    }

	    @Override
	    public void removeUpdate(final DocumentEvent e) {
		txtName_textChanged(e);
	    }
	});
	cmdSort.setEnabled(false);
	cmdSort.setText("Sort List");
	cmdSort.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		final DefaultListModel model = (DefaultListModel) lstAttributes
			.getModel();
		final String[] values = new String[model.getSize()];
		for (int i = 0; i < values.length; ++i) {
		    values[i] = model.get(i).toString();
		}
		Arrays.sort(values, String.CASE_INSENSITIVE_ORDER);
		model.clear();
		model.ensureCapacity(values.length);
		for (final String value : values) {
		    model.addElement(value);
		}
	    }
	});
	lblAttributes.setText("Attributes:");
	lstAttributes.getSelectionModel().addListSelectionListener(
		new ListSelectionListener() {
		    @Override
		    public void valueChanged(final ListSelectionEvent e) {
			final StringBuffer name = new StringBuffer();
			final Object[] values = lstAttributes
				.getSelectedValues();
			for (int i = 0; i < values.length; ++i) {
			    if (i != 0) {
				name.append('_');
			    }
			    name.append(values[i]);
			}
			txtName.setText(name.toString());
			txtName.selectAll();
			txtName.requestFocus();
			cmdConstruct.setEnabled(values.length > 0);
			cmdDelete.setEnabled((values.length > 0)
				&& (values.length < lstAttributes.getModel()
					.getSize()));
		    }
		});
	this.add(lblAttributes, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0,
		GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5,
			5, 5, 5), 0, 0));
	this.add(scpAttributes, new GridBagConstraints(0, 1, 1, 6, 0.0, 1.0,
		GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(
			5, 5, 0, 5), 0, 0));
	this.add(lblName, new GridBagConstraints(1, 0, 2, 1, 0.0, 0.0,
		GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5,
			5, 5, 0), 0, 0));
	this.add(txtName, new GridBagConstraints(1, 1, 2, 1, 1.0, 0.0,
		GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
		new Insets(5, 5, 5, 0), 0, 0));
	this.add(cmdConstruct, new GridBagConstraints(1, 2, 1, 1, 0.0, 0.0,
		GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
		new Insets(5, 5, 5, 5), 0, 0));
	final GridBagConstraints gbc_lblUseControlKey = new GridBagConstraints();
	gbc_lblUseControlKey.gridheight = 2;
	gbc_lblUseControlKey.insets = new Insets(0, 0, 5, 0);
	gbc_lblUseControlKey.gridx = 2;
	gbc_lblUseControlKey.gridy = 2;
	add(lblUseControlKey, gbc_lblUseControlKey);
	this.add(cmdDelete, new GridBagConstraints(1, 3, 1, 1, 0.0, 0.0,
		GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
		new Insets(5, 5, 5, 5), 0, 0));
	this.add(cmdSort, new GridBagConstraints(1, 4, 1, 1, 0.0, 0.0,
		GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
		new Insets(5, 5, 5, 5), 0, 0));
	this.add(cmdExport, new GridBagConstraints(1, 5, 1, 1, 0.0, 0.0,
		GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
		new Insets(5, 5, 5, 5), 0, 0));
	scpAttributes.setViewportView(lstAttributes);
    }

    @Override
    public void paint(final Graphics g) {
	final Color c = g.getColor();
	g.setColor(getBackground());
	g.fillRect(0, 0, getWidth(), getHeight());
	g.setColor(c);
	super.paint(g);
    }

    public void removeChangeListener(final ChangeListener l) {
	listenerList.remove(ChangeListener.class, l);
    }

    public void setData(final Dataset data) {
	cmdExport.setEnabled((data != null) && isEnabled());
	final DefaultListModel model = new DefaultListModel();
	if (Console.console.data != null) {
	    model.ensureCapacity(data.getCols() - 1);
	    for (int i = 0; i < (data.getLabels().size() - 1); ++i) {
		model.addElement(data.getLabels().get(i));
	    }
	}
	lstAttributes.setModel(model);
	cmdSort.setEnabled((lstAttributes.getModel().getSize() > 1)
		&& isEnabled());
    }

    @Override
    public void setEnabled(final boolean enabled) {
	if (enabled) {
	    final int selectedCount = lstAttributes.getSelectedValues().length;
	    cmdConstruct.setEnabled((selectedCount > 0)
		    && (txtName.getText().length() > 0));
	    cmdDelete.setEnabled(selectedCount > 0);
	    cmdSort.setEnabled(lstAttributes.getModel().getSize() > 1);
	    cmdExport.setEnabled(Console.console.data != null);
	} else {
	    lstAttributes.clearSelection();
	    cmdConstruct.setEnabled(enabled);
	    cmdDelete.setEnabled(enabled);
	    cmdSort.setEnabled(enabled);
	    cmdExport.setEnabled(enabled);
	}
	lstAttributes.setEnabled(enabled);
	lblName.setEnabled(enabled);
	txtName.setEnabled(enabled);
	super.setEnabled(enabled);
    }

    public void setWarnOnChange(final boolean warnOnChange) {
	this.warnOnChange = warnOnChange;
    }

    public void txtName_textChanged(final DocumentEvent e) {
	cmdConstruct.setEnabled((txtName.getText().length() > 0)
		&& (lstAttributes.getSelectedValues().length > 0));
    }

    private boolean warn(final String warning) {
	return JOptionPane.showConfirmDialog(this, warning, "Warning",
		JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE) == JOptionPane.YES_OPTION;
    }
}
