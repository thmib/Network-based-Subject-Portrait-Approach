package org.epistasis.mdr.networkEntropy;

import org.epistasis.AbstractModelObject;
import org.epistasis.mdr.entropy.EntropyAnalysis.NetworkDataType;

public class NetworkDisplayModel extends AbstractModelObject {
    private String allSummaryData;
    private NetworkDataType networkDataType = NetworkDataType.MDR_ATTRIBUTE;
    // private List<Double> nodeThresholdList;
    // private List<Double> edgeThresholdList;
    private double nodeThreshold;
    // private final int nodeThresholdSliderValue = 10;
    // private final int edgeThresholdSliderValue = 10;
    private double edgeThreshold;
    private boolean graphAvailableForDisplay = false;
    private boolean isBusy = false;
    private Integer graphMaximumVertices = 0;

    // List<GraphLevelMetrics<Integer, Integer>> graphLevelMetricsList = new
    // ArrayList<GraphLevelMetrics<Integer, Integer>>();

    public String getAllSummaryData() {
	return allSummaryData;
    }

    // public double getEdgeThreshold() {
    // return edgeThreshold;
    // }
    //
    // public List<Double> getEdgeThresholdList() {
    // return edgeThresholdList;
    // }
    //
    // public int getEdgeThresholdSliderValue() {
    // return edgeThresholdSliderValue;
    // }
    //
    public boolean getGraphAvailableForDisplay() {
	return graphAvailableForDisplay;
    }

    public Integer getGraphMaximumVertices() {
	return graphMaximumVertices;
    }

    // public List<GraphLevelMetrics<Integer, Integer>> getGraphLevelMetrics() {
    // return graphLevelMetricsList;
    // }
    //
    public boolean getIsBusy() {
	return isBusy;
    }

    public NetworkDataType getNetworkDataType() {
	return networkDataType;
    }

    public void setEdgeThreshold(final double edgeThreshold) {
	firePropertyChange("edgeThreshold", this.edgeThreshold,
		this.edgeThreshold = edgeThreshold);
    }

    // public double getNodeThreshold() {
    // return nodeThreshold;
    // }
    //
    // public List<Double> getNodeThresholdList() {
    // return nodeThresholdList;
    // }
    //
    // public int getNodeThresholdSliderValue() {
    // return nodeThresholdSliderValue;
    // }
    //
    // public void setAllSummaryData(final String allSummaryData) {
    // firePropertyChange("allSummaryData", this.allSummaryData,
    // this.allSummaryData = allSummaryData);
    // }

    // public void setEdgeThresholdList(final List<Double> edgeThresholdList) {
    // firePropertyChange("edgeThresholdList", this.edgeThresholdList,
    // this.edgeThresholdList = edgeThresholdList);
    // }
    //
    // public void setEdgeThresholdSliderValue(final int
    // edgeThresholdSliderValue) {
    // firePropertyChange("edgeThresholdSliderValue",
    // this.edgeThresholdSliderValue,
    // this.edgeThresholdSliderValue = edgeThresholdSliderValue);
    // }
    //
    public void setGraphAvailableForDisplay(
	    final boolean graphAvailableForDisplay) {
	firePropertyChange("graphAvailableForDisplay",
		this.graphAvailableForDisplay,
		this.graphAvailableForDisplay = graphAvailableForDisplay);
    }

    public void setGraphMaximumVertices(final Integer graphMaximumVertices) {
	firePropertyChange("graphMaximumVertices", this.graphMaximumVertices,
		this.graphMaximumVertices = graphMaximumVertices);
    }

    public void setIsBusy(final boolean isBusy) {
	firePropertyChange("isBusy", this.isBusy, this.isBusy = isBusy);
    }

    public void setNetworkDataType(final NetworkDataType networkDataType) {
	firePropertyChange("networkDataType", this.networkDataType,
		this.networkDataType = networkDataType);
    }

    public void setNodeThreshold(final double nodeThreshold) {
	firePropertyChange("nodeThreshold", this.nodeThreshold,
		this.nodeThreshold = nodeThreshold);
    }

    // public void setNodeThresholdList(final List<Double> nodeThresholdList) {
    // firePropertyChange("nodeThresholdList", this.nodeThresholdList,
    // this.nodeThresholdList = nodeThresholdList);
    // }
    //
    // public void setNodeThresholdSliderValue(final int
    // nodeThresholdSliderValue) {
    // firePropertyChange("nodeThresholdSliderValue",
    // this.nodeThresholdSliderValue,
    // this.nodeThresholdSliderValue = nodeThresholdSliderValue);
    // }
}
