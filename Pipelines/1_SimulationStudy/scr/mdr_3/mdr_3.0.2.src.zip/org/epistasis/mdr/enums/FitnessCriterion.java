package org.epistasis.mdr.enums;

import java.io.Serializable;

public enum FitnessCriterion implements Serializable {
    CVC(MdrTableColumnName.CVC, true, true), CV_TRAINING(
	    MdrTableColumnName.CV_TRAINING, true, true), CV_TESTING(
	    MdrTableColumnName.CV_TESTING, true, true), MODEL_OVERALL(
	    MdrTableColumnName.OVERALL_SCORE),
    // LEAVE_ONE_OUT_CROSS_VALIDATION_TESTING(
    // MdrTableColumnName.LOOCV_TESTING),
    // LEAVE_ONE_OUT_CROSS_VALIDATION_TRAINING(
    // MdrTableColumnName.LOOCV_TRAINING),
    MODEL_TRAINING(MdrTableColumnName.MODEL_TRAINING, true, false), MODEL_TESTING(
	    MdrTableColumnName.MODEL_TESTING, true, false),
    // first parsimony, next attribute indices
    MODEL_ATTRIBUTES(MdrTableColumnName.MODEL_ATTRIBUTES),
    /**
     * The idea of 'adjusted testing' is to create metric that shows a 'good
     * model'. Naively, you might think that a good model would be the one with
     * the highest testing score but unfortunately with the way we do cross
     * validation and pick models by CVC, the testing data is somewhat dependent
     * on the training data and therefore tends to increase with training score
     * (which tends to increase with number of levels). A different signal of
     * 'goodness' is when the difference between the training and testing score
     * is small -- this is an indication that the model is not overfit. The
     * 'adjusted testing' metric tries to increase models with reduced
     * overfitting (alternatively to punish models with excessive overfitting).
     * */
    MODEL_ADJUSTED_TESTING(MdrTableColumnName.MODEL_ADJUSTED_TESTING, true,
	    false),
    // MODEL_WINNERS_TESTING is the aggregate testing fitness for just those
    // intervals of a model that are the winners in their interval.
    // This is used to decide which model to select if there is a tie on CVC
    MODEL_WINNERS_TESTING(MdrTableColumnName.MODEL_WINNERS_TESTING, true, true), COVERAGE(
	    MdrTableColumnName.COVERAGE), ;

    private final boolean dependentOnCVC;
    private boolean dependentOnCrossValidation;
    private final MdrTableColumnName mdrTableColumnName;

    private FitnessCriterion(final MdrTableColumnName mdrTableColumnName) {
	this(mdrTableColumnName, false /* dependentOnCrossValidation */, false /* dependentOnCVC */);
    }

    private FitnessCriterion(final MdrTableColumnName mdrTableColumnName,
	    final boolean dependentOnCrossValidation,
	    final boolean dependentOnCVC) {
	this.mdrTableColumnName = mdrTableColumnName;
	this.dependentOnCrossValidation = dependentOnCrossValidation;
	this.dependentOnCVC = dependentOnCVC;
	// if dependentOnCVC then by definition must also be
	// dependentOnCrossValidation
	assert dependentOnCVC ? dependentOnCrossValidation : true;
    }

    public MdrTableColumnName getMdrTableColumnName() {
	return mdrTableColumnName;
    }

    /**
     * indicates whether this is a fixed model attribute or whether its value
     * can change based on whether it wins (or loses) a cross-validation
     * interval
     * 
     * @return
     */
    public boolean isDependentOnCrossValidation() {
	return dependentOnCrossValidation;
    }

    /**
     * indicates whether this is a fixed model attribute or whether its value
     * can change based on whether it wins (or loses) a cross-validation
     * interval
     * 
     * @return
     */
    public boolean isDependentOnCVC() {
	return dependentOnCVC;
    }
}