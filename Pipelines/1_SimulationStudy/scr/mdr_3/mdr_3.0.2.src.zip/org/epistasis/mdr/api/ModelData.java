package org.epistasis.mdr.api;

public class ModelData {
    private final String name;
    private final float modelTrainingAverage;
    private final float modelTestingAggregate;

    public ModelData(final String name, final float modelTrainingAverage,
	    final float modelTestingAverage) {
	this.name = name;
	this.modelTrainingAverage = modelTrainingAverage;
	modelTestingAggregate = modelTestingAverage;
    }

    public String getName() {
	return name;
    }

    public float getModelTrainingAverage() {
	return modelTrainingAverage;
    }

    public float getModelTestingAggregate() {
	return modelTestingAggregate;
    }
}
