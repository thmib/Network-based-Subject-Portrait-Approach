package org.epistasis.mdr.newengine;

import java.util.Comparator;

import org.epistasis.Utility;
import org.epistasis.mdr.enums.FitnessCriteriaOrder;
import org.epistasis.mdr.enums.FitnessCriterion;

public class ModelInfoInterfaceComparator implements
	Comparator<ModelInfoInterface> {

    private final FitnessCriteriaOrder fitnessCriteriaOrder;

    public ModelInfoInterfaceComparator(
	    final FitnessCriteriaOrder fitnessCriteriaOrder) {
	this.fitnessCriteriaOrder = fitnessCriteriaOrder;
    }

    @Override
    public int compare(final ModelInfoInterface o1, final ModelInfoInterface o2) {
	final boolean debug = false;
	int compareResult = 0;
	if (o1 != o2) {
	    for (final FitnessCriterion fitnessCriterion : fitnessCriteriaOrder
		    .getTestsInOrder()) {
		compareResult = compare(o1, o2, fitnessCriterion);
		if (compareResult != 0) {
		    break;
		}
	    } // end for loop over tests
	    if (debug) {
		System.out.println("ModelComparisonInfo compareTo returning "
			+ compareResult + ":\n self: " + o1.toString()
			+ "\nother: " + o2.toString());
	    }
	    // if (compareResult == 0) {
	    // System.err
	    // .println("EQUALS BUT NOT SAME OBJECT: ModelComparisonInfo compareTo returning "
	    // + compareResult
	    // + ":\n self: "
	    // + o1.toString()
	    // + "\nother: " + o2.toString());
	    // }
	} // end if not the same object

	return compareResult;
    }

    private int compare(final ModelInfoInterface o1,
	    final ModelInfoInterface o2, final FitnessCriterion fitnessCriterion) {

	int compareResult = 0;
	if (o1 != o2) {
	    switch (fitnessCriterion) {
	    case CVC:
		// bigger is better so order of comparison is reversed
		compareResult = o2.getCVC() - o1.getCVC();
		// System.err.println("CVC of o1: " + o1.getModelName() +
		// "(CVC:"
		// + o1.getCVC() + ") and o2: " + o2.getModelName()
		// + "(CVC:" + o2.getCVC() + ") returning "
		// + compareResult);
		break;
	    case CV_TESTING:
		// bigger is better so order of comparison is reversed
		compareResult = Utility.compareFloatsHandlingNan(
			o2.getCVAggregateTestingFitness(),
			o1.getCVAggregateTestingFitness());
		break;
	    case CV_TRAINING:
		// bigger is better so order of comparison is reversed
		compareResult = Utility.compareFloatsHandlingNan(
			o2.getCVAverageTrainingFitness(),
			o1.getCVAverageTrainingFitness());
		break;
	    case MODEL_OVERALL:
		// bigger is better so order of comparison is reversed
		compareResult = Utility.compareFloatsHandlingNan(
			o2.getOverallFitness(), o1.getOverallFitness());
		break;
	    case MODEL_TRAINING:
		// bigger is better so order of comparison is reversed
		compareResult = Utility.compareFloatsHandlingNan(
			o2.getAverageTrainingFitness(),
			o1.getAverageTrainingFitness());
		break;
	    case MODEL_TESTING:
		// bigger is better so order of comparison is reversed
		compareResult = Utility.compareFloatsHandlingNan(
			o2.getAggregateTestingFitness(),
			o1.getAggregateTestingFitness());
		break;
	    case MODEL_ADJUSTED_TESTING:
		compareResult = Utility.compareFloatsHandlingNan(
			o2.getAdjustedTesting(), o1.getAdjustedTesting());
		break;
	    case MODEL_ATTRIBUTES:
		// fewer attributes is better or if same size, lower
		// attribute
		// indices (just to make deterministic)
		compareResult = o1.getModel().compareTo(o2.getModel());
		break;
	    case MODEL_WINNERS_TESTING:
		// bigger is better so order of comparison is reversed
		compareResult = Utility.compareFloatsHandlingNan(
			o2.getModelWinnersAggregateTestingFitness(),
			o1.getModelWinnersAggregateTestingFitness());
		break;
	    // case LEAVE_ONE_OUT_CROSS_VALIDATION_TESTING:
	    // // bigger is better so order of comparison is reversed
	    // compareResult = Utility.compareFloatsHandlingNan(
	    // o2.getLeaveOneOutCrossValidationTestingFitness(),
	    // o1.getLeaveOneOutCrossValidationTestingFitness());
	    // break;
	    // case LEAVE_ONE_OUT_CROSS_VALIDATION_TRAINING:
	    // // bigger is better so order of comparison is reversed
	    // compareResult = Utility.compareFloatsHandlingNan(
	    // o2.getLeaveOneOutCrossValidationTrainingFitness(),
	    // o1.getLeaveOneOutCrossValidationTrainingFitness());
	    // break;
	    default:
		throw new RuntimeException(
			"ModelComparisonInfo compareTo(final FitnessCriterion fitnessCriterion) unhandled case: "
				+ fitnessCriterion);
		// break;
	    } // end switch
	}
	return compareResult;
    }

    public FitnessCriteriaOrder getFitnessCriteriaOrder() {
	return fitnessCriteriaOrder;
    }

    public boolean isDependentOnCrossValidation() {
	return fitnessCriteriaOrder.isDependentOnCrossValidation();
    }

    @Override
    public String toString() {
	return getClass().getSimpleName() + " using: " + fitnessCriteriaOrder;
    }

} // end static class ModelComparisonInfoComparator