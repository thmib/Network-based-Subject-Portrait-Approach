package org.epistasis.mdr;

import java.text.NumberFormat;

import org.epistasis.mdr.newengine.Collector;
import org.epistasis.mdr.newengine.Collector.ModelComparisonInfo.ModelIntervalInfo;
import org.epistasis.mdr.newengine.Dataset;

public class CVResultsTextGenerator extends ModelTextGenerator {
    private final Collector coll;

    public CVResultsTextGenerator(final Dataset data, final Collector coll,
	    final AmbiguousCellStatus tieStatus, final byte affectedStatus,
	    final NumberFormat nf, final double pValueTol,
	    final boolean isVerbose) {
	super(data, tieStatus, nf, pValueTol, isVerbose);
	this.coll = coll;
    }

    private void addInterval(final Dataset data,
	    final ModelIntervalInfo modelIntervalInfo, final StringBuffer b,
	    final int idx) {
	b.append("Cross Validation ");
	b.append(idx + 1);
	b.append(" of ");
	b.append(coll.getNumIntervals());
	b.append(": ");
	b.append(modelIntervalInfo.getModelName());
	b.append("\n");
	b.append(getResultText(data, modelIntervalInfo.getModel(),
		modelIntervalInfo.getTrainingConfusionMatrix(), " Training", 28));
	if (modelIntervalInfo.hasTesting()) {
	    b.append("\n");
	    b.append(getResultText(data, modelIntervalInfo.getModel(),
		    modelIntervalInfo.getTestingConfusionMatrix(), " Testing",
		    28));
	}
    }

    @Override
    public String toString() {
	final StringBuffer b = new StringBuffer();
	final ModelIntervalInfo[] winningIntervals = coll
		.getWinningIntervalsModelInfo();
	for (int i = 0; i < coll.getNumIntervals(); ++i) {
	    if (i != 0) {
		b.append('\n');
	    }
	    addInterval(data, winningIntervals[i], b, i);
	}
	return b.toString();
    }
}
