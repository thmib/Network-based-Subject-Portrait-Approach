package org.epistasis.mdr.entropy;

import java.io.PrintWriter;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.SortedMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.epistasis.ColumnFormat;
import org.epistasis.Entropy;
import org.epistasis.Pair;
import org.epistasis.PriorityList;
import org.epistasis.Utility;
import org.epistasis.gui.ProgressPanelUpdater;
import org.epistasis.mdr.AmbiguousCellStatus;
import org.epistasis.mdr.Main;
import org.epistasis.mdr.gui.Frame;
import org.epistasis.mdr.networkEntropy.NetworkGraph;
import org.epistasis.mdr.newengine.AttributeCombination;
import org.epistasis.mdr.newengine.Dataset;
import org.epistasis.mdr.newengine.Model;
import org.epistasis.mdr.newengine.Model.Cell;

import edu.uci.ics.jung.graph.UndirectedGraph;

public class EntropyAnalysis {
    public static final String I_AB_C = "I(AB;C)";
    public static final String I_A_B = "I(A;B)";
    public static final String H_AB_C = "H(AB|C)";
    public static final String H_AB = "H(AB)";
    public static final String H_A_C = "H(A|C)";
    public static final String H_A = "H(A)";
    public static final String I_A_C = "I(A;C)";
    public static final String IG_AB_C = "IG(A;B;C)";
    private List<String> attrNames;
    private double[][] entropy;
    private double[][] cond_entropy;
    // private double class_entropy;
    private double maxDist = 1000;
    private List<Integer> attributeIndices;
    private Dataset data;
    private HierarchicalCluster<String> cluster;
    private DistanceMatrix<String> distmat;
    private DistanceMatrix<String> infomat;
    private AmbiguousCellStatus ambiguousCellStatus = Main.defaultAmbiguousCellStatus;
    ProgressPanelUpdater progressPanelUpdater = null;
    Thread entropyCalculationThread = null;
    private int numEntropyEdges;
    private int numEntropyAttributes;
    private NetworkDataType networkDataType;
    private final EntropyValuesCalculator entropyValues = new EntropyValuesCalculator();
    private final boolean parallel;
    private final int digitsOfPrecision;
    public final static int DEFAULT_DIGITS_OF_PRECISION = 5;
    private boolean entropyDataReady = false;

    public EntropyAnalysis() {
	this(NetworkDataType.MDR_ATTRIBUTE, false /* parallel */,
		EntropyAnalysis.DEFAULT_DIGITS_OF_PRECISION /* digitsOfPrecision */);
    }

    public EntropyAnalysis(final NetworkDataType networkDataType,
	    final boolean parallel, final int digitsOfPrecision) {
	setNetworkDataType(networkDataType);
	this.parallel = parallel;
	this.digitsOfPrecision = digitsOfPrecision;
    }

    public NetworkGraph buildGraph(
	    final UndirectedGraph<Integer, Integer> jungGraph) {
	final double[][] edgeValues = new double[entropy.length][];
	final double[] class_cond_entropy = new double[entropy.length];
	for (int a = 0; a < entropy.length; ++a) {
	    edgeValues[a] = new double[a];
	    entropyValues.calculateValuesA(a);
	    class_cond_entropy[a] = BigDecimal.valueOf(entropyValues.i_a_c)
		    .setScale(digitsOfPrecision, BigDecimal.ROUND_FLOOR)
		    .doubleValue();
	}
	for (int a = 1; a < entropy.length; ++a) {
	    for (int b = 0; b < a; ++b) {
		entropyValues.calculateValues(a, b);
		edgeValues[a][b] = BigDecimal.valueOf(entropyValues.ig_a_b_c)
			.setScale(digitsOfPrecision, BigDecimal.ROUND_FLOOR)
			.doubleValue();
	    }
	}
	final NetworkGraph networkGraph = new NetworkGraph(attrNames,
		class_cond_entropy, edgeValues, null /* ignoredNodes */,
		true /* includeJGraphT */, false /* collectFrequencyData */,
		jungGraph);
	return networkGraph;
    }

    public void clear() {
	attributeIndices = null;
	data = null;
	entropyDataReady = false;
	cluster = null;
	distmat = null;
	infomat = null;
    }

    private void constructMatrices(final boolean calculateAllEntropyMetrics) {
	final boolean debug = false;
	numEntropyAttributes = attributeIndices.size();
	numEntropyEdges = Utility.combinations(numEntropyAttributes, 2)
		.intValue();
	if (progressPanelUpdater != null) {
	    final long totalNumberOfCombinations = numEntropyEdges
		    + numEntropyAttributes;
	    progressPanelUpdater.setMaximum(totalNumberOfCombinations);
	}
	final byte[] classAttribute = data.getDichotomousEndpoints();

	// class_entropy = Entropy.getEntropy(classAttribute); // 1.0 for
	// balanced data
	entropy = new double[numEntropyAttributes][];
	cond_entropy = new double[numEntropyAttributes][];
	attrNames = new ArrayList<String>(numEntropyAttributes);
	if (calculateAllEntropyMetrics) {
	    distmat = new DistanceMatrix<String>();
	    infomat = new DistanceMatrix<String>();
	}
	final int NUMBER_THREADS = parallel ? (Runtime.getRuntime()
		.availableProcessors() * 1) : 1;
	final ExecutorService oneWayExecutorService = new ThreadPoolExecutor(
		NUMBER_THREADS, NUMBER_THREADS, 0L, TimeUnit.MILLISECONDS,
		new LinkedBlockingQueue<Runnable>(NUMBER_THREADS));
	entropyCalculationThread = new Thread("EntropyCalculation") {

	    @Override
	    public void run() {
		if (debug) {
		    System.out
			    .println("Starting Entropy calculation. Initially getting entropy for single attributes.");
		}
		for (int entropyAttributeIndex = 0; entropyAttributeIndex < numEntropyAttributes; ++entropyAttributeIndex) {
		    final int finalEntropyAttributeIndex = entropyAttributeIndex;
		    final int datasetAttributeIndex = attributeIndices
			    .get(finalEntropyAttributeIndex);
		    final String attributeName = data.getLabels().get(
			    datasetAttributeIndex);
		    attrNames.add(attributeName);
		    final Runnable runnable = new Runnable() {
			@Override
			public void run() {
			    // if (debug) {
			    // System.out.println("getting entropy for attributeIndex: "
			    // + finalAttributeIndex);
			    // }
			    final byte[] attribute = data
				    .getColumn(datasetAttributeIndex);
			    entropy[finalEntropyAttributeIndex] = new double[finalEntropyAttributeIndex + 1];
			    entropy[finalEntropyAttributeIndex][finalEntropyAttributeIndex] = Entropy
				    .getEntropy(attribute);
			    // final Model model = new Model(new
			    // AttributeCombination(Arrays
			    // .asList(new Integer[] { datasetAttributeIndex }),
			    // data
			    // .getLabels()), ambiguousCellStatus);
			    // model.buildCounts(data);
			    // model.buildStatuses(data,
			    // data.getStatusCounts());
			    // final double modelEntropy =
			    // model.getEntropy(data);
			    // final double conditionalModelEntropy = model
			    // .getConditionalEntropy(data);
			    cond_entropy[finalEntropyAttributeIndex] = new double[finalEntropyAttributeIndex + 1];
			    cond_entropy[finalEntropyAttributeIndex][finalEntropyAttributeIndex] = Entropy
				    .getConditionalEntropy(attribute,
					    classAttribute);
			    if (progressPanelUpdater != null) {
				progressPanelUpdater.run();
			    } // end if progressPanelUpdater != null
			} // end run()
		    };
		    if (!parallel) {
			runnable.run();
		    } else {
			while (true) {
			    try {
				oneWayExecutorService.submit(runnable);
				break; // EXIT WHILE LOOP
			    } catch (final RejectedExecutionException rejectedException) {
				Thread.yield();
				// if (debug) {
				// System.out.println("Submittal loop caught: "
				// + rejectedException
				// + " cause: " + rejectedException.getCause());
				// }
			    } // end catch
			} // end while true
		    } // end if parallel
		} // end loop over attributes
		oneWayExecutorService.shutdown();
		try {
		    oneWayExecutorService.awaitTermination(1, TimeUnit.MINUTES);
		} catch (final InterruptedException ex) {
		    ex.printStackTrace();
		}
		if (debug) {
		    System.out
			    .println("Finished getting all 1-way entropy metrics. Next getting entropy for all 2-way interactions.");
		}
		final ExecutorService twoWayExecutorService = new ThreadPoolExecutor(
			NUMBER_THREADS, NUMBER_THREADS, 0L,
			TimeUnit.MILLISECONDS,
			new LinkedBlockingQueue<Runnable>(NUMBER_THREADS * 1));
		for (int outerEntropyAttributeIndex = 0; outerEntropyAttributeIndex < numEntropyAttributes; ++outerEntropyAttributeIndex) {
		    final int finalOuterEntropyAttributeIndex = outerEntropyAttributeIndex;
		    final int outerDatasetAttributeIndex = attributeIndices
			    .get(finalOuterEntropyAttributeIndex);
		    final String outerAttributeName = data.getLabels().get(
			    outerDatasetAttributeIndex);
		    data.getColumn(outerDatasetAttributeIndex);
		    final Runnable runnable = new Runnable() {
			@Override
			public void run() {
			    for (int innerEntropyAttributeIndex = 0; innerEntropyAttributeIndex < finalOuterEntropyAttributeIndex; ++innerEntropyAttributeIndex) {
				final int innerDatasetAttributeIndex = attributeIndices
					.get(innerEntropyAttributeIndex);
				final String innerAttributeName = data
					.getLabels().get(
						innerDatasetAttributeIndex);
				// System.out
				// .println("getting 2-way entropy for attributeIndices: "
				// + finalOuterAttributeIndex + ","
				// + finalInnerAttributeIndex);
				final Model model = new Model(
					new AttributeCombination(Arrays.asList(
						outerDatasetAttributeIndex,
						innerDatasetAttributeIndex),
						data.getLabels()),
					ambiguousCellStatus);
				final SortedMap<byte[], Cell> cells = model
					.buildCounts(data);
				model.buildStatuses(data,
					data.getStatusCounts(), cells);
				data.getColumn(innerDatasetAttributeIndex);
				switch (networkDataType) {
				// case BALANCED_ACCURACY: {
				// }
				// break;
				case CARTESIAN_PRODUCT: {
				    entropy[finalOuterEntropyAttributeIndex][innerEntropyAttributeIndex] = model
					    .getEntropy(data);
				    cond_entropy[finalOuterEntropyAttributeIndex][innerEntropyAttributeIndex] = model
					    .getConditionalEntropy(data);
				}
				    break;
				case MDR_ATTRIBUTE: {
				    final byte[] combinedAttribute = model
					    .constructRawAttribute(data);
				    entropy[finalOuterEntropyAttributeIndex][innerEntropyAttributeIndex] = Entropy
					    .getEntropy(combinedAttribute);
				    cond_entropy[finalOuterEntropyAttributeIndex][innerEntropyAttributeIndex] = Entropy
					    .getConditionalEntropy(
						    combinedAttribute,
						    classAttribute);
				    // IF WANT TO CHECK THAT NEW MODEL ENTROPY
				    // CODE MATCHES OLD
				    // final List<String> attribute = model
				    // .constructAttribute(data);
				    // data.insertColumn(0,
				    // model.getCombo().getComboString('_'),
				    // attribute);
				    // final Model combined_attribute_model =
				    // new Model(
				    // new AttributeCombination(Arrays
				    // .asList(new Integer[] { 0 }),
				    // data.getLabels()),
				    // ambiguousCellStatus);
				    // combined_attribute_model.buildCounts(data);
				    // combined_attribute_model.buildStatuses(data,
				    // data.getStatusCounts());
				    // System.out.println(combined_attribute_model.getCombo()
				    // + " OLD Entropy : "
				    // +
				    // entropy[finalOuterEntropyAttributeIndex][finalInnerEntropyAttributeIndex]
				    // + " conditional entropy: "
				    // +
				    // cond_entropy[finalOuterEntropyAttributeIndex][finalInnerEntropyAttributeIndex]);
				    // System.out.println(combined_attribute_model.getCombo()
				    // + " NEW Entropy : "
				    // +
				    // combined_attribute_model.getEntropy(data)
				    // + " conditional entropy: "
				    // + combined_attribute_model
				    // .getConditionalEntropy(data));
				    // data.removeColumn(0);
				}
				    break;
				default:
				    throw new RuntimeException(
					    "switch on NetworkDataType found unhandled type: "
						    + networkDataType);
				} // end switch
				if (calculateAllEntropyMetrics) {
				    entropyValues.calculateValues(
					    finalOuterEntropyAttributeIndex,
					    innerEntropyAttributeIndex);
				    double distance = Math
					    .abs(1 / entropyValues.ig_a_b_c);
				    distance = Math.min(maxDist, distance);
				    distmat.put(innerAttributeName,
					    outerAttributeName, distance);
				    infomat.put(innerAttributeName,
					    outerAttributeName,
					    entropyValues.ig_a_b_c);
				}
				if (progressPanelUpdater != null) {
				    progressPanelUpdater.run();
				} // end if progressPanelUpdater != null
			    } // end inner attribute loop
			} // end run()
		    }; // end Runnable class
		    if (!parallel) {
			runnable.run();
		    } else {
			while (true) {
			    try {
				twoWayExecutorService.submit(runnable);
				break; // EXIT while true loop
			    } catch (final RejectedExecutionException rejectedException) {
				Thread.yield();
				// System.out.println("2-way Submittal loop caught: "
				// + rejectedException + " cause: "
				// + rejectedException.getCause());
			    } // end catch
			} // end while true
		    } // end if parallel
		} // end outerAttributeLoop
		twoWayExecutorService.shutdown();
		try {
		    twoWayExecutorService.awaitTermination(1, TimeUnit.MINUTES);
		} catch (final InterruptedException ex) {
		    ex.printStackTrace();
		}
		if (debug) {
		    System.out
			    .println("Finished getting all 2-way entropy metrics.");
		}
		if (calculateAllEntropyMetrics) {
		    if (debug) {
			System.out
				.println("Next calculating hierarchical cluster.");
		    }
		    final ExecutorService hierarchicalClusterCalculationExecutorService = new ThreadPoolExecutor(
			    NUMBER_THREADS, NUMBER_THREADS, 0L,
			    TimeUnit.MILLISECONDS,
			    new LinkedBlockingQueue<Runnable>(
				    NUMBER_THREADS * 1));
		    hierarchicalClusterCalculationExecutorService
			    .submit(new Runnable() {
				@Override
				public void run() {
				    // System.out.println("Starting calculating HierarchicalCluster");
				    cluster = new HierarchicalCluster<String>(
					    distmat);
				} // end run()
			    }); // end submit
		    hierarchicalClusterCalculationExecutorService.shutdown();
		    try {
			hierarchicalClusterCalculationExecutorService
				.awaitTermination(1, TimeUnit.MINUTES);
		    } catch (final InterruptedException ex) {
			ex.printStackTrace();
		    }
		    if (debug) {
			System.out
				.println("Finished calculating HierarchicalCluster");
			// final EntropyAnalysis entropyAnalysis = new
			// EntropyAnalysis(data);
			// System.out.println(entropyAnalysis.getEntropyText(Main.defaultFormat));
		    }
		} // end if calculatingHierarchicalCluster
		entropyDataReady = true;
	    } // end run in submittal loop
	}; // end run() method of submitting thread that submits all the worker
	   // threads
	entropyCalculationThread.start();
    } // end constructMatrices

    public List<String> getAttrNames() {
	return attrNames;
    }

    public HierarchicalCluster<String> getCluster() {
	return cluster;
    }

    public List<Integer> getCombos() {
	return attributeIndices;
    }

    // public double getClass_entropy() {
    // return class_entropy;
    // }

    public double[][] getCond_entropy() {
	return cond_entropy;
    }

    public Dataset getData() {
	return data;
    }

    public DistanceMatrix<String> getDistmat() {
	return distmat;
    }

    public DistanceMatrix<String> getDistMatrix() {
	return distmat;
    }

    // public SortedSet<Double> getEdgeThresholdList() {
    // if (edgeThresholdSet == null) {
    // edgeThresholdSet = new TreeSet<Double>();
    // for (int a = 1; a < entropy.length; ++a) {
    // for (int b = 0; b < a; ++b) {
    // entropyValues.calculateValues(a, b);
    // edgeThresholdSet.add(BigDecimal.valueOf(entropyValues.ig_a_b_c)
    // .setScale(digitsOfPrecision, BigDecimal.ROUND_FLOOR)
    // .doubleValue());
    // }
    // }
    // } // end if needed to create list
    // return edgeThresholdSet;
    // }
    public double[][] getEntropy() {
	return entropy;
    }

    public String getEntropyText(final NumberFormat nf, final boolean useTabs) {
	if (entropy == null) {
	    return "";
	}
	return getEntropyTextOneWay(nf, useTabs)
		+ getEntropyTextTwoWay(nf, useTabs);
    }

    public String getEntropyTextOneWay(final NumberFormat nf,
	    final boolean useTabs) {
	waitUntilEntropyCalculationFinished();
	final List<Integer> widths = new ArrayList<Integer>();
	final List<String> values = new ArrayList<String>();
	final StringBuffer sb = new StringBuffer();
	widths.add(30);
	widths.add(10);
	widths.add(10);
	widths.add(10);
	final ColumnFormat fmt = new ColumnFormat(widths, useTabs);
	sb.append("Single Attribute Values:\n\n");
	values.add("Attribute");
	values.add(EntropyAnalysis.H_A);
	values.add(EntropyAnalysis.H_A_C);
	values.add(EntropyAnalysis.I_A_C);
	sb.append(fmt.format(values));
	sb.append('\n');
	values.clear();
	values.add("---------");
	values.add("----");
	values.add("------");
	values.add("------");
	sb.append(fmt.format(values));
	sb.append('\n');
	values.clear();
	for (int a = 0; a < entropy.length; ++a) {
	    entropyValues.calculateValuesA(a);
	    values.add(attrNames.get(a).toString());
	    values.add(nf.format(entropyValues.h_a));
	    values.add(nf.format(entropyValues.h_a_c));
	    values.add(nf.format(entropyValues.i_a_c));
	    sb.append(fmt.format(values));
	    sb.append('\n');
	    values.clear();
	}
	sb.append('\n');
	return sb.toString();
    }

    public String getEntropyTextTwoWay(final NumberFormat nf,
	    final boolean useTabs) {
	waitUntilEntropyCalculationFinished();
	final List<Integer> widths = new ArrayList<Integer>();
	final List<String> values = new ArrayList<String>();
	final StringBuffer sb = new StringBuffer();
	widths.add(new Integer(30));
	widths.add(new Integer(30));
	widths.add(new Integer(10));
	widths.add(new Integer(10));
	widths.add(new Integer(10));
	widths.add(new Integer(10));
	widths.add(new Integer(10));
	final ColumnFormat fmt = new ColumnFormat(widths, useTabs);
	sb.append("Pairwise Values:\n\n");
	values.add("Attribute A");
	values.add("Attribute B");
	values.add(EntropyAnalysis.H_AB);
	values.add(EntropyAnalysis.H_AB_C);
	values.add(EntropyAnalysis.I_A_B);
	values.add(EntropyAnalysis.IG_AB_C);
	values.add(EntropyAnalysis.I_AB_C);
	sb.append(fmt.format(values));
	sb.append('\n');
	values.clear();
	values.add("-----------");
	values.add("-----------");
	values.add("-----");
	values.add("-------");
	values.add("------");
	values.add("--------");
	values.add("-------");
	sb.append(fmt.format(values));
	sb.append('\n');
	values.clear();
	for (int a = 1; a < entropy.length; ++a) {
	    for (int b = 0; b < a; ++b) {
		entropyValues.calculateValues(a, b);
		values.add(attrNames.get(a).toString());
		values.add(attrNames.get(b).toString());
		values.add(nf.format(entropyValues.h_ab));
		values.add(nf.format(entropyValues.h_ab_c));
		values.add(nf.format(entropyValues.i_a_b));
		values.add(nf.format(entropyValues.ig_a_b_c));
		values.add(nf.format(entropyValues.i_ab_c));
		sb.append(fmt.format(values));
		sb.append('\n');
		values.clear();
	    }
	}
	return sb.toString();
    }

    public EntropyValuesCalculator getEntropyValues() {
	return entropyValues;
    }

    /**
     * This creates bins that are even divided between negative and positive
     * values If 5 bins requested, first two are degrees of being negative,
     * middle bin means 'near zero' and last 2 bins are degrees of being
     * positive
     * 
     * @param numberOfBins
     * @param info
     * @return
     */
    public int getIndexIntoRange(final int numberOfBins, final double info) {
	final double maxDistanceFromZero = getMaxDistanceFromZero();
	final double totalRangeSize = maxDistanceFromZero * 2; // range covers
							       // both
	// negative and positive
	// numbers
	final double minOfVirtualRange = -maxDistanceFromZero;
	final double amountPerBin = totalRangeSize / numberOfBins;
	int bin = numberOfBins - 1; // initialize to last bin and then check to
				    // see
	// if in any earlier bin
	for (int index = 1; index < numberOfBins; ++index) {
	    final double binStart = minOfVirtualRange + (index * amountPerBin);
	    if (info < binStart) {
		// if less than bin's starting value then must be in previous
		// bin
		bin = index - 1;
		break;
	    }
	}
	return bin;
    } // end getIndexIntoRange

    public double getInfo(final HierarchicalCluster.Cluster<String> a,
	    final HierarchicalCluster.Cluster<String> b) {
	double sum = 0;
	for (final String o1 : a) {
	    for (final String o2 : b) {
		sum += infomat.get(o1, o2);
	    }
	}
	return sum / (a.size() * b.size());
    }

    public DistanceMatrix<String> getInfomat() {
	return infomat;
    }

    public DistanceMatrix<String> getInfoMatrix() {
	return infomat;
    }

    public double getMaxDist() {
	return maxDist;
    }

    public double getMaxDistanceFromZero() {
	double maxDistanceFromZero = 0.0;
	if (infomat != null) {
	    maxDistanceFromZero = Math.max(Math.abs(infomat.getMinValue()),
		    Math.abs(infomat.getMaxValue()));
	}
	return maxDistanceFromZero;
    }

    public NetworkDataType getNetworkDataType() {
	return networkDataType;
    }

    public AmbiguousCellStatus getTiePriority() {
	return ambiguousCellStatus;
    }

    public boolean hasData() {
	return data != null;
    }

    public boolean isEntropyDataReady() {
	return entropyDataReady;
    }

    public void set(final Dataset newData,
	    final NetworkDataType networkDataType,
	    final AmbiguousCellStatus tiePriority, final boolean parallel,
	    final ProgressPanelUpdater progressPanelUpdater,
	    final boolean waitForCalculationToComplete,
	    final boolean calculateAllEntropyMetrics, final Integer topNVertices) {
	clear();
	setNetworkDataType(networkDataType);
	final int numAttributes = newData.getCols() - 1;
	List<Integer> newColumnIndices;
	final boolean getTopNAttributes = (topNVertices != null)
		&& (topNVertices < numAttributes);
	// if topNVertices non-null then calculate information gain for each
	// attribute with respect to class

	if (getTopNAttributes) {
	    PriorityList<Pair<Double, Integer>> topNOneWayInformationGain = null;
	    topNOneWayInformationGain = new PriorityList<Pair<Double, Integer>>(
		    topNVertices, new Pair.FirstComparator<Double, Integer>(
			    new Comparator<Double>() {

				@Override
				public int compare(final Double o1,
					final Double o2) {
				    // REVERSE COMPARATOR -- note order is o2,
				    // o1
				    return Double.compare(o2, o1);
				}
			    }));
	    // h_a = entropy[a][a];
	    // h_a_c = cond_entropy[a][a];
	    // i_a_c = h_a - h_a_c;
	    final byte[] classAttribute = newData.getDichotomousEndpoints();
	    for (int datasetAttributeIndex = 0; datasetAttributeIndex < numAttributes; ++datasetAttributeIndex) {
		final byte[] attribute = newData
			.getColumn(datasetAttributeIndex);
		final double h_a = Entropy.getEntropy(attribute);
		final double h_a_c = Entropy.getConditionalEntropy(attribute,
			classAttribute);
		final double i_a_c = h_a - h_a_c;
		final Pair<Double, Integer> pair = new Pair<Double, Integer>(
			i_a_c, datasetAttributeIndex);
		topNOneWayInformationGain.add(pair);
	    } // end loop over attributes
	      // need to make a new dataset of just the topNAttributes
	    newColumnIndices = new ArrayList<Integer>(
		    topNOneWayInformationGain.size());
	    for (final Pair<Double, Integer> pair : topNOneWayInformationGain) {
		newColumnIndices.add(pair.getSecond());
	    }
	} // end if getTopNAttributes
	else {
	    newColumnIndices = new ArrayList<Integer>(numAttributes);
	    for (Integer colIndex = 0; colIndex < numAttributes; ++colIndex) {
		newColumnIndices.add(colIndex);
	    }

	}
	// call to set will start thread to calculate all entropy values
	setTiePriority(tiePriority);
	set(newColumnIndices, newData, progressPanelUpdater,
		waitForCalculationToComplete, calculateAllEntropyMetrics);
    } // end constructor for entire dataset

    public void set(final List<Integer> columnIndices, final Dataset data,
	    final ProgressPanelUpdater progressPanelUpdater,
	    final boolean waitForCalculationToComplete,
	    final boolean calculateAllEntropyMetrics) {
	clear();
	attributeIndices = columnIndices;
	this.data = data;
	this.progressPanelUpdater = progressPanelUpdater;
	constructMatrices(calculateAllEntropyMetrics);
	if (waitForCalculationToComplete) {
	    waitUntilEntropyCalculationFinished();
	}
    }

    public void setMaxDist(final double maxDist) {
	this.maxDist = maxDist;
    }

    public void setNetworkDataType(final NetworkDataType networkDataType) {
	this.networkDataType = networkDataType;
    }

    public void setTiePriority(final AmbiguousCellStatus tiePriority) {
	ambiguousCellStatus = tiePriority;
    }

    public int size() {
	return hasData() ? attributeIndices.size() : 0;
    }

    public void waitUntilEntropyCalculationFinished() {
	try {
	    entropyCalculationThread.join();
	} catch (final InterruptedException ex) {
	    ex.printStackTrace();
	}
    }

    /***
     * http://guess.wikispot.org/The_GUESS_.gdf_format
     * https://gephi.org/users/supported-graph-formats/gdf-format/
     * 
     * @param pw
     */
    public void writeGDF(final PrintWriter pw) {
	pw.println("nodedef>name VARCHAR, label VARCHAR, H_A DOUBLE, H_A_C DOUBLE, I_A_C DOUBLE");
	for (int a = 0; a < entropy.length; ++a) {
	    pw.print("n" + (a + 1));
	    pw.print(",");
	    pw.print(attrNames.get(a).toString());
	    entropyValues.calculateValuesA(a);
	    pw.print(",");
	    pw.print(Main.decimalUpToSixPrecision.format(entropyValues.h_a));
	    pw.print(",");
	    pw.print(Main.decimalUpToSixPrecision.format(entropyValues.h_a_c));
	    pw.print(",");
	    pw.print(Main.decimalUpToSixPrecision.format(entropyValues.i_a_c));
	    pw.println();
	}
	pw.println("edgedef>node1 VARCHAR, node2 VARCHAR, label VARCHAR, H_AB DOUBLE, H_AB_C DOUBLE, I_A_B DOUBLE, IG_AB_C DOUBLE, I_AB_C DOUBLE");
	for (int a = 1; a < entropy.length; ++a) {
	    for (int b = 0; b < a; ++b) {
		pw.print("n" + (b + 1));
		pw.print(",");
		pw.print("n" + (a + 1));
		pw.print(",");
		pw.print("'" + attrNames.get(b).toString() + "-"
			+ attrNames.get(a).toString() + "'");
		entropyValues.calculateValues(a, b);
		pw.print(",");
		pw.print(Main.decimalUpToSixPrecision
			.format(entropyValues.h_ab));
		pw.print(",");
		pw.print(Main.decimalUpToSixPrecision
			.format(entropyValues.h_ab_c));
		pw.print(",");
		pw.print(Main.decimalUpToSixPrecision
			.format(entropyValues.i_a_b));
		pw.print(",");
		pw.print(Main.decimalUpToSixPrecision
			.format(entropyValues.ig_a_b_c));
		pw.print(",");
		pw.print(Main.decimalUpToSixPrecision
			.format(entropyValues.i_ab_c));
		pw.println();
	    }
	}
    }

    public void writeGEXF(final PrintWriter pw) {
	pw.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
	pw.println("<gexf xmlns=\"http://www.gexf.net/1.2draft\" version=\"1.2\">");
	pw.println("<meta>");
	pw.println("  <creator>Multifactor Dimensionality Reduction (MDR) dataset: '\" + Frame.getFrame().getDatasetName() + \"' network type: \""
		+ networkDataType.getDisplayString() + "\"</creator>");
	pw.println("</meta>");
	pw.println("<graph defaultedgetype=\"undirected\">");
	pw.println("  <attributes class=\"node\">");
	pw.println("    <attribute  id=\"H_A\" title=\"" + EntropyAnalysis.H_A
		+ "\" type=\"float\"/>");
	pw.println("    <attribute  id=\"H_A_C\" title=\""
		+ EntropyAnalysis.H_A_C + "\" type=\"float\"/>");
	pw.println("    <attribute  id=\"I_A_C\" title=\""
		+ EntropyAnalysis.I_A_C + "\" type=\"float\"/>");
	pw.println("  </attributes>");
	pw.println("  <attributes class=\"edge\">");
	pw.println("    <attribute  id=\"H_AB\" title=\""
		+ EntropyAnalysis.H_AB + "\" type=\"float\"/>");
	pw.println("    <attribute  id=\"H_AB_C\" title=\""
		+ EntropyAnalysis.H_AB_C + "\" type=\"float\"/>");
	pw.println("    <attribute  id=\"I_A_B\" title=\""
		+ EntropyAnalysis.I_A_B + "\" type=\"float\"/>");
	pw.println("    <attribute  id=\"IG_AB_C\" title=\""
		+ EntropyAnalysis.IG_AB_C + "\" type=\"float\"/>");
	pw.println("    <attribute  id=\"I_AB_C\" title=\""
		+ EntropyAnalysis.I_AB_C + "\" type=\"float\"/>");
	pw.println("  </attributes>");
	pw.println("  <nodes>");
	for (int a = 0; a < entropy.length; ++a) {
	    pw.println("    <node id=\"" + a + "\" label=\""
		    + attrNames.get(a).toString() + "\">");
	    pw.println("      <attvalues>");
	    entropyValues.calculateValuesA(a);
	    pw.println("        <attvalue  id=\"H_A\" value=\""
		    + Main.decimalUpToSixPrecision.format(entropyValues.h_a)
		    + "\"/>");
	    pw.println("        <attvalue  id=\"H_A_C\" value=\""
		    + Main.decimalUpToSixPrecision.format(entropyValues.h_a_c)
		    + "\"/>");
	    pw.println("        <attvalue  id=\"I_A_C\" value=\""
		    + Main.decimalUpToSixPrecision.format(entropyValues.i_a_c)
		    + "\"/>");
	    pw.println("      </attvalues>");
	    pw.println("    </node>");
	}
	pw.println("  </nodes>");
	pw.println("  <edges>");
	int edgeCtr = 0;
	for (int a = 1; a < entropy.length; ++a) {
	    for (int b = 0; b < a; ++b) {
		pw.println("    <edge id=\"" + (edgeCtr++) + "\" label=\""
			+ attrNames.get(b).toString() + "-"
			+ attrNames.get(a).toString() + "\" source=\"" + b
			+ "\" target=\"" + a + "\">");
		entropyValues.calculateValues(a, b);
		pw.println("      <attvalues>");
		pw.println("        <attvalue  id=\"H_AB\" value=\""
			+ Main.decimalUpToSixPrecision
				.format(entropyValues.h_ab) + "\"/>");
		pw.println("        <attvalue  id=\"H_AB_C\" value=\""
			+ Main.decimalUpToSixPrecision
				.format(entropyValues.h_ab_c) + "\"/>");
		pw.println("        <attvalue  id=\"I_A_B\" value=\""
			+ Main.decimalUpToSixPrecision
				.format(entropyValues.i_a_b) + "\"/>");
		pw.println("        <attvalue  id=\"IG_AB_C\" value=\""
			+ Main.decimalUpToSixPrecision
				.format(entropyValues.ig_a_b_c) + "\"/>");
		pw.println("        <attvalue  id=\"I_AB_C\" value=\""
			+ Main.decimalUpToSixPrecision
				.format(entropyValues.i_ab_c) + "\"/>");
		pw.println("      </attvalues>");
		pw.println("    </edge>");
	    }
	}
	pw.println("  </edges>");
	pw.println("</graph>");
	pw.println("</gexf>");
    }

    /**
     * See http://www.infosun.fmi.uni-passau.de/Graphlet/GML/gml-tr.html print
     * "graph [" foreach node n in g do print "node [" print "id", n.id (*
     * Insert other node attributes here *) print "]" done foreach edge e in g
     * do print "edge [" print "source", e.source.id print "target", e.target.id
     * (* Insert other edge attributes here *) print "]" done (* Insert other
     * graph attributes here *) end
     * 
     * @param pw
     */
    public void writeGML(final PrintWriter pw) {
	pw.println("graph [");
	pw.println("       creater \"Multifactor Dimensionality Reduction (MDR)\"");
	pw.println("       label \"dataset: '"
		+ Frame.getFrame().getDatasetName() + "' network type: "
		+ networkDataType.getDisplayString() + "\"");
	pw.println("       directed 0");
	for (int a = 0; a < entropy.length; ++a) {
	    pw.println("       node [");
	    pw.println("             id " + (a + 1));
	    pw.println("             label \"" + attrNames.get(a).toString()
		    + "\"");
	    entropyValues.calculateValuesA(a);
	    pw.println("             H_A "
		    + Main.decimalUpToSixPrecision.format(entropyValues.h_a));
	    pw.println("             H_A_C "
		    + Main.decimalUpToSixPrecision.format(entropyValues.h_a_c));
	    pw.println("             I_A_C "
		    + Main.decimalUpToSixPrecision.format(entropyValues.i_a_c));
	    pw.println("            ]");
	}
	int edgeId = 1;
	for (int a = 1; a < entropy.length; ++a) {
	    for (int b = 0; b < a; ++b) {
		pw.println("       edge [");
		pw.println("             id " + (edgeId++));
		pw.println("             label \""
			+ attrNames.get(b).toString() + "-"
			+ attrNames.get(a).toString() + "\"");
		pw.println("             source " + (b + 1));
		pw.println("             target " + (a + 1));
		entropyValues.calculateValues(a, b);
		pw.println("             H_AB "
			+ Main.decimalUpToSixPrecision
				.format(entropyValues.h_ab));
		pw.println("             H_AB_C "
			+ Main.decimalUpToSixPrecision
				.format(entropyValues.h_ab_c));
		pw.println("             I_A_B "
			+ Main.decimalUpToSixPrecision
				.format(entropyValues.i_a_b));
		pw.println("             IG_AB_C "
			+ Main.decimalUpToSixPrecision
				.format(entropyValues.ig_a_b_c));
		pw.println("             I_AB_C "
			+ Main.decimalUpToSixPrecision
				.format(entropyValues.i_ab_c));
		pw.println("            ]");
	    }
	}
	pw.println("      ]");

    }

    /**
     * http://graphml.graphdrawing.org/primer/graphml-primer.html
     * 
     * @param pw
     */
    public void writeGraphML(final PrintWriter pw) {
	pw.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
		+ "<graphml xmlns=\"http://graphml.graphdrawing.org/xmlns\"  \n"
		+ "      xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\n"
		+ "      xsi:schemaLocation=\"http://graphml.graphdrawing.org/xmlns \n"
		+ "        http://graphml.graphdrawing.org/xmlns/1.0/graphml.xsd\">");
	pw.println("  <key id=\"H_A\" for=\"node\" attr.name=\""
		+ EntropyAnalysis.H_A + "\" attr.type=\"double\"/>");
	pw.println("  <key id=\"H_A_C\" for=\"node\" attr.name=\""
		+ EntropyAnalysis.H_A_C + "\" attr.type=\"double\"/>");
	pw.println("  <key id=\"H_A\" for=\"node\" attr.name=\""
		+ EntropyAnalysis.H_A + "\" attr.type=\"double\"/>");
	pw.println("  <key id=\"I_A_C\" for=\"node\" attr.name=\""
		+ EntropyAnalysis.I_A_C + "\" attr.type=\"double\"/>");

	pw.println("  <key id=\"H_AB\" for=\"edge\" attr.name=\""
		+ EntropyAnalysis.H_AB + "\" attr.type=\"double\"/>");
	pw.println("  <key id=\"H_AB_C\" for=\"edge\" attr.name=\""
		+ EntropyAnalysis.H_AB_C + "\" attr.type=\"double\"/>");
	pw.println("  <key id=\"I_A_B\" for=\"edge\" attr.name=\""
		+ EntropyAnalysis.I_A_B + "\" attr.type=\"double\"/>");
	pw.println("  <key id=\"IG_AB_C\" for=\"edge\" attr.name=\""
		+ EntropyAnalysis.IG_AB_C + "\" attr.type=\"double\"/>");
	pw.println("  <key id=\"I_AB_C\" for=\"edge\" attr.name=\""
		+ EntropyAnalysis.I_AB_C + "\" attr.type=\"double\"/>");

	pw.println("  <graph id=\"MDR_GRAPH\" edgedefault=\"undirected\">");
	pw.println("    <desc>dataset: '" + Frame.getFrame().getDatasetName()
		+ "' network type: " + networkDataType.getDisplayString()
		+ "</desc>");

	for (int a = 0; a < entropy.length; ++a) {
	    pw.println("    <node id=\"" + attrNames.get(a).toString() + "\">");
	    entropyValues.calculateValuesA(a);
	    pw.println("      <data key=\"H_A\">"
		    + Main.decimalUpToSixPrecision.format(entropyValues.h_a)
		    + "</data>");
	    pw.println("      <data key=\"H_A_C\">"
		    + Main.decimalUpToSixPrecision.format(entropyValues.h_a_c)
		    + "</data>");
	    pw.println("      <data key=\"I_A_C\">"
		    + Main.decimalUpToSixPrecision.format(entropyValues.i_a_c)
		    + "</data>");
	    pw.println("    </node>");
	}
	for (int a = 1; a < entropy.length; ++a) {
	    for (int b = 0; b < a; ++b) {
		pw.println("    <edge id=\"" + attrNames.get(b).toString()
			+ "-" + attrNames.get(a).toString() + "\" source=\""
			+ attrNames.get(b).toString() + "\" target=\""
			+ attrNames.get(a).toString() + "\">");
		entropyValues.calculateValues(a, b);
		pw.println("      <data key=\"H_AB\">"
			+ Main.decimalUpToSixPrecision
				.format(entropyValues.h_ab) + "</data>");
		pw.println("      <data key=\"H_AB_C\">"
			+ Main.decimalUpToSixPrecision
				.format(entropyValues.h_ab_c) + "</data>");
		pw.println("      <data key=\"I_A_B\">"
			+ Main.decimalUpToSixPrecision
				.format(entropyValues.i_a_b) + "</data>");
		pw.println("      <data key=\"IG_AB_C\">"
			+ Main.decimalUpToSixPrecision
				.format(entropyValues.ig_a_b_c) + "</data>");
		pw.println("      <data key=\"I_AB_C\">"
			+ Main.decimalUpToSixPrecision
				.format(entropyValues.i_ab_c) + "</data>");
		pw.println("    </edge>");
	    }
	}
	pw.println("  </graph>");
	pw.println("</graphml>");
    }

    public void writeXGMML(final PrintWriter pw) {
	pw.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
	pw.println("  <graph label=\""
		+ Frame.getFrame().getDatasetName()
		+ " network type: "
		+ networkDataType.getDisplayString()
		+ "\" directed=\"0\"\n"
		+ "    xmlns:dc=\"http://purl.org/dc/elements/1.1/\" \n"
		+ "    xmlns:xlink=\"http://www.w3.org/1999/xlink\" \n"
		+ "    xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\" \n"
		+ "    xmlns:cy=\"http://www.cytoscape.org\" \n"
		+ "    xmlns=\"http://www.cs.rpi.edu/XGMML\" >");
	for (int a = 0; a < entropy.length; ++a) {
	    entropyValues.calculateValuesA(a);
	    pw.println("    <node id=\"" + a + "\" label=\""
		    + attrNames.get(a).toString() + "\" weight=\""
		    + Main.decimalUpToSixPrecision.format(entropyValues.i_a_c)
		    + "\" >");
	    pw.println("        <att type=\"real\" name=\"H_A\" value=\""
		    + Main.decimalUpToSixPrecision.format(entropyValues.h_a)
		    + "\"/>");
	    pw.println("        <att type=\"real\" name=\"H_A_C\" value=\""
		    + Main.decimalUpToSixPrecision.format(entropyValues.h_a_c)
		    + "\"/>");
	    pw.println("        <att type=\"real\" name=\"I_A_C\" value=\""
		    + Main.decimalUpToSixPrecision.format(entropyValues.i_a_c)
		    + "\"/>");
	    pw.println("    </node>");
	}
	int edgeCtr = 0;
	for (int a = 1; a < entropy.length; ++a) {
	    for (int b = 0; b < a; ++b) {
		entropyValues.calculateValues(a, b);
		pw.println("    <edge id=\""
			+ (edgeCtr++)
			+ "\" label=\""
			+ attrNames.get(b).toString()
			+ "-"
			+ attrNames.get(a).toString()
			+ "\" source=\""
			+ b
			+ "\" target=\""
			+ a
			+ "\" weight=\""
			+ Main.decimalUpToSixPrecision
				.format(entropyValues.ig_a_b_c) + "\" >");
		pw.println("        <att type=\"real\" name=\"H_AB\" value=\""
			+ Main.decimalUpToSixPrecision
				.format(entropyValues.h_ab) + "\"/>");
		pw.println("        <att type=\"real\" name=\"H_AB_C\" value=\""
			+ Main.decimalUpToSixPrecision
				.format(entropyValues.h_ab_c) + "\"/>");
		pw.println("        <att type=\"real\" name=\"I_A_B\" value=\""
			+ Main.decimalUpToSixPrecision
				.format(entropyValues.i_a_b) + "\"/>");
		pw.println("        <att type=\"real\" name=\"IG_AB_C\" value=\""
			+ Main.decimalUpToSixPrecision
				.format(entropyValues.ig_a_b_c) + "\"/>");
		pw.println("        <att type=\"real\" name=\"I_AB_C\" value=\""
			+ Main.decimalUpToSixPrecision
				.format(entropyValues.i_ab_c) + "\"/>");
		pw.println("    </edge>");
	    }
	}
	pw.println("</graph>");
    }

    /**
     * Small utility class so that code to calculate these values was not
     * duplicated
     * 
     * @author pandrews
     */
    public class EntropyValuesCalculator {
	public double h_a;
	public double h_b;
	// public double h_c;
	public double h_ab;
	public double h_ab_c;
	public double i_a_b;
	public double h_a_c;
	public double h_b_c;
	public double ig_a_b_c;
	public double i_a_c;
	public double i_b_c;
	public double i_ab_c;

	private EntropyValuesCalculator() {
	}

	public EntropyValuesCalculator calculateValues(final int a, final int b) {
	    calculateValuesA(a);
	    calculateValuesB(b);
	    h_ab = entropy[a][b];
	    h_ab_c = cond_entropy[a][b];
	    i_a_b = (h_a + h_b) - h_ab;

	    i_ab_c = h_ab - h_ab_c;
	    ig_a_b_c = i_ab_c - i_a_c - i_b_c;

	    /**
	     * alternatively ig_a_b_c = (h_a_c + h_b_c) - h_ab_c - i_a_b; i_ab_c
	     * = ig_a_b_c + i_a_c + i_b_c;
	     */
	    return this; // make it easy to do chaining
	}

	public EntropyValuesCalculator calculateValuesA(final int a) {
	    // if (a >= entropy.length) {
	    // System.err.println("calculateValuesA(" + a
	    // + ") Bad array index because size() is: " + size());
	    // }
	    // h_c = class_entropy;
	    h_a = entropy[a][a];
	    h_a_c = cond_entropy[a][a];
	    i_a_c = h_a - h_a_c; // class_cond_entropy[a];
	    return this; // make it easy to do chaining
	}

	public EntropyValuesCalculator calculateValuesB(final int b) {
	    h_b = entropy[b][b];
	    h_b_c = cond_entropy[b][b];
	    i_b_c = h_b - h_b_c; // class_cond_entropy[b];
	    return this; // make it easy to do chaining
	}
    } // end class EntropyValues

    public enum NetworkDataType {
	MDR_ATTRIBUTE(
		"Nodes: cartesian product entropy; Edges: MDR constructed attribute entropy"), CARTESIAN_PRODUCT(
		"Nodes and Edges: cartesian product entropy"); // BALANCED_ACCURACY("Balanced accuracy")
	private final String displayName;

	NetworkDataType() {
	    this(null);
	}

	NetworkDataType(final String displayName) {
	    if (displayName == null) {
		this.displayName = name(); // OPTIONAL -- if displayName is null
					   // programmatically create a display
					   // name
	    } else {
		this.displayName = displayName;
	    }
	}

	public String getDisplayString() {
	    return displayName;
	}
    } // end enum NetworkDataTypes
} // end class EntropyAnalysis
