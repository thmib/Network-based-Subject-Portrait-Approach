package org.epistasis.mdr.gui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.filechooser.FileFilter;

import org.epistasis.FileSaver;
import org.epistasis.FileSaver.ExtensionFilter;
import org.epistasis.Pair;
import org.epistasis.Utility;
import org.epistasis.gui.CmdMaximizeActionListener;
import org.epistasis.mdr.AmbiguousCellStatus;
import org.epistasis.mdr.Main;
import org.epistasis.mdr.entropy.EntropyAnalysis;
import org.epistasis.mdr.gui.InteractionGraph.JungLayoutType;
import org.epistasis.mdr.networkEntropy.NetworkGraph;
import org.epistasis.mdr.newengine.AttributeCombination;
import org.epistasis.mdr.newengine.Collector;
import org.epistasis.mdr.newengine.Dataset;

@SuppressWarnings("serial")
public class EntropyPanel extends JPanel implements PropertyChangeListener {
    JPanel pnlEntropyDisplayCommonControls = new JPanel(new GridBagLayout());
    private final EntropyAnalysis entropyAnalysis;
    private final Dendrogram pnlDendrogram;
    private final InteractionGraph pnlInteractionGraph;
    private final int defaultMinimumEntropyPercentage;

    private boolean initializedSliderToPercentage = false;
    JButton cmdSaveEntropy = new JButton();
    JLabel lblEntropyGraphLineThickness = new JLabel();
    JSpinner spnEntropyGraphLineThickness = new JSpinner();
    JLabel lblEntropyGraphTextSize = new JLabel();
    JSpinner spnEntropyGraphTextSize = new JSpinner();
    JButton cmdResetEntropyGraph = new JButton();
    JButton cmdMaximizeEntropy = new JButton();
    // Panel contains a card layout so that only one
    // component is visible at a time. Override
    // getPreferredSize to getPreferredSize of
    // the currently visible item. This will determine whether
    // scroll bars are shown
    JPanel pnlEntropyDisplay = new JPanel(new BorderLayout());
    // {
    // @Override
    // public Dimension getPreferredSize() {
    // Dimension returnDimension = null;
    // for (final Component component : getComponents()) {
    // final boolean isVisible = component.isVisible();
    // if (isVisible) {
    // returnDimension = component.getPreferredSize();
    // break;
    // }
    // }
    // return returnDimension;
    // }
    // };
    JTextArea txaRawEntropyValues = new JTextArea();
    JScrollPane scrollPaneRawText = new JScrollPane();
    JPanel pnlEntropyGraphControls = new JPanel(new GridBagLayout());
    JPanel pnlEntropyDisplaySpecificControls = new JPanel(new GridBagLayout());
    JPanel pnlRawEntropyValuesControls = new JPanel(new GridBagLayout());
    JComboBox cboEntropy = new JComboBox(new DefaultComboBoxModel(
	    DisplayType.values()));
    private final int defaultLineThickness;
    private final int defaultTextSize;
    private final PercentageSliderWithSpinnerAndText pnlPercentageSlider = new PercentageSliderWithSpinnerAndText();
    private int defaultEntropyListIndex;
    private final JComponent maximizeEnclosingComponent;

    public EntropyPanel() {
	this(new EntropyAnalysis(), Main.defaultEntropyGraphLineThickness,
		Main.defaultEntropyGraphTextSize, 100, DisplayType.DENDROGRAM,
		(JComponent) null /* pMaximizeEnclosingComponent */);
    }

    public EntropyPanel(final EntropyAnalysis entropyAnalysis,
	    final int defaultLineThickness, final int defaultTextSize,
	    final int defaultMinimumEntropyPercentage,
	    final DisplayType initialDisplayType,
	    final JComponent pMaximizeEnclosingComponent) {
	maximizeEnclosingComponent = (pMaximizeEnclosingComponent == null) ? this
		: pMaximizeEnclosingComponent;
	this.entropyAnalysis = entropyAnalysis;
	this.defaultLineThickness = defaultLineThickness;
	this.defaultTextSize = defaultTextSize;
	this.defaultMinimumEntropyPercentage = defaultMinimumEntropyPercentage;
	pnlDendrogram = new Dendrogram(entropyAnalysis);
	pnlInteractionGraph = new InteractionGraph(
		Main.decimalUpToFourPrecision, 5, entropyAnalysis,
		InteractionGraph.JungLayoutType.FRUCHTERMAN_RHEINGOLD);
	scrollPaneRawText.setViewportView(txaRawEntropyValues);
	init();
	cboEntropy.setSelectedItem(initialDisplayType);
	pnlPercentageSlider.addPropertyChangeListener(this);
	final GridBagConstraints gbc_pnlPercentageSlider = new GridBagConstraints();
	gbc_pnlPercentageSlider.gridwidth = 4;
	gbc_pnlPercentageSlider.fill = GridBagConstraints.HORIZONTAL;
	gbc_pnlPercentageSlider.gridx = 0;
	gbc_pnlPercentageSlider.gridy = 0;
	pnlEntropyDisplayCommonControls.add(pnlPercentageSlider,
		gbc_pnlPercentageSlider);
	pnlEntropyDisplayCommonControls.add(cmdMaximizeEntropy,
		new GridBagConstraints(2, 1, 1, 1, 1.0, 0.0,
			GridBagConstraints.NORTHEAST, GridBagConstraints.NONE,
			new Insets(5, 5, 0, 5), 0, 0));
	pnlEntropyDisplayCommonControls.add(cmdSaveEntropy,
		new GridBagConstraints(3, 1, 1, 1, 0.0, 0.0,
			GridBagConstraints.NORTHEAST, GridBagConstraints.NONE,
			new Insets(5, 5, 0, 0), 0, 0));
	pnlEntropyDisplayCommonControls.add(cboEntropy, new GridBagConstraints(
		0, 1, 1, 1, 0.0, 0.0, GridBagConstraints.NORTHWEST,
		GridBagConstraints.NONE, new Insets(5, 5, 0, 5), 0, 0));
	pnlEntropyDisplayCommonControls.add(pnlEntropyDisplaySpecificControls,
		new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0,
			GridBagConstraints.NORTH, GridBagConstraints.NONE,
			new Insets(5, 5, 0, 5), 0, 0));
	pnlEntropyGraphControls.add(lblEntropyGraphLineThickness,
		new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0,
			GridBagConstraints.WEST, GridBagConstraints.NONE,
			new Insets(0, 0, 0, 0), 0, 0));
	pnlEntropyGraphControls.add(spnEntropyGraphLineThickness,
		new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0,
			GridBagConstraints.CENTER, GridBagConstraints.BOTH,
			new Insets(0, 5, 0, 0), 0, 0));
	pnlEntropyGraphControls.add(lblEntropyGraphTextSize,
		new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0,
			GridBagConstraints.WEST, GridBagConstraints.NONE,
			new Insets(0, 5, 0, 0), 0, 0));
	pnlEntropyGraphControls.add(spnEntropyGraphTextSize,
		new GridBagConstraints(3, 0, 1, 1, 0.0, 0.0,
			GridBagConstraints.CENTER, GridBagConstraints.BOTH,
			new Insets(0, 5, 0, 0), 0, 0));
	pnlEntropyGraphControls.add(cmdResetEntropyGraph,
		new GridBagConstraints(6, 0, 1, 1, 0.0, 0.0,
			GridBagConstraints.CENTER, GridBagConstraints.NONE,
			new Insets(0, 5, 0, 0), 0, 0));
	final GridBagConstraints gbc_pnlEntropyDisplayCommonControls = new GridBagConstraints();
	gbc_pnlEntropyDisplayCommonControls.anchor = GridBagConstraints.SOUTH;
	gbc_pnlEntropyDisplayCommonControls.fill = GridBagConstraints.HORIZONTAL;
	gbc_pnlEntropyDisplayCommonControls.gridx = 0;
	gbc_pnlEntropyDisplayCommonControls.gridy = 1;
	add(pnlEntropyDisplayCommonControls,
		gbc_pnlEntropyDisplayCommonControls);
	lockdown(true);
    }

    public void focusOnSlider() {
	pnlPercentageSlider.focusOnSlider();
    }

    public EntropyAnalysis getEntropyAnalysis() {
	return entropyAnalysis;
    }

    public Component getEntropyPanelDisplay(final DisplayType displayType) {
	Component returnComponent = null;
	switch (displayType) {
	case DENDROGRAM:
	    returnComponent = pnlDendrogram;
	    break;
	case RAW_ENTROPY_VALUES:
	    returnComponent = scrollPaneRawText;
	    break;
	default:
	    returnComponent = pnlInteractionGraph;
	    break;
	} // end switch
	return returnComponent;
    } // end getEntropyPanelDisplay

    private Component getEntropyPanelSpecificControls(
	    final DisplayType displayType) {
	Component returnComponent = null;
	switch (displayType) {
	case RAW_ENTROPY_VALUES:
	    returnComponent = pnlRawEntropyValuesControls;
	    break;
	default:
	    returnComponent = pnlEntropyGraphControls;
	    break;
	} // end switch
	return returnComponent;
    } // end getEntropyPanelSpecificControls

    public JPanel getPnlEntropyDisplay() {
	return pnlEntropyDisplay;
    }

    public JPanel getPnlEntropyDisplayCommonControls() {
	return pnlEntropyDisplayCommonControls;
    }

    public InteractionGraph getPnlInteractionGraph() {
	return pnlInteractionGraph;
    }

    public PercentageSliderWithSpinnerAndText getPnlPercentageSlider() {
	return pnlPercentageSlider;
    }

    public void init() {
	cmdSaveEntropy.setText("Save");
	cmdSaveEntropy.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		final DisplayType displayType = (DisplayType) cboEntropy
			.getSelectedItem();
		final Component component = getEntropyPanelDisplay(displayType);
		List<ExtensionFilter> fileFilters;

		switch (displayType) {
		case CIRCLE_GRAPH:
		case DENDROGRAM:
		case FRUCHTERMAN_RHEINGOLD:
		case KAMADA_KAWAI:
		case SELF_ORGANIZING_MAP:
		    fileFilters = FileSaver.filtersNetworkDataTypesGraphicalAndText;
		    break;
		case RAW_ENTROPY_VALUES:
		    fileFilters = FileSaver.filtersNetworkDataTypesText;
		    break;
		default:
		    throw new RuntimeException("Unhanded DisplayType: "
			    + displayType);
		    // break;
		} // end switch
		final Pair<File, FileFilter> ff = FileSaver.getSaveFile(
			"Save Entropy Graph",
			FileSaver.FileSuffixBeforeExtension._entropy_graph,
			fileFilters);
		if (ff == null) {
		    return;
		}
		try {
		    final File fileToWrite = ff.getFirst();
		    final String fileNameToWrite = fileToWrite.getName();
		    final int extensionPos = fileNameToWrite.lastIndexOf('.');
		    String extension = "";
		    if (extensionPos >= 0) {
			extension = fileNameToWrite.substring(extensionPos + 1);
		    }
		    if (FileSaver.ExtensionFilter.gmlFilter.getExtension()
			    .equals(extension)) {
			final PrintWriter pw = new PrintWriter(fileToWrite);
			entropyAnalysis.writeGML(pw);
			pw.close();
		    } else if (FileSaver.ExtensionFilter.xgmmlFilter
			    .getExtension().equals(extension)) {
			final PrintWriter pw = new PrintWriter(fileToWrite);
			entropyAnalysis.writeXGMML(pw);
			pw.close();
		    } else if (FileSaver.ExtensionFilter.graphMlFilter
			    .getExtension().equals(extension)) {
			final PrintWriter pw = new PrintWriter(fileToWrite);
			entropyAnalysis.writeGraphML(pw);
			pw.close();
		    } else if (FileSaver.ExtensionFilter.gdfFilter
			    .getExtension().equals(extension)) {
			final PrintWriter pw = new PrintWriter(fileToWrite);
			entropyAnalysis.writeGDF(pw);
			pw.close();
		    } else if (FileSaver.ExtensionFilter.gexfFilter
			    .getExtension().equals(extension)) {
			final PrintWriter pw = new PrintWriter(fileToWrite);
			entropyAnalysis.writeGEXF(pw);
			pw.close();
		    } else if (FileSaver.ExtensionFilter.epsFilter
			    .getExtension().equals(extension)) {
			final EntropyDisplay entropyDisplay = (EntropyDisplay) component;
			final Writer w = new FileWriter(fileToWrite);
			w.write(entropyDisplay.getEPSText());
			w.flush();
			w.close();
		    } else if (FileSaver.ExtensionFilter.jpgFilter
			    .getExtension().equals(extension)) {
			final EntropyDisplay entropyDisplay = (EntropyDisplay) component;
			ImageIO.write(entropyDisplay.getImage(), "jpeg",
				fileToWrite);
		    } else if (FileSaver.ExtensionFilter.pngFilter
			    .getExtension().equals(extension)) {
			final EntropyDisplay entropyDisplay = (EntropyDisplay) component;
			ImageIO.write(entropyDisplay.getImage(), "png",
				fileToWrite);
		    } else if (FileSaver.ExtensionFilter.txtFilter
			    .getExtension().equals(extension)) {
			FileSaver.saveText(txaRawEntropyValues.getText(),
				fileToWrite);

		    } else {
			JOptionPane.showMessageDialog(
				EntropyPanel.this.getParent(),
				"Unrecognized file extension so do not know what type of file to save",
				"Unknown save file type",
				JOptionPane.PLAIN_MESSAGE);
		    }
		} catch (final IOException ex) {
		    Utility.logException(ex);
		    JOptionPane.showMessageDialog(
			    EntropyPanel.this.getParent(), ex.getMessage(),
			    "I/O Error", JOptionPane.ERROR_MESSAGE);
		}
	    } // end actionPerformed()
	} // end actionListener
	);
	cmdSaveEntropy.setFont(Frame.font);
	pnlDendrogram.setMargin(5);
	lblEntropyGraphLineThickness
		.setText("<html><align='right'>Line<br>size:</align></html>");
	lblEntropyGraphLineThickness.setFont(Frame.font);
	lblEntropyGraphTextSize
		.setText("<html><align='right'>Text<br>size:</align></html>");
	lblEntropyGraphTextSize.setFont(Frame.font);
	spnEntropyGraphLineThickness.setMinimumSize(new Dimension(40, 20));
	spnEntropyGraphLineThickness.setPreferredSize(new Dimension(40, 20));
	spnEntropyGraphLineThickness.setModel(new SpinnerNumberModel(
		new Integer(defaultLineThickness), new Integer(1), new Integer(
			1000), new Integer(1)));
	spnEntropyGraphLineThickness.setFont(Frame.font);
	spnEntropyGraphLineThickness.addChangeListener(new ChangeListener() {
	    @Override
	    public void stateChanged(final ChangeEvent e) {
		cmdResetEntropyGraph.setEnabled(!isDefaultEntropyGraph());
		final int lineThickness = ((Number) spnEntropyGraphLineThickness
			.getValue()).intValue();
		pnlDendrogram.setLineThickness(lineThickness);
		pnlInteractionGraph.setLineThickness(lineThickness);
	    }
	});
	// force initial setting of line thickness
	spnEntropyGraphLineThickness.getChangeListeners()[0]
		.stateChanged(new ChangeEvent(this));
	spnEntropyGraphTextSize.setMinimumSize(new Dimension(40, 20));
	spnEntropyGraphTextSize.setPreferredSize(new Dimension(40, 20));
	spnEntropyGraphTextSize.setModel(new SpinnerNumberModel(new Integer(
		defaultTextSize), new Integer(1), new Integer(1000),
		new Integer(1)));
	spnEntropyGraphTextSize.setFont(Frame.font);
	spnEntropyGraphTextSize.addChangeListener(new ChangeListener() {
	    @Override
	    public void stateChanged(final ChangeEvent e) {
		cmdResetEntropyGraph.setEnabled(!isDefaultEntropyGraph());
		final int fontSize = ((Number) spnEntropyGraphTextSize
			.getValue()).intValue();
		pnlDendrogram.setFontSize(fontSize);
		pnlInteractionGraph.setFontSize(fontSize);
	    }
	});
	// force initial setting of font size
	spnEntropyGraphTextSize.getChangeListeners()[0]
		.stateChanged(new ChangeEvent(this));
	cmdResetEntropyGraph.setText("Reset");
	cmdResetEntropyGraph.setFont(Frame.font);
	cmdResetEntropyGraph.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		spnEntropyGraphLineThickness.setValue(new Integer(
			defaultLineThickness));
		spnEntropyGraphTextSize.setValue(new Integer(defaultTextSize));
		pnlPercentageSlider
			.setSliderPercentage(defaultMinimumEntropyPercentage);
	    }
	});
	cmdMaximizeEntropy.setText("Maximize");
	cmdMaximizeEntropy.setFont(Frame.font);
	cmdMaximizeEntropy.addActionListener(new CmdMaximizeActionListener(
		maximizeEnclosingComponent, cmdMaximizeEntropy));
	txaRawEntropyValues.setEditable(false);
	txaRawEntropyValues.setTabSize(20);
	txaRawEntropyValues.setFont(Frame.fontFixed);
	cboEntropy.addItemListener(new ItemListener() {
	    @Override
	    public void itemStateChanged(final ItemEvent e) {
		if (e.getStateChange() == ItemEvent.SELECTED) {
		    final DisplayType displayType = (DisplayType) cboEntropy
			    .getSelectedItem();
		    updateSelection(displayType);
		}
	    }
	});
	// force initial setting of entropy display
	cboEntropy.getItemListeners()[0].itemStateChanged(new ItemEvent(
		cboEntropy, 0, null, ItemEvent.SELECTED));
	cboEntropy.setFont(Frame.font);
	cboEntropy.setEditable(false);
	final GridBagLayout gridBagLayout = new GridBagLayout();
	gridBagLayout.columnWeights = new double[] { 1.0 };
	gridBagLayout.rowWeights = new double[] { 1.0, 0.0 };
	setLayout(gridBagLayout);
	pnlEntropyDisplay.setBorder(BorderFactory.createLoweredBevelBorder());
	final GridBagConstraints gbc_pnlEntropyDisplay = new GridBagConstraints();
	gbc_pnlEntropyDisplay.fill = GridBagConstraints.BOTH;
	gbc_pnlEntropyDisplay.insets = new Insets(0, 0, 5, 0);
	gbc_pnlEntropyDisplay.gridx = 0;
	gbc_pnlEntropyDisplay.gridy = 0;
	add(pnlEntropyDisplay, gbc_pnlEntropyDisplay);
	pnlEntropyDisplaySpecificControls.add(pnlEntropyGraphControls);
	initDataBindings();
    }

    protected void initDataBindings() {
    }

    private boolean isDefaultEntropyGraph() {
	boolean returnValue = (((Number) spnEntropyGraphLineThickness
		.getValue()).intValue() == defaultLineThickness)
		&& (((Number) spnEntropyGraphTextSize.getValue()).intValue() == defaultTextSize);
	if (returnValue) {
	    final Component component = getEntropyPanelDisplay((DisplayType) cboEntropy
		    .getSelectedItem());
	    if (component == pnlInteractionGraph) {
		returnValue = pnlPercentageSlider.getSliderValue() == defaultEntropyListIndex;
	    }
	}
	return returnValue;
    }

    public void lockdown(final boolean lock) {
	lblEntropyGraphLineThickness.setEnabled(!lock);
	spnEntropyGraphLineThickness.setEnabled(!lock);
	lblEntropyGraphTextSize.setEnabled(!lock);
	spnEntropyGraphTextSize.setEnabled(!lock);
	pnlPercentageSlider.setEnabled(!lock);
	cmdSaveEntropy.setEnabled(!lock);
	cboEntropy.setEnabled(!lock);
	if (lock) {
	    cmdResetEntropyGraph.setEnabled(false);
	} else {
	    cmdResetEntropyGraph.setEnabled(!isDefaultEntropyGraph());
	}
    }

    public void pnlEntropy_clearTabs() {
	entropyAnalysis.clear();
	final Component component = getEntropyPanelDisplay(DisplayType
		.lookup(cboEntropy.getSelectedItem().toString()));
	if (component instanceof EntropyDisplay) {
	    final EntropyDisplay entropyDisplay = (EntropyDisplay) component;
	    entropyDisplay.updateGraph();
	}
	txaRawEntropyValues.setText("");
	lockdown(true);
    }

    @Override
    public void propertyChange(final PropertyChangeEvent evt) {
	final String propertyName = evt.getPropertyName();
	// System.out.println("EntropyPanel received property change evt: "
	// + evt.getPropertyName() + " changing from " + evt.getOldValue()
	// + " to " + evt.getNewValue());
	if (propertyName
		.startsWith("Edge_PercentageSliderWithSpinnerAndText_value")) {
	    pnlInteractionGraph.setEdgeVisibility((Double) evt.getNewValue(),
		    propertyName.endsWith("_while_adjusting"));
	    cmdResetEntropyGraph.setEnabled(!isDefaultEntropyGraph());
	    firePropertyChange("EntropyPanel_" + evt.getPropertyName(),
		    evt.getOldValue(), evt.getNewValue());
	} else if (propertyName
		.startsWith("Node_PercentageSliderWithSpinnerAndText_value")) {
	    pnlInteractionGraph.setNodeVisibilityThreshold(
		    (Double) evt.getNewValue(),
		    propertyName.endsWith("_while_adjusting"));
	    cmdResetEntropyGraph.setEnabled(!isDefaultEntropyGraph());
	    firePropertyChange("EntropyPanel_" + evt.getPropertyName(),
		    evt.getOldValue(), evt.getNewValue());
	}
    }

    public void setPercentageSliderSpinnerPanelEnabled(final boolean enabled) {
	final boolean isCurrentlyEnabled = pnlPercentageSlider.isEnabled();
	pnlPercentageSlider.setEnabled(enabled);
	// System.out.println("setPercentageSliderSpinnerPanelEnabled(" +
	// enabled
	// + ") when pnlPercentageSlider.isEnabled() = "
	// + pnlPercentageSlider.isEnabled());
	if (!isCurrentlyEnabled && enabled) {
	    focusOnSlider();
	}
    }

    public void updateEntropyDisplay(final Dataset pData,
	    final List<Collector> modelFilter, final int min, final int max,
	    final AmbiguousCellStatus tiePriority) {
	// entropy display does not care what the actual combinations were,
	// only what attributes were involved so need to get unique list of
	// attributes
	// in the summary table's best models
	final Set<Integer> attributeIndicesSet = new TreeSet<Integer>();
	for (int i = min; i <= max; ++i) {
	    final AttributeCombination combo = modelFilter.get(i - min)
		    .getBestModel().getModel().getCombo();
	    if (combo.size() > 1) {
		for (int j = 0; j < combo.size(); ++j) {
		    attributeIndicesSet.add(combo.get(j));
		}
	    } else {
		attributeIndicesSet.add(combo.get(0));
	    }
	}
	final List<Integer> attributeIndicesList = new ArrayList<Integer>(
		attributeIndicesSet);
	if (attributeIndicesList.size() > 1) {
	    entropyAnalysis.setTiePriority(tiePriority);
	    entropyAnalysis
		    .set(attributeIndicesList, pData,
			    null /* progressPanelUpdater */,
			    true /* waitForCalculationToComplete */, true /* calculateAllEntropyMetrics */);
	} else {
	    entropyAnalysis.clear();
	}
	updateEntropyDisplay(null /* networkGraph */);
    }

    public void updateEntropyDisplay(NetworkGraph networkGraph) {
	lockdown(!entropyAnalysis.hasData() /* lock */);
	if (entropyAnalysis.hasData()) {
	    txaRawEntropyValues.setText(entropyAnalysis.getEntropyText(
		    Main.decimalUpToFourPrecision, true /* useTabs */));
	    txaRawEntropyValues.select(0, 0);
	    // final SortedSet<Double> sortedSet = entropyAnalysis
	    // .getEdgeThresholdList();
	    // final Double[] spinnerValues = new Double[sortedSet.size()];
	    // sortedSet.toArray(spinnerValues);
	} else {
	    entropyAnalysis.clear();
	    txaRawEntropyValues.setText("");
	}
	pnlDendrogram.updateGraph();
	networkGraph = pnlInteractionGraph.createEntropyGraph(networkGraph);
	if (networkGraph != null) {
	    pnlPercentageSlider
		    .setSpinnerListModel(networkGraph
			    .getEdgeThresholdList(EntropyAnalysis.DEFAULT_DIGITS_OF_PRECISION));
	    final DisplayType displayType = (DisplayType) cboEntropy
		    .getSelectedItem();
	    final JungLayoutType newNetworkType = JungLayoutType
		    .lookup(displayType.toString());
	    pnlInteractionGraph.setJungLayoutType(newNetworkType);

	}
	// final Component component = entropyPanelEntropyDisplay.get(cboEntropy
	// .getSelectedItem().toString());
	// if (component instanceof EntropyDisplay) {
	// final EntropyDisplay entropyDisplay = (EntropyDisplay) component;
	// entropyDisplay.updateGraph();
	// }
	if (!initializedSliderToPercentage) {
	    initializedSliderToPercentage = true;
	    pnlPercentageSlider
		    .setSliderPercentage(defaultMinimumEntropyPercentage);
	    defaultEntropyListIndex = pnlPercentageSlider.getSliderValue();
	}
    }

    public void updateSelection(final DisplayType displayType) {
	pnlEntropyDisplay.removeAll();
	pnlEntropyDisplaySpecificControls.removeAll();
	pnlEntropyDisplaySpecificControls
		.add(getEntropyPanelSpecificControls(displayType));
	final Component component = getEntropyPanelDisplay(displayType);
	component.setBounds(pnlEntropyDisplay.getBounds());
	pnlEntropyDisplay.add(component);
	final JungLayoutType newNetworkType = JungLayoutType.lookup(displayType
		.toString());
	pnlInteractionGraph.setJungLayoutType(newNetworkType);
	pnlPercentageSlider.setVisible(component == pnlInteractionGraph);
	cmdResetEntropyGraph.setEnabled(!isDefaultEntropyGraph());
	invalidate();
	repaint();
    }

    public enum DisplayType {
	DENDROGRAM("Dendogram"), FRUCHTERMAN_RHEINGOLD(
		InteractionGraph.JungLayoutType.FRUCHTERMAN_RHEINGOLD
			.getDisplayName()), CIRCLE_GRAPH(
		InteractionGraph.JungLayoutType.CIRCLE.getDisplayName()), KAMADA_KAWAI(
		InteractionGraph.JungLayoutType.KAMADA_KAWAI.getDisplayName()), SELF_ORGANIZING_MAP(
		InteractionGraph.JungLayoutType.SELF_ORGANIZING_MAP
			.getDisplayName()), RAW_ENTROPY_VALUES("Raw Values");
	private final String displayName;
	private final static Map<String, DisplayType> displayTypeLookupMap = new HashMap<String, DisplayType>();
	static {
	    for (final DisplayType displayType : DisplayType.values()) {
		DisplayType.displayTypeLookupMap.put(displayType.toString(),
			displayType);
	    }
	}

	public static DisplayType lookup(final String pDisplayName) {
	    return DisplayType.displayTypeLookupMap.get(pDisplayName);
	}

	DisplayType(final String pDisplayName) {
	    displayName = pDisplayName;
	}

	@Override
	public String toString() {
	    return displayName;
	}
    } // end enum DisplayType
}
