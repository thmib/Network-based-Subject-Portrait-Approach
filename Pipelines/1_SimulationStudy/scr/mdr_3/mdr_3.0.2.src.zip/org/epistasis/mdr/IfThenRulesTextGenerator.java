package org.epistasis.mdr;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Map;
import java.util.SortedMap;

import org.epistasis.mdr.newengine.Dataset;
import org.epistasis.mdr.newengine.Model;
import org.epistasis.mdr.newengine.Model.Cell;
import org.epistasis.mdr.newengine.ModelInfoInterface;

public class IfThenRulesTextGenerator {
    private final Dataset data;
    private final ModelInfoInterface modelComparisonInfo;

    public IfThenRulesTextGenerator(final Dataset data,
	    final ModelInfoInterface modelComparisonInfo) {
	this.modelComparisonInfo = modelComparisonInfo;
	this.data = data;
    }

    @Override
    public String toString() {
	final StringWriter s = new StringWriter();
	final PrintWriter w = new PrintWriter(s);
	// need to make sure the model is setup to show overall statuses
	final Model model = modelComparisonInfo.getModel();
	final SortedMap<byte[], Cell> cells = model.buildCounts(data);

	model.buildStatuses(data, data.getStatusCounts(), cells);
	model.test(data, cells);
	final int[] attr = model.getCombo().getAttributeIndices();

	for (final Map.Entry<byte[], Model.Cell> cell : cells.entrySet()) {
	    w.print("IF ");
	    final byte[] bytes = cell.getKey();
	    for (int i = 0; i < bytes.length; ++i) {
		if (i != 0) {
		    w.print(" AND ");
		}
		w.print(data.getLabels().get(attr[i]));
		w.print(" = ");
		final byte attributeLevelIndex = bytes[i];
		final String attributeValue = data.getLevels().get(attr[i])
			.get(attributeLevelIndex);
		if (attributeValue == data.getMissing()) {
		    w.print(Main.missingRepresentation);
		}
		w.print(attributeValue);
	    }
	    w.print(" THEN CLASSIFY AS ");
	    final int predictedStatus = cell.getValue().getStatus();
	    if (predictedStatus == Model.UNKNOWN_STATUS) {
		w.print(Main.unknownRepresentation);
	    } else {
		w.print(data.getLevels().get(data.getCols() - 1)
			.get(predictedStatus));
	    }
	    w.print('.');
	    w.println();
	}

	return s.toString();
    }
}
