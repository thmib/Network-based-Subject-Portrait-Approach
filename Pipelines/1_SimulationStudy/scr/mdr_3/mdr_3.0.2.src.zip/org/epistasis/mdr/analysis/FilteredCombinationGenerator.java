package org.epistasis.mdr.analysis;

public class FilteredCombinationGenerator {

}
