package org.epistasis.mdr.analysis;

import java.util.List;

import org.epistasis.mdr.newengine.AttributeCombination;

public class FixedRandomCombinationGenerator extends RandomCombinationGenerator {
    private final long maxEval;
    private long nEval;

    public FixedRandomCombinationGenerator(final List<String> labels,
	    final int attrCount, final long seed, final long maxEval) {
	super(labels, attrCount, seed);
	this.maxEval = maxEval;
	nEval = 0;
    }

    @Override
    public boolean hasNext() {
	return nEval <= maxEval;
    }

    @Override
    public AttributeCombination next() {
	final AttributeCombination next = super.next();
	++nEval;
	return next;
    }
}
