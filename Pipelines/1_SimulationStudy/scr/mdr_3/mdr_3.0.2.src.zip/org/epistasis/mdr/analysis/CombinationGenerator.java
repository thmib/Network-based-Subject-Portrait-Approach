package org.epistasis.mdr.analysis;

import java.util.Iterator;
import java.util.List;

import org.epistasis.Utility;
import org.epistasis.mdr.Main;
import org.epistasis.mdr.newengine.AttributeCombination;

/***
 * Specific to MDR used to generate combinations. Heavy lifting of the actual
 * generation is do in CombinadicGenetator
 * 
 * @author pandrews
 * 
 */
public class CombinationGenerator implements Iterator<AttributeCombination>,
	Iterable<AttributeCombination> {
    private final List<String> labels;
    private final static int[] EMPTY_INT_ARRAY = new int[0];
    private final CombinadicGenerator combination;
    private final AttributeCombination forced;
    private final int[] forcedAttributeIndices;
    private final Iterator<int[]> combinationIterator;
    private final int[] attributeIndicesToCombine;

    public CombinationGenerator(final int numAttributes, int comboSize,
	    final List<String> labels, final int[] restrictedSearchAttributes,
	    final AttributeCombination forced, final int distributedNodeCount,
	    final int distributedNodeNumber) {
	this.labels = labels;

	this.forced = forced;
	if (this.forced == null) {
	    forcedAttributeIndices = CombinationGenerator.EMPTY_INT_ARRAY;
	} else {
	    forcedAttributeIndices = forced.getAttributeIndices();
	    comboSize = forced.getMax() - forced.getMin();
	}
	int numAttributesBeingCombined;
	if (restrictedSearchAttributes != null) {
	    numAttributesBeingCombined = restrictedSearchAttributes.length
		    - forcedAttributeIndices.length;
	    attributeIndicesToCombine = new int[numAttributesBeingCombined];
	    int insertionPosition = 0;
	    for (final int attributeIndexToCombine : restrictedSearchAttributes) {
		insertionPosition = addAttributeToCombine(
			attributeIndexToCombine, insertionPosition,
			attributeIndicesToCombine);
	    } // end loop over restricted attributes
	} else if (forced != null) {
	    numAttributesBeingCombined = numAttributes
		    - forcedAttributeIndices.length;
	    attributeIndicesToCombine = new int[numAttributesBeingCombined];
	    int insertionPosition = 0;
	    for (int attributeIndexToCombine = 0; attributeIndexToCombine < numAttributes; attributeIndexToCombine++) {
		insertionPosition = addAttributeToCombine(
			attributeIndexToCombine, insertionPosition,
			attributeIndicesToCombine);
	    } // for loop over numAttributes
	} // end if neither restricted or forced
	else {
	    numAttributesBeingCombined = numAttributes;
	    attributeIndicesToCombine = null;
	}

	combination = new CombinadicGenerator(numAttributesBeingCombined,
		comboSize);
	if (distributedNodeCount != Main.defaultDistributedNodeCount) {
	    final long numberOfCombinations = combination
		    .getNumberOfCombinations();
	    final long combinationsPerDistributedNode = (long) Math
		    .ceil(numberOfCombinations / (double) distributedNodeCount);

	    long combinadicIndex = combinationsPerDistributedNode
		    * (distributedNodeNumber - 1);
	    if (combinadicIndex >= numberOfCombinations) {
		// sometimes the number of nodes available does not fit neatly
		// into the number of combinations. Imagine 100 nodes with 968
		// attributes. This gives an average of 10 combinations per node
		// but distributed nodes 98, 99, 100 will have nothing to do
		// One solution it to return an iterator that already is
		// !hasNext() but this causes problems because MDR does not deal
		// with with analyses that have zero results.
		// Workaround is to return the very last combination for all
		// excess nodes.
		combinadicIndex = numberOfCombinations - 1;
	    }
	    combinationIterator = combination.iterator(combinadicIndex,
		    combinationsPerDistributedNode);

	} else {
	    combinationIterator = combination.iterator();
	}

    }

    private int addAttributeToCombine(final int attributeIndexToCombine,
	    int insertionIndex, final int[] attributeIndicesToCombine) {
	boolean addAttributeIndex = true;
	// is it forced?
	if (forced != null) {
	    for (final int forcedAttributeIndex : forcedAttributeIndices) {
		if (forcedAttributeIndex == attributeIndexToCombine) {
		    // good -- found one of forced so don't add to array
		    // of
		    // attributes to be combined
		    addAttributeIndex = false;
		    break;
		}
	    }
	    if (insertionIndex == attributeIndicesToCombine.length) {
		throw new IllegalArgumentException(
			"Forced arguments "
				+ forced
				+ " were not all found among the set of attributes being searched.");
	    }
	} // end if forced
	if (addAttributeIndex) {
	    attributeIndicesToCombine[insertionIndex++] = attributeIndexToCombine;
	}
	return insertionIndex;
    }

    @Override
    public boolean hasNext() {
	return combinationIterator.hasNext();
    }

    @Override
    public Iterator<AttributeCombination> iterator() {
	throw new UnsupportedOperationException();
	// return this;
    }

    @Override
    public AttributeCombination next() {

	final int[] combo = combinationIterator.next();
	AttributeCombination ret;
	if (attributeIndicesToCombine != null) {
	    final int[] remappedCombo = new int[combo.length];
	    for (final int index : Utility.range(combo.length)) {
		remappedCombo[index] = attributeIndicesToCombine[combo[index]];
	    }
	    ret = new AttributeCombination(forced, remappedCombo, labels);
	} else {
	    ret = new AttributeCombination(combo, labels);
	}

	return ret;
    }

    @Override
    public void remove() {
	throw new UnsupportedOperationException();
    }
}
