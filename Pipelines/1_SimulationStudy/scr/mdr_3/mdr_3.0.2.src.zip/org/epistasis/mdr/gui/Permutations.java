package org.epistasis.mdr.gui;

import javax.swing.JPanel;

public class Permutations extends JPanel {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public Permutations() {
    }

}
