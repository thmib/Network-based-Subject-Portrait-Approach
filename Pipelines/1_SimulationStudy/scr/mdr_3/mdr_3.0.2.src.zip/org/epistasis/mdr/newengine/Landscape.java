package org.epistasis.mdr.newengine;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.AbstractList;

import org.epistasis.LabeledFloatInterface;

public abstract class Landscape extends AbstractList<LabeledFloatInterface> {
    @SuppressWarnings("unused")
    private static final long serialVersionUID = 1L;

    public abstract LabeledFloatInterface first();

    public abstract LabeledFloatInterface last();

    @Override
    public abstract int size();

    @Override
    public String toString() {
	final StringWriter writer = new StringWriter();
	write(writer);
	return writer.toString();
    }

    public final void write(final Writer w) {
	final PrintWriter p = new PrintWriter(w);
	for (final LabeledFloatInterface pair : this) {
	    p.print(pair.getLabel());
	    p.print('\t');
	    p.println(pair.getFloat());
	}
	p.flush();
    }
}
