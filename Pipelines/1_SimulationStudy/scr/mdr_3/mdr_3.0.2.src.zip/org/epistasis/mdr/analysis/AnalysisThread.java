package org.epistasis.mdr.analysis;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.epistasis.Pair;
import org.epistasis.ProducerConsumerController;
import org.epistasis.mdr.AmbiguousCellStatus;
import org.epistasis.mdr.AnalysisFileManager;
import org.epistasis.mdr.Main;
import org.epistasis.mdr.enums.FitnessCriteriaOrder;
import org.epistasis.mdr.newengine.AllModelsLandscape;
import org.epistasis.mdr.newengine.AttributeCombination;
import org.epistasis.mdr.newengine.Collector;
import org.epistasis.mdr.newengine.Dataset;
import org.epistasis.mdr.newengine.Model;

public abstract class AnalysisThread extends Thread {

    protected final Dataset data;

    protected final Pair<List<Dataset>, List<Dataset>> partitions;
    protected final int numCrossValidationIntervals;
    protected final AmbiguousCellStatus tieStatus;
    private final long seed;
    protected final boolean parallel;
    protected final Runnable onEndModel;
    protected final Runnable onEndLevel;
    protected final Runnable onEndAnalysis;
    private boolean interrupted = false;
    private boolean complete = false;
    protected final List<Producer> producers = new LinkedList<Producer>();
    protected final List<Collector> collectors = new ArrayList<Collector>();
    protected Collector collector;
    protected final int topModelsLandscapeSize;
    protected final AllModelsLandscape allModelsLandscape;

    protected final FitnessCriteriaOrder topModelsFitnessCriteriaOrder;

    protected final FitnessCriteriaOrder bestModelFitnessCriteriaOrder;

    protected int minAttr;

    protected int maxAttr;

    protected AnalysisThread(final Dataset data,
	    final FitnessCriteriaOrder topModelsFitnessCriteriaOrder,
	    final FitnessCriteriaOrder bestModelFitnessCriteriaOrder,
	    final int numCrossValidationIntervals, final int minAttr,
	    final int maxAttr, final AmbiguousCellStatus tiePriority,
	    final long seed, final Runnable onEndModel,
	    final Runnable onEndLevel, final Runnable onEndAnalysis,
	    final boolean parallel, final int topModelsLandscapeSize,
	    final boolean computeAllModelsLandscape) {
	super("Analysis Thread");
	this.data = data;
	this.topModelsFitnessCriteriaOrder = topModelsFitnessCriteriaOrder;
	this.bestModelFitnessCriteriaOrder = bestModelFitnessCriteriaOrder;
	this.numCrossValidationIntervals = numCrossValidationIntervals;
	this.minAttr = minAttr;
	this.maxAttr = maxAttr;
	partitions = data.partition(numCrossValidationIntervals, seed);
	tieStatus = tiePriority;
	this.seed = seed;
	this.onEndModel = onEndModel;
	this.onEndLevel = onEndLevel;
	this.onEndAnalysis = onEndAnalysis;
	this.parallel = parallel;
	if (computeAllModelsLandscape) {
	    allModelsLandscape = new AllModelsLandscape();
	} else {
	    allModelsLandscape = null;
	}
	this.topModelsLandscapeSize = topModelsLandscapeSize;

    }

    protected void addProducer(final Producer producer) {
	producers.add(producer);
    }

    public AllModelsLandscape getAllModelsLandscape() {
	return allModelsLandscape;
    }

    public List<Collector> getCollectors() {
	return collectors;
    }

    protected List<AttributeCombination> getForced() {
	return null;
    }

    public int getIntervals() {
	return numCrossValidationIntervals;
    }

    public int getMaxAttr() {
	int returnValue = maxAttr;
	if ((collectors != null) && (collectors.size() > 0)) {
	    returnValue = (minAttr + collectors.size()) - 1;
	    if (returnValue != maxAttr) {
		System.out
			.println("calculated maxAttr ("
				+ returnValue
				+ ") different than stored maxAttr ("
				+ maxAttr
				+ "). Perhaps unusual set of forced attributes (skipping levels) or analysis was interrupted?");
	    }
	}
	return returnValue;
    }

    public int getMinAttr() {
	return minAttr;
    }

    public long getSeed() {
	return seed;
    }

    public AmbiguousCellStatus getTiePriority() {
	return tieStatus;
    }

    public boolean isComplete() {
	return complete;
    }

    @Override
    public void run() {
	FinishType finishType = FinishType.NOT_FINISHED;
	try {
	    for (final ProducerConsumerController.Producer<QueueEntry> producer : producers) {
		final int processorsToUse = parallel ? Runtime.getRuntime()
			.availableProcessors() : 1;
		collectors.add(collector = new Collector(data, partitions,
			topModelsLandscapeSize, allModelsLandscape,
			topModelsFitnessCriteriaOrder,
			bestModelFitnessCriteriaOrder));
		if (processorsToUse > 1) {
		    final ProducerConsumerController<QueueEntry> pct = new ProducerConsumerController<QueueEntry>();
		    pct.setProducer(producer);
		    for (int j = 0; j < (processorsToUse); ++j) {
			pct.addConsumer(new ModelAnalyzer());
		    }
		    pct.runProducerConsumerThreads();
		} else {
		    QueueEntry queueEntry;
		    final ModelAnalyzer modelAnalyzer = new ModelAnalyzer();
		    while (((queueEntry = producer.produce()) != null)
			    && !isInterrupted()) {
			modelAnalyzer.consume(queueEntry);
		    }
		}
		if (isInterrupted()) {
		    // remove current collector since it is likely to be
		    // incomplete
		    collectors.remove(collector);
		    break;
		}
		collector.getBestModel();
		if (onEndLevel != null) {
		    onEndLevel.run();
		}
	    } // end loop over producers
	    finishType = FinishType.NORMAL;
	} catch (final Throwable ex) {
	    finishType = FinishType.CAUGHT_EXCEPTION;
	    ex.printStackTrace();
	    // System.err.println("AnalysisThread caught an exception: " + ex
	    // + "\n" + MiscUtilities.);
	} finally {
	    assert finishType != FinishType.NOT_FINISHED : "finishType: "
		    + finishType + " but how is that possible?";
	    collector = null;
	    setComplete();
	    if (onEndAnalysis != null) {
		onEndAnalysis.run();
	    }
	}
    }

    public abstract void saveAnalysis(AnalysisFileManager analysisFileManager);

    public void saveAnalysis(final String analysisSavePath)
	    throws FileNotFoundException {
	final AnalysisFileManager tempAfm = new AnalysisFileManager();
	tempAfm.setAnalysis(data, data.getDataFileName(), getMinAttr(),
		(getMinAttr() + getCollectors().size()) - 1, getCollectors(),
		getAllModelsLandscape(), getForced(), getSeed(),
		getTiePriority());

	// each analysis overrides saveAnalysis to do the correct thing
	saveAnalysis(tempAfm);
	final PrintWriter fileWriter = new PrintWriter(analysisSavePath);
	tempAfm.write(fileWriter);
	fileWriter.flush();
	fileWriter.close();

    }

    protected void setComplete() {
	complete = true;
	interrupted = isInterrupted();

	// if the analysis did not complete properly then maxAttr might not be
	// correct which can caouse problems when saving and then loading an
	// analysis
	if ((collectors != null) && (collectors.size() > 0)) {
	    final int newMaxAttr = minAttr + (collectors.size() - 1);
	    if (newMaxAttr != maxAttr) {
		System.out
			.println("calculated maxAttr ("
				+ newMaxAttr
				+ ") different than stored maxAttr ("
				+ maxAttr
				+ "). collectors.size(): "
				+ collectors.size()
				+ " Perhaps unusual set of forced attributes (skipping levels) or analysis was interrupted?");

		setMaxAttr(newMaxAttr);
	    }
	}

    }

    protected void setMaxAttr(final int maxAttr) {
	this.maxAttr = maxAttr;
    }

    protected void setMinAttr(final int minAttr) {
	this.minAttr = minAttr;
    }

    public boolean wasInterrupted() {
	return interrupted;
    }

    public static abstract class AnalysisThreadBuilder<T extends AnalysisThread> {
	/* required or computed */
	protected Dataset data;
	protected int numCrossValidationIntervals;
	protected int minAttr = -1;
	protected int maxAttr = -1;

	/* optional */
	protected AmbiguousCellStatus tiePriorityList = Main.defaultAmbiguousCellStatus;
	protected Long seed = null;
	protected boolean parallel = Main.defaultParallel;
	protected Runnable onEndModel = null;
	protected Runnable onEndLevel = null;
	protected Runnable onEndAnalysis = null;
	protected int topModelsLandscapeSize = Main.defaultTopModelsLandscapeSize;
	protected boolean computeAllModelsLandscape = Main.defaultComputeAllModelsLandscape;
	protected int[] restrictedSearchAttributes = null;
	protected int distributedNodeCount = Main.defaultDistributedNodeCount;
	protected int distributedNodeNumber = Main.defaultDistributedNodeNumber;
	protected FitnessCriteriaOrder bestModelFitnessCriteriaOrder = Main.defaultBestModelsFitnessCriteriaOrder;
	protected FitnessCriteriaOrder topModelsFitnessCriteriaOrder = Main.defaultTopModelsFitnessCriteriaOrder;

	protected AnalysisThreadBuilder(final Dataset data,
		final int numCrossValidationIntervals, final long seed) {
	    this.data = data;
	    this.numCrossValidationIntervals = numCrossValidationIntervals;
	    this.seed = seed;
	}

	public abstract T build();

	public AnalysisThreadBuilder<T> setBestModelFitnessCriteriaOrder(
		final FitnessCriteriaOrder bestModelFitnessCriteriaOrder) {
	    this.bestModelFitnessCriteriaOrder = bestModelFitnessCriteriaOrder;
	    return this;
	}

	public AnalysisThreadBuilder<T> setComputeAllModelsLandscape(
		final boolean computeAllModelsLandscape) {
	    this.computeAllModelsLandscape = computeAllModelsLandscape;
	    return this;
	}

	public AnalysisThreadBuilder<T> setDistributedNodeCount(
		final int distributedNodeCount) {
	    this.distributedNodeCount = distributedNodeCount;
	    return this;
	}

	public AnalysisThreadBuilder<T> setDistributedNodeNumber(
		final int distributedNodeNumber) {
	    this.distributedNodeNumber = distributedNodeNumber;
	    return this;
	}

	public AnalysisThreadBuilder<T> setMaxAttr(final int maxAttr) {
	    this.maxAttr = maxAttr;
	    return this;
	}

	public AnalysisThreadBuilder<T> setMinAttr(final int minAttr) {
	    this.minAttr = minAttr;
	    return this;
	}

	public AnalysisThreadBuilder<T> setOnEndAnalysis(
		final Runnable onEndAnalysis) {
	    this.onEndAnalysis = onEndAnalysis;
	    return this;
	}

	public AnalysisThreadBuilder<T> setOnEndLevel(final Runnable onEndLevel) {
	    this.onEndLevel = onEndLevel;
	    return this;
	}

	public AnalysisThreadBuilder<T> setOnEndModel(final Runnable onEndModel) {
	    this.onEndModel = onEndModel;
	    return this;
	}

	public AnalysisThreadBuilder<T> setParallel(final boolean parallel) {
	    this.parallel = parallel;
	    return this;
	}

	public AnalysisThreadBuilder<T> setRestrictedSearchAttributes(
		final int[] restrictedSearchAttributes) {
	    this.restrictedSearchAttributes = restrictedSearchAttributes;
	    return this;
	}

	public AnalysisThreadBuilder<T> setTiePriorityList(
		final AmbiguousCellStatus tieStatus) {
	    this.tiePriorityList = tieStatus;
	    return this;
	}

	public AnalysisThreadBuilder<T> setTopModelsFitnessCriteriaOrder(
		final FitnessCriteriaOrder topModelsFitnessCriteriaOrder) {
	    this.topModelsFitnessCriteriaOrder = topModelsFitnessCriteriaOrder;
	    return this;
	}

	public AnalysisThreadBuilder<T> setTopModelsLandscapeSize(
		final int topModelsLandscapeSize) {
	    this.topModelsLandscapeSize = topModelsLandscapeSize;
	    return this;
	}

    }

    enum FinishType {
	NOT_FINISHED, NORMAL, CAUGHT_EXCEPTION
    }

    protected class ModelAnalyzer extends
	    ProducerConsumerController.Consumer<QueueEntry> {
	@Override
	public void consume(final QueueEntry entry) {
	    // assert collector != null :
	    // "collector was null when not expected";
	    if (collector != null) {
		final Model model = new Model(entry.getAttributes(), tieStatus);
		collector.consider(model);
		if (onEndModel != null) {
		    onEndModel.run();
		}
	    }
	}
    }

    protected abstract static class Producer extends
	    ProducerConsumerController.Producer<QueueEntry> {

	public Producer() {
	}

    }

    protected static class QueueEntry {
	private AttributeCombination attributes;

	public QueueEntry(final AttributeCombination attributes) {
	    this.attributes = attributes;
	}

	public AttributeCombination getAttributes() {
	    return attributes;
	}

	public void setAttributeCombination(
		final AttributeCombination newAttributeCombination) {
	    attributes = newAttributeCombination;

	}

	@Override
	public String toString() {
	    return "attributes: " + attributes;
	}
    }
}
