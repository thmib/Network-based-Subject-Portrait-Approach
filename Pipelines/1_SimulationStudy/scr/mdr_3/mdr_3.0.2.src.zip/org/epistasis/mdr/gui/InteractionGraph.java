package org.epistasis.mdr.gui;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.Timer;

import org.apache.commons.collections15.Transformer;
import org.epistasis.mdr.Main;
import org.epistasis.mdr.entropy.EntropyAnalysis;
import org.epistasis.mdr.networkEntropy.NetworkGraph;
import org.jibble.epsgraphics.EpsGraphics2D;

import edu.uci.ics.jung.algorithms.layout.CircleLayout;
import edu.uci.ics.jung.algorithms.layout.FRLayout;
import edu.uci.ics.jung.algorithms.layout.GraphElementAccessor;
import edu.uci.ics.jung.algorithms.layout.ISOMLayout;
import edu.uci.ics.jung.algorithms.layout.KKLayout;
import edu.uci.ics.jung.algorithms.layout.Layout;
import edu.uci.ics.jung.algorithms.layout.util.Relaxer;
import edu.uci.ics.jung.algorithms.util.IterativeContext;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.UndirectedGraph;
import edu.uci.ics.jung.graph.UndirectedSparseMultigraph;
import edu.uci.ics.jung.visualization.DefaultVisualizationModel;
import edu.uci.ics.jung.visualization.Layer;
import edu.uci.ics.jung.visualization.VisualizationModel;
import edu.uci.ics.jung.visualization.VisualizationViewer;
import edu.uci.ics.jung.visualization.control.AbstractGraphMousePlugin;
import edu.uci.ics.jung.visualization.control.CrossoverScalingControl;
import edu.uci.ics.jung.visualization.control.PluggableGraphMouse;
import edu.uci.ics.jung.visualization.control.ScalingGraphMousePlugin;
import edu.uci.ics.jung.visualization.decorators.EdgeShape;
import edu.uci.ics.jung.visualization.renderers.Renderer.VertexLabel;
import edu.uci.ics.jung.visualization.renderers.VertexLabelAsShapeRenderer;
import edu.uci.ics.jung.visualization.transform.MutableTransformer;
import edu.uci.ics.jung.visualization.util.Animator;

public class InteractionGraph extends JPanel implements EntropyDisplay {
    private static final Color DEFAULT_VERTEX_COLOR = Color.WHITE;
    private static final Color INITIAL_HIGHLIGHT_COLOR = SystemColor.textHighlight;
    private static final Color FINAL_HIGHLIGHT_COLOR = InteractionGraph.DEFAULT_VERTEX_COLOR;
    private static final int REPAINT_INTERVAL = 250;
    private static final int RESIZE_WAIT_INTERVAL = InteractionGraph.REPAINT_INTERVAL;
    private final Map<Integer, BasicStroke> edgeWidthMap = new HashMap<Integer, BasicStroke>();
    private final Map<Integer, Font> fontSizeMap = new HashMap<Integer, Font>();
    private final EntropyAnalysis.EntropyValuesCalculator entropyValues;
    private static final long serialVersionUID = 1L;
    private UndirectedGraph<Integer, Integer> entropyGraph = new UndirectedSparseMultigraph<Integer, Integer>();
    private JungLayoutType networkType;
    private int lineThickness;
    private final NumberFormat numberFormat;
    private final EntropyAnalysis entropyAnalysis;
    private int fontSize;
    VisualizationViewer<Integer, Integer> vv = null;// new
    VisualizationModel<Integer, Integer> vm = null;
    public final static String VERTEX_CLICKED = "VERTEX_CLICKED";
    // VisualizationViewer<Integer,
    // Integer>(layout);
    private static final RoundRectangle2D theRoundRectangle = new RoundRectangle2D.Float();
    private final Transformer<Integer, Integer> edgeLengthTransformer = new Transformer<Integer, Integer>() {
	private static final int EDGE_LENGTH_MIN = 30;
	private static final int EDGE_LENGTH_MAX = 100;
	private static final int EDGE_LENGTH_RANGE = EDGE_LENGTH_MAX
		- EDGE_LENGTH_MIN;

	@Override
	public Integer transform(final Integer edge) {
	    Integer edgeLength = 1;
	    if (entropyAnalysis.isEntropyDataReady()) {
		final edu.uci.ics.jung.graph.util.Pair<Integer> endPoints = entropyGraph
			.getEndpoints(edge);
		final int a = endPoints.getFirst();
		final int b = endPoints.getSecond();

		final double edgeValuePercentage = networkGraph
			.getEdgeValuePercentage(a, b);
		// higher percentage means more entropy so want those nodes to
		// be closer to each other

		edgeLength = (int) (EDGE_LENGTH_MIN + ((1.0 - edgeValuePercentage) * EDGE_LENGTH_RANGE));
	    }
	    return edgeLength;
	}
    };
    private double edgeVisibilityThreshold;
    private double nodeVisibilityThreshold;
    private long resizeEventTimer = System.currentTimeMillis();
    private final ActionListener resizeActionListener = new ActionListener() {
	@Override
	public void actionPerformed(final ActionEvent e) {
	    if ((resizeEventTimer + InteractionGraph.RESIZE_WAIT_INTERVAL) < System
		    .currentTimeMillis()) {
		resizeTimer.stop();
		updateGraphDisplay(false /* isAdjusting */);
	    } else {
		// keep repeating
	    }
	}
    };
    private final Timer resizeTimer = new Timer(
	    InteractionGraph.RESIZE_WAIT_INTERVAL, resizeActionListener);
    private NetworkGraph networkGraph;
    private BitSet nodesToHighlight;
    private Color highlightedNodesColor;

    private final static int MILLISECONDS_TO_HIGHLIGHT_NODES = 3 * 1000;
    private static final int LAYOUT_INSET = 20;

    public InteractionGraph(final NumberFormat pNumberFormat,
	    final int pMargin, final EntropyAnalysis pEntropyAnalysis,
	    final JungLayoutType pNetworkType) {
	super();
	edgeWidthMap.put(Main.defaultEntropyGraphLineThickness,
		new BasicStroke(Main.defaultEntropyGraphLineThickness));
	setBackground(Color.white);
	setLayout(new BorderLayout(0, 0));
	entropyAnalysis = pEntropyAnalysis;
	entropyValues = entropyAnalysis.getEntropyValues();
	// entropyGraph.addVertex(0);
	// entropyGraph.addVertex(1);
	// entropyGraph.addEdge(0, 0, 1);
	setFontSize(Main.defaultEntropyGraphTextSize);
	setLineThickness(Main.defaultEntropyGraphLineThickness);
	numberFormat = pNumberFormat;
	setMargin(pMargin);
	setJungLayoutType(pNetworkType);
	setFontSize(Main.defaultEntropyGraphTextSize);
	setLineThickness(Main.defaultEntropyGraphLineThickness);
	createEntropyGraph(null /* networkGraph */);
    }

    public NetworkGraph createEntropyGraph(final NetworkGraph pNetworkGraph) {
	// removing vertices automatically removes all edges connected to it
	// needed to make a copy of collection returned by graph.getVertices()
	// to avoid concurrent modification exception
	for (final Integer vertex : new ArrayList<Integer>(
		entropyGraph.getVertices())) {
	    entropyGraph.removeVertex(vertex);
	}

	if (entropyAnalysis.isEntropyDataReady()) {
	    networkGraph = pNetworkGraph;
	    if (networkGraph == null) {
		networkGraph = entropyAnalysis.buildGraph(entropyGraph);
	    }
	    entropyGraph = networkGraph.getJungGraph();
	    // networkGraph.addPropertyChangeListener(this);
	    vv.setEnabled(true);
	    vv.setVisible(true);

	}
	return networkGraph;
    } // end createEntropyGraph()

    public void drawImage(final Graphics2D drawingObject) {
	drawingObject.setStroke(new BasicStroke(lineThickness,
		BasicStroke.CAP_SQUARE, BasicStroke.JOIN_MITER));
	drawingObject.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
		RenderingHints.VALUE_ANTIALIAS_ON);
	drawingObject.setBackground(getBackground());
	drawingObject.clearRect(0, 0, getWidth(), getHeight());
	drawingObject.setFont(getFont());
	invalidate();
	// printComponent(g);
	vv.paint(drawingObject);
    }

    @Override
    public String getEPSText() {
	final EpsGraphics2D g = new EpsGraphics2D();
	drawImage(g);
	final String epsText = g.toString();
	g.dispose();
	return epsText;
    }

    @Override
    public int getFontSize() {
	final Font font = getFont();
	return font.getSize();
    }

    @Override
    public BufferedImage getImage() {
	final BufferedImage img = new BufferedImage(getWidth(), getHeight(),
		BufferedImage.TYPE_INT_RGB);
	final Graphics2D g = img.createGraphics();
	drawImage(g);
	g.dispose();
	return img;
    }

    @Override
    public int getLineThickness() {
	return lineThickness;
    }

    private Dimension getPreferreredLayoutSize() {
	// inset down and to the right
	final Dimension layoutSize = new Dimension(getWidth()
		- InteractionGraph.LAYOUT_INSET, getHeight()
		- InteractionGraph.LAYOUT_INSET);
	return layoutSize;
    }

    public VisualizationViewer<Integer, Integer> getVisualizationViewer() {
	return vv;
    }

    public void highlightAndFade(final BitSet nodesToHighlight) {
	this.nodesToHighlight = nodesToHighlight;
	highlightedNodesColor = InteractionGraph.INITIAL_HIGHLIGHT_COLOR;
	final Animator animator = new Animator(new IterativeContext() {
	    private final long startTime = System.currentTimeMillis();

	    @Override
	    public boolean done() {
		final boolean isDone = getFractionOfTimeElapsed() >= 1.0;
		if (isDone) {
		    highlightedNodesColor = InteractionGraph.DEFAULT_VERTEX_COLOR;
		    vv.repaint(InteractionGraph.REPAINT_INTERVAL);
		}
		return isDone;
	    }

	    private double getFractionOfTimeElapsed() {
		final long elapsedMilliseconds = System.currentTimeMillis()
			- startTime;
		return elapsedMilliseconds
			/ (double) InteractionGraph.MILLISECONDS_TO_HIGHLIGHT_NODES;
	    }

	    private int scale(final double fraction, final int start,
		    final int end) {
		final int scaledValue = (int) (start + ((end - start) * fraction));
		return scaledValue;
	    }

	    @Override
	    public void step() {
		final double fraction = getFractionOfTimeElapsed();
		if (fraction <= 1.0) {
		    // interpolate between starting and ending color based on
		    // fraction of time elapsed
		    final int red = scale(fraction,
			    InteractionGraph.INITIAL_HIGHLIGHT_COLOR.getRed(),
			    InteractionGraph.FINAL_HIGHLIGHT_COLOR.getRed());
		    final int green = scale(
			    fraction,
			    InteractionGraph.INITIAL_HIGHLIGHT_COLOR.getGreen(),
			    InteractionGraph.FINAL_HIGHLIGHT_COLOR.getGreen());
		    final int blue = scale(fraction,
			    InteractionGraph.INITIAL_HIGHLIGHT_COLOR.getBlue(),
			    InteractionGraph.FINAL_HIGHLIGHT_COLOR.getBlue());
		    // System.out.println("fraction: " + fraction + " red: " +
		    // red
		    // + " green: " + green + " blue: " + blue);
		    highlightedNodesColor = new Color(red, green, blue);
		    // vv.repaint();
		    vv.repaint(InteractionGraph.REPAINT_INTERVAL);
		}
	    }
	}, 200);
	animator.start();
    }

    void setEdgeVisibility(final double pEdgeVisibilityThreshold,
	    final boolean isAdjusting) {
	edgeVisibilityThreshold = pEdgeVisibilityThreshold;
	if (networkGraph != null) {
	    networkGraph.filterGraph(networkGraph.getNodeValidityThreshold(),
		    edgeVisibilityThreshold);
	}
	updateGraphDisplay(isAdjusting);
    }

    @Override
    public void setFontSize(final int pFontSize) {
	fontSize = (pFontSize < 1) ? Main.defaultEntropyGraphTextSize
		: pFontSize;
	repaint();
    }

    public void setJungLayoutType(final JungLayoutType newNetworkType) {
	if (newNetworkType != null) {
	    networkType = newNetworkType;
	    final Layout<Integer, Integer> newLayout = networkType.getLayout(
		    this, entropyGraph, edgeLengthTransformer);
	    if (vv == null) {
		vm = new DefaultVisualizationModel<Integer, Integer>(newLayout,
			getSize());
		vv = new VisualizationViewer<Integer, Integer>(vm);
		vv.setBackground(Color.white);
		addComponentListener(new ComponentAdapter() {
		    @Override
		    public void componentResized(final ComponentEvent e) {
			if (e.getComponent() == InteractionGraph.this) {
			    startResizeTimer();
			}
		    }
		});
		// Create a graph mouse and add it to the visualization
		// component
		// final GraphZoomScrollPane graphZoomScrollPane = new
		// GraphZoomScrollPane();
		// add(graphZoomScrollPane);
		this.add(vv);
		vv.setGraphMouse(new PickableDraggableGraphMouse<Integer, Integer>());
		setupVisualizationVertices();
		setupVisualizationEdges();
	    } else {
		final Layout<Integer, Integer> currentLayout = vm
			.getGraphLayout();
		if (vm.getRelaxer() != null) {
		    vm.getRelaxer().stop();
		    // System.out.println("Stopping relaxer when switching from: "
		    // + currentLayout + " ==> " + newLayout);
		}

		// undo any scaling
		vv.getRenderContext().getMultiLayerTransformer()
			.getTransformer(Layer.VIEW).setToIdentity();

		// undo any panning
		final AffineTransform modelTransformer = vv.getRenderContext()
			.getMultiLayerTransformer()
			.getTransformer(Layer.LAYOUT).getTransform();
		modelTransformer.setToTranslation(
			InteractionGraph.LAYOUT_INSET,
			InteractionGraph.LAYOUT_INSET);

		if (currentLayout != null) {
		    newLayout.setInitializer(currentLayout);
		}

		vm.setGraphLayout(newLayout);
		final Dimension preferredLayoutSize = getPreferreredLayoutSize();
		vm.getGraphLayout().setSize(preferredLayoutSize);

		// System.out.println("Changing layout from: " + currentLayout
		// + " ==> " + newLayout);
	    }
	}
	updateGraphDisplay(false /* is adjusting */);
    }

    @Override
    public void setLineThickness(final int pLineThickness) {
	lineThickness = (pLineThickness < 1) ? Main.defaultEntropyGraphLineThickness
		: pLineThickness;

	repaint();
    }

    @Override
    public void setMargin(final int pMargin) {
    }

    void setNodeVisibilityThreshold(final double pNodeVisibilityThreshold,
	    final boolean isAdjusting) {
	// System.out.println("nodeVisibilityThreshold changing from "
	// + nodeVisibilityThreshold + " to " + pNodeVisibilityThreshold);
	nodeVisibilityThreshold = pNodeVisibilityThreshold;
	if (networkGraph != null) {
	    networkGraph.filterGraph(nodeVisibilityThreshold,
		    networkGraph.getEdgeValidityThreshold());
	}
	updateGraphDisplay(isAdjusting);
    }

    private void setupVisualizationEdges() {
	// edges
	// vv.getRenderContext().setEdgeIncludePredicate(
	// new Predicate<Context<Graph<Integer, Integer>, Integer>>() {
	// @Override
	// public boolean evaluate(
	// final Context<Graph<Integer, Integer>, Integer> context) {
	// final Integer edge = context.element;
	// final Double edgeDataValue = edgeDataMap.get(edge);
	// // display if edge value is greater than or equal to threshold
	// final boolean display = Double.compare(edgeDataValue,
	// edgeVisibilityThreshold) >= 0;
	// return display;
	// }
	// });
	// vv.getRenderContext().setEdgeShapeTransformer(
	// new EdgeLabelAsShapeRenderer<Integer, Integer>(vv
	// .getRenderContext()) {
	// @Override
	// public Shape transform(final Integer v) {
	// final Shape bounds = super.transform(v);
	// final Rectangle2D frame = bounds.getBounds2D();
	// final float arc_size = (float) Math.min(
	// frame.getHeight(), frame.getWidth()) / 2;
	// InteractionGraph.theRoundRectangle.setRoundRect(
	// frame.getX(), frame.getY(), frame.getWidth(),
	// frame.getHeight(), arc_size, arc_size);
	// return InteractionGraph.theRoundRectangle;
	// }
	// });
	vv.getRenderContext().setEdgeShapeTransformer(
		new EdgeShape.QuadCurve<Integer, Integer>());
	vv.getRenderContext().setEdgeLabelTransformer(
		new Transformer<Integer, String>() {
		    @Override
		    public String transform(final Integer edge) {
			final StringBuilder sb = new StringBuilder();
			if (entropyAnalysis.isEntropyDataReady()) {
			    final edu.uci.ics.jung.graph.util.Pair<Integer> endPoints = entropyGraph
				    .getEndpoints(edge);
			    final int a = endPoints.getFirst();
			    final int b = endPoints.getSecond();
			    // final Double edgeDataValue =
			    // edgeDataMap.get(edge);
			    sb.append(String.format("%.2f%%",
				    networkGraph.getEdgeValue(a, b) * 100));
			}
			return sb.toString();
		    }
		});
	vv.setEdgeToolTipTransformer(new Transformer<Integer, String>() {
	    @Override
	    public String transform(final Integer edge) {
		final StringBuilder sb = new StringBuilder("<html>");
		if (entropyAnalysis.isEntropyDataReady()) {
		    final edu.uci.ics.jung.graph.util.Pair<Integer> endPoints = entropyGraph
			    .getEndpoints(edge);
		    final int a = endPoints.getFirst();
		    final int b = endPoints.getSecond();
		    sb.append("<center><bold>");
		    sb.append(entropyAnalysis.getAttrNames().get(a)
			    + " &lt;--&gt; "
			    + entropyAnalysis.getAttrNames().get(b));
		    sb.append("</bold></center>");
		    entropyValues.calculateValues(a, b);
		    sb.append(EntropyAnalysis.H_AB + "="
			    + numberFormat.format(entropyValues.h_ab) + "<br>");
		    sb.append(EntropyAnalysis.H_AB_C + "="
			    + numberFormat.format(entropyValues.h_ab_c)
			    + "<br>");
		    sb.append(EntropyAnalysis.I_A_B + "="
			    + numberFormat.format(entropyValues.i_a_b) + "<br>");
		    sb.append("<b>" + EntropyAnalysis.IG_AB_C + "="
			    + numberFormat.format(entropyValues.ig_a_b_c)
			    + "</b><br>");
		    sb.append(EntropyAnalysis.I_AB_C + "="
			    + numberFormat.format(entropyValues.i_ab_c));
		}
		sb.append("</html>");
		return sb.toString();
	    }
	});
	vv.getRenderContext().setEdgeStrokeTransformer(
		new Transformer<Integer, Stroke>() {
		    @Override
		    public Stroke transform(final Integer edge) {
			BasicStroke edgeStroke = edgeWidthMap
				.get(Main.defaultEntropyGraphLineThickness);
			if (entropyAnalysis.isEntropyDataReady()) {
			    final edu.uci.ics.jung.graph.util.Pair<Integer> endPoints = entropyGraph
				    .getEndpoints(edge);
			    final int a = endPoints.getFirst();
			    final int b = endPoints.getSecond();
			    final int bin = entropyAnalysis.getIndexIntoRange(
				    Dendrogram.NUM_DATA_BINS,
				    networkGraph.getEdgeValue(a, b));
			    final int differenceFromNeutral = Math
				    .abs(Dendrogram.NEUTRAL_BIN - bin);
			    final int lineWidth = 1
				    * (1 + differenceFromNeutral)
				    * lineThickness;
			    edgeStroke = edgeWidthMap.get(lineWidth);
			    if (edgeStroke == null) {
				edgeStroke = new BasicStroke(lineWidth);
				edgeWidthMap.put(lineWidth, edgeStroke);
			    }
			}
			return edgeStroke;
		    }
		});
	vv.getRenderContext().setEdgeFontTransformer(
		new Transformer<Integer, Font>() {
		    @Override
		    public Font transform(final Integer vertex) {
			Font vertexFont = fontSizeMap.get(fontSize);
			if (vertexFont == null) {
			    vertexFont = new Font("Helvetica", Font.BOLD,
				    fontSize);
			    fontSizeMap.put(fontSize, vertexFont);
			}
			return vertexFont;
		    }
		});
	vv.getRenderContext().setEdgeDrawPaintTransformer(
		new Transformer<Integer, Paint>() {
		    @Override
		    public Paint transform(final Integer edge) {
			Color color = Color.white;

			if (entropyAnalysis.isEntropyDataReady()) {
			    final edu.uci.ics.jung.graph.util.Pair<Integer> endPoints = entropyGraph
				    .getEndpoints(edge);
			    final int a = endPoints.getFirst();
			    final int b = endPoints.getSecond();
			    final int bin = entropyAnalysis.getIndexIntoRange(
				    Dendrogram.NUM_DATA_BINS,
				    networkGraph.getEdgeValue(a, b));
			    color = Dendrogram.colors[bin];
			}
			return color;
		    }
		});
    }

    private void setupVisualizationVertices() {
	// nodes
	// vv.getRenderContext().setVertexIncludePredicate(
	// new Predicate<Context<Graph<Integer, Integer>, Integer>>() {
	// @Override
	// public boolean evaluate(
	// final Context<Graph<Integer, Integer>, Integer> context) {
	// final Integer vertex = context.element;
	// final double vertexValue = vertexDataMap.get(vertex);
	// // display if node value is greater than or equal to threshold
	// final boolean display = Double.compare(vertexValue,
	// nodeVisibilityThreshold) >= 0;
	// return display;
	// }
	// });
	vv.getRenderContext().setVertexShapeTransformer(
		new VertexLabelAsShapeRenderer<Integer, Integer>(vv
			.getRenderContext()) {
		    @Override
		    public Shape transform(final Integer v) {
			final Shape bounds = super.transform(v);
			final Rectangle2D frame = bounds.getBounds2D();
			final float arc_size = (float) Math.min(
				frame.getHeight(), frame.getWidth()) / 2;
			InteractionGraph.theRoundRectangle.setRoundRect(
				frame.getX(), frame.getY(), frame.getWidth(),
				frame.getHeight(), arc_size, arc_size);
			return InteractionGraph.theRoundRectangle;
		    }
		});
	vv.getRenderContext().setVertexFontTransformer(
		new Transformer<Integer, Font>() {
		    @Override
		    public Font transform(final Integer vertex) {
			Font vertexFont = fontSizeMap.get(fontSize);
			if (vertexFont == null) {
			    vertexFont = new Font("Helvetica", Font.BOLD,
				    fontSize);
			    fontSizeMap.put(fontSize, vertexFont);
			}
			return vertexFont;
		    }
		});
	vv.getRenderContext().setVertexFillPaintTransformer(
		new Transformer<Integer, Paint>() {
		    @Override
		    public Paint transform(final Integer vertex) {
			Paint paint = InteractionGraph.DEFAULT_VERTEX_COLOR;
			if ((nodesToHighlight != null)
				&& nodesToHighlight.get(vertex)) {
			    paint = highlightedNodesColor;
			}
			return paint;
		    }
		});
	vv.getRenderer().getVertexLabelRenderer()
		.setPosition(VertexLabel.Position.CNTR);
	vv.getRenderContext().setVertexLabelTransformer(
		new Transformer<Integer, String>() {
		    @Override
		    public String transform(final Integer vertex) {
			final StringBuilder sb = new StringBuilder(
				"<html><center><bold>");
			if (entropyAnalysis.isEntropyDataReady()) {
			    final int a = vertex;
			    sb.append(entropyAnalysis.getAttrNames().get(a));
			    sb.append("</bold><br>");
			    sb.append(String.format(
				    "%.2f%%",
				    entropyValues.calculateValuesA(a).i_a_c * 100));
			}
			sb.append("</center></html>");
			return sb.toString();
		    }
		});
	vv.setVertexToolTipTransformer(new Transformer<Integer, String>() {
	    @Override
	    public String transform(final Integer vertex) {
		final StringBuilder sb = new StringBuilder(
			"<html><center><bold>");
		if (entropyAnalysis.isEntropyDataReady()) {
		    final int a = vertex;
		    sb.append(entropyAnalysis.getAttrNames().get(a));
		    entropyValues.calculateValuesA(a);
		    sb.append("</bold></center>");
		    sb.append(EntropyAnalysis.H_A + "="
			    + numberFormat.format(entropyValues.h_a) + "<br>");
		    sb.append(EntropyAnalysis.H_A_C + "="
			    + numberFormat.format(entropyValues.h_a_c) + "<br>");
		    sb.append("<b>" + EntropyAnalysis.I_A_C + "="
			    + numberFormat.format(entropyValues.i_a_c) + "</b>");
		}
		sb.append("</html>");
		return sb.toString();
	    }
	});
    }

    private void startResizeTimer() {
	resizeEventTimer = System.currentTimeMillis();
	if (!resizeTimer.isRunning()) {
	    resizeTimer.start();
	}
    }

    @Override
    public boolean supportEntropyThreshold() {
	return true;
    }

    @Override
    public void updateGraph() {
	createEntropyGraph(null /* networkGraph */);
    }

    private void updateGraphDisplay(final boolean isAdjusting) {
	// System.out.println("updateGraphDisplay(isAdjusting=" + isAdjusting
	// + ") when size: " + getSize());
	if (entropyAnalysis.isEntropyDataReady()) {
	    if (!isAdjusting) {
		final Dimension preferredLayoutSize = getPreferreredLayoutSize();
		final Layout<Integer, Integer> layout = vm.getGraphLayout();
		if (layout != null) {
		    layout.setSize(preferredLayoutSize);
		    layout.reset();
		    final Relaxer relaxer = vm.getRelaxer();
		    if (relaxer != null) {
			layout.reset();
			relaxer.prerelax();
		    }
		}
	    }
	    vv.repaint(InteractionGraph.REPAINT_INTERVAL);
	} else {
	    vv.setEnabled(false);
	    vv.setVisible(false);
	}
    }

    public enum JungLayoutType {
	KAMADA_KAWAI("Kamada-Kawaii", 10000, true, true), FRUCHTERMAN_RHEINGOLD(
		"Fruchterman-Rheingold", 10000, true, true), SELF_ORGANIZING_MAP(
		"Self Organizing Map", 0, true, true), CIRCLE("Circle Graph",
		0, false, true);
	private String displayName;
	private String[] groupNames;
	private long actionListDuration;
	private boolean doClick;
	private boolean doDrag;
	private final static Map<String, JungLayoutType> jungLayoutTypeLookupMap = new HashMap<String, JungLayoutType>();
	static {
	    for (final JungLayoutType layoutType : JungLayoutType.values()) {
		JungLayoutType.jungLayoutTypeLookupMap.put(
			layoutType.toString(), layoutType);
	    }
	}

	/**
	 * return the layout type or null if not recognized
	 * 
	 * @param pJungLayoutTypeName
	 * @return
	 */
	public static JungLayoutType lookup(final String pJungLayoutTypeName) {
	    final JungLayoutType layoutType = JungLayoutType.jungLayoutTypeLookupMap
		    .get(pJungLayoutTypeName);
	    // if (prefuseLayoutType == null) {
	    // throw new IllegalArgumentException("JungLayoutType.layout("
	    // + pJungLayoutTypeName + ") could not be recognized!");
	    // }
	    return layoutType;
	}

	private JungLayoutType(final String pDisplayName,
		final long pActionListDuration, final boolean pDoClick,
		final boolean pDoDrag) {
	    displayName = pDisplayName;
	    actionListDuration = pActionListDuration;
	    doClick = pDoClick;
	    doDrag = pDoDrag;
	}

	public boolean doClick() {
	    return doClick;
	}

	public boolean doDrag() {
	    return doDrag;
	}

	public long getActionListDuration() {
	    return actionListDuration;
	}

	public String getDisplayName() {
	    return displayName;
	}

	public String getEdgeGroup() {
	    return groupNames[2];
	}

	public Layout<Integer, Integer> getLayout(final JComponent component,
		final Graph<Integer, Integer> graph,
		final Transformer<Integer, Integer> edgeLengthTransformer) {
	    Layout<Integer, Integer> layout = null;
	    switch (this) {
	    case CIRCLE:
		final CircleLayout<Integer, Integer> circleLayout = new CircleLayout<Integer, Integer>(
			graph);
		final double radius = 0.40 * (component.getHeight() < component
			.getWidth() ? component.getHeight() : component
			.getWidth());
		circleLayout.setRadius(radius);
		layout = circleLayout;
		break;
	    case FRUCHTERMAN_RHEINGOLD:
		layout = new FRLayout<Integer, Integer>(graph);
		break;
	    case SELF_ORGANIZING_MAP:
		layout = new ISOMLayout<Integer, Integer>(graph);
		break;
	    case KAMADA_KAWAI:
		final KKLayout<Integer, Integer> kkLayout = new KKLayout<Integer, Integer>(
			graph);
		kkLayout.setLengthFactor(1.1);
		layout = kkLayout;
		break;
	    default:
		throw new RuntimeException("Unhandled layout type: "
			+ toString());
		// break;
	    }
	    // layout.setSize(component.getSize());
	    // layout.initialize();
	    return layout;
	} // end getLayout

	public String getNetworkType() {
	    return groupNames[0];
	}

	public String getNodeGroup() {
	    return groupNames[1];
	}

	@Override
	public String toString() {
	    return getDisplayName();
	}
    } // end enum NetworkTypes

    private class PickableDraggableGraphMouse<V, E> extends PluggableGraphMouse {
	public PickableDraggableGraphMouse() {
	    add(new ScalingGraphMousePlugin(new CrossoverScalingControl(), 0));
	    add(new PickableDraggableGraphMousePlugin<V, E>());
	    // add(new AnimatedPickingGraphMousePlugin<V, E>());
	    // add(new TranslatingGraphMousePlugin(InputEvent.BUTTON1_MASK));
	    // add(new RotatingGraphMousePlugin());
	    // add(new ShearingGraphMousePlugin());
	}
    } // end static class PickableDraggableGraphMouse

    private class PickableDraggableGraphMousePlugin<V, E> extends
	    AbstractGraphMousePlugin implements MouseListener,
	    MouseMotionListener {
	/**
	 * the picked Vertex, if any
	 */
	protected V vertex;

	/**
	 * create an instance with default settings
	 */
	public PickableDraggableGraphMousePlugin() {
	    super(InputEvent.BUTTON1_MASK);
	}

	@Override
	public void mouseClicked(final MouseEvent e) {
	    @SuppressWarnings("unchecked")
	    final VisualizationViewer<V, E> vv = (VisualizationViewer<V, E>) e
		    .getSource();
	    final GraphElementAccessor<V, E> pickSupport = vv.getPickSupport();
	    final Layout<V, E> layout = vv.getGraphLayout();
	    // p is the screen point for the mouse event
	    vertex = pickSupport.getVertex(layout, e.getX(), e.getY());
	    if (vertex != null) {
		// toggle locked state
		layout.lock(vertex, !layout.isLocked(vertex));
		InteractionGraph.this.firePropertyChange(
			InteractionGraph.VERTEX_CLICKED, null, vertex);
	    }
	}

	/**
	 * If the mouse is over a picked vertex, drag all picked vertices with
	 * the mouse. If the mouse is not over a Vertex, draw the rectangle to
	 * select multiple Vertices
	 */
	@Override
	public void mouseDragged(final MouseEvent e) {
	    @SuppressWarnings("unchecked")
	    final VisualizationViewer<V, E> vv = (VisualizationViewer<V, E>) e
		    .getSource();
	    final Layout<V, E> layout = vv.getGraphLayout();
	    final Point2D currentPosInGraphCoords = vv.getRenderContext()
		    .getMultiLayerTransformer().inverseTransform(e.getPoint());
	    final Point2D prevPosInGraphCoords = vv.getRenderContext()
		    .getMultiLayerTransformer().inverseTransform(down);
	    final float dx = (float) (currentPosInGraphCoords.getX() - prevPosInGraphCoords
		    .getX());
	    final float dy = (float) (currentPosInGraphCoords.getY() - prevPosInGraphCoords
		    .getY());
	    if (vertex != null) {
		final Point2D vp = layout.transform(vertex);
		vp.setLocation(vp.getX() + dx, vp.getY() + dy);
		layout.setLocation(vertex, vp);
		layout.lock(vertex, true);
	    } else {
		final MutableTransformer modelTransformer = vv
			.getRenderContext().getMultiLayerTransformer()
			.getTransformer(Layer.LAYOUT);
		modelTransformer.translate(dx, dy);
		// System.out.println("Dragging whole graph: down: " + down +
		// " point: "
		// + e.getPoint() + " dx: " + dx + " dy: " + dy);
	    }
	    down = e.getPoint();
	    e.consume();
	    vv.repaint();
	}

	@Override
	public void mouseEntered(final MouseEvent e) {
	    final JComponent c = (JComponent) e.getSource();
	    c.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	}

	@Override
	public void mouseExited(final MouseEvent e) {
	    final JComponent c = (JComponent) e.getSource();
	    c.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
	}

	@Override
	public void mouseMoved(final MouseEvent e) {
	}

	/**
	 * For primary modifiers (default, MouseButton1): pick a single Vertex
	 * or Edge that is under the mouse pointer. If no Vertex or edge is
	 * under the pointer, unselect all picked Vertices and edges, and set up
	 * to draw a rectangle for multiple selection of contained Vertices. For
	 * additional selection (default Shift+MouseButton1): Add to the
	 * selection, a single Vertex or Edge that is under the mouse pointer.
	 * If a previously picked Vertex or Edge is under the pointer, it is
	 * un-picked. If no vertex or Edge is under the pointer, set up to draw
	 * a multiple selection rectangle (as above) but do not unpick
	 * previously picked elements.
	 * 
	 * @param e
	 *            the event
	 */
	@Override
	public void mousePressed(final MouseEvent e) {
	    @SuppressWarnings("unchecked")
	    final VisualizationViewer<V, E> vv = (VisualizationViewer<V, E>) e
		    .getSource();
	    final GraphElementAccessor<V, E> pickSupport = vv.getPickSupport();
	    final Layout<V, E> layout = vv.getGraphLayout();
	    // p is the screen point for the mouse event
	    vertex = pickSupport.getVertex(layout, e.getX(), e.getY());
	    down = e.getPoint();
	    if (vertex != null) {
		InteractionGraph.this.firePropertyChange(
			InteractionGraph.VERTEX_CLICKED, null, vertex);
	    }
	    // if (vertex != null) {
	    // // System.out.println("Picked up vertex: " + vertex);
	    // final Relaxer relaxer = vm.getRelaxer();
	    // if (relaxer != null) {
	    // relaxer.pause();
	    // }
	    // } else {
	    // // System.out.println("Picked up whole graph");
	    // }
	    // else panning the whole graph
	}

	/**
	 * If the mouse is dragging a rectangle, pick the Vertices contained in
	 * that rectangle clean up settings from mousePressed
	 */
	@Override
	public void mouseReleased(final MouseEvent e) {
	    if (vertex != null) {
		// @SuppressWarnings("unchecked")
		// final VisualizationViewer<V, E> vv = (VisualizationViewer<V,
		// E>) e
		// .getSource();
		// vv.getGraphLayout();
		// // layout.lock(vertex, oldLockState);
		// System.out.println("mouseReleased. oldLockState: "
		// + oldLockState + " Releasing Vertex: " + vertex
		// + " hasRelaxer?: "
		// + (vm.getRelaxer() != null));
		vertex = null;
		// final Relaxer relaxer = vm.getRelaxer();
		// if (relaxer != null) {
		// System.out.println("restarting relaxer");
		// // relaxer.prerelax();
		// vv.getGraphLayout().reset();
		// relaxer.resume();
		// }
	    }
	}
    } // end static class PickableDraggableGraphMousePlugin

} // end class InteractionGraph
