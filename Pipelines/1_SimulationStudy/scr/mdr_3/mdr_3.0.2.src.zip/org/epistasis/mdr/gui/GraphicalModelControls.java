package org.epistasis.mdr.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.NumberFormat;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.filechooser.FileFilter;

import org.epistasis.FileSaver;
import org.epistasis.FileSaver.FileSuffixBeforeExtension;
import org.epistasis.Pair;
import org.epistasis.Utility;
import org.epistasis.gui.CmdMaximizeActionListener;
import org.epistasis.mdr.newengine.Dataset;
import org.epistasis.mdr.newengine.Model;

public class GraphicalModelControls extends JPanel {
    /**
	 * 
	 */
    private static final long serialVersionUID = 1L;
    private final BorderLayout bolThis = new BorderLayout();
    private final JScrollPane scpGraphicalModel = new JScrollPane();
    private final JPanel pnlControls = new JPanel();
    private final GridBagLayout gblControls = new GridBagLayout();
    private final JLabel lblPage = new JLabel();
    private final JCheckBox chkLimitDimension = new JCheckBox();
    private final JSpinner spnLimitDimension = new JSpinner();
    private final JButton cmdPrevious = new JButton();
    private final JButton cmdNext = new JButton();
    private final JButton cmdSave = new JButton();
    private final GraphicalModelPanel gmpGraphicalModel = new GraphicalModelPanel();
    private final JButton cmdMaximize = new JButton();
    private final JLabel lblGraphExplanation = new JLabel("");

    public GraphicalModelControls() {
	jbInit();
    }

    public void addActionListener(final ActionListener l) {
	listenerList.add(ActionListener.class, l);
    }

    private void checkEnabled() {
	lblPage.setEnabled(isEnabled());
	chkLimitDimension.setEnabled(isEnabled());
	gmpGraphicalModel.setEnabled(isEnabled());
	if (isEnabled()) {
	    spnLimitDimension.setEnabled(chkLimitDimension.isSelected());
	    cmdPrevious.setEnabled(gmpGraphicalModel.getPage() > 0);
	    cmdNext.setEnabled((gmpGraphicalModel.getPage() + 1) < gmpGraphicalModel
		    .getNumPages());
	    cmdSave.setEnabled(gmpGraphicalModel.getNumPages() > 0);
	} else {
	    spnLimitDimension.setEnabled(false);
	    cmdPrevious.setEnabled(false);
	    cmdNext.setEnabled(false);
	    cmdSave.setEnabled(false);
	}
	cmdMaximize.setEnabled(isEnabled());
    }

    public void chkLimitDimension_actionPerformed(final ActionEvent e) {
	if (chkLimitDimension.isSelected()) {
	    gmpGraphicalModel.setMaxDim(((Number) spnLimitDimension.getValue())
		    .intValue());
	} else {
	    gmpGraphicalModel.setMaxDim(0);
	}
	updateLabel();
	checkEnabled();
    }

    public void cmdMaximize_actionPerformed(final ActionEvent e) {
	if (cmdMaximize.getText().equals("Maximize")) {
	    cmdMaximize.setText("Restore");
	} else {
	    cmdMaximize.setText("Maximize");
	}
	fireActionEvent(e);
    }

    public void cmdNext_actionPerformed(final ActionEvent e) {
	gmpGraphicalModel.setPage(gmpGraphicalModel.getPage() + 1);
	updateLabel();
	checkEnabled();
    }

    public void cmdPrevious_actionPerformed(final ActionEvent e) {
	gmpGraphicalModel.setPage(gmpGraphicalModel.getPage() - 1);
	updateLabel();
	checkEnabled();
    }

    public void cmdSave_actionPerformed(final ActionEvent e) {
	final NumberFormat nf = new DecimalFormat("0000");
	final int pages = gmpGraphicalModel.getNumPages();
	final Pair<File, FileFilter> ff = FileSaver.getSaveFile(
		(pages > 1) ? "Save " + pages + " Pages" : "Save 1 Page",
		FileSuffixBeforeExtension._cell_values_chart,
		FileSaver.filtersGraphics);
	if (ff != null) {
	    try {
		final File file = ff.getFirst();
		final FileFilter fileFilter = ff.getSecond();
		for (int i = 0; i < pages; ++i) {
		    String filename = file.getCanonicalPath();
		    if (pages > 1) {
			final int extensionPos = filename.lastIndexOf('.');
			filename = filename.substring(0, extensionPos)
				+ nf.format(i + 1)
				+ filename.substring(extensionPos);
		    }
		    if (fileFilter == FileSaver.ExtensionFilter.epsFilter) {
			final BufferedWriter w = new BufferedWriter(
				new FileWriter(filename));
			w.write(gmpGraphicalModel.getPageEPS(i));
			w.flush();
			w.close();
		    } else if (fileFilter == FileSaver.ExtensionFilter.jpgFilter) {
			ImageIO.write(gmpGraphicalModel.getPageImage(i),
				"jpeg", new File(filename));
		    } else if (fileFilter == FileSaver.ExtensionFilter.pngFilter) {
			ImageIO.write(gmpGraphicalModel.getPageImage(i), "png",
				new File(filename));
		    }
		}
	    } catch (final IOException ex) {
		Utility.logException(ex);
		JOptionPane.showMessageDialog(this, ex.getMessage(),
			"I/O Error", JOptionPane.ERROR_MESSAGE);
	    }
	} // end if user did not bail out of save dialog
    }

    protected void fireActionEvent(final ActionEvent e) {
	final ActionListener[] listeners = listenerList
		.getListeners(ActionListener.class);
	for (final ActionListener listener : listeners) {
	    listener.actionPerformed(e);
	}
    }

    private void jbInit() {
	setLayout(bolThis);
	scpGraphicalModel.setBorder(BorderFactory.createLoweredBevelBorder());
	gmpGraphicalModel
		.setCellFont(new java.awt.Font("Dialog", Font.BOLD, 14));
	gmpGraphicalModel.setValueFont(new java.awt.Font("Dialog", Font.PLAIN,
		14));
	gmpGraphicalModel
		.setAxisFont(new java.awt.Font("Dialog", Font.BOLD, 16));
	pnlControls.setLayout(gblControls);
	lblPage.setText("");
	chkLimitDimension.setSelected(true);
	chkLimitDimension.setText("Limit Dimension");
	chkLimitDimension.addActionListener(new ActionListener() {

	    @Override
	    public void actionPerformed(final ActionEvent e) {
		chkLimitDimension_actionPerformed(e);

	    }
	});
	cmdPrevious.setText("< Previous");
	cmdPrevious.addActionListener(new ActionListener() {

	    @Override
	    public void actionPerformed(final ActionEvent e) {
		cmdPrevious_actionPerformed(e);

	    }
	});
	cmdNext.setText("Next >");
	cmdNext.addActionListener(new ActionListener() {

	    @Override
	    public void actionPerformed(final ActionEvent e) {
		cmdNext_actionPerformed(e);

	    }
	});
	cmdSave.setText("Save");
	cmdSave.addActionListener(new ActionListener() {

	    @Override
	    public void actionPerformed(final ActionEvent e) {
		cmdSave_actionPerformed(e);

	    }
	});
	spnLimitDimension.setMinimumSize(new Dimension(60, 20));
	spnLimitDimension.setPreferredSize(new Dimension(60, 20));
	spnLimitDimension.addChangeListener(new ChangeListener() {
	    @Override
	    public void stateChanged(final ChangeEvent e) {
		gmpGraphicalModel.setMaxDim(((Number) spnLimitDimension
			.getValue()).intValue());
		updateLabel();
		checkEnabled();
	    }
	});
	spnLimitDimension.setModel(new SpinnerNumberModel(new Integer(3),
		new Integer(1), null, new Integer(1)));
	cmdMaximize.setText("Maximize");
	cmdMaximize.addActionListener(new CmdMaximizeActionListener(this,
		cmdMaximize));
	lblGraphExplanation.setFont(new Font("Tahoma", Font.BOLD, 11));

	add(lblGraphExplanation, BorderLayout.NORTH);
	this.add(scpGraphicalModel, java.awt.BorderLayout.CENTER);
	scpGraphicalModel.setViewportView(gmpGraphicalModel);
	this.add(pnlControls, java.awt.BorderLayout.SOUTH);
	pnlControls.add(lblPage, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0,
		GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(
			5, 5, 5, 0), 0, 0));
	pnlControls.add(chkLimitDimension, new GridBagConstraints(2, 0, 1, 1,
		1.0, 0.0, GridBagConstraints.EAST, GridBagConstraints.NONE,
		new Insets(5, 5, 5, 0), 0, 0));
	pnlControls.add(spnLimitDimension, new GridBagConstraints(3, 0, 1, 1,
		0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.NONE,
		new Insets(5, 5, 5, 0), 0, 0));
	pnlControls.add(cmdPrevious, new GridBagConstraints(4, 0, 1, 1, 0.0,
		0.0, GridBagConstraints.CENTER, GridBagConstraints.NONE,
		new Insets(5, 5, 5, 0), 0, 0));
	pnlControls.add(cmdNext, new GridBagConstraints(5, 0, 1, 1, 0.0, 0.0,
		GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(
			5, 5, 5, 0), 0, 0));
	pnlControls.add(cmdMaximize, new GridBagConstraints(6, 0, 1, 1, 0.0,
		0.0, GridBagConstraints.CENTER, GridBagConstraints.NONE,
		new Insets(5, 5, 5, 0), 0, 0));
	pnlControls.add(cmdSave, new GridBagConstraints(7, 0, 1, 1, 0.0, 0.0,
		GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(
			5, 5, 5, 5), 0, 0));
    }

    public void removeActionListener(final ActionListener l) {
	listenerList.remove(ActionListener.class, l);
    }

    public void setDatasetAndModel(final Dataset data, final Model model) {
	gmpGraphicalModel.setDatasetAndModel(data, model);
	updateLabel();
	updateGraphExplanationText(data);
	checkEnabled();
    }

    @Override
    public void setEnabled(final boolean enabled) {
	super.setEnabled(enabled);
	if (lblPage != null) {
	    checkEnabled();
	}
    }

    @Override
    public void setFont(final Font font) {
	super.setFont(font);
	if (lblPage == null) {
	    return;
	}
	lblPage.setFont(font);
	chkLimitDimension.setFont(font);
	spnLimitDimension.setFont(font);
	cmdPrevious.setFont(font);
	cmdNext.setFont(font);
	cmdSave.setFont(font);
	cmdMaximize.setFont(font);
    }

    private void updateGraphExplanationText(final Dataset data) {
	if (!gmpGraphicalModel.hasDataAndModel()) {
	    lblGraphExplanation.setText("");
	} else if (data.hasContinuousEndpoints()) {
	    //
	    // lblGraphExplanation.setText("  Each cell shows average of "
	    // + data.getStatusColumnName()
	    // + " with height and proportion of dataset with width.");
	    lblGraphExplanation
		    .setText("  Bar height shows difference between the global and cell averages of '"
			    + data.getStatusColumnName()
			    + "'. Bar width shows proportion of dataset.");
	} else {
	    lblGraphExplanation.setText("  Each cell shows counts of '"
		    + data.getStatusColumnName() + " "
		    + data.getAffectedValuesString() + "' on left and '"
		    + data.getStatusColumnName() + " "
		    + data.getUnaffectedValuesString() + "' on right.");
	}
	// } // end if a model
    }

    private void updateLabel() {
	if (!gmpGraphicalModel.hasDataAndModel()) {
	    lblPage.setText("");
	} else {
	    lblPage.setText("Page " + (gmpGraphicalModel.getPage() + 1)
		    + " of " + gmpGraphicalModel.getNumPages());
	}
    }
}
