package org.epistasis.mdr.gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EventListener;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.UIManager;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import org.epistasis.Pair;
import org.epistasis.mdr.Console;
import org.epistasis.mdr.Console.DatasetStackAction;
import org.epistasis.mdr.Main;
import org.epistasis.mdr.newengine.Dataset;

public class CovariateAdjustmentPanel extends JComponent {
    private static final long serialVersionUID = 1L;
    private final GridBagLayout gblThis = new GridBagLayout();
    private final JButton cmdAdjustCovariate = new JButton();
    private final JButton cmdRevert = new JButton();
    private final JScrollPane scpAttributes = new JScrollPane();
    private final JButton cmdExport = new JButton();
    private final JLabel lblName = new JLabel();
    private final JTextField txtName = new JTextField();
    private final JList lstAttributes = new JList();
    private final JButton cmdSort = new JButton();
    private final JLabel lblAttributes = new JLabel();
    private ChangeEvent changeEvent;
    private boolean warnOnChange = false;

    public CovariateAdjustmentPanel() {
	jbInit();
    }

    public void addChangeListener(final ChangeListener l) {
	listenerList.add(ChangeListener.class, l);
    }

    private boolean canDatasetBeReverted() {
	return Console.console.datasetCanBeReverted();
    }

    public void cmdSort(final ActionEvent e) {
	final DefaultListModel model = (DefaultListModel) lstAttributes
		.getModel();
	final String[] values = new String[model.getSize()];
	for (int i = 0; i < values.length; ++i) {
	    values[i] = model.get(i).toString();
	}
	Arrays.sort(values, String.CASE_INSENSITIVE_ORDER);
	model.clear();
	model.ensureCapacity(values.length);
	for (final String value : values) {
	    model.addElement(value);
	}
    }

    protected void fireChangeEvent() {
	final EventListener[] listeners = listenerList
		.getListeners(ChangeListener.class);
	cmdSort.setEnabled((lstAttributes.getModel().getSize() > 1)
		&& isEnabled());
	for (final EventListener element : listeners) {
	    if (changeEvent == null) {
		changeEvent = new ChangeEvent(this);
	    }
	    ((ChangeListener) element).stateChanged(changeEvent);
	}
    }

    public JButton getCmdRevert() {
	return cmdRevert;
    }

    public boolean isWarnOnChange() {
	return warnOnChange;
    }

    private void jbInit() {
	setBackground(UIManager.getColor("control"));
	setLayout(gblThis);
	cmdAdjustCovariate.setText("Adjust for covariate");
	cmdAdjustCovariate.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		final String covariateAttributeName = txtName.getText();
		if (warnOnChange) {
		    if (!warn("Adjusting for covariate attribute will clear the current "
			    + "analysis pane.  Continue?")) {
			return;
		    }
		    warnOnChange = false;
		}
		final Object[] labels = lstAttributes.getSelectedValues();
		final List<Integer> indices = new ArrayList<Integer>(
			labels.length);
		for (final Object label : labels) {
		    indices.add(Console.console.data.getLabels().indexOf(
			    label.toString()));
		}
		try {
		    final Pair<Dataset, String> datasetAndChangeReport = Console.console.data.adjustForCovariate(
			    Console.console
				    .getRandomSeed("CovariateAdjustmentPanel call to CovariateAdjustment"),
			    covariateAttributeName, true /* createChangeReport */);
		    Console.console.setDataset(
			    datasetAndChangeReport.getFirst(),
			    DatasetStackAction.PUSH_ONTO_STACK);
		    // "Attribute 'X1' was adjusted for by: Genotype 'AT': case / control counts changed from 135, 97 to 135/135; Genotype 'AA': case / control counts changed from 25, 37 to 37/37; Genotype 'TT' case control changed from 17, 16 to 17, 17"
		    fireChangeEvent();
		    JOptionPane.showMessageDialog(
			    CovariateAdjustmentPanel.this,
			    datasetAndChangeReport.getSecond(),
			    "Covariate adjustment suceeded",
			    JOptionPane.INFORMATION_MESSAGE);
		} catch (final Exception ex) {
		    JOptionPane.showMessageDialog(
			    CovariateAdjustmentPanel.this, ex.getMessage(),
			    "Covariate adjustment failed",
			    JOptionPane.ERROR_MESSAGE);
		}
	    }
	});
	cmdAdjustCovariate.setEnabled(false);
	cmdRevert
		.setToolTipText("<html>Whenever filtering or covariate adjustment is done<br>a snapshot of the data is saved. This will change<br>the datafile to the most recent snapshot.</html>");
	cmdRevert.setText(Main.REVERT_DATAFILE);
	cmdRevert.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		Frame.cmdRevertData();
	    }
	});
	cmdRevert.setEnabled(canDatasetBeReverted());
	cmdExport.setEnabled(false);
	cmdExport.setText(Main.EXPORT_DATAFILE);
	cmdExport.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		Frame.cmdExportData();
	    }
	});
	cmdRevert.setVisible(true);
	scpAttributes.setBorder(BorderFactory.createLoweredBevelBorder());
	scpAttributes.setMinimumSize(new Dimension(200, 0));
	scpAttributes.setPreferredSize(new Dimension(200, 0));
	lblName.setToolTipText("");
	lblName.setText("Covariate attribute to adjust for:");
	txtName.getDocument().addDocumentListener(new DocumentListener() {
	    @Override
	    public void changedUpdate(final DocumentEvent e) {
		txtName_textChanged(e);
	    }

	    @Override
	    public void insertUpdate(final DocumentEvent e) {
		txtName_textChanged(e);
	    }

	    @Override
	    public void removeUpdate(final DocumentEvent e) {
		txtName_textChanged(e);
	    }
	});
	cmdSort.setEnabled(false);
	cmdSort.setText("Sort List");
	cmdSort.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		cmdSort(e);
	    }
	});
	lstAttributes.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	lblAttributes.setText("Attributes:");
	lstAttributes.getSelectionModel().addListSelectionListener(
		new ListSelectionListener() {
		    @Override
		    public void valueChanged(final ListSelectionEvent e) {
			lstAttributes_selectionChanged(e);
		    }
		});
	this.add(lblAttributes, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0,
		GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5,
			5, 0, 0), 0, 0));
	this.add(scpAttributes, new GridBagConstraints(0, 1, 1, 6, 0.0, 1.0,
		GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(
			5, 5, 5, 0), 0, 0));
	this.add(lblName, new GridBagConstraints(1, 0, 2, 1, 0.0, 0.0,
		GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5,
			5, 0, 0), 0, 0));
	this.add(txtName, new GridBagConstraints(1, 1, 2, 1, 1.0, 0.0,
		GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
		new Insets(5, 5, 0, 5), 0, 0));
	this.add(cmdAdjustCovariate, new GridBagConstraints(1, 2, 1, 1, 0.0,
		0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
		new Insets(5, 5, 0, 0), 0, 0));
	this.add(cmdRevert, new GridBagConstraints(1, 3, 1, 1, 0.0, 0.0,
		GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
		new Insets(5, 5, 0, 0), 0, 0));
	this.add(cmdSort, new GridBagConstraints(1, 4, 1, 1, 0.0, 0.0,
		GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
		new Insets(5, 5, 0, 0), 0, 0));
	this.add(cmdExport, new GridBagConstraints(1, 5, 1, 1, 0.0, 0.0,
		GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
		new Insets(5, 5, 0, 0), 0, 0));
	scpAttributes.setViewportView(lstAttributes);
    }

    public void lstAttributes_selectionChanged(final ListSelectionEvent e) {
	final Object selectedName = lstAttributes.getSelectedValue();
	txtName.setText((selectedName != null) ? selectedName.toString() : "");
	txtName.selectAll();
	txtName.requestFocus();
    }

    @Override
    public void paint(final Graphics g) {
	final Color c = g.getColor();
	g.setColor(getBackground());
	g.fillRect(0, 0, getWidth(), getHeight());
	g.setColor(c);
	super.paint(g);
    }

    public void removeChangeListener(final ChangeListener l) {
	listenerList.remove(ChangeListener.class, l);
    }

    public void setData(final Dataset data) {
	cmdExport.setEnabled((data != null) && isEnabled());
	final DefaultListModel model = new DefaultListModel();
	if (data != null) {
	    model.ensureCapacity(data.getCols() - 1);
	    for (int i = 0; i < (data.getLabels().size() - 1); ++i) {
		model.addElement(data.getLabels().get(i));
	    }
	}
	lstAttributes.setModel(model);
	cmdSort.setEnabled((lstAttributes.getModel().getSize() > 1)
		&& isEnabled());
    }

    @Override
    public void setEnabled(final boolean enabled) {
	if (enabled) {
	    final int selectedCount = lstAttributes.getSelectedValues().length;
	    cmdAdjustCovariate.setEnabled((selectedCount > 1)
		    && (txtName.getText().length() > 0));
	    cmdRevert.setEnabled(canDatasetBeReverted());
	    cmdSort.setEnabled(lstAttributes.getModel().getSize() > 1);
	    cmdExport.setEnabled(Console.console.data != null);
	} else {
	    lstAttributes.clearSelection();
	    cmdAdjustCovariate.setEnabled(enabled);
	    cmdRevert.setEnabled(enabled);
	    cmdSort.setEnabled(enabled);
	    cmdExport.setEnabled(enabled);
	}
	lstAttributes.setEnabled(enabled);
	lblName.setEnabled(enabled);
	txtName.setEnabled(enabled);
	super.setEnabled(enabled);
    }

    public void setWarnOnChange(final boolean warnOnChange) {
	this.warnOnChange = warnOnChange;
    }

    public void txtName_textChanged(final DocumentEvent e) {
	final String attributeName = txtName.getText();
	final DefaultListModel model = (DefaultListModel) lstAttributes
		.getModel();
	// if current contents is an attribute then enable button
	cmdAdjustCovariate.setEnabled(model.contains(attributeName));
    }

    private boolean warn(final String warning) {
	return JOptionPane.showConfirmDialog(this, warning, "Warning",
		JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE) == JOptionPane.YES_OPTION;
    }
}
