package org.epistasis.mdr.gui;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.List;
import java.util.SortedSet;

import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import org.epistasis.mdr.Main;
import org.epistasis.mdr.networkEntropy.NetworkGraph;

public class GraphMetricsTable extends JTable {
    private final GraphMetricTableModel tableModel;
    private static final long serialVersionUID = 1L;
    private final List<NetworkGraph> connectedComponents = new ArrayList<NetworkGraph>();
    private final NodeMetricsTable nodeMetricsTable;
    private final InteractionGraph interactionGraph;

    public GraphMetricsTable(final NodeMetricsTable nodeMetricsTable,
	    final InteractionGraph interactionGraph) {
	this.nodeMetricsTable = nodeMetricsTable;
	this.interactionGraph = interactionGraph;
	setFillsViewportHeight(true);
	interactionGraph.addPropertyChangeListener(
		InteractionGraph.VERTEX_CLICKED, new PropertyChangeListener() {

		    @Override
		    public void propertyChange(final PropertyChangeEvent evt) {
			final Integer pickedVertex = (Integer) evt
				.getNewValue();
			if (connectedComponents.size() > 1) {
			    for (int rowIndex = 0; rowIndex < connectedComponents
				    .size(); ++rowIndex) {
				if (connectedComponents.get(rowIndex)
					.nodeIsConnected(pickedVertex)) {
				    getSelectionModel().setSelectionInterval(
					    rowIndex, rowIndex);
				    break;
				}

			    } // end if found connected component
			}
		    } // end propertyChange

		});
	setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	setRowSelectionAllowed(true);
	getSelectionModel().addListSelectionListener(
		new ListSelectionListener() {

		    @Override
		    public void valueChanged(final ListSelectionEvent e) {
			if (!e.getValueIsAdjusting()) {
			    changeSelectedRow();
			}

		    }
		});
	tableModel = new GraphMetricTableModel();
	setModel(tableModel);
    }

    private void changeSelectedRow() {
	final int selectedRowIndex = getSelectedRow();
	// System.out.println("changeSelectedRow(" + selectedRowIndex + ")");
	if (selectedRowIndex >= 0) {
	    if (selectedRowIndex > (connectedComponents.size() - 1)) {
		System.err
			.println("changeSelectedRow("
				+ selectedRowIndex
				+ ") selected row is not a valid connected component index. connectedComponents.size():  "
				+ connectedComponents.size());
	    } else {
		final NetworkGraph selectedGraph = connectedComponents
			.get(selectedRowIndex);
		nodeMetricsTable.updateGraph(selectedGraph);
		if ((selectedGraph != null) && (getRowCount() > 1)) {
		    // need to highlight one of the connected components
		    interactionGraph.highlightAndFade(selectedGraph
			    .getConnectedNodes());
		}
	    }
	}
    }

    public void reset() {
	tableModel.reset();
    }

    public void setData(final NetworkGraph networkGraph) {
	tableModel.setData(networkGraph);
    }

    enum GraphMetricsTableModelColumns {
	ATTRIBUTE, SCORE, INITIAL_PROBABILITY, CURRENT_PROBABILITY
    }

    private class GraphMetricTableModel extends DefaultTableModel {

	private static final long serialVersionUID = 1L;

	// @Override
	// public Class<?> getColumnClass(final int columnIndex) {
	// Class<?> classVar;
	// if (columnIndex == GraphMetricsTableModelColumns.ATTRIBUTE
	// .ordinal()) {
	// classVar = String.class;
	// } else {
	// classVar = Double.class;
	// }
	// return classVar;
	// }

	@Override
	public Object getValueAt(final int row, final int column) {
	    final Object value = super.getValueAt(row, column);
	    if (value instanceof Number) {
		return Main.decimalUpToFourPrecision.format(value);
	    } else {
		return value;
	    }
	}

	// @Override
	// public int getColumnCount() {
	// return GraphMetricsTableModelColumns.values().length;
	// }
	//
	// @Override
	// public String getColumnName(final int columnIndex) {
	// String returnValue = null;
	// switch (GraphMetricsTableModelColumns.values()[columnIndex]) {
	// case ATTRIBUTE:
	// returnValue = "Attribute";
	// break;
	// case SCORE:
	// returnValue = "Score";
	// break;
	// case INITIAL_PROBABILITY:
	// returnValue = "Initial Probability";
	// break;
	// case CURRENT_PROBABILITY:
	// returnValue = "Current Probability";
	// break;
	// default:
	// throw new RuntimeException("Unexpected column: " + columnIndex);
	// // break;
	// } // end switch
	// return returnValue;
	// }
	//
	// @Override
	// public int getRowCount() {
	// return size();
	// }
	//
	// @Override
	// public Object getValueAt(final int rowIndex, final int columnIndex) {
	// Object returnValue = null;
	// final Attribute expertKnowledgeAttribute = get(rowIndex);
	// switch (GraphMetricsTableModelColumns.values()[columnIndex]) {
	// case ATTRIBUTE:
	// returnValue = expertKnowledgeAttribute.getLabel();
	// break;
	// case SCORE:
	// returnValue = expertKnowledgeAttribute.getScore();
	// break;
	// case INITIAL_PROBABILITY:
	// returnValue = expertKnowledgeAttribute
	// .getScaledAndWeightedScore();
	// break;
	// case CURRENT_PROBABILITY:
	// if (attributeAdjustments == null) {
	// returnValue = Double.NaN;
	// } else {
	// final AttributeFitnessData attributeFitnessData =
	// attributeAdjustments
	// .get(expertKnowledgeAttribute.index);
	// if (attributeFitnessData == null) {
	// returnValue = Double.NaN;
	// } else {
	// returnValue = attributeFitnessData.normalizedAdjustedWeight;
	// }
	// }
	// break;
	// default:
	// throw new RuntimeException("Unexpected column: " + columnIndex);
	// // break;
	// } // end switch
	// return returnValue;
	// }

	@Override
	public boolean isCellEditable(final int row, final int col) {
	    return false;
	}

	public void reset() {
	    setRowCount(0);
	    nodeMetricsTable.updateGraph(null);
	}

	public void setData(final NetworkGraph networkGraph) {
	    int selectedRowIndex = getSelectedRow();
	    setNumRows(0);
	    connectedComponents.clear();
	    setColumnIdentifiers(networkGraph.getGraphSummaryColumnNames());
	    final SortedSet<NetworkGraph> allSubGraphs = networkGraph
		    .getAllSubgraphs();
	    if (allSubGraphs.isEmpty()) {
		if (networkGraph.getNumConnectedNodes() > 0) {
		    addRow(networkGraph.getGraphSummaryRow());
		    connectedComponents.add(networkGraph);
		}
	    } else {
		// sb.append(subGraphsDistributionToString(allSubGraphs));
		for (final NetworkGraph subGraph : allSubGraphs) {
		    addRow(subGraph.getGraphSummaryRow());
		    connectedComponents.add(subGraph);
		} // end for all subgraphs
	    } // end if more than one connectedComponent
	    if (getRowCount() > 0) {
		if (selectedRowIndex == -1) {
		    selectedRowIndex = 0;
		} else {
		    selectedRowIndex = Math.min(getRowCount() - 1,
			    selectedRowIndex);
		}
		setRowSelectionInterval(selectedRowIndex, selectedRowIndex);
	    } else {
		changeSelectedRow();
	    }
	}

    } // end GraphMetricTableModel
} // end GraphMetricsTable
