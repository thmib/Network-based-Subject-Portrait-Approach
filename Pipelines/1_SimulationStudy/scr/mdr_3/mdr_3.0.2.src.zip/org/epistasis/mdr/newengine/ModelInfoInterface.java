package org.epistasis.mdr.newengine;

import java.text.NumberFormat;

public interface ModelInfoInterface {

    String[] asStringArray();

    String[] asStringArray(NumberFormat numberFormatter);

    float getAdjustedTesting();

    ConfusionMatrix getAggregateTestingConfusionMatrix();

    float getAggregateTestingFitness();

    ConfusionMatrix getAverageTrainingConfusionMatrix();

    float getAverageTrainingFitness();

    ConfusionMatrix getCVAggregateTestingConfusionMatrix();

    float getCVAggregateTestingFitness();

    ConfusionMatrix getCVAverageTrainingConfusionMatrix();

    float getCVAverageTrainingFitness();

    int getCVC();

    String[] getHeaders();

    Model getModel();

    String getModelName();

    float getModelWinnersAggregateTestingFitness();

    int getNumCrossValidations();

    ConfusionMatrix getOverallConfusionMatrix();

    float getOverallFitness();

    float getPrimaryFitnessCriterionValue();

    boolean hasTesting();

    int size();

}