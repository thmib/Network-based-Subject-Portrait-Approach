package org.epistasis.mdr.api;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.epistasis.Utility;
import org.epistasis.mdr.Main;
import org.epistasis.mdr.enums.FitnessCriteriaOrder;
import org.epistasis.mdr.enums.MdrTableColumnName;
import org.epistasis.mdr.newengine.ModelInfoInterface;
import org.epistasis.mdr.newengine.ModelInfoInterfaceComparator;

public class PermutationResults {

    private static final String RANK_PLACEHOLDER = "=====>";
    private final List<List<ModelInfoInterface>> permutations;
    private final List<ModelInfoInterface> bestModelForEachPermutation;

    private final List<ModelInfoInterface> unpermutedAnalysisLevelResults;

    private ModelInfoInterfaceComparator interLevelComparator;

    public PermutationResults(
	    final FitnessCriteriaOrder permutationFitnessCriteriaOrder,
	    final List<ModelInfoInterface> unpermutedAnalysisLevelResults) {
	this.unpermutedAnalysisLevelResults = unpermutedAnalysisLevelResults;
	permutations = new ArrayList<List<ModelInfoInterface>>(1000);
	bestModelForEachPermutation = new ArrayList<ModelInfoInterface>(1000);
	setFitnessCriteriaOrder(permutationFitnessCriteriaOrder);
    }

    public void addPermutationResult(final List<ModelInfoInterface> levelResults) {
	permutations.add(levelResults);
	bestModelForEachPermutation
		.add(getBestModelOfWinningLevel(levelResults));
    }

    private ModelInfoInterface getBestModelOfWinningLevel(
	    final List<ModelInfoInterface> levelResults) {
	return MDRResult.getBestModelOfWinningLevel(levelResults,
		interLevelComparator);
    }

    public int getNumPermutations() {
	return bestModelForEachPermutation.size();
    }

    public List<List<ModelInfoInterface>> getPermutations() {
	return Collections.unmodifiableList(permutations);
    }

    /**
     * 
     * @param modelToEstablishPValueFor
     * @return either a one or two item list
     */
    public synchronized List<Float> getPValueRange(
	    final ModelInfoInterface modelToEstablishPValueFor) {
	final List<Float> pValueRange = new ArrayList<Float>(2);

	assert modelToEstablishPValueFor != null;

	final List<ModelInfoInterface> sortedPermutationResults = new ArrayList<ModelInfoInterface>(
		bestModelForEachPermutation);
	sortedPermutationResults.add(modelToEstablishPValueFor);
	Collections.sort(sortedPermutationResults, interLevelComparator);

	// there may be multiple items with the same score so need to
	// determine range of the p-value

	// need a comparator that can identify ties. Normally, in order to
	// make all sorts fully deterministic I make all
	// comparators detailed enough that two different objects will
	// always be seen as different. In the case of Models, the last
	// fitnessCriterion is MODEL_ATTRIBUTES since these are guaranteed
	// to differ between models. I now make a comparator with that last
	// tie breaker criterion removed so we can identify results with
	// same scores as original
	int minIndex = sortedPermutationResults
		.indexOf(modelToEstablishPValueFor);
	int maxIndex = minIndex;
	final ModelInfoInterfaceComparator tieComparator = new ModelInfoInterfaceComparator(
		FitnessCriteriaOrder
			.stripFinalModelAttributesFitnessCriterion(interLevelComparator
				.getFitnessCriteriaOrder()));
	for (int index = minIndex - 1; index >= 0; --index) {
	    final int compareResult = tieComparator.compare(
		    modelToEstablishPValueFor,
		    sortedPermutationResults.get(index));
	    assert compareResult >= 0 : "originalBestResult was found to be better than a better ranked item from permutationResults which should be impossible";
	    if (compareResult == 0) {
		// the items are tied -- need to keep looking
		minIndex = index;
	    } else {
		// found a better item so stop looking above
		break;
	    }
	} // end looking for tied items above original item

	for (int index = maxIndex + 1; index < sortedPermutationResults.size(); ++index) {
	    final int compareResult = tieComparator.compare(
		    modelToEstablishPValueFor,
		    sortedPermutationResults.get(index));
	    assert compareResult <= 0 : "originalBestResult was found to be worse than a worse ranked item from permutationResults which should be impossible";
	    if (compareResult == 0) {
		// the items are tied -- need to keep looking
		maxIndex = index;
	    } else {
		// found a worse item so stop looking below
		break;
	    }
	} // end looking for tied items below original item

	// now make pValues. pValues is based on rank rather than indices so
	// we add one to min and max index
	final Float minBound = (minIndex + 1)
		/ (float) sortedPermutationResults.size();
	pValueRange.add(minBound);
	if (minIndex != maxIndex) {
	    final Float maxBound = (maxIndex + 1)
		    / (float) sortedPermutationResults.size();
	    pValueRange.add(maxBound);
	}
	return pValueRange;
    }

    public List<ModelInfoInterface> getSortedPermutationBestModels() {
	Collections.sort(bestModelForEachPermutation, interLevelComparator);
	return bestModelForEachPermutation;
    }

    public List<ModelInfoInterface> getUnpermutedAnalysisLevelResults() {
	return Collections.unmodifiableList(unpermutedAnalysisLevelResults);
    }

    public void printReport(final PrintStream outPrintStream) {
	final List<ModelInfoInterface> sortedPermutationResults = new ArrayList<ModelInfoInterface>(
		bestModelForEachPermutation);
	if (unpermutedAnalysisLevelResults != null) {
	    sortedPermutationResults.addAll(unpermutedAnalysisLevelResults);
	}
	Collections.sort(sortedPermutationResults, interLevelComparator);
	outPrintStream.println(MdrTableColumnName.RANK.capitalized()
		+ '\t'
		+ Utility.join(sortedPermutationResults.get(0).getHeaders(),
			'\t'));
	int rankCtr = 1;
	for (final ModelInfoInterface permutationResult : sortedPermutationResults) {
	    String rankString;
	    if ((unpermutedAnalysisLevelResults != null)
		    && unpermutedAnalysisLevelResults
			    .contains(permutationResult)) {
		rankString = PermutationResults.RANK_PLACEHOLDER;
	    } else {
		rankString = String.valueOf(rankCtr++);
	    }
	    outPrintStream.println(rankString
		    + '\t'
		    + Utility.join(permutationResult
			    .asStringArray(Main.decimalManyPrecision), '\t'));
	}
	outPrintStream.println();

	outPrintStream.println("For " + getNumPermutations()
		+ " permutations, best models picked using "
		+ interLevelComparator.getFitnessCriteriaOrder());
	outPrintStream.println();

	if ((unpermutedAnalysisLevelResults != null)
		&& (unpermutedAnalysisLevelResults.size() > 0)) {

	    outPrintStream.println(MdrTableColumnName.PVALUE.capitalized()
		    + "\t"
		    + Utility.join(unpermutedAnalysisLevelResults.get(0)
			    .getHeaders(), '\t'));
	    for (final ModelInfoInterface modelInfo : unpermutedAnalysisLevelResults) {
		outPrintStream.println(Utility.join(getPValueRange(modelInfo),
			'-', Main.decimalUpToFourPrecision)
			+ '\t'
			+ Utility.join(modelInfo.asStringArray(), '\t'));
	    }
	    outPrintStream.println();
	}
    }

    public void setFitnessCriteriaOrder(
	    final FitnessCriteriaOrder permutationFitnessCriteriaOrder) {
	interLevelComparator = new ModelInfoInterfaceComparator(
		permutationFitnessCriteriaOrder);
    }

}
