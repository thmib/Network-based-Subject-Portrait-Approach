package org.epistasis.mdr.filters;

import java.util.List;
import java.util.Map;
import java.util.Random;

import org.epistasis.mdr.enums.FilterMethod;
import org.epistasis.mdr.newengine.Dataset;

public class MultiSURFAttributeScorer extends ReliefFAttributeScorer {
    public MultiSURFAttributeScorer(final Dataset data, final Random random,
	    final boolean parallel) {
	this(data, random, parallel, null);
    }

    public MultiSURFAttributeScorer(final Dataset data, final Random random,
	    final boolean parallel, final Runnable onIncrementProgress) {
	super(data, data.getRows(), 0, random, parallel, onIncrementProgress);

    }

    @Override
    protected void calculateInstanceDifferences() {
	calculateInstanceDifferences(true /* calculateIndividualDistanceAverages */);
    }

    @Override
    protected Map<Byte, List<Integer>> computeNeighborhood(
	    final Integer instanceIndex) {
	throw new RuntimeException(
		"ComputeNeighborhood should never be called for multiSURF");
    } // end computeNeighborhood()

    @Override
    String getFilterName() {
	return FilterMethod.MULTISURF.name();
    }

    @Override
    int getNormalizationFactor() {
	return 1;
    }

    @Override
    protected void processInstance(final int idx) {
	final byte instanceStatus = getData().getRawDatum(idx, numAttributes);
	final long[] neighborhoodAttributeSameClassDifferenceSums = new long[numAttributes];
	final long[] neighborhoodAttributeSameClassAgreementSums = new long[numAttributes];
	final long[] neighborhoodAttributeDifferentClassDifferenceSums = new long[numAttributes];
	final long[] neighborhoodAttributeDifferentClassAgreementSums = new long[numAttributes];
	for (final Map.Entry<Byte, List<Integer>> statusAndNeighborhood : instByClass
		.entrySet()) {
	    final byte neighborStatus = statusAndNeighborhood.getKey();
	    final boolean isSameClass = (neighborStatus == instanceStatus);
	    final List<Integer> neighborhoodIndices = statusAndNeighborhood
		    .getValue();
	    final double closeThresholdDistance = individualAverageDistances[idx]
		    - individualDeadBandDistances[idx];
	    final double farThresholdDistance = individualAverageDistances[idx]
		    + individualDeadBandDistances[idx];
	    for (final int neighborIndex : neighborhoodIndices) {
		// if idx > neighborIndex can skip since we will check the
		// relation since all
		// we sample all rows
		if (idx < neighborIndex) {
		    final double distance = distance(idx, neighborIndex);
		    int delta = 0;
		    final boolean closeNeighbor = distance < closeThresholdDistance;
		    final boolean distantNeighbor = distance > farThresholdDistance;
		    if (closeNeighbor) {
			delta = 1;
		    } else if (distantNeighbor) {
			delta = -1;
		    }
		    if (delta != 0) {
			for (int attributeIndex = 0; attributeIndex < numAttributes; ++attributeIndex) {
			    final boolean attributeHasSameValue = getData()
				    .getRawDatum(idx, attributeIndex) == getData()
				    .getRawDatum(neighborIndex, attributeIndex);
			    // basic idea is that when distance of neighbor
			    // greater than average distance
			    // reverse the weighting
			    if (attributeHasSameValue) {
				// if (closeNeighbor)
				{
				    if (isSameClass) {
					neighborhoodAttributeSameClassAgreementSums[attributeIndex] += delta;
				    } else {
					neighborhoodAttributeDifferentClassAgreementSums[attributeIndex] += delta;
				    }
				}
			    } else { // attribute has different value
				     // if (distantNeighbor)
				{
				    if (isSameClass) {
					neighborhoodAttributeSameClassDifferenceSums[attributeIndex] += delta;
				    } else {
					neighborhoodAttributeDifferentClassDifferenceSums[attributeIndex] += delta;
				    }
				}
			    } // end if attribute has different value
			} // end attribute loop
		    } // end if distance not exactly equal to average distance
		} // end if low enough index that it wasn't skipped
	    } // end neighbor loop
	} // end status loop
	  // totalAttributeSameClassDifferenceSums and
	  // totalAttributeDifferentClassDifferenceSums are member variables
	  // written to simultaneously
	  // by many threads so need to synchronize
	synchronized (this) {
	    for (int attributeIndex = 0; attributeIndex < totalAttributeSameClassDifferenceSums.length; ++attributeIndex) {
		totalAttributeSameClassDifferenceSums[attributeIndex] += neighborhoodAttributeSameClassDifferenceSums[attributeIndex];
		totalAttributeSameClassAgreementSums[attributeIndex] += neighborhoodAttributeSameClassAgreementSums[attributeIndex];
		totalAttributeDifferentClassDifferenceSums[attributeIndex] += neighborhoodAttributeDifferentClassDifferenceSums[attributeIndex];
		totalAttributeDifferentClassAgreementSums[attributeIndex] += neighborhoodAttributeDifferentClassAgreementSums[attributeIndex];
		// diffWeights[attributeIndex] =
		// (totalAttributeSameClassDifferenceSums[attributeIndex] -
		// totalAttributeDifferentClassDifferenceSums[attributeIndex]);
	    } // end for attributes
	} // end synchronized
    } // end processInstance
} // end MultiSURFAttributeScorer
