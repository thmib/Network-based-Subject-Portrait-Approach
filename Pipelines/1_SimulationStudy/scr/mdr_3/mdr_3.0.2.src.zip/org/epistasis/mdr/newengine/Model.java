package org.epistasis.mdr.newengine;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.WeakHashMap;

import org.apache.commons.math3.exception.NumberIsTooSmallException;
import org.apache.commons.math3.stat.descriptive.SummaryStatistics;
import org.apache.commons.math3.stat.inference.TestUtils;
import org.epistasis.Pair;
import org.epistasis.Utility;
import org.epistasis.customApacheCommonsMath.OneWayAnovaForStatisticalSummaryValuesWithSumSq;
import org.epistasis.customApacheCommonsMath.StatisticalSummaryValuesWithSumSq;
import org.epistasis.mdr.AmbiguousCellStatus;
import org.epistasis.mdr.Console;
import org.epistasis.mdr.Main;
import org.epistasis.mdr.enums.ContinuousEndpointSignificanceMetric;
import org.epistasis.mdr.enums.DiscreteEndpointSignificanceMetric;

import edu.northwestern.at.utils.math.matrix.MatrixFactory;
import edu.northwestern.at.utils.math.statistics.ContingencyTable;

public class Model implements Comparable<Model> {
    public final static WeakHashMap<String, Double> fisherExactResultsCache = new WeakHashMap<String, Double>();
    public static final byte UNKNOWN_STATUS = (byte) 255;
    public static final byte MISSING_DATA = Model.UNKNOWN_STATUS;
    public static final byte INVALID_STATUS = (byte) 254;
    private final AmbiguousCellStatus tieStatus;
    private final AttributeCombination combo;
    private final static Comparator<byte[]> byteArrayComparator = new Comparator<byte[]>() {
	@Override
	public int compare(final byte[] o1, final byte[] o2) {
	    if (o1.length != o2.length) {
		throw new RuntimeException(
			"byte arrays are not the same length! first: "
				+ Arrays.toString(o1) + " second: "
				+ Arrays.toString(o2));
	    }
	    int comparisonResult = 0;
	    for (int index = 0; index < o1.length; ++index) {
		comparisonResult = o1[index] - o2[index];
		if (comparisonResult != 0) {
		    break;
		}
	    }
	    return comparisonResult;
	}
    };
    private static final DecimalFormat plainNumberFormat = new DecimalFormat(
	    "0.####");
    public static final Model EMPTY = new Model(AttributeCombination.EMPTY,
	    AmbiguousCellStatus.UNCLASSIFIED);
    static {
	Model.plainNumberFormat.setDecimalSeparatorAlwaysShown(false);
    }

    private final boolean keepDichotomousCountsForContinuousData = true;

    static long fishersExactCacheSuccessCount = 0;

    static long fishersExactCacheFailureCount = 0;

    public Model(final AttributeCombination combo,
	    final AmbiguousCellStatus tieStatus) {
	this.tieStatus = tieStatus;
	this.combo = combo;
    }

    public SortedMap<byte[], Cell> buildCounts(final Dataset data) {
	return buildCounts(data, null);
    }

    public SortedMap<byte[], Cell> buildCounts(final Dataset data,
	    SortedMap<byte[], Cell> cells) {
	// System.err.println("buildCounts called on " + toString());
	// System.err.flush();
	if (cells != null) {
	    for (final Model.Cell c : cells.values()) {
		if (c != null) {
		    c.resetCounts();
		}
	    }
	} else {
	    cells = new TreeMap<byte[], Cell>(Model.byteArrayComparator);
	}
	if (data.hasContinuousEndpoints()) {
	    buildCountsContinuousEndpoints(data, cells);
	} else {
	    buildCountsDiscreteEndpoints(data, cells);
	} // end if discrete data
	return cells;
    } // end buildCounts

    private void buildCountsContinuousEndpoints(final Dataset data,
	    final SortedMap<byte[], Cell> cells) {
	/**
	 * for continuous data we don't know it is not possible to make a
	 * standard confusion matrix because that uses discrete data and the
	 * concept of what a cell's 'true' status is. We can fake this by
	 * assigning a row's status by whether its continuous endpoint is above
	 * or below the median or mean value for the whole dataset -- in other
	 * words -- dichotomize the data set.
	 */
	double datasetEndpointAverage = Double.NaN;
	if (keepDichotomousCountsForContinuousData) {
	    datasetEndpointAverage = data.getAverageEndpoint();
	} // end if keepingCounts
	final int[] attributeIndices = combo.getAttributeIndices();
	for (int rowIndex = data.getRows() - 1; rowIndex >= 0; --rowIndex) {
	    final Dataset.RowData rowData = data.getRowData(rowIndex);
	    final byte[] rowSlice = data
		    .getRowSlice(rowIndex, attributeIndices);
	    ContinuousEndpointCell c = (ContinuousEndpointCell) cells
		    .get(rowSlice);
	    if (c == null) {
		c = new ContinuousEndpointCell();
		cells.put(rowSlice, c);
	    }
	    final double endpointValue = rowData.getEndpoint();
	    c.addValue(endpointValue);
	    if (keepDichotomousCountsForContinuousData) {
		// use whether the point is less than or greater than/equal to
		// the dataset average value as
		// a semi-arbitrary way to decide if status is 0 (<) or 1 (>1)
		final byte status = (byte) ((endpointValue < datasetEndpointAverage) ? 0
			: 1);
		rowData.setStatus(status);
		++c.counts[status];
		c.weightedCounts[status] += data.getRowWeight(rowIndex);
	    } // end if keepCounts
	} // end row loop
    } // end buildsCountContinuousEndpoints

    public void buildCountsDiscreteEndpoints(final Dataset data,
	    final SortedMap<byte[], Cell> cells) {

	final int statusColIndex = data.getStatusColIndex();
	final byte nStatus = data.getNumStatuses();
	final int[] attributeIndices = combo.getAttributeIndices();
	for (int rowIndex = 0; rowIndex < data.getRows(); ++rowIndex) {
	    final byte status = data.getRawDatum(rowIndex, statusColIndex);
	    final byte[] rowSlice = data
		    .getRowSlice(rowIndex, attributeIndices);
	    Cell c = cells.get(rowSlice);
	    if (c == null) {
		c = new Cell(nStatus, data.getAffectedStatus());
		cells.put(rowSlice, c);
	    }
	    ++c.counts[status];
	    c.weightedCounts[status] += data.getRowWeight(rowIndex);
	} // end row loop
    }

    private void buildStatusContinuousEndpoints(final Dataset data,
	    final int[] statusCounts, final SortedMap<byte[], Cell> cells) {
	final double datasetMean = data.getAverageEndpoint();
	final boolean printDebug = false;// getCombo().toString().equals("P1 P2");
	for (final Model.Cell c : cells.values()) {
	    if (c != null) {
		final ContinuousEndpointCell continuousEndpointCell = (ContinuousEndpointCell) c;
		final double cellContinuousEndpointsMean = continuousEndpointCell
			.getMean();

		final int compareResult = Double.compare(
			cellContinuousEndpointsMean, datasetMean);
		if (compareResult < 0) {
		    continuousEndpointCell.status = continuousEndpointCell
			    .getUnaffectedStatus();
		} else if (compareResult >= 0) {
		    continuousEndpointCell.status = continuousEndpointCell
			    .getAffectedStatus();
		}
		if (printDebug) {
		    System.out.println("dataset mean: " + datasetMean
			    + " cell mean: " + cellContinuousEndpointsMean
			    + " status set to: "
			    + continuousEndpointCell.status);
		}
	    } // end if cell not null
	} // end cell loop
    } // buildStatusContinuousEndpoints

    public void buildStatuses(final Dataset data, final int[] statusCounts,
	    final SortedMap<byte[], Cell> cells) {
	// System.out.println("buildStatuses called with dataset identity "
	// + System.identityHashCode(data));
	if (data.hasContinuousEndpoints()) {
	    buildStatusContinuousEndpoints(data, statusCounts, cells);
	} else {
	    buildStatusesDiscreteEndpoints(data, statusCounts, cells);
	}
    }

    public void buildStatusesDiscreteEndpoints(final Dataset data,
	    final int[] statusCounts, final SortedMap<byte[], Cell> cells) {
	final byte affectedStatus = data.getAffectedStatus();
	final byte unaffectedStatus = data.getUnaffectedStatus();
	final float affectedUnaffectedRatio = statusCounts[affectedStatus]
		/ (float) statusCounts[unaffectedStatus];
	final String missing = data.getMissing();
	for (final Map.Entry<byte[], Cell> entry : cells.entrySet()) {
	    final Cell cell = entry.getValue();
	    // if any of the attributes are missing then cell status must be set
	    // to unknown
	    // Unknown status cells will be later used in confusion matrix to
	    // calculate coverage
	    // and lower the fitness of the model
	    boolean statusAlreadySet = false;
	    final byte[] attributeLevelIndices = entry.getKey();
	    // support for missing data is still experimental because of the
	    // issue about how fitness should be adjusted for unclassifiable
	    // data
	    if (Main.isExperimental) {
		// this is probably slow, especially since it has string
		// comparisons
		for (int index = 0; index < combo.size(); ++index) {
		    final int attributeIndex = combo.get(index);
		    final List<String> attributeLevels = data.getLevels().get(
			    attributeIndex);
		    final byte attributeLevelIndex = attributeLevelIndices[index];
		    // can use object comparison == instead of String.equals
		    // here because
		    // Dataset read code makes sure all missing values use
		    // missing string object
		    if (attributeLevels.get(attributeLevelIndex) == missing) {
			cell.status = Model.MISSING_DATA; /*
							   * MISSING_DATA is the
							   * same as
							   * UNKNOWN_STATUS
							   */
			statusAlreadySet = true;
			continue;
		    }
		}
	    } // end if experimental
	    if (!statusAlreadySet) {
		// if (c == null) {
		// continue;
		// }
		// code below in new as of 2008-10-20 and was not in mdr alpha
		// 2.0
		final float affected = cell.counts[affectedStatus];
		final float unaffected = cell.counts[unaffectedStatus];
		// Need to adjust the counts for imbalances so that we can
		// determine cell status
		// Also wish to keep the total of the count unchanged -- this is
		// needed if we do a fisher's test for significance since we
		// don't
		// wish
		// to change the quantities which would change the significance
		final byte status = determineCellStatus(affectedStatus,
			unaffectedStatus, affectedUnaffectedRatio, affected,
			unaffected);
		cell.status = status;
	    } // end if !statusAlreadySet
	} // end cell loop
    } // end buildStatusesDiscreteEndpoints()

    @Override
    public int compareTo(final Model o) {
	return combo.compareTo(o.combo);
    }

    public List<String> constructAttribute(final Dataset data) {
	final byte[] raw = constructRawAttribute(data);
	final List<String> attribute = new ArrayList<String>(raw.length);
	final int statusCol = data.getCols() - 1;
	for (final byte status : raw) {
	    if (status == Model.MISSING_DATA) {
		attribute.add(data.getMissing());
	    } else {
		attribute.add(data.getLevels().get(statusCol).get(status));
	    }
	}
	return attribute;
    }

    /**
     * Create a new 'constructed' attribute for the combination of this Model
     * 
     * @param data
     * @return
     */
    public byte[] constructRawAttribute(final Dataset data) {
	final SortedMap<byte[], Cell> cells = buildCounts(data);
	buildStatuses(data, data.getStatusCounts(), cells);
	final byte[] attribute = new byte[data.getRows()];
	for (int i = 0; i < data.getRows(); ++i) {
	    final byte[] rowSlice = data.getRowSlice(i,
		    combo.getAttributeIndices());
	    final Model.Cell c = cells.get(rowSlice);
	    if (c != null) {
		attribute[i] = c.getStatus();
	    } else {
		attribute[i] = Model.UNKNOWN_STATUS;
	    }
	} // end row loop
	return attribute;
    }

    public byte determineCellStatus(final byte affectedStatus,
	    final byte unaffectedStatus, final float affectedUnaffectedRatio,
	    final float affected, final float unaffected) {
	final float totalInCell = affected + unaffected;
	final float proportionalUnaffected = unaffected
		* affectedUnaffectedRatio;
	final float reductionRatio = totalInCell
		/ (proportionalUnaffected + affected);
	final float normalizedUnaffected = proportionalUnaffected
		* reductionRatio;
	final float normalizedAffected = totalInCell - normalizedUnaffected;
	// System.out.println(" original affected: " + affected +
	// "+           unaffected: " + unaffected + "=" + (affected +
	// unaffected)
	// + "\nnormalizedAffected: " + normalizedAffected +
	// "+ normalizedUnaffected: " + normalizedUnaffected + "="
	// + (normalizedAffected + normalizedUnaffected + "\n"));
	byte status;
	boolean isSignificantDifference = Float.compare(normalizedAffected,
		normalizedUnaffected) != 0;
	double twoTailedFisherExact = Double.NaN;
	// look for tie
	// EXPERIMENTAL
	if (isSignificantDifference && !Double.isNaN(Console.fishersThreshold)
		&& (Console.fishersThreshold != 1.0f)) {
	    final edu.northwestern.at.utils.math.matrix.Matrix matrix = MatrixFactory
		    .createMatrix(2, 2);
	    matrix.set(1, 1, normalizedAffected);
	    matrix.set(1, 2, normalizedUnaffected);
	    matrix.set(2, 1, normalizedUnaffected);
	    matrix.set(2, 2, normalizedAffected);
	    // double vector with three entries. [0] = two-sided Fisher's exact
	    // test. [1] = left-tail Fisher's exact test. [2] =
	    // right-tail
	    // Fisher's exact test.
	    twoTailedFisherExact = getFishersExactTwoTailedResult(matrix);
	    isSignificantDifference = twoTailedFisherExact <= Console.fishersThreshold;
	} // end if doing fisher test
	if (isSignificantDifference) {
	    if (normalizedAffected > normalizedUnaffected) {
		status = affectedStatus;
	    } else {
		status = unaffectedStatus;
	    }
	} else { // not significant so consider a tie
	    switch (tieStatus) {
	    case AFFECTED:
		status = affectedStatus;
		break;
	    case UNAFFECTED:
		status = unaffectedStatus;
		break;
	    case UNCLASSIFIED:
		status = Model.UNKNOWN_STATUS;
		break;
	    default:
		throw new RuntimeException(
			"Unhandled AmbiguousCellAssgnmentType: "
				+ tieStatus.toString());
	    }
	}
	return status;
    } // end determineCellStatus

    public AggregatedTestingData getAggregatedTestingDataForContinuousEndpoints(
	    final Dataset data,
	    final SortedMap<byte[], Cell> cells,
	    final ContinuousEndpointSignificanceMetric continuousEndpointSignificanceMetric) {
	if (!data.hasContinuousEndpoints()) {
	    throw new RuntimeException(
		    "getAggregatedTestingDataForContinuousEndpoints called when there is discrete data");
	}
	AggregatedTestingData continuousEndpointsSignificanceTestingData = null;
	final Map<String, Collection<SummaryStatistics>> summaryStatisticsListOfLists = new HashMap<String, Collection<SummaryStatistics>>();
	switch (continuousEndpointSignificanceMetric) {
	case TTEST: {
	    final Collection<SummaryStatistics> affectedEndpointsList = new ArrayList<SummaryStatistics>();
	    final Collection<SummaryStatistics> unaffectedEndpointsList = new ArrayList<SummaryStatistics>();
	    summaryStatisticsListOfLists
		    .put(Dataset.ABOVE_AVERAGE_OR_EQUAL_CLASS,
			    affectedEndpointsList);
	    summaryStatisticsListOfLists.put(Dataset.BELOW_AVERAGE_CLASS,
		    unaffectedEndpointsList);
	    for (final Entry<byte[], Cell> pair : cells.entrySet()) {
		final ContinuousEndpointCell cell = (ContinuousEndpointCell) pair
			.getValue();
		final SummaryStatistics cellSummaryStatistics = cell
			.getSummaryStatistics();
		if (cellSummaryStatistics.getN() > 0) {
		    final byte predictedStatus = cell
			    .getPredictedStatus(tieStatus);
		    if (predictedStatus == cell.affectedStatus) {
			affectedEndpointsList.add(cellSummaryStatistics);
		    } else {
			unaffectedEndpointsList.add(cellSummaryStatistics);
		    }
		} // end if cell has non-zero items
	    } // end for cells
	      // assert affectedEndpointsList.size() > 0 :
	      // "affectedEndpointsList.size() > 0";
	      // assert unaffectedEndpointsList.size() > 0 :
	      // "unaffectedEndpointsList.size() > 0";
	} // end case TTEST
	    break;
	case ANOVA: {
	    final int[] attr = getCombo().getAttributeIndices();
	    for (final Entry<byte[], Cell> pair : cells.entrySet()) {
		final ContinuousEndpointCell cell = (ContinuousEndpointCell) pair
			.getValue();
		final SummaryStatistics cellSummaryStatistics = cell
			.getSummaryStatistics();
		if (cellSummaryStatistics.getN() > 0) {
		    // we need a list of lists so need to make a list even
		    // though
		    // there is always just one item
		    final Collection<SummaryStatistics> summaryStatisticsList = new ArrayList<SummaryStatistics>(
			    Arrays.asList(cellSummaryStatistics));
		    // use the attribute combination values as the key
		    final byte[] rowSlice = pair.getKey();
		    final String[] attributes = data.getAttributeValues(attr,
			    rowSlice);
		    summaryStatisticsListOfLists.put(
			    Utility.join(attributes, ','),
			    summaryStatisticsList);
		} // end if cell has non-zero items
	    } // end genotype loop
	} // end case ANOVA
	    break;
	default:
	    throw new RuntimeException(
		    "Unhandled Console.console.continuousSignificanceMetric: "
			    + Console.console
				    .getContinuousEndpointSignificanceMetric());
	} // end switch
	assert !summaryStatisticsListOfLists.isEmpty() : "!summaryStatisticsListOfLists.isEmpty()";
	continuousEndpointsSignificanceTestingData = new AggregatedTestingData(
		summaryStatisticsListOfLists);
	return continuousEndpointsSignificanceTestingData;
    } // end getContinuousEndpointsSignificanceTestingData

    public AttributeCombination getCombo() {
	return combo;
    }

    public double getConditionalEntropy(final Dataset data) {
	double conditionalEntropy = 0;
	final double numRows = data.getRows();
	final byte nStatus = data.getNumStatuses();
	final int[] statusCounts = data.getStatusCounts();
	final SortedMap<byte[], Cell> cells = buildCounts(data);

	for (byte status = 0; status < nStatus; ++status) {
	    double entropyWithinStatusRows = 0;
	    final int statusCount = statusCounts[status];
	    for (final Cell cell : cells.values()) {
		final float genotypeCountForThisStatus = cell.getCounts()[status];
		if (genotypeCountForThisStatus > 0.0) {
		    final double genotypeProbability = genotypeCountForThisStatus
			    / statusCount;
		    entropyWithinStatusRows -= (genotypeProbability * Math
			    .log(genotypeProbability)) / Math.log(2);
		}
	    } // end loop over genotypes
	    final double fractionOfTotalRows = statusCount / numRows;
	    final double statusContributionToOverallConditionalEntropy = entropyWithinStatusRows
		    * fractionOfTotalRows;
	    conditionalEntropy += statusContributionToOverallConditionalEntropy;
	} // end loop over statuses
	return conditionalEntropy;
    }

    public double getEntropy(final Dataset data) {
	double entropy = 0;
	final double numRows = data.getRows();
	final SortedMap<byte[], Cell> cells = buildCounts(data);
	for (final Cell cell : cells.values()) {
	    final double genotypeProbability = cell.getTotalCount() / numRows;
	    entropy -= (genotypeProbability * Math.log(genotypeProbability))
		    / Math.log(2);
	}
	return entropy;
    }

    private double getFishersExactTwoTailedResult(
	    final edu.northwestern.at.utils.math.matrix.Matrix matrix) {
	final String matrixKey = matrix.toString();
	Double twoTailedResult = Model.fisherExactResultsCache.get(matrixKey);
	if (twoTailedResult == null) {
	    Model.fishersExactCacheFailureCount++;
	    synchronized (Model.fisherExactResultsCache) {
		twoTailedResult = Model.fisherExactResultsCache.get(matrixKey);
		if (twoTailedResult == null) {

		    twoTailedResult = ContingencyTable.fishersExactTest(matrix)[0];
		    Model.fisherExactResultsCache.put(matrixKey,
			    twoTailedResult);
		}
	    }
	} else {
	    ++Model.fishersExactCacheSuccessCount;
	}
	// if (((Model.fishersExactCacheFailureCount +
	// Model.fishersExactCacheSuccessCount) % 500) == 0) {
	// System.out
	// .println("fisher exact cache hit rate: "
	// + Model.fishersExactCacheSuccessCount
	// + "/"
	// + (Model.fishersExactCacheSuccessCount +
	// Model.fishersExactCacheFailureCount)
	// + " or "
	// + Main.decimalUpToTwoPrecision
	// .format((Model.fishersExactCacheSuccessCount * 100.0)
	// / (Model.fishersExactCacheSuccessCount +
	// Model.fishersExactCacheFailureCount))
	// + "%");
	// }
	return twoTailedResult;
    }

    public byte getGenotypePredictedStatus(final SortedMap<byte[], Cell> cells,
	    final byte[] rowSlice) {
	final Model.Cell c = cells.get(rowSlice);
	byte predictedStatus;
	if (c == null) {
	    predictedStatus = Model.UNKNOWN_STATUS;
	} else {
	    predictedStatus = c.getStatus();
	    if (predictedStatus == Model.INVALID_STATUS) {
		// if a genotype was not encountered in the training
		// data but exists in the
		// testing data we give it the tie status. That is
		// because 'not encountered' is
		// another way of saying the count was 0 and 0 -- a tie
		// (assuming balanced data -- not sure what would be
		// better for unbalanced
		// data).
		switch (tieStatus) {
		case AFFECTED:
		    predictedStatus = c.affectedStatus;
		    break;
		case UNAFFECTED:
		    predictedStatus = c.getUnaffectedStatus();
		    break;
		case UNCLASSIFIED:
		    predictedStatus = Model.UNKNOWN_STATUS;
		    break;
		default:
		    throw new RuntimeException(
			    "Unhandled AmbiguousCellAssgnmentType: "
				    + tieStatus.toString());
		} // end switch
	    } // end if INVALID_STATUS
	}
	return predictedStatus;
    }

    public Pair<ConfusionMatrix, ConfusionMatrix> getLeaveOneOutTrainingAndTesting(
	    final Dataset data) {
	final SortedMap<byte[], Cell> cells = buildCounts(data);
	buildStatuses(data, data.getStatusCounts(), cells);
	return getLeaveOneOutTrainingAndTesting(data, cells);
    }

    private Pair<ConfusionMatrix, ConfusionMatrix> getLeaveOneOutTrainingAndTesting(
	    final Dataset data, final SortedMap<byte[], Cell> cells) {
	if (data.hasContinuousEndpoints()) {
	    throw new IllegalArgumentException(
		    "getLeaveOneOutTrainingAndTesting called on continuous endpoints!");
	}
	final ConfusionMatrix loocvTraining = new ConfusionMatrix(data
		.getLevels().get(data.getCols() - 1), data.getAffectedStatus());
	final ConfusionMatrix loocvTesting = new ConfusionMatrix(data
		.getLevels().get(data.getCols() - 1), data.getAffectedStatus());
	final byte affectedStatus = data.getAffectedStatus();
	final byte unaffectedStatus = data.getUnaffectedStatus();
	final float datasetAffectUnaffectedRatio = data.getRatio();
	for (final Cell c : cells.values()) {
	    final byte predictedStatus = c.getPredictedStatus(tieStatus);
	    final float affectedCount = c.getAffected();
	    final float unaffectedCount = c.getUnaffected();
	    // NOTE: the dataset ratio here are for the ENTIRE dataset -- not
	    // dataset after one row is left out. Jason thinks this is correct
	    // since
	    // by analogy,
	    // we often use allele frequency estimates from the data but if we
	    // have better allele frequency estimates from the world we use
	    // those.
	    // In this case the whole dataset is a better estimate of the
	    // case/control ratio than just the training dataset
	    final float cellTotal = affectedCount + unaffectedCount;
	    if (affectedCount >= 1) {
		final float leaveOneOutAffected = affectedCount - 1;
		final byte leaveOneAffectedOutStatus = determineCellStatus(
			affectedStatus, unaffectedStatus,
			datasetAffectUnaffectedRatio, leaveOneOutAffected,
			unaffectedCount);
		loocvTraining.add(affectedStatus, leaveOneAffectedOutStatus,
			affectedCount * (affectedCount - 1));
		loocvTraining.add(unaffectedStatus, leaveOneAffectedOutStatus,
			affectedCount * unaffectedCount);
		loocvTesting.add(affectedStatus, leaveOneAffectedOutStatus,
			affectedCount);
		// System.err.println("loocvTesting.add(affectedStatus(" +
		// affectedStatus
		// + "), leaveOneAffectedOutStatus(" + leaveOneAffectedOutStatus
		// + "), affected(" + affected + "))");
	    }
	    if (unaffectedCount >= 1) {
		final float leaveOneOutUnaffected = unaffectedCount - 1;
		final byte leaveOneUnaffectedOutStatus = determineCellStatus(
			affectedStatus, unaffectedStatus,
			datasetAffectUnaffectedRatio, affectedCount,
			leaveOneOutUnaffected);
		// loocvTraining.add(affectedStatus,
		// leaveOneUnaffectedOutStatus,
		// affectedTimesCellTotalMinusOne);
		loocvTraining.add(affectedStatus, leaveOneUnaffectedOutStatus,
			affectedCount * unaffectedCount);
		loocvTraining.add(unaffectedStatus,
			leaveOneUnaffectedOutStatus, unaffectedCount
				* (unaffectedCount - 1));
		loocvTesting.add(unaffectedStatus, leaveOneUnaffectedOutStatus,
			unaffectedCount);
		// System.err.println("loocvTesting.add(unaffectedStatus("
		// + unaffectedStatus + "), leaveOneUnaffectedOutStatus("
		// + leaveOneUnaffectedOutStatus + "), unaffected(" + unaffected
		// + "))");
	    }
	    final float totalInstancesOutsideOfThisCell = data.getRows()
		    - cellTotal;
	    loocvTraining.add(affectedStatus, predictedStatus,
		    totalInstancesOutsideOfThisCell * affectedCount);
	    loocvTraining.add(unaffectedStatus, predictedStatus,
		    totalInstancesOutsideOfThisCell * unaffectedCount);
	} // end for cells
	  // System.out.println(this + " loocvTraining: " + loocvTraining);
	  // System.out.println(this + " loocvTesting: " + loocvTesting);
	return new Pair<ConfusionMatrix, ConfusionMatrix>(loocvTraining,
		loocvTesting);
    }

    public String getModelName() {
	return combo.toString();
    }

    private double getSignificanceMetricBalancedAccuracyWeightedByFishersExact(
	    final Dataset data, final SortedMap<byte[], Cell> datasetCells) {
	final Pair<Double, Double> counts = data
		.getAffectedAndUnaffectedCounts();
	final double globalAffectedRowsCount = counts.getFirst();
	final double globalUnaffectedRowsCount = counts.getSecond();
	final edu.northwestern.at.utils.math.matrix.Matrix matrix = MatrixFactory
		.createMatrix(2, 2);
	final ConfusionMatrix confusionMatrix = new ConfusionMatrix(data
		.getLevels().get(data.getCols() - 1), data.getAffectedStatus());
	float totalFisherAdjustedCount = 0;
	for (final Cell cell : datasetCells.values()) {
	    if (cell.getTotalCount() > 0) {
		double cellAffectedRowsCount;
		double cellUnaffectedRowsCount;
		cellAffectedRowsCount = cell.getAffected();
		cellUnaffectedRowsCount = cell.getUnaffected();
		// case GLOBAL_INDEPENDENT:
		matrix.set(1, 1, globalAffectedRowsCount
			- cellAffectedRowsCount);
		matrix.set(1, 2, globalUnaffectedRowsCount
			- cellUnaffectedRowsCount);
		matrix.set(2, 1, cellAffectedRowsCount);
		matrix.set(2, 2, cellUnaffectedRowsCount);
		final double twoTailedFisherExact = getFishersExactTwoTailedResult(matrix);
		if (Double.isNaN(twoTailedFisherExact)) {
		    System.err.println("Fisher's Exact result NAN on matrix: "
			    + matrix);
		}
		final byte predictedStatus = cell.getPredictedStatus(tieStatus);
		for (byte status = 0; status < cell.counts.length; ++status) {
		    final float cellCount = cell.weightedCounts[status];
		    final double fisherAdjustedCellCount = cellCount
			    - (cellCount * twoTailedFisherExact);
		    final double unknownCount = cellCount
			    - fisherAdjustedCellCount;
		    confusionMatrix.add(status, Model.UNKNOWN_STATUS,
			    (float) unknownCount);
		    totalFisherAdjustedCount += fisherAdjustedCellCount;
		    if (Double.isNaN(fisherAdjustedCellCount)) {
			System.err
				.println("making weighted confusion matrix got NAa with cellCount: "
					+ cellCount
					+ " and fisheres: "
					+ twoTailedFisherExact);
		    }
		    confusionMatrix.add(status, predictedStatus,
			    (float) fisherAdjustedCellCount);
		} // end for status
	    }// end if cell not empty
	} // end cell loop
	float fitness = (totalFisherAdjustedCount == 0.0) ? 0.5f
		: confusionMatrix.getFitness();
	if (Double.isNaN(fitness)) {
	    System.err
		    .println("getSignificanceMetricFishersExactWeightedCounts returning NaN from confusionMatrix: "
			    + confusionMatrix
			    + " totalFisherAdjustedCount: "
			    + totalFisherAdjustedCount
			    + " cells: "
			    + datasetCells.values());
	    fitness = 0.0f;
	}
	return fitness;
    }

    public StatisticAndPValue getSignificanceMetricChiSquared(final Dataset data) {
	final SortedMap<byte[], Cell> cells = buildCounts(data);
	return getSignificanceMetricMaximumLikelihoodOrChiSquare(data, cells,
		DiscreteEndpointSignificanceMetric.CHI_SQUARED);
    }

    private double getSignificanceMetricFishersExactMultiply(
	    final Dataset data, final SortedMap<byte[], Cell> datasetCells) {
	double multipliedFishers = 0.0f;
	final Pair<Double, Double> counts = data
		.getAffectedAndUnaffectedCounts();
	final double globalAffectedRowsCount = counts.getFirst();
	final double globalUnaffectedRowsCount = counts.getSecond();
	final edu.northwestern.at.utils.math.matrix.Matrix matrix = MatrixFactory
		.createMatrix(2, 2);
	for (final Cell cell : datasetCells.values()) {
	    if (cell.getTotalCount() > 0) {
		double cellAffectedRowsCount;
		double cellUnaffectedRowsCount;
		cellAffectedRowsCount = cell.getAffected();
		cellUnaffectedRowsCount = cell.getUnaffected();
		// matrix[cellIndex][0] = Math.max(1, (long)
		// cellAffectedRowsCount);
		// matrix[cellIndex][1] = Math.max(1, (long)
		// cellUnaffectedRowsCount);
		// case GLOBAL_INDEPENDENT:
		matrix.set(1, 1, globalAffectedRowsCount
			- cellAffectedRowsCount);
		matrix.set(1, 2, globalUnaffectedRowsCount
			- cellUnaffectedRowsCount);
		matrix.set(2, 1, cellAffectedRowsCount);
		matrix.set(2, 2, cellUnaffectedRowsCount);
		final double twoTailedFisherExact = getFishersExactTwoTailedResult(matrix);
		// adding a log is equivalent to multiply
		multipliedFishers += Math.log(twoTailedFisherExact);
	    }// end if cell not empty
	} // end cell loop
	  // Fisher's Method https://en.wikipedia.org/wiki/Fishers_method
	  // This returns a T-statistic so can be converted to a p-value
	final double fishersMethod = -2 * multipliedFishers;
	return fishersMethod;
    }

    public StatisticAndPValue getSignificanceMetricMaximumLikelihood(
	    final Dataset data) {
	final SortedMap<byte[], Cell> cells = buildCounts(data);
	return getSignificanceMetricMaximumLikelihoodOrChiSquare(data, cells,
		DiscreteEndpointSignificanceMetric.MAXIMUM_LIKELIHOOD);
    }

    private StatisticAndPValue getSignificanceMetricMaximumLikelihoodOrChiSquare(
	    final Dataset data,
	    final SortedMap<byte[], Cell> datasetCells,
	    final DiscreteEndpointSignificanceMetric maximumLikelihoodOrChiSquaredMetric) {
	long[] affectedCounts = new long[datasetCells.size()];
	long[] unaffectedCounts = new long[datasetCells.size()];
	final Iterator<Cell> cellIterator = datasetCells.values().iterator();
	int numberOfNonEmptyCells = 0;
	for (int rowIndex = 0; cellIterator.hasNext(); ++rowIndex) {
	    final Cell cell = cellIterator.next();
	    if (cell.getTotalCount() > 0) {
		affectedCounts[rowIndex] = (long) cell.getAffected();
		unaffectedCounts[rowIndex] = (long) cell.getUnaffected();
		++numberOfNonEmptyCells;
	    }// end if cell not empty
	} // end cell loop
	if (numberOfNonEmptyCells < datasetCells.size()) {
	    // Matrix has one-based indexing.
	    affectedCounts = Utility.resizeArray(affectedCounts,
		    numberOfNonEmptyCells);
	    unaffectedCounts = Utility.resizeArray(unaffectedCounts,
		    numberOfNonEmptyCells);
	}
	final StatisticAndPValue returnValue = new StatisticAndPValue();
	// test affected versus unaffected to see if they come from the same
	// distribution
	if (maximumLikelihoodOrChiSquaredMetric == DiscreteEndpointSignificanceMetric.MAXIMUM_LIKELIHOOD) {
	    returnValue.setStatistic(TestUtils.gDataSetsComparison(
		    affectedCounts, unaffectedCounts));
	    returnValue.setP(TestUtils.gTestDataSetsComparison(affectedCounts,
		    unaffectedCounts));
	} else if (maximumLikelihoodOrChiSquaredMetric == DiscreteEndpointSignificanceMetric.CHI_SQUARED) {
	    returnValue.setStatistic(TestUtils.chiSquareDataSetsComparison(
		    affectedCounts, unaffectedCounts));
	    returnValue.setP(TestUtils.chiSquareTestDataSetsComparison(
		    affectedCounts, unaffectedCounts));
	} else {
	    throw new RuntimeException(
		    "getSignificanceMetricMaximumLikelihoodORChiSquareUnhandled("
			    + maximumLikelihoodOrChiSquaredMetric
			    + "): Unhandled metric argument passed in");
	}
	return returnValue;
    } // end getSignificanceMetricMaximumLikelihoodOrChiSquare

    private double getSignificanceMetricValueForDiscreteEndpoints(
	    final Dataset data,
	    final DiscreteEndpointSignificanceMetric discreteEndpointsSignificanceMetric) {
	double significance;
	final boolean debug = false;
	// need to build counts for passed in data. Save the existing counts
	// contained in cells.
	// once done getting counts, restore the original counts
	// final SortedMap<byte[], Cell> oldCells = new TreeMap<byte[],
	// Model.Cell>(
	// cells);
	assert !data.hasContinuousEndpoints() : "!data.hasContinuousEndpoints()";
	try {
	    if (debug) {
		System.err
			.println(Thread.currentThread().getName()
				+ " id:"
				+ Thread.currentThread().getId()
				+ " entering getSignificanceMetricValueForDiscreteEndpoints");
		System.err.flush();
	    }
	    final SortedMap<byte[], Cell> cells = buildCounts(data);
	    if (cells.size() < 2) {
		significance = Double.NEGATIVE_INFINITY;
	    } else {
		switch (discreteEndpointsSignificanceMetric) {
		case LEAVE_ONE_OUT_CROSS_VALIDATION_TESTING:
		    buildStatuses(data, data.getStatusCounts(), cells);
		    final Pair<ConfusionMatrix, ConfusionMatrix> loocvTrainingAndTesting = getLeaveOneOutTrainingAndTesting(
			    data, cells);
		    significance = loocvTrainingAndTesting.getSecond()
			    .getFitness(); // call getFitness rather than
					   // getBalancedAccuracy because want
					   // to penalize for lack of coverage
		    break;
		case BALANCED_ACCURACY_WEIGHTED_BY_FISHERS_EXACT:
		    buildStatuses(data, data.getStatusCounts(), cells);
		    significance = getSignificanceMetricBalancedAccuracyWeightedByFishersExact(
			    data, cells);
		    if (Double.isNaN(significance)) {
			significance = 0.0;
		    }
		    break;
		case BALANCED_ACCURACY:
		    buildStatuses(data, data.getStatusCounts(), cells);
		    significance = test(data, cells).getFitness();
		    break;
		case CHI_SQUARED: {
		    final StatisticAndPValue statisticAndPValue = getSignificanceMetricMaximumLikelihoodOrChiSquare(
			    data, cells,
			    DiscreteEndpointSignificanceMetric.CHI_SQUARED);
		    significance = statisticAndPValue.getStatistic();
		    break;
		}
		case MAXIMUM_LIKELIHOOD: {
		    final StatisticAndPValue statisticAndPValue = getSignificanceMetricMaximumLikelihoodOrChiSquare(
			    data,
			    cells,
			    DiscreteEndpointSignificanceMetric.MAXIMUM_LIKELIHOOD);
		    significance = statisticAndPValue.getStatistic();
		    break;
		}
		case FISHERS_EXACT_MULTIPLY:
		    significance = getSignificanceMetricFishersExactMultiply(
			    data, cells);
		    break;
		default:
		    throw new RuntimeException(
			    "Unhandled ModelSignificanceMetric: "
				    + Console.console
					    .getDiscreteEndpointSignificanceMetric());
		} // end switch
	    } // end if
	      // this can be a legitimate case -- especially in high order model
	      // using
	      // fisher's exact
	      // if (Double.isNaN(significance)) {
	      // System.out.println("Model " + this
	      // + " got NaN significance using: "
	      // + discreteEndpointsSignificanceMetric);
	      // }
	} finally {
	    // DO NOT CLEAR CELLS -- NEEDED BY IF THEN TEXT GENERATOR
	    if (debug) {
		System.err
			.println(Thread.currentThread().getName()
				+ " id:"
				+ Thread.currentThread().getId()
				+ " EXITING getSignificanceMetricValueForDiscreteEndpoints");
		System.err.flush();
	    }
	}
	return significance;
    } // end getModelSignificance

    public AmbiguousCellStatus getTieStatus() {
	return tieStatus;
    }

    public void read(final Dataset data, final BufferedReader r)
	    throws IOException {
	String line = r.readLine();
	if (!line.equals("BeginModelDetail")) {
	    throw new IOException();
	}
	final List<Byte> dims = new ArrayList<Byte>(combo.size());
	boolean useDenseMatrix = true;
	long ncells = 1;
	for (final int attr : combo.getAttributeIndices()) {
	    final byte dim = (byte) data.getLevels().get(attr).size();
	    if (useDenseMatrix) {
		ncells *= dim;
		// need to stop checking if there are a lot of dimensions be
		useDenseMatrix = (ncells > 0) && (ncells < data.getRows());
	    }
	    dims.add(dim);
	}
	// if (useDenseMatrix) {
	// cells = new DenseMatrix<Cell>(dims);
	// } else {
	// cells = new SparseMatrix<Cell>(dims);
	// }
	// final byte nStatus = data.getNumStatuses();
	while ((line = r.readLine()) != null) {
	    if (line.equals("EndModelDetail")) {
		break;
	    }
	    // ignore model detail -- the model counts can be re-created as
	    // needed
	    // final String[] fields = line.split("\\s+");
	    // final String[] values = fields[0].split(",");
	    // final byte[] rowSlice = new byte[values.length];
	    // for (int i = 0; i < values.length; ++i) {
	    // final int attributeIndex = combo.get(i);
	    // final List<String> attributeLevels = data.getLevels().get(
	    // attributeIndex);
	    // final String attributeValue = values[i];
	    // final int attributeValueIndex = attributeLevels
	    // .indexOf(attributeValue);
	    // if (attributeValueIndex == -1) {
	    // final String errorMessage = "For model " + combo.toString()
	    // + " Attribute '" + combo.getLabel(i)
	    // + "' which is column index #" + attributeIndex
	    // + "'s value '" + attributeValue
	    // + "' was not found in the attribute levels: "
	    // + attributeLevels.toString();
	    // System.out.println(errorMessage);
	    // throw new RuntimeException(errorMessage);
	    // }
	    // rowSlice[i] = (byte) attributeValueIndex;
	    // }
	    // if (data.hasContinuousEndpoints()) {
	    // final Model.ContinuousEndpointCell c = new
	    // ContinuousEndpointCell();
	    // final int countOfGenotype = Integer.parseInt(fields[1]);
	    // final float averageValue = Float.parseFloat(fields[2]);
	    // for (int i = 0; i < countOfGenotype; ++i) {
	    // c.addValue(averageValue);
	    // }
	    // cells.put(rowSlice, c);
	    //
	    // } else {
	    // final Model.Cell c = new Cell(nStatus, data.getAffectedStatus());
	    // for (int i = 0; i < nStatus; ++i) {
	    // c.getCounts()[i] = Float.parseFloat(fields[i + 1]);
	    // }
	    // cells.put(rowSlice, c);
	    // }
	} // end while reading ModelDetail
    }

    public int size() {
	return combo.size();
    }

    /**
     * despite the name, this is used this is used for to evaluate both training
     * and test data
     * 
     * @param data
     * @return
     */
    public ConfusionMatrix test(final Dataset data,
	    final SortedMap<byte[], Cell> cells) {
	// System.out.println("test called with dataset identity " +
	// System.identityHashCode(data));
	final ConfusionMatrix confusionMatrix = new ConfusionMatrix(data
		.getLevels().get(data.getCols() - 1), data.getAffectedStatus());
	if (data.hasContinuousEndpoints()) {
	    final AggregatedTestingData aggregatedData = getAggregatedTestingDataForContinuousEndpoints(
		    data, cells,
		    Console.console.getContinuousEndpointSignificanceMetric());
	    confusionMatrix.setAggregatedData(aggregatedData);
	    final double significanceMetric = aggregatedData
		    .getSignificanceMetric();
	    confusionMatrix.setScoreOverrideValue(significanceMetric);

	} else {
	    for (final Cell c : cells.values()) {
		final byte predictedStatus = c.getPredictedStatus(tieStatus);
		for (byte status = 0; status < c.counts.length; ++status) {
		    confusionMatrix.add(status, predictedStatus,
			    c.weightedCounts[status]);
		} // end for status
	    } // end for cells
	    final DiscreteEndpointSignificanceMetric metric = Console.console
		    .getDiscreteEndpointSignificanceMetric();
	    if (metric != DiscreteEndpointSignificanceMetric.BALANCED_ACCURACY) {
		final double significanceValue = getSignificanceMetricValueForDiscreteEndpoints(
			data, metric);
		confusionMatrix.setScoreOverrideValue(significanceValue);
	    } // end if overriding usual scoring metric
	} // end if discrete
	  // System.out.println(this + " " + confusionMatrix);
	return confusionMatrix;
    } // end test()

    @Override
    public String toString() {
	return combo.toString();// + " cells: " + cells;
    }

    public void write(final PrintWriter p, final Dataset data) {
	p.println("BeginModelDetail");
	final SortedMap<byte[], Cell> cells = buildCounts(data);
	buildStatuses(data, data.getStatusCounts(), cells);
	for (final Map.Entry<byte[], Model.Cell> matrixCell : cells.entrySet()) {
	    final byte[] dims = matrixCell.getKey();
	    final Model.Cell cell = matrixCell.getValue();
	    for (int i = 0; i < dims.length; ++i) {
		if (i != 0) {
		    p.print(',');
		}
		final int attributeIndex = combo.get(i);
		final List<String> attributeLevels = data.getLevels().get(
			attributeIndex);
		final int attributeValueIndex = dims[i];
		final String attributeValue = attributeLevels
			.get(attributeValueIndex);
		p.print(attributeValue);
	    }
	    if (data.hasContinuousEndpoints()) {
		p.print(' ');
		p.print(Model.plainNumberFormat.format(cell.getTotalCount()));
		p.print(' ');
		p.print(Model.plainNumberFormat.format(cell.getMean()));
	    } else {
		for (final float count : cell.getCounts()) {
		    p.print(' ');
		    p.print(Model.plainNumberFormat.format(count));
		}
	    }
	    p.println();
	}
	p.println("EndModelDetail");
    }

    /**
     * This can store data either as a dataset OR as two arrays of doubles
     * 
     * @author pandrews
     */
    public static class AggregatedTestingData {
	private static final double INVALID_T_STATISTIC = Double.NEGATIVE_INFINITY;
	private final Map<String, Collection<SummaryStatistics>> mapOfLists;
	private Map<String, StatisticalSummaryValuesWithSumSq> mapOfAggregates = null;
	private double fStatistic = Double.NaN;
	private double tStatistic = Double.NaN;
	private final boolean sanityCheck = true;

	public AggregatedTestingData(
		final Collection<AggregatedTestingData> partitionsEndpointData) {

	    mapOfLists = new HashMap<String, Collection<SummaryStatistics>>();
	    for (final AggregatedTestingData continuousEndpointsSignificanceTestingData : partitionsEndpointData) {
		if (sanityCheck) {
		    continuousEndpointsSignificanceTestingData.sanityCheck();
		}
		for (final Map.Entry<String, Collection<SummaryStatistics>> entry : continuousEndpointsSignificanceTestingData.mapOfLists
			.entrySet()) {
		    final String key = entry.getKey();
		    Collection<SummaryStatistics> collection = mapOfLists
			    .get(key);
		    if (collection == null) {
			collection = new ArrayList<SummaryStatistics>();
			mapOfLists.put(key, collection);
		    }
		    collection.addAll(entry.getValue());
		}
	    } // end partitions loop
	    if (sanityCheck) {
		sanityCheck();
	    }

	}

	public AggregatedTestingData(
		final Map<String, Collection<SummaryStatistics>> mapOfLists) {
	    assert mapOfLists != null : "mapOfLists != null";
	    assert !mapOfLists.isEmpty() : "!mapOfLists.isEmpty()";
	    this.mapOfLists = mapOfLists;
	    assert getTotalN() > 0 : "getTotalN() > 0";
	    if (sanityCheck) {
		sanityCheck();
	    }

	} // end constructor

	public void aggregateSummaryStatistics() {
	    assert mapOfAggregates == null : "mapOfAggregates == null";
	    if (mapOfAggregates == null) {
		mapOfAggregates = new HashMap<String, StatisticalSummaryValuesWithSumSq>(
			mapOfLists.size());
		for (final Map.Entry<String, Collection<SummaryStatistics>> entry : mapOfLists
			.entrySet()) {
		    final String key = entry.getKey();
		    final Collection<SummaryStatistics> summaryStatisticsCollection = entry
			    .getValue();
		    assert summaryStatisticsCollection != null : "summaryStatisticsCollection != null";
		    // assert !summaryStatisticsCollection.isEmpty() :
		    // "!summaryStatisticsCollection.isEmpty()";
		    final StatisticalSummaryValuesWithSumSq statisticalSummaryValuesWithSumSq = StatisticalSummaryValuesWithSumSq
			    .aggregate(summaryStatisticsCollection);
		    if (sanityCheck) {
			sanityCheck(statisticalSummaryValuesWithSumSq,
				summaryStatisticsCollection);
		    }
		    assert statisticalSummaryValuesWithSumSq != null : "statisticalSummaryValuesWithSumSq != null";
		    mapOfAggregates.put(key, statisticalSummaryValuesWithSumSq);
		}
		if (sanityCheck) {
		    sanityCheck();
		}
	    }
	}

	public double getAnovaFStatistic() {
	    if (mapOfAggregates == null) {
		aggregateSummaryStatistics();
		fStatistic = OneWayAnovaForStatisticalSummaryValuesWithSumSq
			.anovaFValue(mapOfAggregates.values(), true /* doNotCheckDimensionMismatchException */);
		if (Double.isNaN(fStatistic)) {
		    System.err.println("getAnovaFStatistic returning null "
			    + toString());
		    fStatistic = OneWayAnovaForStatisticalSummaryValuesWithSumSq
			    .anovaFValue(mapOfAggregates.values(), true /* doNotCheckDimensionMismatchException */);

		}
	    }
	    if (sanityCheck) {
		sanityCheck();
	    }
	    return fStatistic;
	}

	public Map<String, StatisticalSummaryValuesWithSumSq> getMapOfAggregates() {
	    if (mapOfAggregates == null) {
		aggregateSummaryStatistics();
	    }
	    return mapOfAggregates;
	}

	public double getSignificanceMetric() {
	    double significanceMetric;
	    switch (Console.console.getContinuousEndpointSignificanceMetric()) {
	    case ANOVA:
		significanceMetric = getAnovaFStatistic();
		break;
	    case TTEST:
		significanceMetric = getTTestStatistic();
		break;
	    default:
		throw new RuntimeException(
			"Unhandled Console.console.continuousEndpointSignificanceMetric: "
				+ Console.console
					.getContinuousEndpointSignificanceMetric());
		// break;

	    }
	    return significanceMetric;
	}

	public int getTotalN() {
	    int sum = 0;
	    for (final Map.Entry<String, Collection<SummaryStatistics>> entry : mapOfLists
		    .entrySet()) {
		for (final SummaryStatistics summaryStatistics : entry
			.getValue()) {
		    sum += summaryStatistics.getN();
		}
	    }

	    return sum;
	}

	public double getTTestStatistic() {
	    if (mapOfAggregates == null) {
		aggregateSummaryStatistics();
		assert mapOfAggregates.size() <= 2 : "statisticalSummaryValuesWithSumSq.size() <= 2";
		if (mapOfAggregates.size() < 2) {
		    tStatistic = AggregatedTestingData.INVALID_T_STATISTIC;
		} else {
		    try {
			tStatistic = TestUtils.t(mapOfAggregates
				.get(Dataset.ABOVE_AVERAGE_OR_EQUAL_CLASS),
				mapOfAggregates
					.get(Dataset.BELOW_AVERAGE_CLASS));
		    } catch (final NumberIsTooSmallException numberIsTooSmallException) {
			// if one of the classes has very few items then this is
			// not a predictive model
			tStatistic = AggregatedTestingData.INVALID_T_STATISTIC;
		    }
		}
		if (Double.isNaN(tStatistic)) {
		    System.err.println("getTTestStatistic returning null "
			    + toString());
		}
	    }
	    if (sanityCheck) {
		sanityCheck();
	    }
	    return tStatistic;
	}

	public void sanityCheck() {
	    if (mapOfLists != null) {
		for (final Map.Entry<String, Collection<SummaryStatistics>> entry : mapOfLists
			.entrySet()) {
		    final Collection<SummaryStatistics> summaryStatisticsCollection = entry
			    .getValue();
		    for (final SummaryStatistics summaryStatistics : summaryStatisticsCollection) {
			if (Double.isNaN(summaryStatistics.getMin())) {
			    throw new RuntimeException(
				    "Double.isNaN(summaryStatistics.getMin())");
			}

		    }
		}
	    }
	    if (mapOfAggregates != null) {
		final int sum = getTotalN();
		int aggregatesSum = 0;
		for (final Entry<String, StatisticalSummaryValuesWithSumSq> entry : mapOfAggregates
			.entrySet()) {
		    final StatisticalSummaryValuesWithSumSq statisticalSummaryValuesWithSumSq = entry
			    .getValue();
		    if (Double
			    .isNaN(statisticalSummaryValuesWithSumSq.getMin())) {
			throw new RuntimeException(
				"Double.isNaN(statisticalSummaryValuesWithSumSq.getMin())");
		    }
		    aggregatesSum += statisticalSummaryValuesWithSumSq.getN();
		}
		if (sum != aggregatesSum) {
		    throw new RuntimeException("sum(" + sum
			    + ") != aggregatesSum(" + aggregatesSum + ")");
		}
	    }

	}

	private void sanityCheck(
		final StatisticalSummaryValuesWithSumSq statisticalSummaryValuesWithSumSq,
		final Collection<SummaryStatistics> summaryStatisticsCollection) {
	    final long totalInAggregate = statisticalSummaryValuesWithSumSq
		    .getN();
	    long totalInCollection = 0;
	    for (final SummaryStatistics summaryStatistics : summaryStatisticsCollection) {
		totalInCollection += summaryStatistics.getN();
	    }
	    if (totalInAggregate != totalInCollection) {

		final String errorMessage = "totalInAggregate("
			+ totalInAggregate + ") != totalInCollection("
			+ totalInCollection + ")";
		// System.err.println(errorMessage);
		final StatisticalSummaryValuesWithSumSq newAggregate = StatisticalSummaryValuesWithSumSq
			.aggregate(summaryStatisticsCollection);
		System.err.println(errorMessage + " newAggregate = "
			+ newAggregate.getN());
		// throw new RuntimeException(errorMessage);
	    }

	}

	@Override
	public String toString() {
	    return "AggregatedTestingData: getTotalN(): " + getTotalN()
		    + " mapOfLists:" + mapOfLists + " mapOfAggregates:"
		    + mapOfAggregates;
	}
    } // end static class

    public static class Cell {
	final float[] counts;
	final float[] weightedCounts;
	byte status;
	final byte affectedStatus;

	public Cell(final byte nStatus, final byte affectedStatus) {
	    counts = new float[nStatus];
	    weightedCounts = new float[nStatus];
	    this.affectedStatus = affectedStatus;
	    status = Model.INVALID_STATUS;
	}

	public float getAffected() {
	    return counts[affectedStatus == 0 ? 0 : 1];
	}

	public byte getAffectedStatus() {
	    return affectedStatus;
	}

	public float[] getCounts() {
	    return counts;
	}

	// public double[] getEndpointNormalizedValues(final Dataset data) {
	// final double[] endpoints = getEndpoints();
	// final double[] endpointNormaizedValues = new
	// double[endpoints.length];
	// for (int index = 0; index < endpointNormaizedValues.length; ++index)
	// {
	// endpointNormaizedValues[index] = data
	// .getEndpointNormalized(endpoints[index]);
	// }
	// return endpointNormaizedValues;
	// }
	//
	// /**
	// * for discrete data there are only two ranks since there are only two
	// statuses so rank can be seen as same as value
	// * @return
	// */
	// public long[] getEndpointRanks(final Dataset data) {
	// final double[] endpoints = getEndpoints();
	// final long[] endpointRanks = new long[endpoints.length];
	// for (int index = 0; index < endpointRanks.length; ++index) {
	// endpointRanks[index] = data.getEndpointRank(endpoints[index]);
	// }
	// return endpointRanks;
	// }
	//
	// public double[] getEndpoints() {
	// final int affected = (int) getAffected();
	// final int unaffected = (int) getUnaffected();
	// final double[] endpoints = new double[affected + unaffected];
	// for (int index = 0; index < affected; ++index) {
	// endpoints[index] = 1.0;
	// }
	// return endpoints;
	// }
	public double getMean() {
	    return getTotal() / getTotalCount();
	}

	public byte getPredictedStatus(
		final AmbiguousCellStatus ambiguousCellStatus) {
	    byte predictedStatus;
	    predictedStatus = status;
	    if (predictedStatus == Model.INVALID_STATUS) {
		// if a genotype was not encountered in the training
		// data but exists in the
		// testing data we give it the tie status. That is
		// because 'not encountered' is
		// another way of saying the count was 0 and 0 -- a tie
		// (assuming balanced data -- not sure what would be
		// better for unbalanced
		// data).
		switch (ambiguousCellStatus) {
		case AFFECTED:
		    predictedStatus = affectedStatus;
		    break;
		case UNAFFECTED:
		    predictedStatus = getUnaffectedStatus();
		    break;
		case UNCLASSIFIED:
		    predictedStatus = Model.UNKNOWN_STATUS;
		    break;
		default:
		    throw new RuntimeException(
			    "Unhandled AmbiguousCellAssgnmentType: "
				    + ambiguousCellStatus.toString());
		} // end switch
	    } // end if INVALID_STATUS
	    return predictedStatus;
	}

	public byte getStatus() {
	    return status;
	}

	/**
	 * for discrete data this is the same as get the number of affected
	 * 
	 * @return
	 */
	public double getTotal() {
	    return getAffected();
	}

	public float getTotalCount() {
	    return getAffected() + getUnaffected();
	}

	public float getUnaffected() {
	    return counts[affectedStatus == 0 ? 1 : 0];
	}

	public byte getUnaffectedStatus() {
	    return (byte) (affectedStatus == 0 ? 1 : 0);
	}

	public void resetCounts() {
	    Arrays.fill(counts, 0);
	    Arrays.fill(weightedCounts, 0);
	}

	@Override
	public String toString() {
	    return getClass().getSimpleName() + ": affected=" + getAffected()
		    + " unaffected=" + getUnaffected() + " status=" + status;
	}
    } // end private class Cell

    public static class ContinuousEndpointCell extends Cell {
	private SummaryStatistics summaryStatistics = new SummaryStatistics();

	public ContinuousEndpointCell() {
	    super((byte) 2 /* nStatus */, (byte) 1 /* affected status */);
	}

	public void addValue(final double endpoint) {
	    summaryStatistics.addValue(endpoint);
	}

	@Override
	public double getMean() {
	    return summaryStatistics.getMean();
	}

	public SummaryStatistics getSummaryStatistics() {
	    return summaryStatistics;
	}

	@Override
	public double getTotal() {
	    return summaryStatistics.getSum();
	}

	@Override
	public float getTotalCount() {
	    return summaryStatistics.getN();
	}

	@Override
	public void resetCounts() {
	    super.resetCounts();
	    // DO NOT just clear here -- someone could be keeping a copy of the
	    // older version. For example the training cells for a model versus
	    // the testing cells
	    summaryStatistics = new SummaryStatistics();
	}

	//
	// @Override
	// public void resetCounts() {
	// super.resetCounts();
	// summary.clear();
	// }
	//
	@Override
	public String toString() {
	    return super.toString() + " " + summaryStatistics;
	}
    } // end ContinuousEndpointCell

    public static class StatisticAndPValue {
	private double statistic;
	private double pValue;

	public double getPValue() {
	    return pValue;
	}

	public double getStatistic() {
	    return statistic;
	}

	public void setP(final double pValue) {
	    this.pValue = pValue;
	}

	public void setStatistic(final double statistic) {
	    this.statistic = statistic;
	}
    }

    /*
     * Licensed to the Apache Software Foundation (ASF) under one or more
     * contributor license agreements. See the NOTICE file distributed with this
     * work for additional information regarding copyright ownership. The ASF
     * licenses this file to You under the Apache License, Version 2.0 (the
     * "License"); you may not use this file except in compliance with the
     * License. You may obtain a copy of the License at
     * 
     * http://www.apache.org/licenses/LICENSE-2.0
     * 
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
     * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
     * License for the specific language governing permissions and limitations
     * under the License.
     */

} // end class Model
