package org.epistasis.mdr.analysis;

import java.util.Iterator;

import org.epistasis.mdr.AmbiguousCellStatus;
import org.epistasis.mdr.enums.FitnessCriteriaOrder;
import org.epistasis.mdr.newengine.AttributeCombination;
import org.epistasis.mdr.newengine.Dataset;

public abstract class RandomAnalysisThread extends AnalysisThread {

    protected RandomAnalysisThread(final Dataset data,
	    final FitnessCriteriaOrder topModelsFitnessCriteriaOrder,
	    final FitnessCriteriaOrder bestModelFitnessCriteriaOrder,
	    final int numCrossValidationIntervals,
	    final AmbiguousCellStatus tiePriorityList, final long seed,
	    final Runnable onEndModel, final Runnable onEndLevel,
	    final Runnable onEndAnalysis, final boolean parallel,
	    final int topModelsLandscapeSize,
	    final boolean computeAllModelsLandscape, final int minAttr,
	    final int maxAttr) {
	super(data, topModelsFitnessCriteriaOrder,
		bestModelFitnessCriteriaOrder, numCrossValidationIntervals,
		minAttr, maxAttr, tiePriorityList, seed, onEndModel,
		onEndLevel, onEndAnalysis, parallel, topModelsLandscapeSize,
		computeAllModelsLandscape);
    }

    public static abstract class RandomAnalysisThreadBuilder<T extends RandomAnalysisThread>
	    extends AnalysisThreadBuilder<T> {
	public RandomAnalysisThreadBuilder(final Dataset data,
		final int numCrossValidationIntervals, final long seed) {
	    super(data, numCrossValidationIntervals, seed);
	}
    }

    protected static class RandomProducer extends Producer {
	private AttributeCombination attributes;
	private final Iterator<AttributeCombination> rcg;

	public RandomProducer(final RandomCombinationGenerator rcg,
		final int intervals) {
	    this.rcg = rcg;
	}

	@Override
	public QueueEntry produce() {
	    if (!rcg.hasNext()) {
		return null;
	    }
	    attributes = rcg.next();
	    final QueueEntry entry = new QueueEntry(attributes);
	    return entry;
	}
    }
}
