package org.epistasis.mdr.enums;

import java.util.HashMap;
import java.util.Map;

public enum DiscreteEndpointSignificanceMetric {
    BALANCED_ACCURACY("Balanced accuracy", "bal. acc."), LEAVE_ONE_OUT_CROSS_VALIDATION_TESTING, MAXIMUM_LIKELIHOOD, FISHERS_EXACT_MULTIPLY, CHI_SQUARED, BALANCED_ACCURACY_WEIGHTED_BY_FISHERS_EXACT;
    private static final Map<String, DiscreteEndpointSignificanceMetric> shortTextLookupMap = new HashMap<String, DiscreteEndpointSignificanceMetric>();
    static {
	for (final DiscreteEndpointSignificanceMetric displayType : DiscreteEndpointSignificanceMetric
		.values()) {
	    DiscreteEndpointSignificanceMetric.shortTextLookupMap.put(
		    displayType.getShortText(), displayType);
	}
    }
    private String shortText = null;
    private String longText = null;

    public static DiscreteEndpointSignificanceMetric[] getMenuItems() {
	return new DiscreteEndpointSignificanceMetric[] { BALANCED_ACCURACY,
		MAXIMUM_LIKELIHOOD, CHI_SQUARED,
		LEAVE_ONE_OUT_CROSS_VALIDATION_TESTING,
		BALANCED_ACCURACY_WEIGHTED_BY_FISHERS_EXACT,
		FISHERS_EXACT_MULTIPLY };
    }

    public static DiscreteEndpointSignificanceMetric lookupByShortText(
	    final String pShortText) {
	return DiscreteEndpointSignificanceMetric.shortTextLookupMap
		.get(pShortText);
    }

    private DiscreteEndpointSignificanceMetric() {

    }

    private DiscreteEndpointSignificanceMetric(final String longText,
	    final String shortText) {
	this.longText = longText;
	this.shortText = shortText;
    }

    public String getLongText() {
	if (longText != null) {
	    return longText;
	} else {
	    return name();
	}
    }

    public String getShortText() {
	if (shortText != null) {
	    return shortText;
	} else {
	    return getLongText();
	}
    }
}