package org.epistasis.mdr;

public enum AmbiguousCellStatus {
    AFFECTED("Affected"), UNAFFECTED("Unaffected"), UNCLASSIFIED("Unclassified");
    private final String displayName;

    public static AmbiguousCellStatus getTiePriorityFromString(
	    String tieStatusString) throws IllegalArgumentException {
	tieStatusString = tieStatusString.toUpperCase();
	AmbiguousCellStatus resultTieStatus = null;
	if (tieStatusString.equals("UNKNOWN")) {
	    resultTieStatus = AmbiguousCellStatus.UNCLASSIFIED;
	} else {
	    resultTieStatus = Enum.valueOf(AmbiguousCellStatus.class,
		    tieStatusString.toUpperCase());
	}
	return resultTieStatus;
    }

    private AmbiguousCellStatus(final String displayName) {
	this.displayName = displayName;
    }

    public String getDisplayName() {
	return displayName;
    }
}