package org.epistasis.mdr.analysis;

import java.util.Arrays;
import java.util.Iterator;

import org.epistasis.Utility;

/**
 * 
 * Based on the Combinadic Algorithm explained by James McCaffrey in the MSDN
 * article titled: "Generating the mth Lexicographical Element of a Mathematical
 * Combination" <http://msdn.microsoft.com/en-us/library/aa289166(VS.71).aspx>
 */
public class CombinadicGenerator {
    private final int k;

    private final int n;

    private static final boolean debug = false;

    /**
     * n choose k
     * 
     * @param n
     *            number of total elements
     * @param k
     *            number of elements in each combination
     * @return
     */
    public static long choose(final int n, final int k) {
	if ((n < 0) || (k < 0)) {
	    throw new RuntimeException(
		    "Invalid negative parameter in choose(n=" + n + ",k=" + k
			    + ")");
	}
	if (n < k) {
	    return 0;
	} // special case
	if (n == k) {
	    return 1;
	}

	int delta, iMax;

	final int nMinusK = n - k;
	if (k < nMinusK) // ex: Choose(100,3)
	{
	    delta = nMinusK;
	    iMax = k;
	} else // ex: Choose(100,97)
	{
	    delta = k;
	    iMax = nMinusK;
	}

	long ans = delta + 1;

	// if (CombinadicGenerator.debug) {
	// System.err.println("choose(n: " + n + " k: " + k + ") iMax: "
	// + iMax + " delta: " + delta);
	// }
	for (int i = 2; i <= iMax; ++i) {
	    ans = (ans * (delta + i)) / i;
	    if (ans < 0) {
		throw new RuntimeException(
			"Overflow -- answer bigger than maximum long for arguments: choose(n="
				+ n + ",k=" + k + ")");
	    }
	}

	return ans;
    }

    // return largest value v where v < a and Choose(v,b) <= x
    private static int largestValue(final int a, final int b, final long x) {

	int heuristicSearchV = CombinadicGenerator.largestValueHeuristic(a, b,
		x);
	if (CombinadicGenerator.debug) {
	    final int stupidSearchV = CombinadicGenerator.largestValueStupid(a,
		    b, x);
	    int binarySearchV = CombinadicGenerator.largestValueBinarySearch(a,
		    b, x);

	    System.err.println("largestValue(a: " + a + " b: " + b + " x: " + x
		    + ") METHODS: stupidSearchV: " + stupidSearchV
		    + " heuristicSearchV: " + heuristicSearchV
		    + " binarySearchV: " + binarySearchV);
	    final boolean allEqual = (stupidSearchV == heuristicSearchV)
		    && (heuristicSearchV == binarySearchV);
	    if (!allEqual) {
		heuristicSearchV = CombinadicGenerator.largestValueHeuristic(a,
			b, x);
		binarySearchV = CombinadicGenerator.largestValueBinarySearch(a,
			b, x);
		assert false : "largestValue(a: " + a + " b: " + b + " x: " + x
			+ ") different methods gave different results!";
	    }
	}

	return heuristicSearchV;
    } // LargestV()

    private static int largestValueBinarySearch(final int a, final int b,
	    final long x) {
	int upperLimit = a - 1;
	int lowerLimit = b;
	@SuppressWarnings("unused")
	int chooseCtr = 0;

	int returnValue = -1;
	while (lowerLimit <= upperLimit) {
	    final int mid = lowerLimit + ((upperLimit - lowerLimit) / 2);
	    final long midChooseB = CombinadicGenerator.choose(mid, b);
	    ++chooseCtr;
	    if (x < midChooseB) {
		upperLimit = mid - 1;
	    } else if (x > midChooseB) {
		lowerLimit = mid + 1;
	    } else {
		returnValue = mid;
		break;
	    }
	}
	if (returnValue < 0) {
	    returnValue = upperLimit;
	}
	if (CombinadicGenerator.debug) {
	    System.err.println("largestValueBinarySearch(a=" + a + ", b=" + b
		    + ",x=" + x + ") chooseCtr=" + chooseCtr + " returning: "
		    + returnValue);
	}
	return returnValue;
    }

    private static int largestValueHeuristic(final int a, final int b,
	    final long x) {
	int v = -1;
	int estimatedValue = -1;
	@SuppressWarnings("unused")
	int chooseCtr = 0;
	if (x == 0) {
	    // odd case -- the only way to get zero combinations is to ask for
	    // more items than there are
	    v = b - 1;
	} else {
	    v = a - 1;
	    final long bFactorial = Utility.factorial(b).longValue();
	    estimatedValue = (int) (Math.pow(x * bFactorial, 1.0f / b) + (b / 2.0f));
	    v = Math.min(v, estimatedValue);
	    ++chooseCtr;
	    long numCombinations = CombinadicGenerator.choose(v, b);
	    if (numCombinations < x) {
		do {
		    ++v;
		    ++chooseCtr;
		    numCombinations = CombinadicGenerator.choose(v, b);
		} while (numCombinations < x);
		if (numCombinations > x) {
		    // go back one so that num combinations will be <= x
		    --v;
		}
	    } else if (numCombinations > x) {
		do {
		    --v;
		    ++chooseCtr;
		    numCombinations = CombinadicGenerator.choose(v, b);
		} while (numCombinations > x);
		// good v is now set so numCombinations will be <= x
	    } else {
		// perfect -- v is all set!

	    }
	} // end if x != 0
	if (CombinadicGenerator.debug) {
	    System.err
		    .println("largestValueHeuristic(a=" + a + ", b=" + b
			    + ",x=" + x + ") chooseCtr=" + chooseCtr
			    + " estimatedValue: " + estimatedValue
			    + " returning: " + v);
	}
	return v;
    }

    private static int largestValueStupid(final int a, final int b, final long x) {
	int v = a - 1;
	@SuppressWarnings("unused")
	long numCombinations;
	while ((numCombinations = CombinadicGenerator.choose(v, b)) > x) {
	    --v;
	}
	return v;
    }

    public CombinadicGenerator(final int n, final int k) {
	if ((n < 0) || (k < 0)) {
	    throw new RuntimeException("Negative parameter in constructor");
	}

	this.n = n;
	this.k = k;
    }

    /**
     * This simply calls choose(n, k)
     * 
     * @return choose(n,k)
     */
    public long getNumberOfCombinations() {
	return CombinadicGenerator.choose(n, k);
    }

    public CombinationIterator iterator() {
	return new CombinationIterator();
    }

    private CombinationIterator iterator(final int[] a,
	    final long maximumIterations) {
	final CombinationIterator combinationIterator = new CombinationIterator(
		a.clone(), maximumIterations);
	combinationIterator.isValid();
	return combinationIterator;
    }

    // return the mth lexicographic element of combination C(n,k)
    public CombinationIterator iterator(final long combinadicIndex) {
	return iterator(combinadicIndex,
		CombinationIterator.UNLIMITED_ITERATIONS);
    }

    // create an iterator starting at the mth lexicographic element of
    // combination C(n,k)
    public CombinationIterator iterator(final long combinadicIndex,
	    final long maximumIterations) {
	final int[] ans = new int[k];

	int a = n;
	int b = k;
	long x = (CombinadicGenerator.choose(n, k) - 1) - combinadicIndex; // x
									   // is
									   // the
									   // "dual"
									   // of
									   // m

	for (int i = 0; i < k; ++i) {
	    ans[i] = CombinadicGenerator.largestValue(a, b, x); // largest value
								// v, where v <
								// a and
	    // vCb
	    // < x
	    x = x - CombinadicGenerator.choose(ans[i], b);
	    a = ans[i];
	    b = b - 1;
	}

	for (int i = 0; i < k; ++i) {
	    ans[i] = (n - 1) - ans[i];
	}

	final CombinadicGenerator combination = new CombinadicGenerator(n, k);
	return combination.iterator(ans, maximumIterations);
    }

    @Override
    public String toString() {
	return "n=" + n + " k=" + k;
    }

    public class CombinationIterator implements Iterator<int[]> {

	private static final int UNLIMITED_ITERATIONS = -1;
	private final int[] data;
	private final long maximumIterations;
	private long iterationCtr = 0;
	private boolean hasNext = true;

	private CombinationIterator() {
	    this(new int[k], CombinationIterator.UNLIMITED_ITERATIONS);
	    for (int i = 0; i < k; ++i) {
		data[i] = i;
	    }
	    isValid();
	}

	public CombinationIterator(final int[] data,
		final long maximumIterations) {
	    assert (data != null) && (data.length > 0) : "CombinationIterator data is bad: "
		    + Arrays.toString(data);
	    this.data = data;
	    this.maximumIterations = maximumIterations;
	}

	@Override
	public boolean hasNext() {
	    return hasNext;
	}

	private boolean isValid() {
	    if (data.length != k) {
		throw new RuntimeException("Array length does not equal k: "
			+ toString());
	    }

	    for (int i = 0; i < k; ++i) {
		if ((data[i] < 0) || (data[i] > (n - 1))) {
		    throw new RuntimeException("value out of range: "
			    + toString());
		}

		for (int j = i + 1; j < k; ++j) {
		    if (data[i] >= data[j]) {
			throw new RuntimeException(
				" duplicate or not lexicographic: "
					+ toString());
		    }
		}
	    }
	    return true;
	}

	/**
	 * this is odd. It actually returns the current one and then advances to
	 * the next This is because we do not want to skip the first one
	 */
	@Override
	public synchronized int[] next() {

	    final int[] result = data.clone();
	    if (hasNext) {
		int i;

		for (i = k - 1; (i > 0) && (data[i] == ((n - k) + i)); --i) {
		    // no content needed inside loop
		}

		++data[i];

		for (int j = i; j < (k - 1); ++j) {
		    data[j + 1] = data[j] + 1;
		}
		// need to set hasNext for the future
		hasNext = (data[0] <= (n - k))
			&& ((maximumIterations == CombinationIterator.UNLIMITED_ITERATIONS) || (++iterationCtr < maximumIterations));
		assert !hasNext || isValid();

	    }
	    return result;
	}

	@Override
	public void remove() {
	    throw new UnsupportedOperationException();

	}

	@Override
	public String toString() {
	    return CombinadicGenerator.this.toString() + ' '
		    + Arrays.toString(data);
	} // ToString()

    } // end private class CombinationIterator

}
