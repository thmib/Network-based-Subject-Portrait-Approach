package org.epistasis.mdr.gui.landscape;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.geom.Rectangle2D;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Stack;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.filechooser.FileFilter;

import org.epistasis.Annotator;
import org.epistasis.DisplayPair;
import org.epistasis.FileSaver;
import org.epistasis.FileSaver.ExtensionFilter;
import org.epistasis.FileSaver.FileSuffixBeforeExtension;
import org.epistasis.LabeledFloatInterface;
import org.epistasis.Pair;
import org.epistasis.Utility;
import org.epistasis.gui.AbstractChart;
import org.epistasis.gui.CmdMaximizeActionListener;
import org.epistasis.gui.SelectionEvent;
import org.epistasis.gui.SelectionListener;
import org.epistasis.mdr.Main;
import org.epistasis.mdr.newengine.Landscape;

public class LandscapePanel extends JComponent implements ItemListener,
	SelectionListener, ActionListener, ChangeListener {
    /**
	 * 
	 */
    private static final long serialVersionUID = 1L;
    private boolean useMinMax;
    private Landscape landscape = null;
    private Float landscapeMin = null;
    private Float landscapeMax = null;
    private Comparator<LabeledFloatInterface> rawTextComparator;
    private final BorderLayout bolThis = new BorderLayout();
    private final JPanel pnlControls = new JPanel();
    private final JPanel pnlDisplay = new JPanel();
    private final CardLayout crdDisplay = new CardLayout();
    private final JScrollPane scpLineChart = new JScrollPane();
    private final JScrollPane scpHistogram = new JScrollPane();
    private final JScrollPane scpRaw = new JScrollPane();
    private final JComboBox cboDisplayType = new JComboBox();
    private final JPanel pnlDisplayControls = new JPanel();
    private final JButton cmdSave = new JButton();
    private final JButton cmdUnzoom = new JButton();
    private final JButton cmdResetView = new JButton();
    private final JPanel pnlHistogramControls = new JPanel();
    private final JPanel pnlLineChartControls = new JPanel();
    private final CardLayout crdDisplayControls = new CardLayout();
    private final GridBagLayout gblControls = new GridBagLayout();
    private final GridBagLayout gblHistogramControls = new GridBagLayout();
    private final JLabel lblBins = new JLabel();
    private final JSpinner spnBins = new JSpinner();
    private final JPanel pnlZoomControls = new JPanel();
    private final JPanel pnlZoomable = new JPanel();
    private final JPanel pnlUnzoomable = new JPanel();
    private final CardLayout crdZoomControls = new CardLayout();
    private final GridBagLayout gblZoomable = new GridBagLayout();
    private final JTextArea txaRaw = new JTextArea();
    private final LandscapeHistogram pnlHistogram = new LandscapeHistogram();
    private final LandscapeLineChart pnlLineChart = new LandscapeLineChart();
    private final Stack<Rectangle2D> stkLineChartZoom = new Stack<Rectangle2D>();
    private final Stack<Rectangle2D> stkHistogramZoom = new Stack<Rectangle2D>();
    public final JButton cmdMaximize = new JButton();
    private final JPanel pnlRawControls = new JPanel();
    private final JCheckBox chkbxVerbose = new JCheckBox("Verbose");
    private String exportableAlternateName;
    private boolean hasAnnotator;
    private static boolean verbose = false;

    public LandscapePanel() {
	jbInit();
    }

    @Override
    public void actionPerformed(final ActionEvent e) {
	@SuppressWarnings("unchecked")
	final Pair<String, Component> p = (Pair<String, Component>) cboDisplayType
		.getSelectedItem();
	AbstractChart chart = null;
	Dimension chartSize = null;
	Stack<Rectangle2D> stack = null;
	String saveDialogTitle = null;
	FileSuffixBeforeExtension saveFileTitleSuffixBeforeExtension = null;
	List<ExtensionFilter> filters = null;
	if (p.getSecond() == scpLineChart) {
	    stack = stkLineChartZoom;
	    chart = pnlLineChart;
	    chartSize = new Dimension(1200, 400);
	    saveDialogTitle = "Save Landscape Line Chart";
	    saveFileTitleSuffixBeforeExtension = FileSuffixBeforeExtension._line_chart;
	    filters = FileSaver.filtersGraphics;
	} else if (p.getSecond() == scpHistogram) {
	    stack = stkHistogramZoom;
	    chart = pnlHistogram;
	    chartSize = new Dimension(1000, 1000);
	    saveDialogTitle = "Save Landscape Frequencies";
	    saveFileTitleSuffixBeforeExtension = FileSuffixBeforeExtension._frequencies;
	    filters = FileSaver.filtersGraphics;
	} else {
	    saveDialogTitle = "Save Landscape Raw Text";
	    saveFileTitleSuffixBeforeExtension = FileSuffixBeforeExtension._raw_text;
	    filters = FileSaver.filtersText;
	}
	if ((e.getSource() == cmdUnzoom) && (stack != null) && (chart != null)) {
	    final Rectangle2D viewport = stack.pop();
	    chart.setViewport(viewport);
	    checkEnabled(isEnabled());
	} else if ((e.getSource() == cmdResetView) && (stack != null)
		&& (chart != null)) {
	    chart.setViewport(stack.firstElement());
	    stack.clear();
	    checkEnabled(isEnabled());
	} else if (e.getSource() == cmdSave) {
	    try {
		final Pair<File, FileFilter> ff = FileSaver.getSaveFile(
			saveDialogTitle, saveFileTitleSuffixBeforeExtension,
			filters);
		if (ff == null) {
		    return;
		}
		if ((ff.getSecond() == FileSaver.ExtensionFilter.txtFilter)
			|| (chart == null) || (chartSize == null)) {
		    FileSaver.saveText(txaRaw.getText(), ff.getFirst());
		} else if (ff.getSecond() == FileSaver.ExtensionFilter.epsFilter) {
		    final Writer w = new FileWriter(ff.getFirst());
		    w.write(chart.getEpsText(chartSize.width, chartSize.height));
		    w.flush();
		    w.close();
		} else if (ff.getSecond() == FileSaver.ExtensionFilter.pngFilter) {
		    ImageIO.write(
			    chart.getImage(chartSize.width, chartSize.height),
			    "png", ff.getFirst());
		} else if (ff.getSecond() == FileSaver.ExtensionFilter.jpgFilter) {
		    ImageIO.write(
			    chart.getImage(chartSize.width, chartSize.height),
			    "jpeg", ff.getFirst());
		}
	    } catch (final IOException ex) {
		Utility.logException(ex);
		JOptionPane
			.showMessageDialog(getTopLevelAncestor(),
				ex.getMessage(), "I/O Error",
				JOptionPane.ERROR_MESSAGE);
	    }
	} else {
	    throw new IllegalArgumentException(e.getActionCommand());
	}
    }

    public void addActionListener(final ActionListener l) {
	listenerList.add(ActionListener.class, l);
    }

    private long[] binLandscape(final int nBins) {
	if (landscape == null) {
	    return null;
	}
	final boolean scaleFitness = ((landscapeMin != null) && (landscapeMax != null))
		&& useMinMax;
	final long[] bins = new long[nBins];
	for (final LabeledFloatInterface p : landscape) {
	    float fitness = p.getFloat();
	    if (Float.isInfinite(fitness) || Float.isNaN(fitness)) {
		continue;
	    }
	    assert fitness >= landscapeMin;
	    assert fitness <= landscapeMax;
	    if (scaleFitness) {
		fitness = (fitness - landscapeMin)
			/ (landscapeMax - landscapeMin);
	    }
	    assert fitness >= 0;
	    if (fitness >= 1.0) {
		bins[bins.length - 1]++;
	    } else {
		bins[(int) (fitness * nBins)]++;
	    }
	}
	return bins;
    }

    @SuppressWarnings("unchecked")
    private void checkEnabled(final boolean enabled) {
	cboDisplayType.setEnabled(enabled);
	cmdSave.setEnabled(enabled);
	lblBins.setEnabled(enabled);
	spnBins.setEnabled(enabled);
	pnlLineChart.setSelectionEnabled(enabled);
	pnlHistogram.setSelectionEnabled(enabled);
	final Pair<String, Component> p = (Pair<String, Component>) cboDisplayType
		.getSelectedItem();
	if (enabled) {
	    boolean zoomed = false;
	    if (p.getSecond() == scpLineChart) {
		zoomed = !stkLineChartZoom.empty();
	    } else if (p.getSecond() == scpHistogram) {
		zoomed = !stkHistogramZoom.empty();
	    }
	    cmdUnzoom.setEnabled(zoomed);
	    cmdResetView.setEnabled(zoomed);
	} else {
	    cmdUnzoom.setEnabled(false);
	    cmdResetView.setEnabled(false);
	}
    }

    protected void fireActionEvent(final ActionEvent e) {
	final ActionListener[] listeners = listenerList
		.getListeners(ActionListener.class);
	for (final ActionListener listener : listeners) {
	    listener.actionPerformed(e);
	}
    }

    public Landscape getLandscape() {
	return landscape;
    }

    public Font getTextFont() {
	return txaRaw.getFont();
    }

    public String getXAxisLabel() {
	return pnlLineChart.getXAxisLabel();
    }

    private String getYAxisExportableName() {
	return exportableAlternateName;

    }

    public String getYAxisLabel() {
	return pnlLineChart.getYAxisLabel();
    }

    @Override
    @SuppressWarnings("unchecked")
    public void itemStateChanged(final ItemEvent e) {
	final Pair<String, Component> p = (Pair<String, Component>) e.getItem();
	crdDisplay.show(pnlDisplay, p.toString());
	crdDisplayControls.show(pnlDisplayControls, p.toString());
	if (p.getSecond() == scpLineChart) {
	    crdZoomControls.show(pnlZoomControls, "Zoomable");
	} else if (p.getSecond() == scpHistogram) {
	    crdZoomControls.show(pnlZoomControls, "Zoomable");
	} else if (p.getSecond() == scpRaw) {
	    crdZoomControls.show(pnlZoomControls, "Unzoomable");
	}
	checkEnabled(isEnabled());
    }

    private void jbInit() {
	setLayout(bolThis);
	pnlDisplay.setLayout(crdDisplay);
	cmdSave.setText("Save");
	cmdSave.addActionListener(this);
	cmdUnzoom.addActionListener(this);
	cmdResetView.addActionListener(this);
	cmdUnzoom.setText("Unzoom");
	cmdResetView.setText("Reset View");
	pnlDisplayControls.setLayout(crdDisplayControls);
	gblControls.rowHeights = new int[] { 0, 0 };
	gblControls.rowWeights = new double[] { 1.0, 1.0 };
	gblControls.columnWeights = new double[] { 0.0, 0.0, 1.0, 0.0, 0.0, 0.0 };
	pnlControls.setLayout(gblControls);
	pnlHistogramControls.setLayout(gblHistogramControls);
	lblBins.setText("Bins:");
	spnBins.setMinimumSize(new Dimension(60, 20));
	spnBins.setPreferredSize(new Dimension(60, 20));
	spnBins.addChangeListener(this);
	spnBins.setModel(new SpinnerNumberModel(new Integer(10),
		new Integer(1), null, new Integer(1)));
	pnlZoomControls.setLayout(crdZoomControls);
	pnlZoomable.setLayout(gblZoomable);
	scpLineChart.setBorder(BorderFactory.createLoweredBevelBorder());
	scpHistogram.setBorder(BorderFactory.createLoweredBevelBorder());
	scpRaw.setBorder(BorderFactory.createLoweredBevelBorder());
	cboDisplayType.addItemListener(this);
	txaRaw.setEditable(false);
	pnlHistogram.setYAxisLabel("Count");
	cmdMaximize.setText("Maximize");
	cmdMaximize.addActionListener(new CmdMaximizeActionListener(this,
		cmdMaximize));
	this.add(pnlControls, java.awt.BorderLayout.SOUTH);
	this.add(pnlDisplay, java.awt.BorderLayout.CENTER);
	pnlDisplay.add(scpLineChart, "Line Chart");
	pnlDisplay.add(scpHistogram, "Frequencies");
	pnlDisplay.add(scpRaw, "Raw Text");
	scpLineChart.setViewportView(pnlLineChart);
	scpHistogram.setViewportView(pnlHistogram);
	scpRaw.setViewportView(txaRaw);
	pnlLineChart.addSelectionListener(this);
	pnlHistogram.addSelectionListener(this);
	cboDisplayType.addItem(new DisplayPair<String, Component>(
		LandscapePanelDisplayTypes.LineChart.getDisplayString(),
		scpLineChart));
	cboDisplayType.addItem(new DisplayPair<String, Component>(
		LandscapePanelDisplayTypes.Frequencies.getDisplayString(),
		scpHistogram));
	cboDisplayType.addItem(new DisplayPair<String, Component>(
		LandscapePanelDisplayTypes.RawText.getDisplayString(), scpRaw));
	pnlZoomControls.add(pnlZoomable, "Zoomable");
	pnlZoomControls.add(pnlUnzoomable, "Unzoomable");
	pnlZoomable.add(cmdUnzoom, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0,
		GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(
			5, 5, 5, 0), 0, 0));
	pnlZoomable.add(cmdResetView, new GridBagConstraints(1, 0, 1, 1, 0.0,
		0.0, GridBagConstraints.CENTER, GridBagConstraints.NONE,
		new Insets(5, 5, 5, 0), 0, 0));
	pnlHistogramControls.add(lblBins, new GridBagConstraints(1, 0, 1, 1,
		0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE,
		new Insets(5, 5, 5, 0), 0, 0));
	pnlHistogramControls.add(spnBins, new GridBagConstraints(2, 0, 1, 1,
		1.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.NONE,
		new Insets(5, 5, 5, 5), 0, 0));
	pnlDisplayControls.add(pnlLineChartControls,
		LandscapePanelDisplayTypes.LineChart.getDisplayString());
	pnlDisplayControls.add(pnlRawControls,
		LandscapePanelDisplayTypes.RawText.getDisplayString());
	chkbxVerbose.setVisible(hasAnnotator);
	chkbxVerbose.setSelected(LandscapePanel.verbose);
	txaRaw.setTabSize(30);
	chkbxVerbose.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		// System.err.println("ActionEvent: " + e);
		LandscapePanel.verbose = chkbxVerbose.isSelected();
		new Thread(new Runnable() {

		    @Override
		    public void run() {
			setLandscapeCommon(landscape);
			invalidate();
		    }
		}, "UpdateLandscapePanelThread").start();
	    }

	});
	pnlRawControls.add(chkbxVerbose);
	pnlDisplayControls.add(pnlHistogramControls,
		LandscapePanelDisplayTypes.Frequencies.getDisplayString());
	pnlControls.add(pnlZoomControls, new GridBagConstraints(1, 0, 1, 2,
		0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.NONE,
		new Insets(0, 0, 5, 5), 0, 0));
	pnlControls.add(cboDisplayType, new GridBagConstraints(0, 0, 1, 2, 0.0,
		0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
		new Insets(5, 5, 5, 5), 0, 0));
	pnlControls.add(pnlDisplayControls, new GridBagConstraints(3, 0, 1, 2,
		1.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH,
		new Insets(0, 0, 5, 5), 0, 0));
	pnlControls.add(cmdMaximize, new GridBagConstraints(4, 0, 1, 2, 0.0,
		0.0, GridBagConstraints.CENTER, GridBagConstraints.NONE,
		new Insets(5, 5, 5, 5), 0, 0));
	pnlControls.add(cmdSave, new GridBagConstraints(5, 0, 1, 2, 0.0, 0.0,
		GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(
			5, 5, 5, 0), 0, 0));
    }

    public void removeActionListener(final ActionListener l) {
	listenerList.remove(ActionListener.class, l);
    }

    @Override
    public void selectionChanged(final SelectionEvent e) {
	final AbstractChart chart = (AbstractChart) e.getSource();
	final Rectangle2D current = e.getViewport();
	if (chart == pnlLineChart) {
	    stkLineChartZoom.push(current);
	} else if (chart == pnlHistogram) {
	    stkHistogramZoom.push(current);
	}
	checkEnabled(isEnabled());
    }

    public void setDisplayType(final LandscapePanelDisplayTypes displayType) {
	cboDisplayType.setSelectedIndex(displayType.ordinal());
    }

    @Override
    public void setEnabled(final boolean enabled) {
	super.setEnabled(enabled);
	if (cboDisplayType == null) {
	    return;
	}
	checkEnabled(enabled);
    }

    @Override
    public void setFont(final Font font) {
	super.setFont(font);
	if (cboDisplayType == null) {
	    return;
	}
	cboDisplayType.setFont(font);
	cmdSave.setFont(font);
	cmdUnzoom.setFont(font);
	cmdResetView.setFont(font);
	cmdMaximize.setFont(font);
	spnBins.setFont(font);
	lblBins.setFont(font);
    }

    public void setHighlightedPointIndex(final int highlightedIndex,
	    final boolean repaint) {
	pnlLineChart.setHighlightedPointIndex(highlightedIndex, repaint);
    }

    public void setLandscape(final Landscape landscape) {
	setLandscape(landscape, true, (Comparator<LabeledFloatInterface>) null);
    }

    public void setLandscape(final Landscape landscape, final boolean scaleToFit) {
	setLandscape(landscape, scaleToFit,
		(Comparator<LabeledFloatInterface>) null);
    }

    private void setLandscape(final Landscape landscape,
	    final boolean scaleToFit,
	    final Comparator<LabeledFloatInterface> rawTextComparator) {
	this.rawTextComparator = rawTextComparator;
	hasAnnotator = (landscape != null) && (landscape.size() > 0)
		&& (landscape.first() instanceof Annotator);

	chkbxVerbose.setVisible(hasAnnotator);
	chkbxVerbose.setSelected(LandscapePanel.verbose);
	useMinMax = scaleToFit;
	setLandscapeCommon(landscape);
	final boolean scaleFitness = ((landscapeMin != null) && (landscapeMax != null))
		&& useMinMax;
	if (scaleFitness) {
	    pnlLineChart.setViewport(new Rectangle2D.Float(0, landscapeMin, 1,
		    landscapeMax - landscapeMin));
	}
	pnlLineChart.setLandscape(landscape, true);
    }

    public void setLandscape(final Landscape landscape,
	    final Comparator<LabeledFloatInterface> labeledFloatComparator) {
	setLandscape(landscape, true, labeledFloatComparator);
    }

    private void setLandscapeCommon(final Landscape landscape) {
	this.landscape = landscape;
	if (!stkLineChartZoom.empty()) {
	    pnlLineChart.setViewport(stkLineChartZoom.get(0));
	    stkLineChartZoom.clear();
	}
	if (landscape == null) {
	    landscapeMin = landscapeMax = null;
	} else {
	    float min = Float.POSITIVE_INFINITY;
	    float max = Float.NEGATIVE_INFINITY;
	    for (final LabeledFloatInterface p : landscape) {
		assert p != null : "an item in a landscape is null!";
		final float fitness = p.getFloat();
		if (Float.isInfinite(fitness)) {
		    continue;
		}
		if (fitness < min) {
		    min = fitness;
		}
		if (fitness > max) {
		    max = fitness;
		}
	    }
	    final float range = max - min;
	    final float fivePercentRange = Math.max(.05f, range * 0.05f);
	    landscapeMin = new Float(min - fivePercentRange);
	    landscapeMax = new Float(max + fivePercentRange);
	}
	if (!stkHistogramZoom.empty()) {
	    pnlHistogram.setViewport(stkHistogramZoom.get(0));
	    stkHistogramZoom.clear();
	}
	final boolean scaleFitness = ((landscapeMin != null) && (landscapeMax != null))
		&& useMinMax;
	if (scaleFitness) {
	    pnlHistogram.setBins(
		    binLandscape(((Number) spnBins.getValue()).intValue()),
		    landscapeMin.floatValue(), landscapeMax.floatValue());
	} else {
	    pnlHistogram.setBins(binLandscape(((Number) spnBins.getValue())
		    .intValue()));
	}
	// cboDisplayType.setSelectedIndex(0);
	if (landscape == null) {
	    txaRaw.setText("");
	} else {
	    final StringBuffer b = new StringBuffer();
	    if (rawTextComparator != null) {
		Collections.sort(landscape, rawTextComparator);
	    }
	    b.append(getXAxisLabel());
	    b.append('\t');
	    b.append(getYAxisExportableName());
	    b.append('\t');
	    if (hasAnnotator) {
		b.append(Utility.join(
			((Annotator) landscape.first())
				.getAnnotationHeader(chkbxVerbose.isSelected() /* verbose */),
			"\t"));
	    }
	    b.append('\n');
	    for (final LabeledFloatInterface p : landscape) {
		b.append(p.getLabel());
		b.append('\t');
		b.append(Main.decimalUpToSixPrecision.format(p.getFloat()));
		b.append('\t');
		if (hasAnnotator) {
		    b.append(Utility.join(
			    ((Annotator) p).getAnnotationFields(chkbxVerbose
				    .isSelected() /* verbose */), "\t"));
		}
		b.append('\n');
	    }
	    txaRaw.setText(b.toString());
	    txaRaw.select(0, 0);
	}
    }

    public void setTextFont(final Font font) {
	txaRaw.setFont(font);
    }

    public void setXAxisLabel(final String label) {
	pnlLineChart.setXAxisLabel(label);
    }

    public void setYAxisExportableName(final String exportableAlternateName) {
	this.exportableAlternateName = exportableAlternateName;

    }

    public void setYAxisLabel(final String label) {
	setYAxisExportableName(label);
	pnlLineChart.setYAxisLabel(label);
	pnlHistogram.setXAxisLabel(label);
    }

    @Override
    public void stateChanged(final ChangeEvent e) {
	if ((landscapeMin != null) && (landscapeMax != null)) {
	    pnlHistogram.setBins(
		    binLandscape(((Number) spnBins.getValue()).intValue()),
		    landscapeMin.floatValue(), landscapeMax.floatValue());
	} else {
	    pnlHistogram.setBins(binLandscape(((Number) spnBins.getValue())
		    .intValue()));
	}
    }

    public enum LandscapePanelDisplayTypes {
	LineChart("Line Chart"), Frequencies, RawText("Raw Text");
	private final String displayName;

	LandscapePanelDisplayTypes() {
	    this(null);
	}

	LandscapePanelDisplayTypes(final String displayName) {
	    if (displayName == null) {
		this.displayName = name(); // OPTIONAL -- if displayName is null
					   // programmatically create a display
					   // name
	    } else {
		this.displayName = displayName;
	    }
	}

	public String getDisplayString() {
	    return displayName;
	}
    } // end enum LandscapePanelDisplayTypes
} // end LandscapePanel class
