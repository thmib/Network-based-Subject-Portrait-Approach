package org.epistasis.mdr.analysis;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

import org.epistasis.exceptions.IncompleteBuildException;
import org.epistasis.mdr.AmbiguousCellStatus;
import org.epistasis.mdr.AnalysisFileManager;
import org.epistasis.mdr.enums.FitnessCriteriaOrder;
import org.epistasis.mdr.newengine.AttributeCombination;
import org.epistasis.mdr.newengine.AttributeCombinationWithWildcards;
import org.epistasis.mdr.newengine.Dataset;

public class ExhaustiveAnalysisThread extends AnalysisThread {

    public static final String FORCED_ATTRIBUTES_ARE_NOT_AMONG_RESTRICTED_ATTRIBUTES = "forced attributes are not among restricted attributes";
    private final List<AttributeCombination> forced;

    private ExhaustiveAnalysisThread(final Dataset data,
	    final FitnessCriteriaOrder topModelsFitnessCriteriaOrder,
	    final FitnessCriteriaOrder bestModelFitnessCriteriaOrder,
	    final int numCrossValidationIntervals,
	    final AmbiguousCellStatus tiePriorityList, final long seed,
	    final Runnable onEndModel, final Runnable onEndLevel,
	    final Runnable onEndAnalysis, final boolean parallel,
	    final int topModelsLandscapeSize,
	    final boolean computeAllModelsLandscape, final int minAttr,
	    final int maxAttr, final int[] restrictedSearchAttributes,
	    final List<AttributeCombination> forced,
	    final int distributedNodeCount, final int distributedNodeNumber) {
	super(data, topModelsFitnessCriteriaOrder,
		bestModelFitnessCriteriaOrder, numCrossValidationIntervals,
		minAttr, maxAttr, tiePriorityList, seed, onEndModel,
		onEndLevel, onEndAnalysis, parallel, topModelsLandscapeSize,
		computeAllModelsLandscape);

	this.forced = forced;
	SortedSet<Integer> comboSizes;
	if (forced != null) {
	    comboSizes = AttributeCombination.getCombinationSizes(forced);
	    setMinAttr(comboSizes.first());
	    setMaxAttr(comboSizes.last());
	} else {
	    if (minAttr > maxAttr) {
		throw new IllegalArgumentException("minAttr(" + minAttr
			+ ") cannot be larger than maxAttr(" + maxAttr + ")");
	    }
	    comboSizes = new TreeSet<Integer>();
	    for (int comboSize = minAttr; comboSize <= maxAttr; ++comboSize) {
		comboSizes.add(comboSize);
	    }
	}

	final int numAttributes = data.getNumAttributes();
	for (final Integer comboSize : comboSizes) {
	    int numAttributesToSearchOver = numAttributes;
	    if (restrictedSearchAttributes != null) {
		numAttributesToSearchOver = restrictedSearchAttributes.length;
	    }
	    final ExhaustiveProducer exhaustiveProducer = new ExhaustiveProducer(
		    numAttributesToSearchOver, comboSize, data.getLabels(),
		    getIntervals(), restrictedSearchAttributes, forced,
		    distributedNodeCount, distributedNodeNumber);
	    addProducer(exhaustiveProducer);
	} // end loop over number of attributes
    }

    @Override
    protected List<AttributeCombination> getForced() {
	return forced;
    }

    @Override
    public void saveAnalysis(final AnalysisFileManager analysisFileManager) {
	if (forced == null) {
	    analysisFileManager.putCfg(AnalysisFileManager.cfgWrapper,
		    AnalysisFileManager.cfgValExhaustive);
	} else {
	    analysisFileManager.putCfg(AnalysisFileManager.cfgWrapper,
		    AnalysisFileManager.cfgValForced);
	}
    }

    public static class ExhaustiveAnalysisThreadBuilder extends
	    AnalysisThreadBuilder<ExhaustiveAnalysisThread> {
	private List<AttributeCombination> forced = null;

	public ExhaustiveAnalysisThreadBuilder(final Dataset data,
		final int numCrossValidationIntervals, final long seed) {
	    super(data, numCrossValidationIntervals, seed);
	}

	@Override
	public ExhaustiveAnalysisThread build() {
	    if ((forced == null) && ((minAttr == -1) || (maxAttr == -1))) {
		throw new IncompleteBuildException("Exhaustive field not set");
	    }

	    if (forced != null) {
		boolean forcedAttributesAmongRestricted = true;
		for (final AttributeCombination attributeCombination : forced) {
		    forcedAttributesAmongRestricted = attributeCombination
			    .checkRestrictedAttributes(restrictedSearchAttributes);
		    if (!forcedAttributesAmongRestricted) {
			throw new IncompleteBuildException(
				ExhaustiveAnalysisThread.FORCED_ATTRIBUTES_ARE_NOT_AMONG_RESTRICTED_ATTRIBUTES);
		    }
		}
	    }
	    return new ExhaustiveAnalysisThread(data,
		    topModelsFitnessCriteriaOrder,
		    bestModelFitnessCriteriaOrder, numCrossValidationIntervals,
		    tiePriorityList, seed, onEndModel, onEndLevel,
		    onEndAnalysis, parallel, topModelsLandscapeSize,
		    computeAllModelsLandscape, minAttr, maxAttr,
		    restrictedSearchAttributes, forced, distributedNodeCount,
		    distributedNodeNumber);
	}

	/*
	 * this will override setMin and setMax since the forced with wildcards
	 * determines the number of levels
	 */
	public ExhaustiveAnalysisThreadBuilder setForced(
		final List<AttributeCombination> forced) {
	    this.forced = forced;
	    return this;
	}

    }

    public static class ExhaustiveProducer extends Producer {
	private AttributeCombination attributes;
	protected Iterator<Iterator<AttributeCombination>> combinationGeneratorIterator;
	protected Iterator<AttributeCombination> combinationIterator;
	private final int numAttributes;

	public ExhaustiveProducer(final int numAttributes, final int comboSize,
		final List<String> labels, final int intervals,
		final int[] restrictedSearchAttributes,
		final List<AttributeCombination> forced,
		final int distributedNodeCount, final int distributedNodeNumber) {
	    this.numAttributes = numAttributes;
	    final List<Iterator<AttributeCombination>> combinationGenerators = new ArrayList<Iterator<AttributeCombination>>();
	    if (forced == null) {
		combinationGenerators.add(new CombinationGenerator(
			numAttributes, comboSize, labels,
			restrictedSearchAttributes,
			(AttributeCombination) null, distributedNodeCount,
			distributedNodeNumber));

	    } else {
		for (final AttributeCombination attributeCombination : forced) {
		    if (attributeCombination.getMax() == comboSize) {
			if (attributeCombination instanceof AttributeCombinationWithWildcards) {
			    combinationGenerators.add(new CombinationGenerator(
				    numAttributes, comboSize, labels,
				    restrictedSearchAttributes,
				    attributeCombination, distributedNodeCount,
				    distributedNodeNumber));
			} else {
			    combinationGenerators.add(attributeCombination
				    .iterator());
			}
		    }
		}
	    }
	    combinationGeneratorIterator = combinationGenerators.iterator();
	    combinationIterator = combinationGeneratorIterator.next();
	}

	public int getNumAttributes() {
	    return numAttributes;
	}

	@Override
	public QueueEntry produce() {
	    QueueEntry entry = null;

	    boolean nextComboReady = combinationIterator.hasNext();
	    if (!nextComboReady) {
		if (combinationGeneratorIterator.hasNext()) {
		    combinationIterator = combinationGeneratorIterator.next();
		    nextComboReady = combinationIterator.hasNext();
		}
	    }
	    if (nextComboReady) {
		attributes = combinationIterator.next();
		entry = new QueueEntry(attributes);
	    }

	    return entry;
	}
    } // end static class ExhaustiveProducer
}
