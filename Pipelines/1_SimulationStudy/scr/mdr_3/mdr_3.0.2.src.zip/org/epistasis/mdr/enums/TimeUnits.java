package org.epistasis.mdr.enums;

public enum TimeUnits {
    Seconds(1), Minutes(60 * Seconds.getSeconds()), Hours(60 * Minutes
	    .getSeconds()), Days(24 * Hours.getSeconds());

    private final long seconds;

    TimeUnits(final long seconds) {
	this.seconds = seconds;
    }

    public long getMillis() {
	return seconds * 1000L;
    }

    public long getSeconds() {
	return seconds;
    }

}
