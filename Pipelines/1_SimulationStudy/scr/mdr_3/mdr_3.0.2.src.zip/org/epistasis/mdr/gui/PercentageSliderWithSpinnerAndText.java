package org.epistasis.mdr.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.SwingConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.plaf.basic.BasicSliderUI;

import org.epistasis.mdr.Main;
import org.epistasis.mdr.networkEntropy.GraphLevelMetrics;

@SuppressWarnings("serial")
public class PercentageSliderWithSpinnerAndText extends JPanel {
    private final JSlider slider = new JSlider();
    private final JButton btnSmaller = new JButton("<<");
    private final JButton btnLarger = new JButton(">>");
    private double spinnerValue = Double.NaN;
    private double adjustingSpinnerValue = Double.NaN;
    private Double[] spinnerValuesArray = new Double[0];
    private final JLabel lblMinimum = new JLabel("minimum");
    private final JLabel lblMaximum = new JLabel("maximum");
    private final JLabel lblCurrent = new JLabel("current");
    private String descriptiveLabelText;
    private String propertyNamePrefix;

    /**
     * Create the panel.
     */
    public PercentageSliderWithSpinnerAndText() {
	this("Edge", "Edge visibility threshold: ");
    }

    public PercentageSliderWithSpinnerAndText(
	    final String newPropertyNamePrefix,
	    final String pDescriptiveLabelText) {
	slider.setMinimum(0);
	slider.setMaximum(0);
	setSpinnerListModel(new Double[] { 0.0 });
	setDescriptiveLabelText(pDescriptiveLabelText);
	setPropertyNamePrefix(newPropertyNamePrefix);
	init();
	initDataBindings();
	slider.setPaintTicks(true);
	slider.setMinorTickSpacing(0);
	slider.setForeground(SystemColor.textHighlight);
	slider.putClientProperty("Slider.paintThumbArrowShape", true);
	slider.addChangeListener(new ChangeListener() {
	    @Override
	    public void stateChanged(final ChangeEvent arg0) {
		setSliderValue(slider.getValue());
	    }
	});
	slider.setSnapToTicks(true);
	slider.setMinorTickSpacing(1);
	final SparklineSliderUI sparklineSliderUI = new SparklineSliderUI(
		slider);
	slider.setUI(sparklineSliderUI);
	final GridBagConstraints gbc_lblMinimum = new GridBagConstraints();
	gbc_lblMinimum.anchor = GridBagConstraints.NORTHWEST;
	gbc_lblMinimum.insets = new Insets(0, 0, 0, 5);
	gbc_lblMinimum.gridx = 0;
	gbc_lblMinimum.gridy = 1;
	lblMinimum.setVerticalAlignment(SwingConstants.TOP);
	add(lblMinimum, gbc_lblMinimum);
	final GridBagConstraints gbc_btnSmaller = new GridBagConstraints();
	gbc_btnSmaller.anchor = GridBagConstraints.NORTH;
	gbc_btnSmaller.insets = new Insets(0, 0, 0, 5);
	gbc_btnSmaller.gridx = 1;
	gbc_btnSmaller.gridy = 1;
	add(btnSmaller, gbc_btnSmaller);
	final GridBagConstraints gbc_lblCurrent = new GridBagConstraints();
	gbc_lblCurrent.anchor = GridBagConstraints.NORTH;
	gbc_lblCurrent.insets = new Insets(0, 0, 0, 5);
	gbc_lblCurrent.gridx = 2;
	gbc_lblCurrent.gridy = 1;
	lblCurrent.setVerticalAlignment(SwingConstants.TOP);
	add(lblCurrent, gbc_lblCurrent);
	final GridBagConstraints gbc_btnLarger = new GridBagConstraints();
	gbc_btnLarger.anchor = GridBagConstraints.NORTH;
	gbc_btnLarger.insets = new Insets(0, 0, 0, 5);
	gbc_btnLarger.gridx = 3;
	gbc_btnLarger.gridy = 1;
	add(btnLarger, gbc_btnLarger);
	final GridBagConstraints gbc_lblMaximum = new GridBagConstraints();
	gbc_lblMaximum.anchor = GridBagConstraints.NORTHEAST;
	gbc_lblMaximum.gridx = 4;
	gbc_lblMaximum.gridy = 1;
	lblMaximum.setVerticalAlignment(SwingConstants.TOP);
	add(lblMaximum, gbc_lblMaximum);
    } // end constructor

    public void focusOnSlider() {
	slider.requestFocusInWindow();
    }

    public String getDescriptiveLabelText() {
	return descriptiveLabelText;
    }

    public double getListValue() {
	return getListValueFromSlider(slider.getValue());
    }

    public double getListValueFromSlider(final int sliderValue) {
	return spinnerValuesArray[sliderValue];
    }

    public int getSliderPercentage() {
	return getSliderPercentage(slider.getValue());
    }

    public int getSliderPercentage(final int sliderValue) {
	final float returnValue = ((spinnerValuesArray.length - sliderValue) * 100)
		/ (float) spinnerValuesArray.length;
	// System.out.println("slideValue: " + sliderValue
	// + " results in percentage: " + returnValue);
	return (int) returnValue;
    }

    public int getSliderValue() {
	return slider.getValue();
    }

    public void init() {
	final GridBagLayout gridBagLayout = new GridBagLayout();
	gridBagLayout.columnWidths = new int[] { 0, 0, 0, 0, 0 };
	gridBagLayout.rowHeights = new int[] { 20, 18, 0 };
	gridBagLayout.columnWeights = new double[] { 0.0, 0.0, 1.0, 0.0, 0.0 };
	gridBagLayout.rowWeights = new double[] { 0.0, 0.0, Double.MIN_VALUE };
	setLayout(gridBagLayout);
	btnSmaller.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		slider.setValue(slider.getValue() - 1);
	    }
	});
	btnSmaller.setFont(new Font("Tahoma", Font.PLAIN, 9));
	slider.setFont(new Font("Tahoma", Font.PLAIN, 9));
	final GridBagConstraints gbc_slider = new GridBagConstraints();
	gbc_slider.insets = new Insets(0, 0, 5, 0);
	gbc_slider.anchor = GridBagConstraints.SOUTH;
	gbc_slider.gridwidth = 5;
	gbc_slider.fill = GridBagConstraints.HORIZONTAL;
	gbc_slider.gridx = 0;
	gbc_slider.gridy = 0;
	add(slider, gbc_slider);
	btnLarger.addActionListener(new ActionListener() {
	    @Override
	    public void actionPerformed(final ActionEvent e) {
		slider.setValue(slider.getValue() + 1);
	    }
	});
	btnLarger.setFont(new Font("Tahoma", Font.PLAIN, 9));
    }

    protected void initDataBindings() {
    }

    private void setCenterLabel() {
	if (slider.getMaximum() > 1) {
	    final int currentSliderValue = slider.getValue();
	    lblCurrent.setText(descriptiveLabelText
		    + getListValueFromSlider(currentSliderValue) + " ("
		    + getSliderPercentage(currentSliderValue) + "%)");
	    lblCurrent.invalidate();
	}
    }

    public void setDescriptiveLabelText(final String descriptiveLabelText) {
	this.descriptiveLabelText = descriptiveLabelText;
	setCenterLabel();
    }

    @Override
    public void setEnabled(final boolean enabled) {
	super.setEnabled(enabled);
	for (final Component component : getComponents()) {
	    component.setEnabled(enabled);
	}
    }

    public void setPropertyNamePrefix(final String newPropertyNamePrefix) {
	propertyNamePrefix = newPropertyNamePrefix;
    }

    public void setSliderPercentage(final int newPercentage) {
	final int newSliderValue = spinnerValuesArray.length
		- ((spinnerValuesArray.length * newPercentage) / 100);
	setSliderValue(newSliderValue);
    }

    private void setSliderValue(final int newSliderValue) {
	final boolean isAdjusting = slider.getValueIsAdjusting();
	boolean redrawCenterLabel = false;
	final double currentSpinnerValue = getListValue();
	if (isAdjusting) {
	    if (adjustingSpinnerValue != currentSpinnerValue) {
		redrawCenterLabel = true;
		firePropertyChange(
			propertyNamePrefix
				+ "_PercentageSliderWithSpinnerAndText_value_while_adjusting",
			adjustingSpinnerValue,
			adjustingSpinnerValue = currentSpinnerValue);
	    }
	} else { // not adjusting
	    if (spinnerValue != currentSpinnerValue) {
		redrawCenterLabel = true;
		firePropertyChange(propertyNamePrefix
			+ "_PercentageSliderWithSpinnerAndText_value",
			spinnerValue, spinnerValue = currentSpinnerValue);
		adjustingSpinnerValue = Double.NaN;
	    }
	} // end if not adjusting
	  // System.out.println("setSliderValue(" + newSliderValue +
	  // ") called");
	if (slider.getValue() != newSliderValue) {
	    slider.setValue(newSliderValue);
	}
	if (redrawCenterLabel) {
	    setCenterLabel();
	}
	btnSmaller.setEnabled(slider.getValue() != slider.getMinimum());
	btnLarger.setEnabled(slider.getValue() != slider.getMaximum());
    }

    /**
     * The set should be sorted ascending.
     * 
     * @param values
     */
    public void setSpinnerListModel(final Double[] values) {
	setSpinnerListModel(values, descriptiveLabelText);
    }

    public void setSpinnerListModel(final Double[] values,
	    final String pDescriptiveLabelText) {
	spinnerValuesArray = values;
	final GraphLevelMetrics.MinimumMaximum minMax = new GraphLevelMetrics.MinimumMaximum(
		spinnerValuesArray);
	slider.setMaximum(spinnerValuesArray.length - 1);
	lblMinimum
		.setText(Main.decimalUpToFourPrecision.format(minMax.minimum));
	lblMaximum
		.setText(Main.decimalUpToFourPrecision.format(minMax.maximum));
	// do not have more than 100 tick marks
	slider.setMajorTickSpacing((int) Math.max(1,
		Math.ceil(spinnerValuesArray.length / 100.0)));
	setDescriptiveLabelText(pDescriptiveLabelText);
	invalidate();
    }

    private class SparklineSliderUI extends BasicSliderUI {
	SparklineSliderUI(final JSlider slider) {
	    super(slider);
	}

	@Override
	public void paintThumb(final Graphics g) {
	    final Color oldBackgroundColor = slider.getBackground();
	    slider.setBackground(slider.getForeground());
	    super.paintThumb(g);
	    slider.setBackground(oldBackgroundColor);
	}

	@Override
	public void paintTrack(final Graphics g) {
	    if (slider.getOrientation() == SwingConstants.HORIZONTAL) {
		GraphLevelMetrics.SparklineIcon.drawSparkline(g, trackRect,
			spinnerValuesArray, slider.getForeground(),
			slider.getValue(), true /* reverseList */);
	    } // end if horizontal
	    else {
		throw new RuntimeException(
			"VERTICAL_ORIENTATION not implemented");
	    }
	} // end paintTrack
    } // end SparklineSliderUI;
}
