package org.epistasis.mdr.newengine;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class AttributeCombinationWithWildcards extends AttributeCombination {
    private static final Pattern whitespace = Pattern.compile("\\s");
    private static final char WILDCARD_CHAR = '*';
    private static final String WILDCARD_STRING = String
	    .valueOf(AttributeCombinationWithWildcards.WILDCARD_CHAR);
    int howManyWildCards = 0;

    public static List<AttributeCombination> parseComboWithPossibilityOfWildcards(
	    final String combinationsString, final int numAttributes,
	    final List<String> labels) {
	final String[] forcedAttributesStrings = AttributeCombinationWithWildcards.whitespace
		.split(combinationsString);
	final List<AttributeCombination> combinations = new ArrayList<AttributeCombination>(
		forcedAttributesStrings.length);
	for (final String comboString : forcedAttributesStrings) {
	    AttributeCombination attributeCombination;
	    if (comboString
		    .contains(AttributeCombinationWithWildcards.WILDCARD_STRING)) {
		attributeCombination = new AttributeCombinationWithWildcards(
			comboString, numAttributes, labels);
	    } else {
		attributeCombination = new AttributeCombination(comboString,
			numAttributes, labels);
	    }
	    combinations.add(attributeCombination);
	}
	return combinations;
    }

    private AttributeCombinationWithWildcards(final String comboString,
	    final int numAttributes, final List<String> labels) {
	super(labels);
	String[] attributeNames = AttributeCombination
		.splitAttributes(comboString);
	final List<String> goodAttributes = new ArrayList<String>(
		attributeNames.length);
	for (final String attributeName : attributeNames) {
	    if (attributeName
		    .contains(AttributeCombinationWithWildcards.WILDCARD_STRING)) {
		// make sure that the name contains only asterisks and count
		// them
		for (final char character : attributeName.toCharArray()) {
		    if (character == AttributeCombinationWithWildcards.WILDCARD_CHAR) {
			++howManyWildCards;
		    } else {
			throw new IllegalArgumentException(
				"Attribute names cannot contain asterisks. Asterisks can be used only to indicate a wildcard. Passed in attribute name: "
					+ attributeName);
		    }
		} // end checking each char
	    } // end if attributeName has at least one wildcard char
	    else {
		goodAttributes.add(attributeName);
	    }
	} // loop over attributeNames
	if (howManyWildCards > 0) {
	    if (goodAttributes.size() == 0) {
		throw new IllegalArgumentException(
			"Attribute names cannot contain ONLY asterisks (wildcards). At least one existing attribute must be specified");
	    }
	    attributeNames = new String[goodAttributes.size()];
	    attributeNames = goodAttributes.toArray(attributeNames);
	}
	combo = Dataset.attributeNameListToAscendingIndicesArray(
		true /* throwExceptionOnUnknownAttributes */, attributeNames,
		numAttributes, labels);

    } // end constructor AttributeCombinationWithWildcards

    @Override
    public int getMax() {
	return size() + howManyWildCards;
    }

    @Override
    public int getMin() {
	return size();
    }

    @Override
    public String toString() {
	final StringBuilder sb = new StringBuilder(super.toString());
	for (int ctr = howManyWildCards; ctr > 0; --ctr) {
	    sb.append(AttributeCombination.MODEL_DELIMITER_CHAR);
	    sb.append(AttributeCombinationWithWildcards.WILDCARD_CHAR);
	}
	return sb.toString();
    }
}
