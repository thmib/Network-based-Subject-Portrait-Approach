package org.epistasis.mdr.gui;

import java.awt.image.BufferedImage;

public interface EntropyDisplay {
    public String getEPSText();

    public int getFontSize();

    public BufferedImage getImage();

    public int getLineThickness();

    public void setFontSize(int fontSize);

    public void setLineThickness(int lineThickness);

    public void setMargin(int pMargin);

    public boolean supportEntropyThreshold();

    public void updateGraph();
}
