package org.epistasis.mdr.enums;

import java.io.Serializable;
import java.util.Arrays;

import org.epistasis.Utility;

public class FitnessCriteriaOrder implements Serializable {
    private static final long serialVersionUID = 1L;
    private final static char delimiterChar = '-';
    private final static String delimiterString = String
	    .valueOf(FitnessCriteriaOrder.delimiterChar);
    public final static FitnessCriteriaOrder MODEL_OVERALL = new FitnessCriteriaOrder(
	    new FitnessCriterion[] { FitnessCriterion.MODEL_OVERALL,
		    FitnessCriterion.MODEL_ATTRIBUTES });
    public final static FitnessCriteriaOrder MODEL_TRAINING = new FitnessCriteriaOrder(
	    new FitnessCriterion[] { FitnessCriterion.MODEL_TRAINING,
		    FitnessCriterion.MODEL_OVERALL,
		    FitnessCriterion.MODEL_ATTRIBUTES });
    public final static FitnessCriteriaOrder MODEL_TESTING = new FitnessCriteriaOrder(
	    new FitnessCriterion[] { FitnessCriterion.MODEL_TESTING,
		    FitnessCriterion.MODEL_OVERALL,
		    FitnessCriterion.MODEL_ATTRIBUTES });
    public final static FitnessCriteriaOrder MODEL_ADJUSTED_TESTING = new FitnessCriteriaOrder(
	    new FitnessCriterion[] { FitnessCriterion.MODEL_ADJUSTED_TESTING,
		    FitnessCriterion.MODEL_OVERALL,
		    FitnessCriterion.MODEL_ATTRIBUTES });
    public final static FitnessCriteriaOrder CVC_MODEL_WINNERS_TESTING = new FitnessCriteriaOrder(
	    new FitnessCriterion[] { FitnessCriterion.CVC,
		    FitnessCriterion.MODEL_WINNERS_TESTING,
		    FitnessCriterion.MODEL_OVERALL,
		    FitnessCriterion.MODEL_ATTRIBUTES });
    public final static FitnessCriteriaOrder CVC_MODEL_TRAINING = new FitnessCriteriaOrder(
	    new FitnessCriterion[] { FitnessCriterion.CVC,
		    FitnessCriterion.MODEL_TRAINING,
		    FitnessCriterion.MODEL_OVERALL,
		    FitnessCriterion.MODEL_ATTRIBUTES });
    public final static FitnessCriteriaOrder CVC_MODEL_TESTING = new FitnessCriteriaOrder(
	    new FitnessCriterion[] { FitnessCriterion.CVC,
		    FitnessCriterion.MODEL_TESTING,
		    FitnessCriterion.MODEL_OVERALL,
		    FitnessCriterion.MODEL_ATTRIBUTES });
    public final static FitnessCriteriaOrder CVC_CV_TESTING = new FitnessCriteriaOrder(
	    new FitnessCriterion[] { FitnessCriterion.CVC,
		    FitnessCriterion.CV_TESTING,
		    FitnessCriterion.MODEL_OVERALL,
		    FitnessCriterion.MODEL_ATTRIBUTES });
    public final static FitnessCriteriaOrder MODEL_TESTING_CVC = new FitnessCriteriaOrder(
	    new FitnessCriterion[] { FitnessCriterion.MODEL_TESTING,
		    FitnessCriterion.CVC, FitnessCriterion.MODEL_OVERALL,
		    FitnessCriterion.MODEL_ATTRIBUTES });
    public final static FitnessCriteriaOrder MODEL_TESTING_TRAINING = new FitnessCriteriaOrder(
	    new FitnessCriterion[] { FitnessCriterion.MODEL_TESTING,
		    FitnessCriterion.MODEL_TRAINING,
		    FitnessCriterion.MODEL_OVERALL,
		    FitnessCriterion.MODEL_ATTRIBUTES });
    public final static FitnessCriteriaOrder MODEL_TRAINING_TESTING = new FitnessCriteriaOrder(
	    new FitnessCriterion[] { FitnessCriterion.MODEL_TRAINING,
		    FitnessCriterion.MODEL_TESTING,
		    FitnessCriterion.MODEL_OVERALL,
		    FitnessCriterion.MODEL_ATTRIBUTES });
    public final static FitnessCriteriaOrder COVERAGE_MODEL_TRAINING = new FitnessCriteriaOrder(
	    new FitnessCriterion[] { FitnessCriterion.COVERAGE,
		    FitnessCriterion.MODEL_TRAINING,
		    FitnessCriterion.MODEL_OVERALL,
		    FitnessCriterion.MODEL_ATTRIBUTES });
    public final static FitnessCriteriaOrder COVERAGE_MODEL_TESTING = new FitnessCriteriaOrder(
	    new FitnessCriterion[] { FitnessCriterion.COVERAGE,
		    FitnessCriterion.MODEL_TESTING,
		    FitnessCriterion.MODEL_OVERALL,
		    FitnessCriterion.MODEL_ATTRIBUTES });
    public final static FitnessCriteriaOrder CV_TESTING_CVC = new FitnessCriteriaOrder(
	    new FitnessCriterion[] { FitnessCriterion.CV_TESTING,
		    FitnessCriterion.CVC, FitnessCriterion.MODEL_OVERALL,
		    FitnessCriterion.MODEL_ATTRIBUTES });

    private final FitnessCriterion[] testsInPriorityOrder;
    private final boolean dependentOnCrossValidation;
    private final boolean dependentOnCVC;
    public final static FitnessCriteriaOrder[] topModelsCriteriaIndependentOfCVC = new FitnessCriteriaOrder[] {
	    FitnessCriteriaOrder.MODEL_OVERALL,
	    FitnessCriteriaOrder.MODEL_TRAINING,
	    FitnessCriteriaOrder.MODEL_TESTING,
	    FitnessCriteriaOrder.MODEL_ADJUSTED_TESTING,
	    FitnessCriteriaOrder.MODEL_TESTING_TRAINING,
	    FitnessCriteriaOrder.MODEL_TRAINING_TESTING,
	    FitnessCriteriaOrder.COVERAGE_MODEL_TRAINING,
	    FitnessCriteriaOrder.COVERAGE_MODEL_TESTING, };
    public final static FitnessCriteriaOrder[] bestModelCriteriaPossiblyDependentOnCVC = new FitnessCriteriaOrder[] {
	    FitnessCriteriaOrder.CVC_MODEL_WINNERS_TESTING,
	    FitnessCriteriaOrder.CVC_CV_TESTING,
	    FitnessCriteriaOrder.CVC_MODEL_TESTING,
	    FitnessCriteriaOrder.CVC_MODEL_TRAINING,
	    FitnessCriteriaOrder.CV_TESTING_CVC,
	    FitnessCriteriaOrder.MODEL_OVERALL,
	    FitnessCriteriaOrder.MODEL_TRAINING,
	    FitnessCriteriaOrder.MODEL_ADJUSTED_TESTING,
	    FitnessCriteriaOrder.MODEL_TESTING_CVC,
	    FitnessCriteriaOrder.MODEL_TESTING_TRAINING,
	    FitnessCriteriaOrder.MODEL_TRAINING_TESTING, };

    public static FitnessCriteriaOrder lookup(final String displayName) {
	final String[] fitnessCriteriaStrings = displayName
		.split(FitnessCriteriaOrder.delimiterString);
	final FitnessCriterion[] fitnessCriteria = new FitnessCriterion[fitnessCriteriaStrings.length];
	for (final int index : Utility.range(fitnessCriteria.length)) {
	    fitnessCriteria[index] = Enum.valueOf(FitnessCriterion.class,
		    fitnessCriteriaStrings[index].toUpperCase());
	}
	final FitnessCriteriaOrder fitnessCriteriaOrder = new FitnessCriteriaOrder(
		fitnessCriteria);
	for (final FitnessCriteriaOrder topModelsCriteriaIndependentOfCVC : FitnessCriteriaOrder.topModelsCriteriaIndependentOfCVC) {
	    if (Arrays.equals(
		    topModelsCriteriaIndependentOfCVC.testsInPriorityOrder,
		    fitnessCriteriaOrder.testsInPriorityOrder)) {
		return topModelsCriteriaIndependentOfCVC;
	    }
	}
	for (final FitnessCriteriaOrder bestModelCriteriaPossiblyDependentOnCVC : FitnessCriteriaOrder.bestModelCriteriaPossiblyDependentOnCVC) {
	    if (Arrays
		    .equals(bestModelCriteriaPossiblyDependentOnCVC.testsInPriorityOrder,
			    fitnessCriteriaOrder.testsInPriorityOrder)) {
		return bestModelCriteriaPossiblyDependentOnCVC;
	    }
	}
	throw new IllegalArgumentException("FitnessCriteriaOrder.lookup("
		+ displayName + ") was not recognized.");
    }

    public static FitnessCriteriaOrder stripFinalModelAttributesFitnessCriterion(
	    final FitnessCriteriaOrder fitnessCriteriaOrder) {
	if (fitnessCriteriaOrder.testsInPriorityOrder[fitnessCriteriaOrder
		.size() - 1] == FitnessCriterion.MODEL_ATTRIBUTES) {
	    return new FitnessCriteriaOrder(Arrays.copyOfRange(
		    fitnessCriteriaOrder.testsInPriorityOrder, 0,
		    fitnessCriteriaOrder.size() - 1), /* requireLastToBeUltimateTieBreaker */
	    false);
	} else {
	    // return original object since last item not MODEL_ATTRIBUTES
	    return fitnessCriteriaOrder;
	}
    }

    /**
     * 
     * @param fitnessCriterions
     */
    public FitnessCriteriaOrder(final FitnessCriterion[] fitnessCriterions) {
	this(fitnessCriterions, true /* requireLastToBeUltimateTieBreaker */);
    }

    public FitnessCriteriaOrder(final FitnessCriterion[] fitnessCriterions,
	    final boolean requireLastToBeUltimateTieBreaker) {
	testsInPriorityOrder = fitnessCriterions;
	if (requireLastToBeUltimateTieBreaker) {
	    if (testsInPriorityOrder[testsInPriorityOrder.length - 1] != FitnessCriterion.MODEL_ATTRIBUTES) {
		throw new IllegalArgumentException(
			"Last test is not FitnessCriterion.MODEL_ATTRIBUTES. Tests: "
				+ Arrays.toString(testsInPriorityOrder));
	    }
	    assert testsInPriorityOrder[testsInPriorityOrder.length - 2] == FitnessCriterion.MODEL_OVERALL : "Second to last test is not FitnessCriterion.MODEL_OVERALL. Tests: "
		    + Arrays.toString(testsInPriorityOrder);
	} else {
	    assert testsInPriorityOrder[testsInPriorityOrder.length - 1] == FitnessCriterion.MODEL_OVERALL : "Second to last test is not FitnessCriterion.MODEL_OVERALL. Tests: "
		    + Arrays.toString(testsInPriorityOrder);

	}

	boolean localDependentOnCVC = false;
	boolean localDependentOnCrossValidation = false;
	for (final FitnessCriterion fitnessCriterion : testsInPriorityOrder) {
	    if (fitnessCriterion.isDependentOnCrossValidation()) {
		localDependentOnCrossValidation |= true;
		if (fitnessCriterion.isDependentOnCVC()) {
		    localDependentOnCVC |= true;
		}
	    }
	} // end loop over all tests
	dependentOnCrossValidation = localDependentOnCrossValidation;
	dependentOnCVC = localDependentOnCVC;
    }

    public FitnessCriterion getPrimaryTest() {
	return testsInPriorityOrder[0];
    }

    public FitnessCriterion getSecondaryTest() {
	return testsInPriorityOrder[1];
    }

    public FitnessCriterion[] getTestsInOrder() {
	return testsInPriorityOrder;
    }

    public boolean isDependentOnCrossValidation() {
	return dependentOnCrossValidation;
    }

    public boolean isDependentOnCVC() {
	return dependentOnCVC;
    }

    public int size() {
	return testsInPriorityOrder.length;
    }

    @Override
    public String toString() {
	return Utility.join(testsInPriorityOrder,
		FitnessCriteriaOrder.delimiterChar);
    }

}