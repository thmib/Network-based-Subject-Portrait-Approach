package org.epistasis.mdr.filters;

import java.util.Collections;
import java.util.Map;
import java.util.TreeMap;

import org.epistasis.Utility;
import org.epistasis.mdr.enums.FilterMethod;
import org.epistasis.mdr.newengine.Dataset;

public class ChiSquaredScorer extends IsolatedAttributeScorer {
    private boolean pvalue;
    private Map<String, String> config = new TreeMap<String, String>();

    public ChiSquaredScorer(final Dataset data, final boolean pvalue,
	    final boolean parallel) {
	super(data, parallel);
	init(pvalue);
    }

    public ChiSquaredScorer(final Dataset data, final boolean pvalue,
	    final boolean parallel, final Runnable onIncrementProgress) {
	super(data, parallel, onIncrementProgress);
	init(pvalue);
    }

    @Override
    protected double computeScore(final int index) {
	final byte[] attribute = getData().getColumn(index);
	final int nLevels = getData().getLevels().get(index).size();
	final double[][] table = new double[classNLevels][nLevels];
	for (int i = 0; i < getData().getRows(); ++i) {
	    table[classes[i]][attribute[i]]++;
	}
	double chisq = Utility.computeChiSquared(table);
	chisq = pvalue ? (double) Utility.pchisq(chisq, (classNLevels - 1)
		* (nLevels - 1)) : chisq;
	return chisq;
    }

    @Override
    public Map<String, String> getConfig() {
	return config;
    }

    private void init(final boolean pPvalue) {
	pvalue = pPvalue;
	config.put("FILTER", FilterMethod.CHISQUARED.name());
	config.put("PVALUE", Boolean.toString(pvalue));
	config = Collections.unmodifiableMap(config);
    }
}
