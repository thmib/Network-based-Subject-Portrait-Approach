package org.epistasis.mdr.analysis;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Iterator;
import java.util.Random;

import org.epistasis.ProducerConsumerController;
import org.epistasis.exceptions.IncompleteBuildException;
import org.epistasis.mdr.AmbiguousCellStatus;
import org.epistasis.mdr.AnalysisFileManager;
import org.epistasis.mdr.AnalysisFileManager.EDAVariables;
import org.epistasis.mdr.ExpertKnowledge;
import org.epistasis.mdr.ExpertKnowledge.RWRuntime;
import org.epistasis.mdr.enums.FitnessCriteriaOrder;
import org.epistasis.mdr.newengine.AttributeCombination;
import org.epistasis.mdr.newengine.Collector;
import org.epistasis.mdr.newengine.Dataset;
import org.epistasis.mdr.newengine.Model;

public class EDAAnalysisThread extends AnalysisThread {
    private final int numEntities;
    private final int numUpdates;
    private final RWRuntime expertKnowledgeRWRuntime;
    private final Random rng;

    private EDAAnalysisThread(final Dataset data,
	    final FitnessCriteriaOrder topModelsFitnessCriteriaOrder,
	    final FitnessCriteriaOrder bestModelFitnessCriteriaOrder,
	    final int numCrossValidationIntervals, final int minAttr,
	    final int maxAttr, final AmbiguousCellStatus tiePriorityList,
	    final long seed, final Runnable onEndModel,
	    final Runnable onEndLevel, final Runnable onEndAnalysis,
	    final boolean parallel, final int topModelsLandscapeSize,
	    final boolean computeAllModelsLandscape, final int numEntities,
	    final int numUpdates, final RWRuntime expertKnowledgeRWRuntime) {
	super(data, topModelsFitnessCriteriaOrder,
		bestModelFitnessCriteriaOrder, numCrossValidationIntervals,
		minAttr, maxAttr, tiePriorityList, seed, onEndModel,
		onEndLevel, onEndAnalysis, parallel, topModelsLandscapeSize,
		computeAllModelsLandscape);
	this.numEntities = numEntities;
	this.numUpdates = numUpdates;
	this.expertKnowledgeRWRuntime = expertKnowledgeRWRuntime;
	// create a random number generator that will be used to generate a seed
	// for a random number generator specific to each thread/level.
	rng = new Random(seed);
    }

    @Override
    public void run() {
	FinishType finishType = FinishType.NOT_FINISHED;
	try {
	    for (int numAttr = minAttr; (numAttr <= maxAttr)
		    && !isInterrupted(); numAttr++) {
		expertKnowledgeRWRuntime.initializeWheel();
		final int processorsToUse = parallel ? Runtime.getRuntime()
			.availableProcessors() : 1;
		collectors.add(collector = new Collector(data, partitions,
			topModelsLandscapeSize, allModelsLandscape,
			topModelsFitnessCriteriaOrder,
			bestModelFitnessCriteriaOrder));
		if (processorsToUse > 1) {
		    // each level starts off with the same initial version of
		    // the
		    // wheel
		    // run for multiple generations
		    for (int updateCtr = 0; (updateCtr < numUpdates)
			    && !isInterrupted(); ++updateCtr) {
			final EDACombinationGenerator combinationGenerator = new EDACombinationGenerator(
				data.getLabels(), numAttr, new Random(
					rng.nextLong()), numEntities,
				expertKnowledgeRWRuntime);
			final ProducerConsumerController.Producer<QueueEntry> producer = new EDAProducer(
				combinationGenerator);
			final ProducerConsumerController<QueueEntry> pct = new ProducerConsumerController<QueueEntry>();
			pct.setProducer(producer);
			for (int j = 0; j < (processorsToUse); ++j) {
			    pct.addConsumer(new EDAModelAnalyzer());
			}
			pct.runProducerConsumerThreads();
			// update rouletteWheel after every generation
			if (updateCtr < (numUpdates - 1)) {
			    expertKnowledgeRWRuntime.adjustRouletteWheel();
			}
		    } // end updateCtr loop
		} else { // not parallel
			 // each level starts off with the same initial version
			 // of
			 // the wheel
			 // run for multiple generations
		    for (int updateCtr = 0; (updateCtr < numUpdates)
			    && !isInterrupted(); ++updateCtr) {
			final EDACombinationGenerator combinationGenerator = new EDACombinationGenerator(
				data.getLabels(), numAttr, new Random(
					rng.nextLong()), numEntities,
				expertKnowledgeRWRuntime);
			final ProducerConsumerController.Producer<QueueEntry> producer = new EDAProducer(
				combinationGenerator);
			QueueEntry queueEntry;
			final EDAModelAnalyzer modelAnalyzer = new EDAModelAnalyzer();
			while (((queueEntry = producer.produce()) != null)
				&& !isInterrupted()) {
			    modelAnalyzer.consume(queueEntry);
			}
			// update rouletteWheel after every generation
			if (updateCtr < (numUpdates - 1)) {
			    expertKnowledgeRWRuntime.adjustRouletteWheel();
			}
		    } // end updateCtr
		} // end if !parallel
		if (isInterrupted()) {
		    // remove current collector since it is likely to be
		    // incomplete
		    collectors.remove(collector);
		    break;
		}
		if (onEndLevel != null) {
		    onEndLevel.run();
		}
	    } // end numAttr loop
	    finishType = FinishType.NORMAL;
	} catch (final Throwable ex) {
	    finishType = FinishType.CAUGHT_EXCEPTION;
	    ex.printStackTrace();
	    // System.err.println("AnalysisThread caught an exception: " + ex
	    // + "\n" + MiscUtilities.);
	} finally {
	    assert finishType != FinishType.NOT_FINISHED : "finishType: "
		    + finishType + " but how is that possible?";
	    collector = null;
	    setComplete();
	    if (onEndAnalysis != null) {
		onEndAnalysis.run();
	    }
	}
    }

    @Override
    public void saveAnalysis(final AnalysisFileManager analysisFileManager) {
	analysisFileManager.putCfg(AnalysisFileManager.cfgWrapper,
		AnalysisFileManager.cfgValEDA);
	analysisFileManager.putCfg(EDAVariables.numAgents,
		String.valueOf(numEntities));
	analysisFileManager.putCfg(EDAVariables.numUpdates,
		String.valueOf(numUpdates));
	analysisFileManager.putCfg(EDAVariables.decay,
		String.valueOf(expertKnowledgeRWRuntime.getDecay()));
	analysisFileManager.putCfg(EDAVariables.alpha,
		String.valueOf(expertKnowledgeRWRuntime.getAlpha()));
	analysisFileManager.putCfg(EDAVariables.beta,
		String.valueOf(expertKnowledgeRWRuntime.getBeta()));
	analysisFileManager.putCfg(EDAVariables.weightScheme,
		String.valueOf(expertKnowledgeRWRuntime.getWeightScheme()));
	analysisFileManager.putCfg(EDAVariables.scalingMethod,
		String.valueOf(expertKnowledgeRWRuntime.getScalingMethod()));
	analysisFileManager.putCfg(EDAVariables.scalingpParameter,
		String.valueOf(expertKnowledgeRWRuntime.getScalingParameter()));
	final ExpertKnowledge ek = expertKnowledgeRWRuntime
		.getExpertKnowledge();
	final StringWriter s = new StringWriter();
	final PrintWriter w = new PrintWriter(s);
	ek.write(w, ExpertKnowledge.SAVED_ANALYSIS_LABEL_SCORE_SEPARATOR,
		ExpertKnowledge.SAVED_ANALYSIS_SCORES_DELIMITER);
	try {
	    s.close();
	} catch (final IOException e) {
	    e.printStackTrace();
	}
	analysisFileManager.putCfg(EDAVariables.scores, s.toString());
    }

    public static class EDAAnalysisThreadBuilder extends
	    AnalysisThreadBuilder<EDAAnalysisThread> {
	/* required */
	private int numEntities = -1;
	private int numUpdates = -1;
	RWRuntime expertKnowledgeRWRuntime = null;

	public EDAAnalysisThreadBuilder(final Dataset data,
		final int intervals, final long seed) {
	    super(data, intervals, seed);
	}

	@Override
	public EDAAnalysisThread build() {
	    if ((minAttr == -1) || (maxAttr == -1) || (numEntities == -1)
		    || (numUpdates == -1) || (expertKnowledgeRWRuntime == null)) {
		throw new IncompleteBuildException("EDA field not set");
	    }
	    return new EDAAnalysisThread(data, topModelsFitnessCriteriaOrder,
		    bestModelFitnessCriteriaOrder, numCrossValidationIntervals,
		    minAttr, maxAttr, tiePriorityList, seed, onEndModel,
		    onEndLevel, onEndAnalysis, parallel,
		    topModelsLandscapeSize, computeAllModelsLandscape,
		    numEntities, numUpdates, expertKnowledgeRWRuntime);
	}

	public EDAAnalysisThreadBuilder setExpertKnowledgeRWRuntime(
		final RWRuntime expertKnowledgeRWRuntime) {
	    this.expertKnowledgeRWRuntime = expertKnowledgeRWRuntime;
	    return this;
	}

	public EDAAnalysisThreadBuilder setNumEntities(final int numEntities) {
	    this.numEntities = numEntities;
	    return this;
	}

	public EDAAnalysisThreadBuilder setNumUpdates(final int numUpdates) {
	    this.numUpdates = numUpdates;
	    return this;
	}

    }

    protected class EDAModelAnalyzer extends ModelAnalyzer {
	@Override
	public void consume(final QueueEntry entry) {
	    if (collector != null) {
		final AttributeCombination combo = entry.getAttributes();
		final Model model = new Model(combo, tieStatus);
		expertKnowledgeRWRuntime.trackFitness(combo, collector
			.consider(model).getPrimaryFitnessCriterionValue());
		if (onEndModel != null) {
		    onEndModel.run();
		}
	    }
	}
    }

    protected static class EDAProducer extends Producer {
	private AttributeCombination attributes;
	private final Iterator<AttributeCombination> ecg;

	public EDAProducer(final EDACombinationGenerator ecg) {
	    this.ecg = ecg;
	}

	@Override
	public QueueEntry produce() {
	    if (!ecg.hasNext()) {
		return null;
	    }
	    attributes = ecg.next();
	    final QueueEntry entry = new QueueEntry(attributes);
	    return entry;
	}

	public void resetCombinationGenerator() {
	}
    }
}
