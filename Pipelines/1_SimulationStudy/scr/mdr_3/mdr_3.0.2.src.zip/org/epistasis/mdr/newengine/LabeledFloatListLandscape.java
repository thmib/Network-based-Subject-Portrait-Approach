package org.epistasis.mdr.newengine;

import java.util.Iterator;
import java.util.List;

import org.epistasis.LabeledFloatInterface;

public class LabeledFloatListLandscape extends Landscape {

    private final List<? super LabeledFloatInterface> labeledFloatList;

    public LabeledFloatListLandscape(
	    final List<? super LabeledFloatInterface> labeledFloatList) {
	this.labeledFloatList = labeledFloatList;
    }

    @Override
    public LabeledFloatInterface first() {
	return (LabeledFloatInterface) labeledFloatList.get(0);
    }

    @Override
    public LabeledFloatInterface get(final int index) {
	return (LabeledFloatInterface) labeledFloatList.get(index);
    }

    @SuppressWarnings("unchecked")
    @Override
    public Iterator<LabeledFloatInterface> iterator() {
	return (Iterator<LabeledFloatInterface>) labeledFloatList.iterator();
    }

    @Override
    public LabeledFloatInterface last() {
	return (LabeledFloatInterface) labeledFloatList.get(labeledFloatList
		.size() - 1);
    }

    @Override
    public LabeledFloatInterface set(final int index,
	    final LabeledFloatInterface element) {
	return (LabeledFloatInterface) labeledFloatList.set(index, element);
    }

    @Override
    public int size() {
	return labeledFloatList.size();
    }

}
