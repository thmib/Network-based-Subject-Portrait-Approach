package org.epistasis.mdr.networkEntropy;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Vector;

import org.apache.commons.math3.stat.descriptive.SummaryStatistics;
import org.epistasis.AbstractModelObject;
import org.epistasis.ColumnFormat;
import org.epistasis.Frequencies;
import org.epistasis.Pair;
import org.epistasis.Utility;
import org.epistasis.mdr.Main;
import org.epistasis.mdr.entropy.EntropyAnalysis;
import org.jgrapht.graph.DefaultEdge;
import org.jgrapht.graph.SimpleGraph;

import edu.uci.ics.jung.algorithms.shortestpath.DistanceStatistics;
import edu.uci.ics.jung.graph.UndirectedGraph;
import edu.uci.ics.jung.graph.UndirectedSparseMultigraph;
//import org.jgrapht.alg.BlockCutpointGraph;
//import org.jgrapht.alg.BronKerboschCliqueFinder;
//import org.jgrapht.alg.ChromaticNumber;
//import org.jgrapht.alg.EulerianCircuit;
//import org.jgrapht.alg.KruskalMinimumSpanningTree;
//import org.jgrapht.alg.VertexCovers;
//import org.jgrapht.graph.DefaultEdge;
//import org.jgrapht.graph.SimpleGraph;

public class NetworkGraph extends AbstractModelObject implements
	Comparable<NetworkGraph> {
    public static final String GRAPH_FILTERED_PROPERTY = "graphFiltered";
    private final BitSet[] adjMatrix;
    private final List<String> nodeNames;
    private final double[] nodeValues;
    private final double[][] edgeValues;
    private final BitSet ignoredNodes;
    private final BitSet connectedNodes;
    private UndirectedGraph<Integer, Integer> jungGraph;

    private final SimpleGraph<Integer, DefaultEdge> jGraphTGraph;
    private final double edgeFrequencyBinTolerance = 0.0005;
    private final double nodeFrequencyBinTolerance = 0.0005;
    private final Frequencies edgeValueFrequencies;
    private final Frequencies nodeValueFrequencies;
    private final int numNodes;
    private int numValidNodes;
    private int numConnectedNodes;
    private int numValidEdges;
    private int numConnectedEdges;
    private double nodeValidityThreshold = Double.NEGATIVE_INFINITY; // all
    // nodes
    // are
    // valid by
    // default
    private double edgeValidityThreshold = Double.NEGATIVE_INFINITY; // all
								     // edges
								     // are
								     // valid by
								     // default
    private final static Comparator<Pair<String, Float>> pairSecondComparator = new Pair.SecondComparator<String, Float>();
    private final boolean collectFrequencyData;
    private double edgeMin;
    private double edgeMax;

    public static Integer[] getSortedSizesOfSubGraphs(
	    final SortedSet<NetworkGraph> allSubGraphs) {
	final Integer[] sortedSizesOfSubGraphs = new Integer[allSubGraphs
		.size()];
	int subGraphIndex = 0;
	for (final NetworkGraph subGraph : allSubGraphs) {
	    sortedSizesOfSubGraphs[subGraphIndex++] = subGraph.numConnectedNodes;
	}
	return sortedSizesOfSubGraphs;
    }

    public static void main(final String[] args) {
	final String[] nodeNames = new String[] { "snp1", "snp2", "snp3",
		"snp4", "snp5", "snp6", "snp7", "snp8", "snp9", "snp10" };
	final double[] nodeValues = new double[] { 0.1, 0.2, 0.3, 0.4, 0.5,
		0.6, 0.7, 0.8, 0.9, 1.0 };
	final double[][] edgeValues = new double[][] { {}, { 0.3 },
		{ 0.4, 0.5 }, { 0.5, 0.6, 0.7 }, { 0.6, 0.7, 0.8, 0.9 },
		{ 0.7, 0.8, 0.9, 1.0, 1.1 }, { 0.8, 0.9, 1.0, 1.1, 1.2, 1.3 },
		{ 0.9, 1.0, 1.1, 1.2, 1.3, 1.4, 1.5 },
		{ 1.0, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7 },
		{ 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9 } };
	final NetworkGraph networkGraph = new NetworkGraph(
		Arrays.asList(nodeNames), nodeValues, edgeValues, true /* includeJGraphT */);
	System.out.println("First: fully connected");
	networkGraph.printEverything();
	System.out.println("\n\nSecond: partially connected");
	networkGraph.filterGraph(networkGraph.getNodeValidityThreshold(), 1.0);
	networkGraph.printEverything();
    } // end main()

    /**
     * @param nodeNames
     * @param nodeValues
     * @param edgeValues
     *            two dimensional array with length equal to the number of
     *            nodes. Use Double.NaN to signal no edge
     * @param includeJGraphT
     */
    public NetworkGraph(final List<String> nodeNames,
	    final double[] nodeValues, final double[][] edgeValues,
	    final BitSet ignoredNodes, final boolean includeJGraphT,
	    final boolean collectFrequencyData,
	    final UndirectedGraph<Integer, Integer> pJungGraph) {
	this.nodeNames = nodeNames;
	this.nodeValues = nodeValues;
	this.edgeValues = edgeValues;
	this.ignoredNodes = ignoredNodes;
	this.collectFrequencyData = collectFrequencyData;
	if (pJungGraph != null) {
	    jungGraph = pJungGraph;
	} else {
	    jungGraph = new UndirectedSparseMultigraph<Integer, Integer>();
	}
	if (collectFrequencyData) {
	    edgeValueFrequencies = new Frequencies(edgeFrequencyBinTolerance);
	    nodeValueFrequencies = new Frequencies(nodeFrequencyBinTolerance);
	} else {
	    edgeValueFrequencies = null;
	    nodeValueFrequencies = null;
	}
	numNodes = nodeValues.length; // do NOT use size of node names since in
				      // case of MDR may pass in labels list
				      // which includes class column
	// edge values is expected to be a two dimensional array with length
	// equal to the number of nodes.
	if (nodeValues.length != edgeValues.length) {
	    throw new RuntimeException(
		    "nodeValues.length != edgeValues.length "
			    + nodeValues.length + " != " + edgeValues.length);
	}
	connectedNodes = new BitSet(numNodes);
	adjMatrix = new BitSet[numNodes];
	jGraphTGraph = includeJGraphT ? new SimpleGraph<Integer, DefaultEdge>(
		DefaultEdge.class) : null;
	for (int nodeIndex = 0; nodeIndex < numNodes; ++nodeIndex) {
	    adjMatrix[nodeIndex] = new BitSet(nodeIndex);
	    // graph.addVertex(nodeIndex); in Jung2 vertices do not need to be
	    // explicitly created or added -- this happens implicitly if an edge
	    // referencing a vertex is added
	    if (jGraphTGraph != null) {
		jGraphTGraph.addVertex(nodeIndex);
	    }
	}
	filterGraph(nodeValidityThreshold, edgeValidityThreshold);
    } // end constructor

    public NetworkGraph(final List<String> nodeNames,
	    final double[] nodeValues, final double[][] edgeValues,
	    final boolean includeJGraphT) {
	this(nodeNames, nodeValues, edgeValues, null /* ignoredNodes */,
		includeJGraphT, false /* collectFrequencyData */, null /* pJungGraph */);
    }

    private NetworkGraph(final NetworkGraph parentGraph,
	    final BitSet newIgnoredNodes,
	    final double newNodeValidityThreshold,
	    final double newEdgeValidityThreshold) {
	this(parentGraph.nodeNames, parentGraph.nodeValues,
		parentGraph.edgeValues, newIgnoredNodes,
		parentGraph.jGraphTGraph != null,
		parentGraph.collectFrequencyData, null /* pJungGraph */);
	// this.activeNodes = activeNodes;
	filterGraph(newNodeValidityThreshold, newEdgeValidityThreshold);
    } // end NetworkGraph constructor

    public String adjacencyMatrixToString() {
	final StringBuilder sb = new StringBuilder();
	sb.append("Connected nodes #" + connectedNodes.cardinality() + ":"
		+ connectedNodes.toString() + "\n");
	for (int outerLoopNodeIndex = 1; outerLoopNodeIndex < numNodes; ++outerLoopNodeIndex) {
	    for (int innerLoopNodeIndex = 0; innerLoopNodeIndex < outerLoopNodeIndex; ++innerLoopNodeIndex) {
		final char cellChar = adjMatrix[outerLoopNodeIndex]
			.get(innerLoopNodeIndex) ? '*' : '-';
		sb.append(cellChar);
	    } // end inner loop
	    sb.append(new String(new char[numNodes - outerLoopNodeIndex])
		    .replace("\0", " "));
	    for (int innerLoopNodeIndex = 0; innerLoopNodeIndex < outerLoopNodeIndex; ++innerLoopNodeIndex) {
		if (adjMatrix[outerLoopNodeIndex].get(innerLoopNodeIndex)) {
		    sb.append("[" + outerLoopNodeIndex + ","
			    + innerLoopNodeIndex + "] ");
		}
	    } // end inner loop
	    sb.append('\n');
	} // end outer loop
	return sb.toString();
    }

    // public String clusteringCoeffientsToString(
    // final Map<Integer, Double> clusteringCoefficients) {
    // final StringBuilder sb = new StringBuilder();
    // final ColumnFormat fmt = new ColumnFormat(Arrays.asList(20, 20, 20));
    // sb.append(fmt.format(Arrays.asList("node #", "node name",
    // "clustering coefficient")));
    // sb.append('\n');
    // for (final Map.Entry<Integer, Double> entry : clusteringCoefficients
    // .entrySet()) {
    // final int nodeIndex = entry.getKey();
    // sb.append(fmt.format(Arrays.asList(String.valueOf(nodeIndex),
    // nodeNames.get(nodeIndex), String.valueOf(entry.getValue()))));
    // sb.append('\n');
    // }
    // return sb.toString();
    // }

    @Override
    public int compareTo(final NetworkGraph otherNetworkGraph) {
	final int otherConnectedNodes = otherNetworkGraph.numConnectedNodes;
	int comparisonResult = otherConnectedNodes - numConnectedNodes;
	if (comparisonResult == 0) {
	    // if same # of nodes then pick by # of edges
	    comparisonResult = otherNetworkGraph.numConnectedEdges
		    - numConnectedEdges;
	}
	if (comparisonResult == 0) {
	    // want comparison result to be repeatable and therefore must make
	    // sort deterministic by
	    // arbitrarily saying network with lowest indexed attribute is less
	    // than
	    comparisonResult = connectedNodes.nextSetBit(0)
		    - otherNetworkGraph.connectedNodes.nextSetBit(0);
	}
	return comparisonResult;
    }

    public void filterGraph(final double newNodeValidityThreshold,
	    final double newEdgeValidityThreshold) {
	nodeValidityThreshold = newNodeValidityThreshold;
	edgeValidityThreshold = newEdgeValidityThreshold;
	numConnectedEdges = 0;
	numValidNodes = 0;
	if (collectFrequencyData) {
	    edgeValueFrequencies.reset();
	}
	connectedNodes.clear();
	// removing vertices automatically removes all edges connected to it
	// needed to make a copy of collection returned by graph.getVertices()
	// to avoid concurrent modification exception
	for (final Integer vertex : new ArrayList<Integer>(
		jungGraph.getVertices())) {
	    jungGraph.removeVertex(vertex);
	}
	if (jGraphTGraph != null) {
	    // remove all vertices
	    // removing vertices automatically removes all edges connected to it
	    for (final Integer vertex : new ArrayList<Integer>(
		    jGraphTGraph.vertexSet())) {
		jGraphTGraph.removeVertex(vertex);
	    }
	}
	numValidEdges = 0;
	for (final double[] edges : edgeValues) {
	    for (final double edge : edges) {
		if (!Double.isNaN(edge)
			&& (Double.compare(edge, edgeValidityThreshold) >= 0)) {
		    ++numValidEdges;
		}
	    }
	}
	for (int outerLoopNodeIndex = 0; outerLoopNodeIndex < numNodes; ++outerLoopNodeIndex) {
	    final double[] internalEdgeArray = edgeValues[outerLoopNodeIndex];
	    final BitSet internalAdjMatrixArray = adjMatrix[outerLoopNodeIndex];
	    internalAdjMatrixArray.clear();
	    if (isNodeValid(outerLoopNodeIndex)) {
		// jungGraph.addVertex(outerLoopNodeIndex);
		if (jGraphTGraph != null) {
		    jGraphTGraph.addVertex(outerLoopNodeIndex);
		}
		++numValidNodes;
		for (int innerLoopNodeIndex = 0; innerLoopNodeIndex < outerLoopNodeIndex; ++innerLoopNodeIndex) {
		    if (isNodeValid(innerLoopNodeIndex)) {
			final double edgeValue = internalEdgeArray[innerLoopNodeIndex];
			if (!Double.isNaN(edgeValue)
				&& (edgeValue >= edgeValidityThreshold)) {
			    internalAdjMatrixArray.set(innerLoopNodeIndex);
			    connectedNodes.set(outerLoopNodeIndex);
			    connectedNodes.set(innerLoopNodeIndex);
			    edgeMin = Math.min(edgeMin, edgeValue);
			    edgeMax = Math.max(edgeMax, edgeValue);
			    if (collectFrequencyData) {
				edgeValueFrequencies.addValue(edgeValue);
			    }
			    jungGraph.addEdge(numConnectedEdges,
				    outerLoopNodeIndex, innerLoopNodeIndex);
			    if (jGraphTGraph != null) {
				jGraphTGraph.addEdge(outerLoopNodeIndex,
					innerLoopNodeIndex);
			    }
			    ++numConnectedEdges;
			} // end if edge value is above or equal to edge
			  // threshold
		    } // end if inner node value valid: i.e. is included and
		      // greater than or equal to node threshold
		} // end inner edge loop
	    } // end if outer node value valid: i.e. is included and greater
	      // than or equal to node threshold
	} // end outer edge loop
	numConnectedNodes = connectedNodes.cardinality();
	if (collectFrequencyData) {
	    nodeValueFrequencies.reset();
	    for (int nodeIndex = connectedNodes.nextSetBit(0); nodeIndex != -1; nodeIndex = connectedNodes
		    .nextSetBit(nodeIndex + 1)) {
		nodeValueFrequencies.addValue(nodeValues[nodeIndex]);
	    }
	}
	// System.err.println(adjacencyMatrixToString());
	firePropertyChange(NetworkGraph.GRAPH_FILTERED_PROPERTY, 0,
		System.currentTimeMillis());
    } // end filter

    /**
     * This returns the graph that can be connected starting with the passed in
     * root node and looking only at the other passed in nodes. This moves any
     * connected nodes from the passed in list into the returned list
     * 
     * @param potentiallyAccessibleNodes
     * @return
     */
    public NetworkGraph getAccessibleNodes(
	    final BitSet potentiallyAccessibleNodes) {
	final int originalCountOfPotentiallyAccessibleNodes = potentiallyAccessibleNodes
		.cardinality();
	final BitSet accessibleNodes = new BitSet(numNodes);
	final int root = potentiallyAccessibleNodes.nextSetBit(0);
	if (root != -1) {
	    potentiallyAccessibleNodes.set(root, false); // remove from list of
							 // available nodes
	    accessibleNodes.set(root); // the first node found is accessible by
				       // definition
	    final LinkedList<Integer> queue = new LinkedList<Integer>();
	    queue.addLast(root);
	    while (!queue.isEmpty()) {
		final Integer inspectionNode = queue.removeFirst();
		for (int potentiallyAccessibleNode = potentiallyAccessibleNodes
			.nextSetBit(0); potentiallyAccessibleNode != -1; potentiallyAccessibleNode = potentiallyAccessibleNodes
			.nextSetBit(potentiallyAccessibleNode + 1)) {
		    final boolean areNodesConnected = (inspectionNode > potentiallyAccessibleNode) ? adjMatrix[inspectionNode]
			    .get(potentiallyAccessibleNode)
			    : adjMatrix[potentiallyAccessibleNode]
				    .get(inspectionNode);
		    if (areNodesConnected) {
			potentiallyAccessibleNodes.set(
				potentiallyAccessibleNode, false); // remove
								   // from list
								   // of
								   // available
								   // nodes
			accessibleNodes.set(potentiallyAccessibleNode);
			queue.addLast(potentiallyAccessibleNode);
		    } // end if nodes are connected
		} // end unmarked nodes loop
	    } // end while queue is not empty
	} // end if availableNodes not empty
	NetworkGraph returnValue;
	final int numAccessibleNodes = accessibleNodes.cardinality();
	final int numRemainingPotentiallyAccessibleNodes = potentiallyAccessibleNodes
		.cardinality();
	if (originalCountOfPotentiallyAccessibleNodes != (numAccessibleNodes + numRemainingPotentiallyAccessibleNodes)) {
	    throw new RuntimeException(
		    "Something is wrong. originalCountOfPotentiallyAccessibleNodes != (numAccessibleNodes + potentiallyAccessibleNodes.cardinality())");
	}
	if (numAccessibleNodes == numConnectedNodes) {
	    returnValue = this;
	} else if (numAccessibleNodes > 0) {
	    final BitSet newIgnoredNodes = (BitSet) accessibleNodes.clone();
	    newIgnoredNodes.flip(0, newIgnoredNodes.size());
	    returnValue = new NetworkGraph(this, newIgnoredNodes,
		    getNodeValidityThreshold(), getEdgeValidityThreshold());
	} else {
	    returnValue = null;
	}
	return returnValue;
    }

    public SortedSet<NetworkGraph> getAllSubgraphs() {
	final SortedSet<NetworkGraph> allSubGraphs = new TreeSet<NetworkGraph>();
	final BitSet availableNodes = (BitSet) connectedNodes.clone();
	NetworkGraph connectedGraph;
	do {
	    connectedGraph = getAccessibleNodes(availableNodes);
	    if (connectedGraph != null) {
		if (connectedGraph == this) {
		    break; // EXIT FROM LOOP
		} else {
		    allSubGraphs.add(connectedGraph);
		}
	    } // end if connectedGraph != null
	} while (connectedGraph != null);
	if (allSubGraphs.size() == 1) {
	    throw new RuntimeException(
		    "Got 1 subgraph which should be impossible.");
	}
	return allSubGraphs;
    }

    public BitSet getConnectedNodes() {
	return connectedNodes;
    }

    public SortedMap<Integer, Integer> getCountDistribution(
	    final Collection<Integer> countsArray) {
	final SortedMap<Integer, Integer> integerCountMap = new TreeMap<Integer, Integer>(
		Collections.reverseOrder());
	for (final int count : countsArray) {
	    Integer currentCount = integerCountMap.get(count);
	    if (currentCount == null) {
		currentCount = 0;
	    }
	    ++currentCount;
	    integerCountMap.put(count, currentCount);
	}
	return integerCountMap;
    }

    /**
     * Pass in a list of integers. Return a list of counts for how many times
     * each integer was found
     * 
     * @param countsArray
     * @return
     */
    public SortedMap<Integer, Integer> getCountDistribution(
	    final Integer[] countsArray) {
	final SortedMap<Integer, Integer> integerCountMap = new TreeMap<Integer, Integer>(
		Collections.reverseOrder());
	for (final int count : countsArray) {
	    Integer currentCount = integerCountMap.get(count);
	    if (currentCount == null) {
		currentCount = 0;
	    }
	    ++currentCount;
	    integerCountMap.put(count, currentCount);
	}
	return integerCountMap;
    }

    public Double[] getEdgeThresholdList(final int digitsOfPrecision) {
	final SortedSet<Double> edgeThresholdList = new TreeSet<Double>();
	for (final double[] edgeArray : edgeValues) {
	    for (final double edgeValue : edgeArray) {
		edgeThresholdList.add(BigDecimal.valueOf(edgeValue)
			.setScale(digitsOfPrecision, BigDecimal.ROUND_FLOOR)
			.doubleValue());
	    }
	}
	final Double[] sortedArray = new Double[edgeThresholdList.size()];
	edgeThresholdList.toArray(sortedArray);
	return sortedArray;
    }

    public double getEdgeValidityThreshold() {
	return edgeValidityThreshold;
    }

    public double getEdgeValue(final int a, final int b) {

	return edgeValues[a][b];
    }

    public Frequencies getEdgeValueFrequencies() {
	return edgeValueFrequencies;
    }

    public double getEdgeValuePercentage(final int a, final int b) {

	final double edgeValue = getEdgeValue(a, b);

	final double percentage = (edgeValue - edgeMin) / (edgeMax - edgeMin);
	return percentage;
    }

    /**
     * http://en.wikipedia.org/wiki/Centrality#Degree_centrality
     * 
     * Wikipedia article says the denominator H is the node degree centrality of
     * a hypothetical graph with the same number of nodes that has the maximum
     * centrality A star graph is always the answer so the denominator H works
     * out to be H = (n-1)(n-2)
     */
    public double getGraphDegreeCentrality() {
	final SortedMap<Integer, Integer> nodeNumEdgesCounter = getVertexDegreeDistribution();
	// nodeNumEdgesCounter.firstKey() is the largest degree largest because
	// SortedMap and NetworkGraph compare function
	final int maxDegreeCentrality = nodeNumEdgesCounter.firstKey();
	long sumOfVertexDegreeDifferences = 0;
	int numNodesBeingExamined = 0;
	for (final Map.Entry<Integer, Integer> entry : nodeNumEdgesCounter
		.entrySet()) {
	    final int vertexDegree = entry.getKey();
	    final int numOccurrences = entry.getValue();
	    numNodesBeingExamined += numOccurrences;
	    final long deltaFromMaxDegreeCentrality = maxDegreeCentrality
		    - vertexDegree;
	    sumOfVertexDegreeDifferences += numOccurrences
		    * deltaFromMaxDegreeCentrality;

	} // end loop over all edge counts
	double graphDegreeCentrality;
	if (numNodesBeingExamined <= 2) {
	    // if only two nodes then code below would get NaN due to divide by
	    // zero. Two nodes have no central node and therefore have a
	    // centrality of zero
	    graphDegreeCentrality = 0.0;
	} else {
	    // H is the denominator and is the sum sumOfVertexDegreeDifferences
	    // for a star graph
	    // (http://en.wikipedia.org/wiki/Centrality#Degree_centrality)
	    final int H_sumOfVertexDegreeDifferences = (numNodesBeingExamined - 1)
		    * (numNodesBeingExamined - 2);
	    graphDegreeCentrality = sumOfVertexDegreeDifferences
		    / (double) H_sumOfVertexDegreeDifferences;
	}
	return graphDegreeCentrality;
    }

    private int getGraphDiameter() {
	return (int) DistanceStatistics.diameter(jungGraph);
    }

    public GraphLevelMetrics<Integer, Integer> getGraphLevelMetricsEdge() {
	final long startTime = System.currentTimeMillis();
	Exception exception = null;
	final int numCurrentEdges = jungGraph.getEdgeCount();
	final Vector<Double> scores = new Vector<Double>(numCurrentEdges);
	try {
	    for (final int edgeIndex : jungGraph.getEdges()) {
		final edu.uci.ics.jung.graph.util.Pair<Integer> endPoints = jungGraph
			.getEndpoints(edgeIndex);
		final int a = endPoints.getFirst(); // outer loop index (smaller
						    // value)
		final int b = endPoints.getSecond(); // inner loop index (bigger
						     // value)
		scores.add(edgeValues[a][b]);
	    }

	} catch (final Exception ex) {
	    exception = ex;
	}
	final GraphLevelMetrics<Integer, Integer> graphLevelMetrics = new GraphLevelMetrics<Integer, Integer>(
		jungGraph,
		"Edge Effect " + EntropyAnalysis.IG_AB_C /* metricName */,
		scores, System.currentTimeMillis() - startTime, exception);
	return graphLevelMetrics;
    }

    public GraphLevelMetrics<Integer, Integer> getGraphLevelMetricsNode() {
	final long startTime = System.currentTimeMillis();
	Exception exception = null;
	final Vector<Double> scores = new Vector<Double>(
		jungGraph.getVertexCount());
	try {
	    for (int nodeIndex = 0; nodeIndex < numNodes; ++nodeIndex) {
		if (connectedNodes.get(nodeIndex)) {
		    scores.add(nodeValues[nodeIndex]);
		}
	    }
	} catch (final Exception ex) {
	    exception = ex;
	}
	final GraphLevelMetrics<Integer, Integer> graphLevelMetrics = new GraphLevelMetrics<Integer, Integer>(
		jungGraph,
		"Vertex Effect " + EntropyAnalysis.I_A_C /* metricName */,
		scores, System.currentTimeMillis() - startTime, exception);
	return graphLevelMetrics;
    }

    public Vector<String> getGraphSummaryColumnNames() {
	final Vector<String> columnNames = new Vector<String>(Arrays.asList(
		"Vertices",
		// "# of connected vertices", "% connected vertices",
		"Edges",
		// "# of connected edges", "% connected edges",
		"Diameter", "Avg. # of neighbors", "Density", "Centralization",
		"Heterogeneity"));
	return columnNames;
    }

    // public String getJGraphTMetrics() {
    // final StringBuilder sb = new StringBuilder();
    // try {
    // if (jGraphTGraph != null) {
    // Set<Integer> cutPoints = new BlockCutpointGraph<Integer, DefaultEdge>(
    // jGraphTGraph).getCutpoints();
    // sb.append("BlockCutpointGraph: "
    // + ((cutPoints.size() == 0) ?
    // "The graph has no cutpoints and therefore is not biconnected."
    // : "The graph is biconnected with "
    // + cutPoints.size()
    // + " cutpoints. The cutpoints: "
    // + cutPoints));
    // sb.append('\n');
    // cutPoints = null; // allow memory reclamation
    // Collection<java.util.Set<Integer>> allMaximalCliques = new
    // BronKerboschCliqueFinder<Integer, DefaultEdge>(
    // jGraphTGraph).getAllMaximalCliques();
    // sb.append("BronKerboschCliqueFinder: The graph has "
    // + allMaximalCliques.size() + " maximal cliques.");
    // sb.append('\n');
    // sb.append("    The clique sizes are: ");
    // for (final Set<Integer> clique : allMaximalCliques) {
    // sb.append(clique.size());
    // sb.append(" ");
    // }
    // sb.append('\n');
    // allMaximalCliques = null; // allow memory reclamation
    // java.util.Set<Integer> vertexCovers = VertexCovers
    // .findGreedyCover(jGraphTGraph);
    // sb.append("VertexCovers: The greedy approximation of minimal vertex covers is "
    // + vertexCovers.size()
    // + " nodes. This is "
    // + Main.decimalUpToFourPrecision.format((vertexCovers
    // .size() * 100.0) / numValidNodes)
    // + "% of all valid nodes");
    // sb.append(" ");
    // sb.append('\n');
    // vertexCovers = null; // allow memory reclamation
    // sb.append("Chromatic number: "
    // + ChromaticNumber
    // .findGreedyChromaticNumber(jGraphTGraph) + '\n');
    // List<Integer> eulerianCircuitVertices = EulerianCircuit
    // .getEulerianCircuitVertices(jGraphTGraph);
    // sb.append("Eulerian circuit: "
    // + ((eulerianCircuitVertices == null) ? "The graph is not Eulerian."
    // : "The graph is Eulerian. The Eulerian circuit is "
    // + eulerianCircuitVertices.size()
    // + " vertices long."));
    // // + eulerianCircuitVertices);
    // sb.append('\n');
    // eulerianCircuitVertices = null; // allow memory reclamation
    // KruskalMinimumSpanningTree<Integer, DefaultEdge>
    // kruskalMinimumSpanningTree = new KruskalMinimumSpanningTree<Integer,
    // DefaultEdge>(
    // jGraphTGraph);
    // Set<DefaultEdge> spanningTreeEdgeSet = kruskalMinimumSpanningTree
    // .getEdgeSet();
    // sb.append("KruskalMinimumSpanningTree: The spanning tree cost (# of edges) is "
    // + spanningTreeEdgeSet.size() + ".");
    // // sb.append(" The spanning tree edges: "
    // // + spanningTreeEdgeSet);
    // sb.append('\n');
    // spanningTreeEdgeSet = null; // allow memory reclamation
    // kruskalMinimumSpanningTree = null; // allow memory reclamation
    // }
    // } catch (final Exception ex) {
    // sb.append("Caught exception: " + ex.getMessage());
    // }
    // return sb.toString();
    // }

    public Vector<Number> getGraphSummaryRow() {
	final Vector<Number> rowData = new Vector<Number>();
	// rowData.add(Integer.valueOf(numValidNodes));
	rowData.add(Integer.valueOf(numConnectedNodes));
	// rowData.add(Float.valueOf((numConnectedNodes * 100.0f) /
	// numValidNodes));
	// rowData.add(Integer.valueOf(numValidEdges));
	rowData.add(Integer.valueOf(numConnectedEdges));
	// rowData.add(Float.valueOf((numConnectedEdges * 100.0f) /
	// numValidEdges));
	rowData.add(getGraphDiameter());
	final NetworkDegreeStatistics networkDegreeStatistics = getNetworkDegreeStatistics();
	rowData.add(networkDegreeStatistics.getAverageNumberOfNeighbors());
	rowData.add(networkDegreeStatistics.getDensity());
	rowData.add(networkDegreeStatistics.getCentralization());
	rowData.add(networkDegreeStatistics.getHeterogeneity());
	return rowData;
    }

    // public String getJungGraphMetrics() {
    // final StringBuilder sb = new StringBuilder();
    // try {
    // if (jungGraph != null) {
    // final double diameter = DistanceStatistics.diameter(jungGraph);
    // sb.append("Distance (maximum shortest path): " + diameter + ".");
    // }
    // } catch (final Exception ex) {
    // sb.append("getJungGraphMetrics() caught exception: "
    // + ex.toString());
    // }
    // return sb.toString();
    // }

    public UndirectedGraph<Integer, Integer> getJungGraph() {
	return jungGraph;
    }

    public List<Pair<String, Float>> getLandscapeForEdges() {
	final List<Pair<String, Float>> landscape = new ArrayList<Pair<String, Float>>();
	for (int outerLoopNodeIndex = 0; outerLoopNodeIndex < numNodes; ++outerLoopNodeIndex) {
	    final double[] internalEdgeArray = edgeValues[outerLoopNodeIndex];
	    if ((ignoredNodes == null) || !ignoredNodes.get(outerLoopNodeIndex)) {
		for (int innerLoopNodeIndex = 0; innerLoopNodeIndex < internalEdgeArray.length; ++innerLoopNodeIndex) {
		    if (outerLoopNodeIndex != innerLoopNodeIndex) {
			final double edgeValue = internalEdgeArray[innerLoopNodeIndex];
			landscape.add(new Pair<String, Float>(nodeNames
				.get(outerLoopNodeIndex)
				+ '+'
				+ nodeNames.get(innerLoopNodeIndex),
				(float) edgeValue));
			if (!Double.isNaN(edgeValue)) {
			} // end if edge exists
		    } // end if not looking at node connecting to itself
		} // end inner edge loop
	    } // end if outer node is valid
	} // end outer edge loop
	Collections.sort(landscape, NetworkGraph.pairSecondComparator);
	return landscape;
    }

    public List<Pair<String, Float>> getLandscapeForNodes() {
	final List<Pair<String, Float>> landscape = new ArrayList<Pair<String, Float>>(
		numNodes);
	for (int nodeIndex = 0; nodeIndex < numNodes; ++nodeIndex) {
	    landscape.add(new Pair<String, Float>(nodeNames.get(nodeIndex),
		    (float) nodeValues[nodeIndex]));
	} // end for nodes
	Collections.sort(landscape, NetworkGraph.pairSecondComparator);
	return landscape;
    }

    public NetworkDegreeStatistics getNetworkDegreeStatistics() {
	return new NetworkDegreeStatistics();
    }

    public Double[] getNodeThresholdList(final int digitsOfPrecision) {
	final SortedSet<Double> nodeThresholdList = new TreeSet<Double>();
	for (final double doubleValue : nodeValues) {
	    nodeThresholdList.add(BigDecimal.valueOf(doubleValue)
		    .setScale(digitsOfPrecision, BigDecimal.ROUND_FLOOR)
		    .doubleValue());
	}
	final Double[] sortedArray = new Double[nodeThresholdList.size()];
	nodeThresholdList.toArray(sortedArray);
	return sortedArray;
    }

    public double getNodeValidityThreshold() {
	return nodeValidityThreshold;
    }

    public Frequencies getNodeValueFrequencies() {
	return nodeValueFrequencies;
    }

    public double[] getNodeValues() {
	return nodeValues;
    }

    public int getNumConnectedNodes() {
	return numConnectedNodes;
    }

    // public double[] getSortedEdgeValues() {
    // final double[] sortedEdgeValues = new double[numEdges];
    // int numEdgesSoFar = 0;
    // for (int outerLoopNodeIndex = 0; outerLoopNodeIndex < numNodes;
    // ++outerLoopNodeIndex) {
    // final double[] internalEdgeArray = edgeValues[outerLoopNodeIndex];
    // System.arraycopy(internalEdgeArray, 0, sortedEdgeValues, numEdgesSoFar,
    // internalEdgeArray.length);
    // numEdgesSoFar += internalEdgeArray.length;
    // }
    // Arrays.sort(sortedEdgeValues);
    // return sortedEdgeValues;
    // }
    // public double[] getSortedNodeValues() {
    // final double[] sortedNodeValues = new double[nodeValues.length];
    // System.arraycopy(nodeValues, 0, sortedNodeValues, 0,
    // sortedNodeValues.length);
    // Arrays.sort(sortedNodeValues);
    // return sortedNodeValues;
    // }
    public SortedMap<Integer, Integer> getSubGraphSizeDistribution(
	    final SortedSet<NetworkGraph> allSubGraphs) {
	final Integer[] subGraphsSizes = NetworkGraph
		.getSortedSizesOfSubGraphs(allSubGraphs);
	final SortedMap<Integer, Integer> subGraphsSizeDistribution = getCountDistribution(subGraphsSizes);
	return subGraphsSizeDistribution;
    }

    public String getSummaryDescription(
	    final SortedSet<NetworkGraph> allSubGraphs) {
	final StringBuilder sb = new StringBuilder();
	sb.append("Filtered by ");
	sb.append(getEdgeValidityThreshold());
	sb.append(" edge validity threshold. This has ");
	sb.append(numValidNodes);
	sb.append(" nodes of which ");
	sb.append(numConnectedNodes);
	sb.append(" are connected by ");
	sb.append(numConnectedEdges);
	sb.append(" out of " + numConnectedEdges + " possible edges.");
	if (!allSubGraphs.isEmpty()) {
	    sb.append("There are " + allSubGraphs.size()
		    + " disjoint sets of nodes.");
	} else {
	    sb.append("The graph is made up of only a single set of connected nodes.");
	}
	return sb.toString();
    }

    public String getSummaryDescriptionMultiline() {
	final StringBuilder sb = new StringBuilder();
	sb.append("Network Summary");
	sb.append('\n');
	sb.append("# of nodes: " + numValidNodes);
	sb.append('\n');
	final double connectedPercentage = (numConnectedNodes * 100.0)
		/ numValidNodes;
	sb.append("# of connected nodes: " + numConnectedNodes + " ("
		+ Main.decimalUpToFourPrecision.format(connectedPercentage)
		+ "%)");
	sb.append('\n');
	final int unconnectedNodes = numValidNodes - numConnectedNodes;
	final double unconnectedPercentage = (unconnectedNodes * 100.0)
		/ numValidNodes;
	sb.append("# of non-connected nodes: " + unconnectedNodes + " ("
		+ Main.decimalUpToFourPrecision.format(unconnectedPercentage)
		+ "%)");
	sb.append('\n');
	sb.append("# of edges: " + numConnectedEdges);
	sb.append('\n');
	sb.append("# of edges if fully connected: " + numValidEdges);
	sb.append('\n');
	sb.append("node threshold: " + nodeValidityThreshold);
	sb.append('\n');
	sb.append("edge threshold: " + edgeValidityThreshold);
	sb.append('\n');
	return sb.toString();
    }

    public String getSummaryDescriptionWithSubGraphs() {
	final SortedSet<NetworkGraph> allSubGraphs = getAllSubgraphs();
	return graphInformationTableToString(allSubGraphs);
    }

    /*
     * http://en.wikipedia.org/wiki/Centrality
     */
    public SortedMap<Integer, Integer> getVertexDegreeDistribution() {
	final SortedMap<Integer, Integer> nodeNumEdgesCounter = getCountDistribution(getVertexDegreesMap()
		.values());
	return nodeNumEdgesCounter;
    }

    private SortedMap<Integer, Integer> getVertexDegreesMap() {
	final SortedMap<Integer, Integer> edgeCountMap = new TreeMap<Integer, Integer>();
	for (int outerLoopNodeIndex = connectedNodes.nextSetBit(1); outerLoopNodeIndex != -1; outerLoopNodeIndex = connectedNodes
		.nextSetBit(outerLoopNodeIndex + 1)) {
	    for (int innerLoopNodeIndex = connectedNodes.nextSetBit(0); innerLoopNodeIndex < outerLoopNodeIndex; innerLoopNodeIndex = connectedNodes
		    .nextSetBit(innerLoopNodeIndex + 1)) {
		if (adjMatrix[outerLoopNodeIndex].get(innerLoopNodeIndex)) {
		    incrementMapCounter(edgeCountMap, outerLoopNodeIndex);
		    incrementMapCounter(edgeCountMap, innerLoopNodeIndex);
		}
	    }
	}
	if (edgeCountMap.size() == 0) {
	    System.err.println("What the hey! adjMatrix:\n"
		    + adjacencyMatrixToString());
	}
	return edgeCountMap;
    }

    public int getVertexNumber(final int[] vertexDegrees) {
	int count = 0;
	for (final int degree : vertexDegrees) {
	    if (degree > 0) {
		++count;
	    }
	}
	return count;
    } // end getVertexNumber
      // public VisualizationViewer getVisualizationViewer() {
      // final VisualizationViewer visualizationViewer = new
      // VisualizationViewer(
      // new KKLayout(jungGraph));
      // visualizationViewer
      // .setVertexToolTipTransformer(new Transformer<Integer, String>() {
      // @Override
      // public String transform(final Integer arg0) {
      // return nodeNames.get(arg0);
      // }
      // });
      // visualizationViewer
      // .setEdgeToolTipTransformer(new Transformer<Integer, String>() {
      // @Override
      // public String transform(final Integer edge) {
      // final edu.uci.ics.jung.graph.util.Pair<Integer> endPoints = jungGraph
      // .getEndpoints(edge);
      // return nodeNames.get(endPoints.getFirst()) + ' '
      // + nodeNames.get(endPoints.getSecond());
      // }
      // });
      // return visualizationViewer;
      // }

    private String graphInformationRowToString(final ColumnFormat fmt,
	    final String graphType, final int numTotalNodes,
	    final int numTotalEdges) {
	return fmt
		.format(Arrays.asList(
			graphType,
			String.valueOf(numConnectedNodes),
			Main.decimalUpToFourPrecision
				.format((numConnectedNodes / (double) numTotalNodes) * 100.0) + '%',
			String.valueOf(numConnectedEdges),
			Main.decimalUpToFourPrecision
				.format((numConnectedEdges / (double) numTotalEdges) * 100.0) + '%')) + '\n';
    }

    private String graphInformationTableToString(
	    final SortedSet<NetworkGraph> allSubGraphs) {
	final StringBuilder sb = new StringBuilder();
	final ColumnFormat fmt = new ColumnFormat(Arrays.asList(25, 20, 20, 20,
		20, 20, 20, 20));
	sb.append("# of nodes: " + numValidNodes + "\n");
	sb.append("# nodes >= node threshold " + nodeValidityThreshold + ": "
		+ numValidNodes + "\n");
	double connectedPercentage = (numConnectedNodes * 100.0)
		/ numValidNodes;
	sb.append("# of connected nodes: " + numConnectedNodes + " ("
		+ Main.decimalUpToFourPrecision.format(connectedPercentage)
		+ "%)\n");
	// final int unconnectedNodes = numValidNodes - numConnectedNodes;
	// final double unconnectedPercentage = (unconnectedNodes * 100.0)
	// / numValidNodes;
	// sb.append("# of non-connected nodes: " + unconnectedNodes + " ("
	// + Main.modelTextNumberFormat.format(unconnectedPercentage) + "%)\n");
	sb.append("# of edges if fully connected: " + numValidEdges + "\n");
	connectedPercentage = (numConnectedEdges * 100.0) / numValidEdges;
	sb.append("# of connected edges >= edge threshold "
		+ edgeValidityThreshold + ": " + numConnectedEdges + " ("
		+ Main.decimalUpToFourPrecision.format(connectedPercentage)
		+ "%)\n\n");
	sb.append(fmt.format(Arrays.asList("Graph Id", "# connected nodes",
		"% connected nodes", "#  edges", "% connected edges")));
	sb.append('\n');
	// show information about all connected components
	if (!allSubGraphs.isEmpty()) {
	    // sb.append(subGraphsDistributionToString(allSubGraphs));
	    int decentSubGraphCtr = 0;
	    for (final NetworkGraph subGraph : allSubGraphs) {
		sb.append(subGraph.graphInformationRowToString(fmt,
			"Connected component " + ++decentSubGraphCtr,
			numValidNodes, numConnectedEdges));
	    } // end for all subgraphs
	} // end if more than one connectedComponent
	  // sb.append(jungGraph.toString());
	sb.append(graphInformationRowToString(fmt, "Entire graph",
		numValidNodes, numConnectedEdges));
	return sb.toString();
    }

    private void incrementMapCounter(
	    final SortedMap<Integer, Integer> countMap, final int mapKey) {
	Integer currentCount = countMap.get(mapKey);
	if (currentCount == null) {
	    currentCount = 0;
	}
	countMap.put(mapKey, ++currentCount);
    }

    protected boolean isNodeValid(final int nodeIndex) {
	boolean isOuterNodeValid = (ignoredNodes == null)
		|| !ignoredNodes.get(nodeIndex);
	isOuterNodeValid &= nodeValues[nodeIndex] >= nodeValidityThreshold;
	return isOuterNodeValid;
    }

    public boolean nodeIsConnected(final Integer vertex) {
	return connectedNodes.get(vertex);
    }

    private void printEverything() {
	System.out.println(getSummaryDescriptionWithSubGraphs());
	System.out.println(adjacencyMatrixToString());
	final List<GraphLevelMetrics<Integer, Integer>> graphLevelMetrics = new ArrayList<GraphLevelMetrics<Integer, Integer>>();
	graphLevelMetrics.add(getGraphLevelMetricsNode());
	graphLevelMetrics
		.add(GraphLevelMetrics
			.getGraphLevelMetricsFromJungScorer(
				jungGraph,
				new edu.uci.ics.jung.algorithms.scoring.DegreeScorer<Integer>(
					jungGraph)));
	graphLevelMetrics.add(GraphLevelMetrics
		.getGraphLevelMetricsFromJungClusteringCoefficients(jungGraph));
	graphLevelMetrics
		.add(GraphLevelMetrics
			.getGraphLevelMetricsFromJungScorer(
				jungGraph,
				new edu.uci.ics.jung.algorithms.scoring.EigenvectorCentrality<Integer, Integer>(
					jungGraph)));
	graphLevelMetrics
		.add(GraphLevelMetrics
			.getGraphLevelMetricsFromJungScorer(
				jungGraph,
				new edu.uci.ics.jung.algorithms.scoring.KStepMarkov<Integer, Integer>(
					jungGraph, Math.max(500,
						jungGraph.getVertexCount()))));
	graphLevelMetrics
		.add(GraphLevelMetrics
			.getGraphLevelMetricsFromJungScorer(
				jungGraph,
				new edu.uci.ics.jung.algorithms.scoring.PageRank<Integer, Integer>(
					jungGraph, 0.85 /*
							 * alpha which Google
							 * uses
							 */)));
	graphLevelMetrics
		.add(GraphLevelMetrics
			.getGraphLevelMetricsFromJungScorer(
				jungGraph,
				new edu.uci.ics.jung.algorithms.scoring.BetweennessCentrality<Integer, Integer>(
					jungGraph)));
	graphLevelMetrics
		.add(GraphLevelMetrics
			.getGraphLevelMetricsFromJungScorer(
				jungGraph,
				new edu.uci.ics.jung.algorithms.scoring.ClosenessCentrality<Integer, Integer>(
					jungGraph)));
	graphLevelMetrics
		.add(GraphLevelMetrics
			.getGraphLevelMetricsFromJungScorer(
				jungGraph,
				new edu.uci.ics.jung.algorithms.scoring.BarycenterScorer<Integer, Integer>(
					jungGraph)));
	graphLevelMetrics
		.add(GraphLevelMetrics
			.getGraphLevelMetricsFromJungScorer(
				jungGraph,
				new edu.uci.ics.jung.algorithms.scoring.DistanceCentralityScorer<Integer, Integer>(
					jungGraph, true /* averaging */)));
	System.out.println();
	for (final GraphLevelMetrics<Integer, Integer> graphLevelMetric : graphLevelMetrics) {
	    System.out.println(graphLevelMetric);
	}
	// System.out.println(getJGraphTMetrics());
    }

    public String subGraphsDistributionToString(
	    final SortedSet<NetworkGraph> allSubGraphs) {
	final StringBuilder sb = new StringBuilder();
	final ColumnFormat fmt = new ColumnFormat(Arrays.asList(20, 20, 40));
	sb.append(fmt.format(Arrays.asList("# of nodes", "# of subGraphs",
		"% of parent graph size")));
	sb.append('\n');
	final SortedMap<Integer, Integer> subGraphSizesCounter = getSubGraphSizeDistribution(allSubGraphs);
	for (final Map.Entry<Integer, Integer> entry : subGraphSizesCounter
		.entrySet()) {
	    sb.append(fmt.format(Arrays.asList(String.valueOf(entry.getKey()),
		    String.valueOf(entry.getValue()), String.valueOf((entry
			    .getValue() / (double) numNodes) * 100.0) + '%')));
	    sb.append('\n');
	}
	return sb.toString();
    }

    public String vertexDegreeDistributionToString() {
	final StringBuilder sb = new StringBuilder();
	final ColumnFormat fmt = new ColumnFormat(Arrays.asList(20, 20, 20));
	sb.append(fmt.format(Arrays.asList("edge_count", "# of nodes", "%")));
	sb.append('\n');
	final SortedMap<Integer, Integer> nodeNumEdgesCounter = getVertexDegreeDistribution();
	for (final Map.Entry<Integer, Integer> entry : nodeNumEdgesCounter
		.entrySet()) {
	    sb.append(fmt.format(Arrays.asList(String.valueOf(entry.getKey()),
		    String.valueOf(entry.getValue()), String.valueOf((entry
			    .getValue() / (double) numNodes) * 100.0) + '%')));
	    sb.append('\n');
	}
	return sb.toString();
    }

    /**
     * This calculates some of the overall network statistics used in the
     * Cytoscape plugin NetworkAnalyzer see
     * http://med.bioinf.mpi-inf.mpg.de/netanalyzer/ It references this paper
     * for its statistics: Dong, Jun, and Steve Horvath. "Understanding Network
     * Concepts in Modules." BMC Systems Biology 1, no. 1 (2007): 24.
     * 
     * 
     */
    private class NetworkDegreeStatistics {
	private double density = Double.NaN;
	private double centralization = Double.NaN;
	private double heterogeneity = Double.NaN;
	SummaryStatistics vertexDistributionStatistics = new SummaryStatistics();

	public NetworkDegreeStatistics() {
	    final SortedMap<Integer, Integer> nodeNumEdgesCounter = getVertexDegreeDistribution();
	    for (final Map.Entry<Integer, Integer> entry : nodeNumEdgesCounter
		    .entrySet()) {
		final int vertexDegree = entry.getKey();
		final int numOccurrences = entry.getValue();
		for (@SuppressWarnings("unused")
		final int occurenceCtr : Utility.range(numOccurrences)) {
		    vertexDistributionStatistics.addValue(vertexDegree);
		}
	    } // end loop over all edge counts
	    final long n = vertexDistributionStatistics.getN();
	    if (n > 2) {
		// the following measures are from the Dong et al paper
		// referenced in class comment
		final double max = vertexDistributionStatistics.getMax();
		final double mean = vertexDistributionStatistics.getMean();
		final double variance = vertexDistributionStatistics
			.getVariance();
		density = mean / (n - 1);
		centralization = (n / (n - 2)) * ((max / (n - 1)) - density);
		heterogeneity = Math.sqrt(variance) / mean;
	    }

	} // end constructor

	public double getAverageNumberOfNeighbors() {
	    return vertexDistributionStatistics.getMean();
	}

	public double getCentralization() {
	    return centralization;
	}

	public double getDensity() {
	    return density;
	}

	public double getHeterogeneity() {
	    return heterogeneity;
	}
    } // class NetworkDegreeStatistics
} // end class NetworkGraph
