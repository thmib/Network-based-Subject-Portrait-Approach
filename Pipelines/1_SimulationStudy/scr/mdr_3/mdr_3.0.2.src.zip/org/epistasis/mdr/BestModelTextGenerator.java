package org.epistasis.mdr;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;

import org.epistasis.ColumnFormat;
import org.epistasis.Utility;
import org.epistasis.mdr.newengine.Dataset;
import org.epistasis.mdr.newengine.Model;
import org.epistasis.mdr.newengine.Model.Cell;
import org.epistasis.mdr.newengine.Model.ContinuousEndpointCell;
import org.epistasis.mdr.newengine.ModelInfoInterface;

public class BestModelTextGenerator extends ModelTextGenerator {
    private final ModelInfoInterface summary;
    private final int intervals;

    public BestModelTextGenerator(final Dataset data,
	    final AmbiguousCellStatus tieStatus,
	    final ModelInfoInterface summary, final int intervals,
	    final NumberFormat nf, final double pValueTol,
	    final boolean isVerbose) {
	super(data, tieStatus, nf, pValueTol, isVerbose);
	this.summary = summary;
	this.intervals = intervals;
    }

    @Override
    public String toString() {
	final Model model = summary.getModel();
	final StringBuffer b = new StringBuffer();
	b.append(model.getCombo());
	b.append("\n");
	if (intervals > 1) {
	    b.append("\nCross-validation Statistics:\n\n");
	    b.append(getResultText(data, model,
		    summary.getCVAverageTrainingConfusionMatrix(), " Training",
		    30));
	    b.append('\n');
	    b.append(getResultText(data, model,
		    summary.getCVAggregateTestingConfusionMatrix(), " Testing",
		    30));
	    b.append(ColumnFormat.fitStringWidth(
		    "Cross-validation Consistency:", 30, true /* useTabs */));
	    b.append(summary.getCVC());
	    b.append('/');
	    b.append(intervals);
	    b.append('\n');
	}
	b.append("\nWhole Dataset Statistics:\n\n");
	b.append(getResultText(data, model,
		summary.getOverallConfusionMatrix(), "", 30));
	final SortedMap<byte[], Cell> cells = model.buildCounts(data);

	model.buildStatuses(data, data.getStatusCounts(), cells);
	model.test(data, cells);
	if (data.hasContinuousEndpoints()) {
	    b.append("\nModel Detail:\n\n");
	    final List<Integer> widths = new ArrayList<Integer>();
	    final List<String> list = new ArrayList<String>();
	    list.add("Combination");
	    widths.add(25);
	    final String statusColumnName = data.getStatusColumnName();
	    list.add("Count");
	    widths.add(list.get(list.size() - 1).length() + 8);
	    list.add(statusColumnName + " Average");
	    widths.add(list.get(list.size() - 1).length() + 8);
	    final double globalAverage = data.getAverageEndpoint();
	    list.add("difference from global average "
		    + Main.decimalUpToFourPrecision.format(globalAverage));
	    widths.add(list.get(list.size() - 1).length() + 8);
	    list.add("Predicted '" + statusColumnName + "'");
	    widths.add(list.get(list.size() - 1).length() + 8);
	    final ColumnFormat cf = new ColumnFormat(widths, true /* useTabs */);
	    b.append(cf.format(list));
	    b.append('\n');
	    final List<String> underScoreList = new ArrayList<String>(
		    widths.size());
	    for (int columnIndex = 0; columnIndex < widths.size(); ++columnIndex) {
		underScoreList.add(Utility.chrdup('-', list.get(columnIndex)
			.length()));
	    }
	    // list.add(Utility.chrdup('-', 11));
	    // for (final String name : data.getLevels().get(data.getCols() -
	    // 1)) {
	    // list.add(Utility.chrdup('-', name.length() + 8));
	    // }
	    // list.add(Utility.chrdup('-', 15));
	    b.append(cf.format(underScoreList));
	    b.append('\n');
	    final int[] attr = summary.getModel().getCombo()
		    .getAttributeIndices();
	    for (final Map.Entry<byte[], Model.Cell> cellPair : cells
		    .entrySet()) {
		list.clear();
		final byte[] bytes = cellPair.getKey();
		final String[] attributes = data
			.getAttributeValues(attr, bytes);
		list.add(Utility.join(attributes, ','));
		final ContinuousEndpointCell continuousEndpointCell = (ContinuousEndpointCell) cellPair
			.getValue();
		list.add(Main.decimalUpToFourPrecision
			.format(continuousEndpointCell.getTotalCount()));
		final double genotypeAverage = continuousEndpointCell.getMean();
		list.add(Main.decimalUpToFourPrecision.format(genotypeAverage));
		list.add(Main.decimalUpToFourPrecision.format(genotypeAverage
			- globalAverage));
		final int predictedStatus = continuousEndpointCell.getStatus();
		if (predictedStatus == Model.UNKNOWN_STATUS) {
		    list.add(Main.unknownRepresentation);
		} else {
		    list.add(data.getLevels().get(data.getCols() - 1)
			    .get(predictedStatus));
		}
		b.append(cf.format(list));
		b.append('\n');
	    }
	} else {
	    b.append("\nModel Detail:\n\n");
	    final List<Integer> widths = new ArrayList<Integer>();
	    final List<String> list = new ArrayList<String>();
	    list.add("Combination");
	    widths.add(25);
	    final String statusColumnName = data.getStatusColumnName();
	    final String affectedValueString = data.getAffectedValuesString();
	    final String unaffectedValueString = data
		    .getUnaffectedValuesString();
	    list.add(statusColumnName + " '" + affectedValueString + "'");
	    widths.add(list.get(list.size() - 1).length() + 8);
	    list.add(statusColumnName + " '" + unaffectedValueString + "'");
	    widths.add(list.get(list.size() - 1).length() + 8);
	    list.add(affectedValueString + "/" + unaffectedValueString
		    + " Ratio");
	    widths.add(list.get(list.size() - 1).length() + 8);
	    list.add("Predicted '" + statusColumnName + "'");
	    widths.add(list.get(list.size() - 1).length() + 8);
	    final ColumnFormat cf = new ColumnFormat(widths, true /* useTabs */);
	    b.append(cf.format(list));
	    b.append('\n');
	    final List<String> underScoreList = new ArrayList<String>(
		    widths.size());
	    for (int columnIndex = 0; columnIndex < widths.size(); ++columnIndex) {
		underScoreList.add(Utility.chrdup('-', list.get(columnIndex)
			.length()));
	    }
	    // list.add(Utility.chrdup('-', 11));
	    // for (final String name : data.getLevels().get(data.getCols() -
	    // 1)) {
	    // list.add(Utility.chrdup('-', name.length() + 8));
	    // }
	    // list.add(Utility.chrdup('-', 15));
	    b.append(cf.format(underScoreList));
	    b.append('\n');
	    final int[] attr = summary.getModel().getCombo()
		    .getAttributeIndices();
	    for (final Map.Entry<byte[], Model.Cell> cellPair : cells
		    .entrySet()) {
		final StringBuffer b2 = new StringBuffer();
		list.clear();
		final byte[] bytes = cellPair.getKey();
		for (int i = 0; i < bytes.length; ++i) {
		    if (i != 0) {
			b2.append(',');
		    }
		    final byte attributeLevelIndex = bytes[i];
		    String attributeValue = data.getLevels().get(attr[i])
			    .get(attributeLevelIndex);
		    if (attributeValue == data.getMissing()) {
			attributeValue = Main.missingRepresentation;
		    }
		    b2.append(attributeValue);
		}
		list.add(b2.toString());
		final float[] counts = cellPair.getValue().getCounts();
		final float affectedCount = counts[data.getAffectedStatus()];
		list.add(Main.decimalUpToFourPrecision.format(affectedCount));
		final float unaffectedCount = counts[data.getUnaffectedStatus()];
		list.add(Main.decimalUpToFourPrecision.format(unaffectedCount));
		list.add(Main.decimalUpToFourPrecision.format(affectedCount
			/ unaffectedCount));
		final int predictedStatus = cellPair.getValue().getStatus();
		if (predictedStatus == Model.UNKNOWN_STATUS) {
		    list.add(Main.unknownRepresentation);
		} else {
		    list.add(data.getLevels().get(data.getCols() - 1)
			    .get(predictedStatus));
		}
		b.append(cf.format(list));
		b.append('\n');
	    }
	} // end if discrete endpoints
	return b.toString();
    }
}
