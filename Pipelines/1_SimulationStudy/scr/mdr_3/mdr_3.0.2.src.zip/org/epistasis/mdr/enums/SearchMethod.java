package org.epistasis.mdr.enums;

public enum SearchMethod {
    EXHAUSTIVE("Exhaustive"), FORCED("Forced"), RANDOM("Random"), EDA("EDA");

    private final String displayName;

    private SearchMethod(final String displayName) {
	this.displayName = displayName;
    }

    @Override
    public String toString() {
	return displayName;
    }
}