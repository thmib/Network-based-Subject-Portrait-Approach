package org.epistasis.mdr.filters;

import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.epistasis.mdr.enums.FilterMethod;
import org.epistasis.mdr.newengine.AttributeCombination;
import org.epistasis.mdr.newengine.Dataset;

public class AttributeNameFileScorer extends AbstractAttributeScorer {
    private Map<String, String> config = new TreeMap<String, String>();
    private File attributeNameFilterFile;
    public final static double KEEP_ATTRIBUTE_SCORE = 1.0;

    public AttributeNameFileScorer(final File attributeNameFilterFile,
	    final Dataset data) {
	super(data);
	init(attributeNameFilterFile);
    }

    @Override
    protected double[] computeScores() {
	Set<String> attributeNamesToKeep;
	try {
	    attributeNamesToKeep = AttributeCombination
		    .readAttributeNamesFile(attributeNameFilterFile);
	} catch (final Exception e) {
	    // this should never happen because file existence checked in UI
	    String message = "Caught exception '"
		    + e
		    + "' calling AttributeCombination.readAttributeNamesFile on file '";
	    try {
		message += attributeNameFilterFile.getCanonicalPath() + "'";
	    } catch (final Exception e1) {
		e1.printStackTrace();
	    }
	    System.err.println(message);
	    throw new RuntimeException(message, e);
	}

	final int[] filterAttributesToKeep = data
		.attributeNameListToAscendingIndicesArray(
			false /* throwExceptionOnUnknownAttributes */,
			attributeNamesToKeep
				.toArray(new String[attributeNamesToKeep.size()]));
	final double[] scores = new double[data.getNumAttributes()];
	for (final int attributeToKeepIndex : filterAttributesToKeep) {
	    scores[attributeToKeepIndex] = AttributeNameFileScorer.KEEP_ATTRIBUTE_SCORE;
	}
	return scores;
    }

    @Override
    public Map<String, String> getConfig() {
	return config;
    }

    @Override
    public int getTotalProgress() {
	return 0;
    }

    private void init(final File attributeNameFilterFile) {
	this.attributeNameFilterFile = attributeNameFilterFile;
	config.put("FILTER", FilterMethod.ATTRIBUTE_FILE.name());
	try {
	    config.put("FILENAME", attributeNameFilterFile.getCanonicalPath());
	} catch (final IOException e) {
	    e.printStackTrace();
	}
	config = Collections.unmodifiableMap(config);
    }

}
