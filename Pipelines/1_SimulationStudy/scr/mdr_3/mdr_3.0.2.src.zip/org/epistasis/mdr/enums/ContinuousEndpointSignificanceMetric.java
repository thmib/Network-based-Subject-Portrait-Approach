package org.epistasis.mdr.enums;

public enum ContinuousEndpointSignificanceMetric {
    TTEST("T-statistic", "T-statistic"), ANOVA("ANalysis Of VAriance", "ANOVA");
    // BALANCED_ACCURACY("balanced accuracy", "bal. acc."),
    // ANOVA_GENOTYPE_STATUSES("F-statistic", "F-statistic");
    private String shortText = null;
    private String longText = null;

    public static ContinuousEndpointSignificanceMetric[] getMenuItems() {
	return new ContinuousEndpointSignificanceMetric[] { TTEST, ANOVA };
    }

    private ContinuousEndpointSignificanceMetric() {
    }

    private ContinuousEndpointSignificanceMetric(final String longText,
	    final String shortText) {
	this.longText = longText;
	this.shortText = shortText;
    }

    public String getLongText() {
	if (longText != null) {
	    return longText;
	} else {
	    return name();
	}
    }

    public String getShortText() {
	if (shortText != null) {
	    return shortText;
	} else {
	    return getLongText();
	}
    }
} // end enum ContinuousEndpointSignificanceMetric