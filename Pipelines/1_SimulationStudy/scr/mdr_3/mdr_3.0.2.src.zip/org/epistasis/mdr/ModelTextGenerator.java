package org.epistasis.mdr;

import java.text.NumberFormat;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map.Entry;

import org.epistasis.ColumnFormat;
import org.epistasis.Pair;
import org.epistasis.Utility;
import org.epistasis.customApacheCommonsMath.StatisticalSummaryValuesWithSumSq;
import org.epistasis.mdr.enums.DiscreteEndpointSignificanceMetric;
import org.epistasis.mdr.newengine.ConfusionMatrix;
import org.epistasis.mdr.newengine.Dataset;
import org.epistasis.mdr.newengine.Model;

public abstract class ModelTextGenerator {
    protected final NumberFormat nf;
    protected final double pValueTol;
    protected final boolean isVerbose;
    protected final AmbiguousCellStatus tieStatus;
    protected final Dataset data;

    public ModelTextGenerator(final Dataset data,
	    final AmbiguousCellStatus tieStatus, final NumberFormat nf,
	    final double pValueTol, final boolean isVerbose) {
	this.data = data;
	this.tieStatus = tieStatus;
	this.nf = nf;
	this.pValueTol = pValueTol;
	this.isVerbose = isVerbose;
    }

    protected String getResultText(final Dataset data, final Model model,
	    final ConfusionMatrix result, final String name,
	    final int labelWidth) {
	final StringBuffer b = new StringBuffer();
	final float total = result.getTotalCount();
	final float unknown = result.getUnknownCount();
	if (data.hasContinuousEndpoints()) {
	    b.append(ColumnFormat
		    .fitStringWidth(name + " " + Console.console.metricLongText
			    + ":", labelWidth, true /* useTabs */));
	    b.append(nf.format(result.getFitness()));
	    b.append('\n');
	    if (!result.hasAggregateData()) {
		b.append(ColumnFormat
			.fitStringWidth(
				"Details not available after reading in saved analysis.",
				labelWidth, true /* useTabs */));
		b.append('\n');
	    } else {
		for (final Entry<String, StatisticalSummaryValuesWithSumSq> entry : result
			.getAggregateData().getMapOfAggregates().entrySet()) {
		    final String key = entry.getKey();
		    b.append(ColumnFormat.fitStringWidth(key + ":", labelWidth,
			    true /* useTabs */));
		    final String columnPadding = ColumnFormat.fitStringWidth(
			    "", labelWidth, true /* useTabs */);
		    final String[] summaryStats = entry.getValue().toString()
			    .split("\n");
		    final Iterator<String> iterator = Arrays.asList(
			    summaryStats).iterator();
		    iterator.next(); // skip "StatisticalSummaryValues"
		    b.append(iterator.next());
		    b.append('\n');
		    while (iterator.hasNext()) {
			b.append(columnPadding);
			b.append(iterator.next());
			b.append('\n');
		    }
		}
	    }
	} else {
	    b.append(ColumnFormat
		    .fitStringWidth(name + " " + Console.console.metricLongText
			    + ":", labelWidth, true /* useTabs */));
	    b.append(nf.format(result.getFitness()));
	    b.append('\n');

	    final boolean wasAdjustedForCoverage = ((Console.console
		    .getDiscreteEndpointSignificanceMetric() == DiscreteEndpointSignificanceMetric.BALANCED_ACCURACY) || (Console.console
		    .getDiscreteEndpointSignificanceMetric() == DiscreteEndpointSignificanceMetric.LEAVE_ONE_OUT_CROSS_VALIDATION_TESTING))
		    && (tieStatus == AmbiguousCellStatus.UNCLASSIFIED);
	    final boolean mustShowUnadjustedBalancedAccuracy = (Console.console
		    .getDiscreteEndpointSignificanceMetric() != DiscreteEndpointSignificanceMetric.BALANCED_ACCURACY)
		    || wasAdjustedForCoverage;
	    if (mustShowUnadjustedBalancedAccuracy) {
		b.append(ColumnFormat.fitStringWidth(
			name
				+ " "
				+ DiscreteEndpointSignificanceMetric.BALANCED_ACCURACY
					.getLongText() + ":", labelWidth, true /* useTabs */));
		b.append(nf.format(result.getBalancedAccuracy()));
		b.append('\n');
		if (wasAdjustedForCoverage) {
		    b.append(ColumnFormat.fitStringWidth(name + " Coverage:",
			    labelWidth, true /* useTabs */));
		    final float coverageRatio = (total - unknown) / total;
		    b.append(nf.format(coverageRatio));
		    b.append(" (");
		    b.append(nf.format(total - unknown));
		    b.append(',');
		    b.append(nf.format(total));
		    b.append(')');
		    b.append('\n');
		}
	    }
	    b.append(ColumnFormat.fitStringWidth(name + " Accuracy:",
		    labelWidth, true /* useTabs */));
	    b.append(nf.format(result.getAccuracy()));
	    b.append('\n');
	    b.append(ColumnFormat.fitStringWidth(name + " Sensitivity:",
		    labelWidth, true /* useTabs */));
	    b.append(nf.format(result.getSensitivity()));
	    b.append('\n');
	    b.append(ColumnFormat.fitStringWidth(name + " Specificity:",
		    labelWidth, true /* useTabs */));
	    b.append(nf.format(result.getSpecificity()));
	    b.append('\n');
	    if (isVerbose) {
		b.append(ColumnFormat.fitStringWidth(name + " Precision:",
			labelWidth, true /* useTabs */));
		b.append(nf.format(result.getPrecision()));
		b.append('\n');
		b.append(ColumnFormat.fitStringWidth(name + " Rows examined:",
			labelWidth, true /* useTabs */));
		b.append(nf.format(total));
		b.append('\n');
		b.append(ColumnFormat
			.fitStringWidth(name + " True Positive(TP):",
				labelWidth, true /* useTabs */));
		b.append(nf.format(result.numTruePositives()));
		b.append('\n');
		b.append(ColumnFormat
			.fitStringWidth(name + " False Positive(FP):",
				labelWidth, true /* useTabs */));
		b.append(nf.format(result.numFalsePositives()));
		b.append('\n');
		b.append(ColumnFormat
			.fitStringWidth(name + " True Negative(TN):",
				labelWidth, true /* useTabs */));
		b.append(nf.format(result.numTrueNegatives()));
		b.append('\n');
		b.append(ColumnFormat
			.fitStringWidth(name + " False Negative(FN):",
				labelWidth, true /* useTabs */));
		b.append(nf.format(result.numFalseNegatives()));
		b.append('\n');
		b.append(ColumnFormat.fitStringWidth(name + " Unknown:",
			labelWidth, true /* useTabs */));
		b.append(nf.format(unknown));
		b.append('\n');
	    }
	    b.append(ColumnFormat.fitStringWidth(name + " Odds Ratio:",
		    labelWidth, true /* useTabs */));
	    final double oddsRatio = result.getOddsRatio();
	    b.append(nf.format(oddsRatio));
	    if (!Double.isNaN(oddsRatio) && !Double.isInfinite(oddsRatio)) {
		final Pair<Float, Float> confInt = result.getORConfInt();
		b.append(" (");
		b.append(nf.format(confInt.getFirst()));
		b.append(',');
		b.append(nf.format(confInt.getSecond()));
		b.append(')');
	    }
	    b.append('\n');
	    final double chisq = result.getChiSquared();
	    b.append(ColumnFormat.fitStringWidth(name + " \u03A7\u00B2:",
		    labelWidth, true /* useTabs */));
	    b.append(nf.format(chisq));
	    if (!Double.isNaN(chisq)) {
		final double p = Utility
			.pchisq(chisq, result.getChiSquaredDF());
		b.append(" (p ");
		if (p < pValueTol) {
		    b.append("< ");
		    b.append(nf.format(pValueTol));
		} else {
		    b.append("= ");
		    b.append(nf.format(p));
		}
		b.append(')');
	    }
	    b.append('\n');
	    b.append(ColumnFormat.fitStringWidth(name + " Precision:",
		    labelWidth, true /* useTabs */));
	    b.append(nf.format(result.getPrecision()));
	    b.append('\n');
	    b.append(ColumnFormat.fitStringWidth(name + " Kappa:", labelWidth,
		    true /* useTabs */));
	    b.append(nf.format(result.getKappa()));
	    b.append('\n');
	    b.append(ColumnFormat.fitStringWidth(name + " F-Measure:",
		    labelWidth, true /* useTabs */));
	    b.append(nf.format(result.getFMeasure()));
	    b.append('\n');
	}
	return b.toString();
    }

    @Override
    public abstract String toString();
}
