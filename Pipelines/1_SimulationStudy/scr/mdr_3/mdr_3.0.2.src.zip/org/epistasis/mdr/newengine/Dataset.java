package org.epistasis.mdr.newengine;

import java.io.IOException;
import java.io.LineNumberReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.regex.Pattern;

import javax.swing.table.AbstractTableModel;

import org.apache.commons.math3.stat.descriptive.SummaryStatistics;
import org.epistasis.ColumnFormat;
import org.epistasis.Pair;
import org.epistasis.Utility;
import org.epistasis.gui.SwingInvoker;
import org.epistasis.mdr.AmbiguousCellStatus;
import org.epistasis.mdr.Main;
import org.epistasis.mdr.newengine.Dataset.Genotype.GenotypeQualityMetric;
import org.epistasis.mdr.newengine.Model.Cell;

import edu.northwestern.at.utils.math.matrix.MatrixFactory;
import edu.northwestern.at.utils.math.statistics.ContingencyTable;

public class Dataset {
    private static final Byte CONTINUOUS_ENDPOINT_AFFECTED_STATUS = 1;
    private static final Byte CONTINUOUS_ENDPOINT_UNAFFECTED_STATUS = 0;
    public static final String ABOVE_AVERAGE_OR_EQUAL_CLASS = "1";
    public static final String BELOW_AVERAGE_CLASS = "0";
    private static final String sDelim = "\t";
    private static final Pattern patDelim = Pattern.compile("[\\s,]+");
    private List<String> labels = Collections.emptyList();
    private List<List<String>> levels;
    private int[] statusCounts;
    private final static ColumnFormat covariateAdjustmentReportTable = new ColumnFormat(
	    Arrays.asList(new Integer[] { 15, 20, 20 }));
    /*
     * weighted status counts takes the weights into account. At first I thought
     * that this should be used when using weights but it seemed strange to
     * Jason and me that the ratios changed due to weighting. For now, the
     * weights alter the contingency table and balanced accuracy but not the
     * ratio
     */
    private final String missing;
    private RowData[] rowData;
    // private byte[][] data;
    // private float[] weights;
    // private double[] continuousEndpoints;
    private boolean matchedPairsOrTriplets = false;
    protected ROW_REPEAT_PATTERN rowRepeatPattern = ROW_REPEAT_PATTERN.NONE;
    private int rows = 0;
    private int cols = 0;
    private byte affectedStatus = Model.UNKNOWN_STATUS;
    private byte unaffectedStatus = Model.UNKNOWN_STATUS;
    private ArrayList<Double> sortedStatusSet = null;
    private static final List<String> datasetLoadingWarningMessages = new ArrayList<String>(
	    1);
    private Double continuousEndpointMedian = null;
    private SummaryStatistics continuousEndpointSummaryStatistics = null;
    private Double averageNormalizedEndpoint;
    private final String dataFileName;
    private boolean datasetHasBeenPermuted = false;

    /**
     * Can be passed either an array of strings or an array of indexes
     * 
     * @param throwExceptionOnUnknownAttributes
     *            (always throws if an out of bound index passed)
     * @param attributeNamesToKeep
     * @param labels
     * @return int array of attribute indices, guaranteed to be sorted ascending
     */
    public static int[] attributeNameListToAscendingIndicesArray(
	    final boolean throwExceptionOnUnknownAttributes,
	    final String[] attributeNamesToKeep, final int numAttributes,
	    final List<String> labels) {
	int[] attributes = Utility
		.stringArrayToIntegerArray(attributeNamesToKeep);
	if (attributes != null) {
	    for (final int arrayIndex : attributes) {
		if (arrayIndex >= numAttributes) {
		    throw new IllegalArgumentException("Passed in index "
			    + arrayIndex
			    + " is too large for the number of attributes: "
			    + numAttributes);
		}
	    }
	    Arrays.sort(attributes);
	} else {
	    final Set<String> attributesToRetainSet = new TreeSet<String>(
		    String.CASE_INSENSITIVE_ORDER);
	    attributesToRetainSet.addAll(Arrays.asList(attributeNamesToKeep));
	    if (attributeNamesToKeep.length != attributesToRetainSet.size()) {
		throw new IllegalArgumentException(
			"attribute list contains duplicate names (comparisons are case insensitive). Passed in list: "
				+ Utility.join(attributeNamesToKeep, ','));
	    }
	    attributes = new int[attributesToRetainSet.size()];
	    int insertionOffset = 0;
	    for (int attributeColumnIndex = 0; attributeColumnIndex < numAttributes; ++attributeColumnIndex) {
		final String label = labels.get(attributeColumnIndex);
		if (attributesToRetainSet.contains(label)) {
		    attributes[insertionOffset++] = attributeColumnIndex;
		    attributesToRetainSet.remove(label);
		    if (attributesToRetainSet.size() == 0) {
			break; // ALL DONE!
		    }
		}
	    } // end loop over all existing columns
	    if (throwExceptionOnUnknownAttributes) {
		if (attributesToRetainSet.size() > 0) {
		    throw new IllegalArgumentException(
			    "attribute list contains some names which were not recognized. # of passed in attributes: "
				    + attributes.length
				    + " number not found: "
				    + attributesToRetainSet.size()
				    + " not found attributes: "
				    + attributesToRetainSet);
		}
	    }
	    if (attributes.length != insertionOffset) {
		final int[] temp = new int[insertionOffset];
		System.arraycopy(attributes, 0, temp, 0, insertionOffset);
		attributes = temp;
	    }
	}
	return attributes;
    }

    public static Dataset createPlaceholderDataset() {

	return new Dataset("BLANK_PLACEHOLDER_DATASET", Main.defaultMissing,
		Main.defaultPairedAnalysis);
    }

    public static Pair<Double, Double> getAffectedAndUnaffectedCounts(
	    final Dataset data, final List<RowData> rowDataList) {
	double affectedRowsTotal = 0;
	double unaffectedRowsTotal = 0;
	if (!data.hasContinuousEndpoints()) {
	    affectedRowsTotal = data.getAffectedStatusCount();
	    unaffectedRowsTotal = data.getUnaffectedStatusCount();
	} else {
	    final double datasetStatusThreshold = data.getAverageEndpoint();
	    for (final RowData rowDatum : rowDataList) {
		if (Double.compare(rowDatum.continuousEndpoint,
			datasetStatusThreshold) <= 0) {
		    ++unaffectedRowsTotal;
		} else {
		    ++affectedRowsTotal;
		}
	    } // end for loop
	} // end if has continuous endpoints
	return new Pair<Double, Double>(affectedRowsTotal, unaffectedRowsTotal);
    } // end getAffectedAndUnaffectedTotalCounts;

    public static Pair<Double, Double> getAffectedAndUnaffectedTotals(
	    final Dataset data, final List<RowData> rowDataList) {
	double affectedRowsTotal = 0;
	double unaffectedRowsTotal = 0;
	if (!data.hasContinuousEndpoints()) {
	    affectedRowsTotal = data.getAffectedStatusCount();
	    unaffectedRowsTotal = data.getUnaffectedStatusCount();
	} else {
	    final double datasetStatusThreshold = data.getAverageEndpoint();
	    for (final RowData rowDatum : rowDataList) {
		if (Double.compare(rowDatum.continuousEndpoint,
			datasetStatusThreshold) <= 0) {
		    unaffectedRowsTotal += rowDatum.continuousEndpoint;
		} else {
		    affectedRowsTotal += rowDatum.continuousEndpoint;
		}
	    } // end for loop
	} // end if has continuous endpoints
	return new Pair<Double, Double>(affectedRowsTotal, unaffectedRowsTotal);
    } // end getAffectedAndUnaffectedRowLists;

    public static List<String> getDatasetLoadingWarningMessages() {
	return Dataset.datasetLoadingWarningMessages;
    }

    /**
     * @param dichotomotousEndpoints
     * @return a map with key = index into status and value = list of rows with
     *         that endpoint
     */
    public static TreeMap<Byte, List<Integer>> mapRowIndicesByClass(
	    final byte[] dichotomotousEndpoints) {
	final TreeMap<Byte, List<Integer>> rowIndicesByClassMap = new TreeMap<Byte, List<Integer>>();
	for (int i = 0; i < dichotomotousEndpoints.length; ++i) {
	    final byte status = dichotomotousEndpoints[i];
	    List<Integer> list = rowIndicesByClassMap.get(status);
	    if (list == null) {
		list = new ArrayList<Integer>();
		rowIndicesByClassMap.put(status, list);
	    }
	    list.add(i);
	}
	return rowIndicesByClassMap;
    }

    public Dataset(final String pDataFileName,
	    final LineNumberReader lineNumberReader) throws IOException {
	this(pDataFileName, Main.defaultMissing, false /* isPaired */,
		lineNumberReader, (Set<? extends Object>) null /* allowedAttributes */);
    }

    /**
     * 
     * @param lineNumberReader
     * @param allowedAttributes
     *            can be set attribute names or zero based indices. Should be
     *            all of one or the other =- not mixed.
     * @throws IOException
     */
    public Dataset(final String pDataFileName,
	    final LineNumberReader lineNumberReader,
	    final Set<? extends Object> allowedAttributes) throws IOException {
	this(pDataFileName, Main.defaultMissing, false /* isPaired */);
	read(lineNumberReader, allowedAttributes);
    }

    public Dataset(final String pDataFileName, final String pMissing,
	    final boolean pPaired) {
	dataFileName = pDataFileName;
	levels = Collections.emptyList();
	labels = new ArrayList<String>();
	labels.add("Class");
	rows = 0;
	cols = labels.size();
	missing = pMissing;
	matchedPairsOrTriplets = pPaired;
    }

    /**
     * 
     * @param pMissing
     * @param pPaired
     * @param lineNumberReader
     * @param allowedAttributes
     *            can be set attribute names or zero based indices. Should be
     *            all of one or the other =- not mixed.
     * @throws IOException
     */
    public Dataset(final String pDataFileName, final String pMissing,
	    final boolean pPaired, final LineNumberReader lineNumberReader,
	    final Set<? extends Object> allowedAttributes) throws IOException {
	this(pDataFileName, pMissing, pPaired);
	read(lineNumberReader, allowedAttributes);
    }

    // public Dataset(final String pMissing, final boolean pPaired,
    // final List<String> labels, final List<List<String>> levels,
    // final byte[][] data, final int rows, final byte affectedStatus,
    // final byte unaffectedStatus) {
    // this(pMissing, pPaired);
    // this.labels = labels;
    // this.levels = levels;
    // this.data = data;
    // this.rows = rows; // rows is passed in when partitioning
    // cols = labels.size();
    // this.affectedStatus = affectedStatus;
    // this.unaffectedStatus = unaffectedStatus;
    // calculateStatusCounts();
    // }
    public Dataset(final String pDataFileName, final String pMissing,
	    final boolean pPaired, final List<String> labels,
	    final List<List<String>> levels,
	    final List<RowData> passedInRowData, final int rows,
	    final byte affectedStatus, final byte unaffectedStatus) {
	this(pDataFileName, pMissing, pPaired);
	this.labels = labels;
	this.levels = levels;
	this.rows = rows; // rows is passed in when partitioning
	cols = labels.size();
	this.affectedStatus = affectedStatus;
	this.unaffectedStatus = unaffectedStatus;
	rowData = new RowData[rows];
	for (int rowIndex = 0; rowIndex < rowData.length; ++rowIndex) {
	    rowData[rowIndex] = passedInRowData.get(rowIndex);
	}
	calculateStatusCounts();
    }

    /**
     * Adjust for a single attribute. Method: For each allele of an attribute,
     * use oversampling to force the ratio of case/control to match the global
     * ratio of case/control
     * 
     * @param covariateAttributeName
     * @return
     * @throws Exception
     */
    public Dataset adjustForCovariate(final long randomSeed,
	    final String covariateAttributeName) throws Exception {
	return adjustForCovariate(randomSeed, covariateAttributeName, false /* createChangeReport */)
		.getFirst();
    }

    public Pair<Dataset, String> adjustForCovariate(final long randomSeed,
	    final String covariateAttributeName,
	    final boolean createChangeReport) throws Exception {
	assert !datasetHasBeenPermuted;
	final StringBuilder sb = new StringBuilder();
	if (createChangeReport) {
	    sb.append(Dataset.covariateAdjustmentReportTable.format(Arrays
		    .asList(new String[] { covariateAttributeName,
			    "initial counts", "adjusted counts" })));
	    sb.append("\n");
	}
	final Random rnd = new Random(randomSeed);
	int covariateAttributeIndex = getLabels().indexOf(
		covariateAttributeName);
	if (covariateAttributeIndex == -1) {
	    covariateAttributeIndex = getLabels().indexOf(
		    covariateAttributeName.toUpperCase());
	    if (covariateAttributeIndex == -1) {
		throw new Exception("Attribute name '" + covariateAttributeName
			+ "' does not exist in the dataset.");
	    }
	}
	final float datasetOverallRatio = getRatio();
	final byte numAttributeLevels = (byte) levels.get(
		covariateAttributeIndex).size();
	final ArrayList<RowData> rowsToAdd = new ArrayList<RowData>();
	// because logic is complicated deal with only one genotype at a time --
	// efficiency not critical here
	for (int attributeLevelIndex = 0; attributeLevelIndex < numAttributeLevels; ++attributeLevelIndex) {
	    final ArrayList<RowData> affectedRows = new ArrayList<RowData>();
	    final ArrayList<RowData> unaffectedRows = new ArrayList<RowData>();
	    for (final RowData rowDatum : rowData) {
		final byte attributeLevelIndexForRow = rowDatum.rowLevelIndices[covariateAttributeIndex];
		if (attributeLevelIndexForRow == attributeLevelIndex) {
		    final byte statusLevelIndex = rowDatum.getStatus();
		    if (statusLevelIndex == affectedStatus) {
			affectedRows.add(rowDatum);
		    } else {
			unaffectedRows.add(rowDatum);
		    }
		} // if the row has the current allele we are considering
	    } // end row
	    if ((affectedRows.size() == 0) || (unaffectedRows.size() == 0)) {
		throw new Exception(
			"Covariate adjustment cannot be made because all rows with attribute value '"
				+ levels.get(covariateAttributeIndex).get(
					attributeLevelIndex)
				+ "' are of the same class.");
	    }
	    final int numAffected = affectedRows.size();
	    final int numUnaffected = unaffectedRows.size();
	    final float affectedUnaffectedRatioForGenotype = (float) numAffected
		    / numUnaffected;
	    int numToOversample;
	    ArrayList<RowData> arrayToOversampleFrom;
	    int finalNumAffected = numAffected;
	    int finalNumUnaffected = numUnaffected;
	    if (affectedUnaffectedRatioForGenotype > datasetOverallRatio) {
		// going to oversample unaffected rows
		// affected / (unaffected + oversampleAmount) =
		// datasetOverallRatio
		// solving for oversampleAmount:
		// oversampleAmount = affected/datasetOverallRatio - unaffected
		arrayToOversampleFrom = unaffectedRows;
		numToOversample = (int) Math
			.ceil((numAffected / datasetOverallRatio)
				- numUnaffected);
		finalNumUnaffected += numToOversample;
	    } else {
		// need to oversample affected rows
		// (affected + oversampleAmount)/unaffected =
		// datasetOverallRatio
		// solving for oversampleAmount:
		// oversampleAmount = unaffected*datasetOverallRatio - affected
		arrayToOversampleFrom = affectedRows;
		numToOversample = (int) Math
			.ceil((numUnaffected * datasetOverallRatio)
				- numAffected);
		finalNumAffected += numToOversample;
	    }
	    for (int overSampleIndex = 0; overSampleIndex < numToOversample; ++overSampleIndex) {
		final int randomIndex = rnd.nextInt(arrayToOversampleFrom
			.size());
		rowsToAdd.add(arrayToOversampleFrom.get(randomIndex));
	    }
	    if (createChangeReport) {
		sb.append(Dataset.covariateAdjustmentReportTable.format(Arrays
			.asList(new String[] {
				levels.get(covariateAttributeIndex).get(
					attributeLevelIndex),
				String.valueOf(numAffected) + "/"
					+ numUnaffected,
				String.valueOf(finalNumAffected) + "/"
					+ finalNumUnaffected })));
		sb.append("\n");
	    }
	} // end attributeLevelIndex (genotype)
	  // create a new dataset
	final List<RowData> newData = new ArrayList<Dataset.RowData>(rows
		+ rowsToAdd.size());
	for (int rowIndex = 0; rowIndex < rows; ++rowIndex) {
	    newData.add(rowData[rowIndex]);
	}
	newData.addAll(rowsToAdd);
	final Dataset adjustedDataset = new Dataset("covariate_adjusted_for_"
		+ covariateAttributeName + "_" + getDataFileName(),
		getMissing(), isPaired(), new ArrayList<String>(getLabels()),
		new ArrayList<List<String>>(getLevels()), newData,
		newData.size(), getAffectedStatus(), getUnaffectedStatus());
	return new Pair<Dataset, String>(adjustedDataset, sb.toString());
    } // end adjustForCovariate

    public int[] attributeNameListToAscendingIndicesArray(
	    final boolean throwExceptionOnUnknownAttributes,
	    final String[] attributeNamesToKeep) {
	return Dataset.attributeNameListToAscendingIndicesArray(
		throwExceptionOnUnknownAttributes, attributeNamesToKeep,
		getNumAttributes(), labels);
    }

    // public float[][] calculateAttributeStats(
    // final PriorityList<Pair<Float, String>>
    // topInterestingGenotypeCombinations) {
    // final int numAttributes = labels.size() - 1;
    // final int statusColIndex = labels.size() - 1;
    // final int numStatuses = levels.get(statusColIndex).size();
    // // order is attribute1, attribute2,attribute1LevelIndex,
    // attribute2levelIndex, statusIndex
    // final int[][][][][] attributesCoOccurrences = new int[numAttributes -
    // 1][][][][];
    // final float[] maxAttributeDifferences = new float[numAttributes];
    // final float[] totalAlleleFrequencyDifferences = new float[numAttributes];
    // final float[] maxAlleleFrequencyDifferences = new float[numAttributes];
    // // final float[] totalAttributeDifferences = new float[numAttributes];
    // final float[][] attributeStatsResults = new float[][] {
    // maxAttributeDifferences, totalAlleleFrequencyDifferences,
    // maxAlleleFrequencyDifferences };
    // // Create list status counts for each attributes different levels
    // // This could be done down below but requires a lot of conditional logic
    // so I thought it cleaner to split it out
    // // order is attribute index, level/value index, status index
    // final int[][][] attributesAlleleCountsByStatus = new
    // int[numAttributes][][];
    // for (int attributeIndex = 0; attributeIndex < numAttributes;
    // ++attributeIndex) {
    // final byte numAttributeLevels = (byte) levels.get(attributeIndex).size();
    // final int[][] attributeAlleleCountsByStatus = new
    // int[numAttributeLevels][numStatuses];
    // attributesAlleleCountsByStatus[attributeIndex] =
    // attributeAlleleCountsByStatus;
    // for (final byte[] row : data) {
    // final byte statusLevelIndex = row[statusColIndex];
    // ++attributeAlleleCountsByStatus[row[attributeIndex]][statusLevelIndex];
    // } // end row
    // } // end attribute
    // for (int attribute1Index = 0; attribute1Index <
    // attributesCoOccurrences.length; ++attribute1Index) {
    // final byte numAttribute1Levels = (byte) levels.get(attribute1Index)
    // .size();
    // final String attribute1Name = labels.get(attribute1Index);
    // final List<String> attribute1Values = levels.get(attribute1Index);
    // final int[][][][] attribute1CoOccurrences = new int[numAttributes
    // - (attribute1Index + 1)][numAttribute1Levels][][];
    // attributesCoOccurrences[attribute1Index] = attribute1CoOccurrences;
    // for (int coOccurrenceIndex = 0; coOccurrenceIndex <
    // attribute1CoOccurrences.length; ++coOccurrenceIndex) {
    // final int attribute2Index = attribute1Index + 1 + coOccurrenceIndex;
    // final String attribute2Name = labels.get(attribute2Index);
    // final List<String> attribute2Values = levels.get(attribute2Index);
    // final byte numAttribute2Levels = (byte) levels.get(attribute2Index)
    // .size();
    // final int[][][] attribute1Attribute2CoOccurrences = new
    // int[numAttribute1Levels][numAttribute2Levels][numStatuses];
    // attribute1CoOccurrences[coOccurrenceIndex] =
    // attribute1Attribute2CoOccurrences;
    // for (final byte[] row : data) {
    // final byte attribute1LevelIndex = row[attribute1Index];
    // final byte attribute2LevelIndex = row[attribute2Index];
    // final byte statusLevelIndex = row[statusColIndex];
    // ++attribute1Attribute2CoOccurrences[attribute1LevelIndex][attribute2LevelIndex][statusLevelIndex];
    // } // end row
    // // finished calculating all interactions between these two attributes so
    // now examine in detail
    // for (byte attribute1LevelIndex = 0; attribute1LevelIndex <
    // numAttribute1Levels; ++attribute1LevelIndex) {
    // final String attribute1ValueName = attribute1Values
    // .get(attribute1LevelIndex);
    // for (byte attribute2LevelIndex = 0; attribute2LevelIndex <
    // numAttribute2Levels; ++attribute2LevelIndex) {
    // final String attribute2ValueName = attribute2Values
    // .get(attribute2LevelIndex);
    // for (int statusLevelIndex = 0; statusLevelIndex < numStatuses;
    // ++statusLevelIndex) {
    // final int attribute1StatusCount =
    // attributesAlleleCountsByStatus[attribute1Index][attribute1LevelIndex][statusLevelIndex];
    // final int attribute2StatusCount =
    // attributesAlleleCountsByStatus[attribute2Index][attribute2LevelIndex][statusLevelIndex];
    // final float predictedCount = (attribute1StatusCount *
    // attribute2StatusCount)
    // / (float) statusCounts[statusLevelIndex];
    // final int actualCount =
    // attribute1Attribute2CoOccurrences[attribute1LevelIndex][attribute2LevelIndex][statusLevelIndex];
    // final float difference = Math.abs(predictedCount - actualCount);
    // maxAttributeDifferences[attribute1Index] = Math.max(
    // maxAttributeDifferences[attribute1Index], difference);
    // maxAttributeDifferences[attribute2Index] = Math.max(
    // maxAttributeDifferences[attribute2Index], difference);
    // final String identifier = "status: "
    // + levels.get(statusColIndex).get(statusLevelIndex) + " "
    // + attribute1Name + "-" + attribute2Name + " ["
    // + attribute1ValueName + "," + attribute2ValueName
    // + "] : actual: " + actualCount + "  predicted: "
    // + predictedCount + " (" + attribute1StatusCount + ","
    // + attribute2StatusCount + ")";
    // if (false && attribute1Name.equals("X0")
    // && attribute2Name.equals("X1")) {
    // System.out.println(difference + ": " + identifier);
    // }
    // topInterestingGenotypeCombinations.add(new Pair<Float, String>(
    // difference, identifier));
    // }
    // } // for attribute2LevelIndex
    // } // for attribute1LevelIndex
    // } // end coOccurrence
    // } // end attribute1
    // return attributeStatsResults;
    // }// calculateAttributeStats()
    private void calculateStatusCounts() {
	if (!hasContinuousEndpoints()) {
	    final int statusColIndex = labels.size() - 1;
	    final List<String> statuses = levels.get(statusColIndex);
	    statusCounts = new int[statuses.size()];
	    final byte[] firstThreeStatuses = new byte[] {
		    Model.INVALID_STATUS, Model.INVALID_STATUS,
		    Model.INVALID_STATUS };
	    final byte[] lastThreeStatuses = new byte[] { Model.INVALID_STATUS,
		    Model.INVALID_STATUS, Model.INVALID_STATUS };
	    int lastStatusLevelIndex = -1;
	    boolean pairedPatternPossible = (rows % 2) == 0;
	    boolean tripletPatternPossible = (rows % 3) == 0;
	    for (int rowIndex = 0; rowIndex < rows; ++rowIndex) {
		final byte statusLevelIndex = rowData[rowIndex].getStatus();
		++statusCounts[statusLevelIndex];
		if (pairedPatternPossible) {
		    pairedPatternPossible = lastStatusLevelIndex != statusLevelIndex;
		    lastStatusLevelIndex = statusLevelIndex;
		}
		if (tripletPatternPossible) {
		    final int rowIndexModulusThree = rowIndex % 3;
		    if (rowIndex < 3) {
			firstThreeStatuses[rowIndexModulusThree] = lastThreeStatuses[rowIndexModulusThree] = statusLevelIndex;
		    } else {
			lastThreeStatuses[rowIndexModulusThree] = statusLevelIndex;
			// if data is paired then we will see repeating patterns
			// of either 010 or 101
			tripletPatternPossible = Arrays.equals(
				firstThreeStatuses, lastThreeStatuses);
		    }
		} // end if triplets enabled
	    } // end for all rows
	    if (pairedPatternPossible && tripletPatternPossible) {
		throw new RuntimeException(
			"Dataset.calculateStatusCounts says both pairedPatternPossible && tripletPatternPossible but this should be impossible since repeating pair does not make repeating triplet");
	    } else if (pairedPatternPossible) {
		rowRepeatPattern = ROW_REPEAT_PATTERN.PAIRED;
	    } else if (tripletPatternPossible) {
		if (firstThreeStatuses[0] == firstThreeStatuses[1]) {
		    rowRepeatPattern = ROW_REPEAT_PATTERN.TWO_ONE;
		} else if (firstThreeStatuses[1] == firstThreeStatuses[2]) {
		    rowRepeatPattern = ROW_REPEAT_PATTERN.ONE_TWO;
		} else {
		    rowRepeatPattern = ROW_REPEAT_PATTERN.ONE_ONE_ONE;
		}
	    }
	    // System.out.println("calculateStatusCounts: # rows: " + rows
	    // + " status counts: " + Arrays.toString(statusCounts)
	    // + " ROW_REPEAT_PATTERN." + rowRepeatPattern);
	    checkPairedIsSupportable();
	} // end if !hasContinuousEndpoints
    }// end calculateStatusCounts

    public boolean canBePaired() {
	return rowRepeatPattern != ROW_REPEAT_PATTERN.NONE;
    }

    private void checkPairedIsSupportable() {
	if (matchedPairsOrTriplets && !canBePaired()) {
	    System.err
		    .println("WARNING: A matched analysis was requested but the dataset does not alternate status/class in the the final column so a normal analysis will be performed instead.");
	    matchedPairsOrTriplets = false;
	}
    }

    public void constructAndAddAttribute(final String[] attributeNamesToSearch,
	    final String constructedAttributeName,
	    final AmbiguousCellStatus ambiguousCellStatus) {
	assert !datasetHasBeenPermuted;
	final AttributeCombination combo = new AttributeCombination(
		attributeNamesToSearch, getNumAttributes(), labels);
	final int[] indexOfConstructedAttribute = attributeNameListToAscendingIndicesArray(
		false /* throwExceptionOnUnknownAttributes */,
		new String[] { constructedAttributeName });
	if (indexOfConstructedAttribute.length > 0) {
	    throw new IllegalArgumentException(
		    "requested constructed attribute name '"
			    + constructedAttributeName
			    + "' already exists in dataset at column index: "
			    + indexOfConstructedAttribute[0]);
	}
	final Model model = new Model(combo, ambiguousCellStatus);
	final SortedMap<byte[], Cell> cells = model.buildCounts(this);
	model.buildStatuses(this, statusCounts, cells);
	final List<String> attribute = model.constructAttribute(this);
	insertColumn(cols - 1, constructedAttributeName, attribute);
    }

    public void createRankedStatusIndexAndNormalizedValues() {
	if (hasContinuousEndpoints()) {
	    sortedStatusSet = new ArrayList<Double>();

	    final SortedSet<Double> setOfDistinctEndpoints = new TreeSet<Double>();
	    for (int rowIndex = 0; rowIndex < rows; ++rowIndex) {
		final double continuousEndpoint = rowData[rowIndex]
			.getEndpoint();
		setOfDistinctEndpoints.add(continuousEndpoint);
	    }
	    sortedStatusSet.addAll(setOfDistinctEndpoints);
	} // end if hasContinuousEndpoints
	else {
	    sortedStatusSet = new ArrayList<Double>();
	    sortedStatusSet.add((double) unaffectedStatus);
	    sortedStatusSet.add((double) affectedStatus);
	}
    } // end createRankedStatusIndexAndNormalizedValues

    /**
     * Filters for the specified attributes (i.e. discards every column not in
     * the given array)
     * 
     * @param attributes
     *            The attributes not to discard
     * @return A <b>new</b> {@code Dataset} built from this {@code Dataset} with
     *         the specified filter.
     */
    public Dataset filter(final int[] attributes) {
	assert !datasetHasBeenPermuted;
	final int numColumns = attributes.length + 1; // add a status column
	final ArrayList<RowData> filteredRowData = new ArrayList<Dataset.RowData>(
		rowData.length);
	final List<String> newLabels = new ArrayList<String>(numColumns);
	final List<List<String>> newLevels = new ArrayList<List<String>>(
		numColumns);
	for (final int i : attributes) {
	    newLabels.add(labels.get(i));
	    newLevels.add(levels.get(i));
	}
	final int statusColIndex = cols - 1;
	newLabels.add(labels.get(statusColIndex));
	newLevels.add(levels.get(statusColIndex));
	for (int r = 0; r < rows; ++r) {
	    filteredRowData.add(rowData[r].makeFilteredCopy(attributes));
	}
	return new Dataset("filtered_to_" + attributes.length + "_"
		+ getDataFileName(), missing, matchedPairsOrTriplets,
		newLabels, newLevels, filteredRowData, rows, affectedStatus,
		unaffectedStatus);
    }

    public Pair<Double, Double> getAffectedAndUnaffectedCounts() {
	return Dataset.getAffectedAndUnaffectedCounts(this,
		Arrays.asList(rowData));
    }

    public Pair<Double, Double> getAffectedAndUnaffectedTotals() {
	return Dataset.getAffectedAndUnaffectedTotals(this,
		Arrays.asList(rowData));
    }

    public byte getAffectedStatus() {
	return affectedStatus;
    }

    public int getAffectedStatusCount() {
	int statusCount;
	if (hasContinuousEndpoints()) {
	    statusCount = -1;
	} else {
	    statusCount = statusCounts[affectedStatus];
	}
	return statusCount;
    }

    public String getAffectedValuesString() {
	return hasContinuousEndpoints() ? "N/A" : levels.get(cols - 1).get(
		affectedStatus);
    }

    public List<String> getAttributeNames() {
	return Collections.unmodifiableList(labels.subList(0,
		getNumAttributes()));
    }

    public String[] getAttributeValues(final int[] attr, final byte[] bytes) {
	final String[] attributeValues = new String[bytes.length];
	for (int i = 0; i < bytes.length; ++i) {
	    final byte attributeLevelIndex = bytes[i];
	    String attributeValue = levels.get(attr[i])
		    .get(attributeLevelIndex);
	    if (attributeValue == getMissing()) {
		attributeValue = Main.missingRepresentation;
	    }
	    attributeValues[i] = attributeValue;
	}
	return attributeValues;
    }

    public double getAverageEndpoint() {
	return getEndpointSummaryStatistics().getMean();
    } // end getContinuousEndpointMean

    public double getAverageNormalizedEndpoint() {
	if (averageNormalizedEndpoint == null) {
	    double sumOfNormalizedEndpoints = 0.0;
	    for (int rowIndex = 0; rowIndex < rows; ++rowIndex) {
		sumOfNormalizedEndpoints += getEndpointNormalized(rowData[rowIndex]
			.getEndpoint());
	    }
	    averageNormalizedEndpoint = sumOfNormalizedEndpoints / rows;
	}
	return averageNormalizedEndpoint;
    }

    public double getAverageRank() {
	if (sortedStatusSet == null) {
	    createRankedStatusIndexAndNormalizedValues();
	}
	return sortedStatusSet.size() / 2.0;
    }

    public int getCols() {
	return cols;
    }

    public byte[] getColumn(final int col) {
	final byte[] ret = new byte[getRows()];
	for (int rowIndex = 0; rowIndex < rows; ++rowIndex) {
	    ret[rowIndex] = rowData[rowIndex].rowLevelIndices[col];
	}
	return ret;
    }

    public String getColumnName(final int columnIndex) {
	return getLabels().get(columnIndex);
    }

    /**
     * get the original data values at the column -- not the byte index but the
     * one from the data file
     * 
     * @param columnIndex
     */

    public String[] getColumnValues(final int columnIndex) {
	final String[] columnValues = new String[rows];
	for (int rowIndex = 0; rowIndex < rows; ++rowIndex) {
	    columnValues[rowIndex] = rowData[rowIndex].getDatum(columnIndex,
		    levels);
	}
	return columnValues;
    }

    public Double getContinuousEndpoint(final int rowIndex) {
	return rowData[rowIndex].continuousEndpoint;
    }

    public Double getContinuousEndpointMedian() {
	if (!hasContinuousEndpoints()) {
	    throw new RuntimeException(
		    "getContinuousEndpointMedian when there is no continous endpoint data!");
	}
	if (continuousEndpointMedian == null) {
	    final double[] sortedContinuousEndpoints = new double[rows];
	    for (int rowIndex = 0; rowIndex < rows; ++rowIndex) {
		sortedContinuousEndpoints[rowIndex] = rowData[rowIndex].continuousEndpoint;
	    }
	    Arrays.sort(sortedContinuousEndpoints);
	    final int medianPos = sortedContinuousEndpoints.length / 2;
	    continuousEndpointMedian = sortedContinuousEndpoints[medianPos];
	}
	return continuousEndpointMedian;
    } // getContinuousEndpointMedian

    public String getDataFileName() {
	return dataFileName;
    }

    public String getDatum(final int rowIndex, final int columnIndex) {
	if (rowIndex > rows) {
	    throw new IndexOutOfBoundsException();
	}
	return rowData[rowIndex].getDatum(columnIndex, levels);
    }

    public byte[] getDichotomousEndpoints() {
	byte[] dichotomousEndpoints;
	if (!hasContinuousEndpoints()) {
	    dichotomousEndpoints = getColumn(getCols() - 1);
	} else {
	    final double medianEndpoint = getContinuousEndpointMedian();
	    dichotomousEndpoints = new byte[rows];
	    // it doesn't seem that likely but if some reason many values were
	    // equal to the median I want to
	    // 'randomly', but deterministically, assign them to either of the
	    // two statuses
	    // this will keep the dataset fairly closely balanced.
	    int tieCounter = 0;
	    for (int rowIndex = 0; rowIndex < rows; ++rowIndex) {
		int compareResult = Double.compare(
			rowData[rowIndex].continuousEndpoint, medianEndpoint);
		if (compareResult == 0) {
		    // which category a tie is set to is based on whether it is
		    // an even or an odd tie
		    if ((tieCounter % 2) == 0) {
			compareResult = -1;
		    } else {
			compareResult = 1;
		    }
		    tieCounter++;
		}
		if (compareResult < 0) {
		    dichotomousEndpoints[rowIndex] = Dataset.CONTINUOUS_ENDPOINT_UNAFFECTED_STATUS;
		} else {
		    dichotomousEndpoints[rowIndex] = Dataset.CONTINUOUS_ENDPOINT_AFFECTED_STATUS;
		}
	    }
	}
	return dichotomousEndpoints;
    }

    /**
     * convert status endpoints to non negative numbers between 0 and 1. This is
     * done value =
     * 
     * @param rowIndex
     * @return
     */
    public double getEndpointNormalized(final Double endpoint) {
	final SummaryStatistics summaryStatistics = getEndpointSummaryStatistics();
	final double normalizedEndpoint = (endpoint - summaryStatistics
		.getMin())
		/ (summaryStatistics.getMax() - summaryStatistics.getMin());
	return normalizedEndpoint;
    }

    /**
     * sort endpoints ascending. Rank is index into sortedSet of all possible
     * values. Note that ties can exist -- forexample in discrete datae with all
     * zeroes and ones there are only two ranks -- 0 and 1
     * 
     * @param rowIndex
     * @return
     */
    public int getEndpointRank(final Double endpoint) {
	if (sortedStatusSet == null) {
	    createRankedStatusIndexAndNormalizedValues();
	    // throw new RuntimeException("getEndpointRank(" + rowIndex
	    // +
	    // ") called before createRankedStatusIndexAndNormalizedValues called");
	}
	final int rank = sortedStatusSet.indexOf(endpoint);
	if (rank < 0) {
	    throw new RuntimeException("getRank(" + endpoint
		    + ") did not find endpoint in sortedStatusSet.");
	}
	return rank;
    } // end getEndpointRank // end getEndpointNormalized

    /**
     * sort endpoints ascending. Rank is index into sortedSet of all possible
     * values. Note that ties can exist -- forexample in discrete datae with all
     * zeroes and ones there are only two ranks -- 0 and 1
     * 
     * @param rowIndex
     * @return
     */
    public int getEndpointRank(final int rowIndex) {
	return getEndpointRank(rowData[rowIndex].continuousEndpoint);
    } // end getEndpointRank

    public SummaryStatistics getEndpointSummaryStatistics() {
	if (continuousEndpointSummaryStatistics == null) {
	    continuousEndpointSummaryStatistics = new SummaryStatistics();
	    for (int rowIndex = 0; rowIndex < rows; ++rowIndex) {
		continuousEndpointSummaryStatistics.addValue(rowData[rowIndex]
			.getEndpoint());
	    }
	}
	return continuousEndpointSummaryStatistics;
    }

    /**
     * @return An {@link java.util.ArrayList} of the attribute names.
     */
    public List<String> getLabels() {
	return Collections.unmodifiableList(labels);
    }

    public List<List<String>> getLevels() {
	return levels;
    }

    /**
     * Return the index to the class which has the most instances or the
     * affected class if they are equal
     * 
     * @return
     */
    public byte getMajorityStatus() {
	byte majorityStatus;
	if (hasContinuousEndpoints()) {
	    majorityStatus = Model.INVALID_STATUS;
	} else {
	    if (statusCounts[getAffectedStatus()] >= statusCounts[getUnaffectedStatus()]) {
		majorityStatus = getAffectedStatus();
	    } else {
		majorityStatus = getUnaffectedStatus();
	    }
	}
	return majorityStatus;
    }

    public int getMajorityStatusCount() {
	final byte majorityStatus = getMajorityStatus();
	return getStatusCount(majorityStatus);
    }

    public double getMaximumEndpoint() {

	return getEndpointSummaryStatistics().getMax();
    }

    public double getMinimumEndpoint() {
	return getEndpointSummaryStatistics().getMin();
    }

    /**
     * Return the index to the class which has the least instances or the
     * unaffected class if they are equal
     * 
     * @return
     */
    public byte getMinorityStatus() {
	byte minorityStatus;
	if (hasContinuousEndpoints()) {
	    minorityStatus = Model.INVALID_STATUS;
	} else {
	    final byte majorityStatus = getMajorityStatus();
	    minorityStatus = (byte) ((majorityStatus == 0) ? 1 : 0);
	}
	return minorityStatus;
    }

    public int getMinorityStatusCount() {
	final byte minorityStatus = getMinorityStatus();
	return getStatusCount(minorityStatus);
    }

    public String getMissing() {
	return missing;
    }

    public int getNumAttributes() {
	return cols - 1;
    }

    public byte getNumStatuses() {
	byte numStatuses;
	if (hasContinuousEndpoints()) {
	    numStatuses = -1;
	} else {
	    final int statusCol = getCols() - 1;
	    numStatuses = (byte) getLevels().get(statusCol).size();
	}
	return numStatuses;
    }

    /**
     * ratio of affected to unaffected
     */
    public float getRatio() {
	float ratio;
	if (hasContinuousEndpoints()) {
	    ratio = Float.NaN;
	} else {
	    ratio = (float) statusCounts[getAffectedStatus()]
		    / (float) statusCounts[getUnaffectedStatus()];
	}
	return ratio;
    }

    public byte getRawDatum(final int rowIndex, final int columnIndex) {
	if ((rowIndex > rows) || (columnIndex > cols)) {
	    throw new IndexOutOfBoundsException();
	}
	return rowData[rowIndex].rowLevelIndices[columnIndex];
    }

    public RowData getRowData(final int rowIndex) {
	return rowData[rowIndex];
    }

    public byte[] getRowDataLevelIndices(final int rowIndex) {
	return rowData[rowIndex].rowLevelIndices;
    }

    public int getRows() {
	return rows;
    }

    public byte[] getRowSlice(final int row, final int[] attributeIndices) {
	final byte[] ret = new byte[attributeIndices.length];
	for (int comboIndex = 0; comboIndex < attributeIndices.length; ++comboIndex) {
	    final int attributeIndex = attributeIndices[comboIndex];
	    final byte levelIndex = rowData[row].rowLevelIndices[attributeIndex];
	    ret[comboIndex] = levelIndex;
	}
	return ret;
    }

    public float getRowWeight(final int rowIndex) {
	final float weight = rowData[rowIndex].getRowWeight();
	return weight;
    }

    /**
     * get fraction of dataset columns that are affected. If continuous data get
     * average value.
     * 
     * @return
     */
    public double getStatusAverage() {
	return getAverageEndpoint();
    }

    public int getStatusColIndex() {
	return cols - 1;
    }

    public String getStatusColumnName() {
	return getColumnName(getStatusColIndex());
    }

    public String[] getStatusColumnValues() {
	final String[] statusColumnValues = new String[rows];
	for (int rowIndex = 0; rowIndex < rows; ++rowIndex) {
	    statusColumnValues[rowIndex] = rowData[rowIndex]
		    .getStatusColumnValue(levels);
	}
	return statusColumnValues;
    }

    public int getStatusCount(final byte status) {
	int count;
	if (hasContinuousEndpoints()) {
	    count = -1;
	} else {
	    count = statusCounts[status];
	}
	return count;
    }

    public int[] getStatusCounts() {
	return statusCounts;
    }

    public byte getStatusLevelIndex(final int rowIndex) {
	return rowData[rowIndex].getStatus();
    }

    public byte getUnaffectedStatus() {
	return unaffectedStatus;
    }

    public int getUnaffectedStatusCount() {
	int statusCount;
	if (hasContinuousEndpoints()) {
	    statusCount = -1;
	} else {
	    statusCount = statusCounts[unaffectedStatus];
	}
	return statusCount;
    }

    public String getUnaffectedValuesString() {
	return hasContinuousEndpoints() ? "N/A" : levels.get(cols - 1).get(
		unaffectedStatus);
    }

    public boolean hasContinuousEndpoints() {
	return (rowData != null) && (rowData.length > 0)
		&& (rowData[0].continuousEndpoint != null);
    }

    public boolean hasDatasetBeenPermuted() {
	return datasetHasBeenPermuted;
    }

    public void insertColumn(final int col, final String name,
	    final List<String> columnValues) {
	final SortedSet<String> uniqueValuesSet = new TreeSet<String>(
		columnValues);
	final List<String> uniqueValues = new ArrayList<String>(uniqueValuesSet);
	final List<Byte> columnLevelIndices = new ArrayList<Byte>(
		columnValues.size());
	for (final String value : columnValues) {
	    columnLevelIndices.add((byte) uniqueValues.indexOf(value));
	}
	insertColumn(col, name, uniqueValues, columnLevelIndices);
    }

    public void insertColumn(final int col, final String name,
	    List<String> uniqueValues, final List<Byte> values) {
	assert ((col >= 0) && (col <= cols));
	labels.add(col, name);
	// look to see if a list of values matching this one already exists
	final int sameLevelsListIndex = levels.indexOf(uniqueValues);
	if (sameLevelsListIndex != -1) {
	    // if a list with these values already exists, use it instead of
	    // newly created one
	    uniqueValues = levels.get(sameLevelsListIndex);
	}
	levels.add(col, uniqueValues);
	for (int r = 0; r < rows; ++r) {
	    final byte value = values.get(r).byteValue();
	    rowData[r].insertColumn(col, value);
	}
	cols = cols + 1;
    }

    public boolean isBalanced() {
	return Float.compare(getRatio(), 1.0f) == 0;
    }

    public boolean isEmpty() {
	return (rows == 0) || (cols == 0);
    }

    public boolean isPaired() {
	return matchedPairsOrTriplets;
    }

    public Pair<List<Dataset>, List<Dataset>> partition(final int intervals,
	    final long seed) {
	final Random rnd = new Random(seed);
	if ((intervals == 0) || (intervals == 1)) {
	    return null;
	} else if (intervals > rows) {
	    throw new IllegalArgumentException(
		    "Number of cross validation intervals (" + intervals
			    + ") cannot be greater than the number of rows("
			    + rows + ")!");
	} else if (intervals < 0) {
	    throw new IllegalArgumentException(
		    "Number of cross validation intervals (" + intervals
			    + ") cannot be negative!");

	}
	final List<List<RowData>> partitions = matchedPairsOrTriplets ? partitionMatchedPairsOrTriplets(
		intervals, rnd) : partitionUnmatchedData(intervals, rnd);
	final List<Dataset> trainingDatasets = new ArrayList<Dataset>(intervals);
	final List<Dataset> testingDatasets = new ArrayList<Dataset>(intervals);
	final Pair<List<Dataset>, List<Dataset>> trainingAndTestingDatasets = new Pair<List<Dataset>, List<Dataset>>(
		trainingDatasets, testingDatasets);
	for (int i = 0; i < intervals; ++i) {
	    final List<RowData> testingPartition = partitions.get(i);
	    testingDatasets.add(new Dataset("testing_" + (i + 1) + "_of_"
		    + getDataFileName(), missing, matchedPairsOrTriplets,
		    labels, levels, testingPartition, testingPartition.size(),
		    affectedStatus, unaffectedStatus));
	    // for each training set, add all of the rows from the testing sets
	    // from all other intervals
	    final List<RowData> trainingData = new ArrayList<RowData>(rows
		    - testingPartition.size());
	    for (int j = 0; j < intervals; ++j) {
		if (i == j) {
		    continue;
		}
		final List<RowData> partition = partitions.get(j);
		trainingData.addAll(partition);
	    }
	    trainingDatasets.add(new Dataset("training_" + (i + 1) + "_of_"
		    + getDataFileName(), missing, matchedPairsOrTriplets,
		    labels, levels, trainingData, trainingData.size(),
		    affectedStatus, unaffectedStatus));
	}
	return trainingAndTestingDatasets;
    }

    private List<List<RowData>> partitionMatchedPairsOrTriplets(
	    final int intervals, final Random rnd) {
	int patternSize;
	switch (rowRepeatPattern) {
	case PAIRED:
	    patternSize = 2;
	    break;
	case ONE_ONE_ONE:
	case ONE_TWO:
	case TWO_ONE:
	    patternSize = 3;
	    break;
	default:
	    throw new RuntimeException(
		    "Dataset.matchedionMatchedPairsOrTriplets() unhandled rowRepeatPattern: "
			    + rowRepeatPattern);
	}
	final List<RowData[]> repeatedPatternRowSets = new ArrayList<RowData[]>();
	for (int rowIndex = 0; rowIndex < (rows - (patternSize - 1)); rowIndex += patternSize) {
	    switch (rowRepeatPattern) {
	    case PAIRED:
		repeatedPatternRowSets.add(new RowData[] { rowData[rowIndex],
			rowData[rowIndex + 1] });
		break;
	    case ONE_ONE_ONE:
	    case ONE_TWO:
	    case TWO_ONE:
		repeatedPatternRowSets.add(new RowData[] { rowData[rowIndex],
			rowData[rowIndex + 1], rowData[rowIndex + 2] });
		break;
	    default:
		throw new RuntimeException(
			"Dataset.matchedionMatchedPairsOrTriplets() unhandled rowRepeatPattern: "
				+ rowRepeatPattern);
	    }
	}
	final List<List<RowData>> partitions = new ArrayList<List<RowData>>(
		intervals);
	if (rnd != null) {
	    Collections.shuffle(repeatedPatternRowSets, rnd);
	}
	for (int i = 0; i < intervals; ++i) {
	    partitions.add(new ArrayList<RowData>());
	}
	for (int i = 0; i < repeatedPatternRowSets.size(); ++i) {
	    final List<RowData> partition = partitions.get(i % intervals);
	    final RowData[] patternRows = repeatedPatternRowSets.get(i);
	    for (final RowData rowData : patternRows) {
		partition.add(rowData);
	    }
	}
	return partitions;
    }

    private List<List<RowData>> partitionUnmatchedData(final int intervals,
	    final Random rnd) {
	final byte[] dichotomousEndpoints = getDichotomousEndpoints();
	final TreeMap<Byte, List<Integer>> instByClass = Dataset
		.mapRowIndicesByClass(dichotomousEndpoints);

	final List<List<RowData>> partitions = new ArrayList<List<RowData>>(
		intervals);
	for (int i = 0; i < intervals; ++i) {
	    partitions.add(new ArrayList<RowData>());
	}
	int total = 0;
	for (final List<Integer> list : instByClass.values()) {
	    Collections.shuffle(list, rnd);
	    for (int i = 0; i < list.size(); ++i) {
		partitions.get((i + total) % intervals).add(
			rowData[list.get(i)]);
	    }
	    total += list.size();
	}
	return partitions;
    }

    /**
     * 
     * @param lnr
     * @param endPattern
     * @param progressUpdater
     * @param allowedAttributes
     *            can be set attribute names or zero based indices. Should be
     *            all of one or the other =- not mixed.
     * @return
     * @throws IOException
     */
    public String read(final LineNumberReader lnr, final Pattern endPattern,
	    final SwingInvoker progressUpdater,
	    final Set<? extends Object> allowedAttributes) throws IOException {
	String line;
	int rowsWithWeights = 0;
	long missingCount = 0;
	long notMissingCount = 0;
	final ArrayList<RowData> newRowData = new ArrayList<RowData>();
	boolean newDataHasContinuousEndpoints = false;
	final boolean allowedAttributesAreIndices = ((allowedAttributes == null) || (allowedAttributes
		.size() == 0)) ? false
		: (allowedAttributes.iterator().next() instanceof Integer);
	Dataset.datasetLoadingWarningMessages.clear();
	line = lnr.readLine();
	if (line == null) {
	    throw new IOException("Empty file!");
	}
	line = line.trim();
	String[] fields = Dataset.patDelim.split(line, 4);
	if (line.equals("@DatafileInformation")) {
	    throw new IOException(
		    "This is an MDR analysis file (which includes the relevant dataset), not a dataset file. Please use the 'Load Analysis...' button.");

	} else if (fields.length < 2) {
	    throw new IOException(
		    "Too few rows: The first row is expected to contain at least one attibute and the class column so there must be at least two columns. '"
			    + line
			    + "' only contains "
			    + fields.length
			    + " recognizable columns: "
			    + Arrays.toString(fields));
	}
	// find the delimiters used between first two columns
	final int endIndexOfFirstField = fields[0].length();
	final int startIndexOfSecondField = line.indexOf(fields[1],
		endIndexOfFirstField);
	final String delimiter = line.substring(endIndexOfFirstField,
		startIndexOfSecondField);
	// split the line from scratch using the delimiter since we expect all
	// fields to be delimited in the same way
	fields = line.split(delimiter);
	final int headerRowNumberOfColumns = fields.length;
	Set<String> labelsSet = new HashSet<String>(headerRowNumberOfColumns);
	int numberOfAttributes = fields.length - 1;
	if (allowedAttributes != null) {
	    numberOfAttributes = allowedAttributes.size();
	}
	labels = new ArrayList<String>(numberOfAttributes + 1);
	levels = new ArrayList<List<String>>(numberOfAttributes + 1);
	Set<Integer> disallowedColumnIndices = null;
	if (allowedAttributes != null) {
	    disallowedColumnIndices = new HashSet<Integer>(fields.length
		    - numberOfAttributes - 1);
	}
	// all columns start off using the same 'templateLevelList'
	final List<String> templateLevelList = new ArrayList<String>(3);
	for (int columnIndex = 0; columnIndex < fields.length; ++columnIndex) {
	    String label = fields[columnIndex].trim();
	    final boolean isStatusColumn = columnIndex == (headerRowNumberOfColumns - 1);
	    if (!isStatusColumn && label.contains(" ")) {
		throw new IOException("Attribute name '" + label
			+ "' in column " + (columnIndex + 1)
			+ " contains a space which is not allowed.");
	    }
	    if (label.length() == 0) {
		throw new IOException(
			"There is an extra delimiter just after attribute name '"
				+ fields[columnIndex - 1] + "' in column "
				+ (columnIndex + 1) + ".");
	    }
	    // if label is surrounded by quotation marks, remove them
	    if ((label.length() > 2) && label.startsWith("\"")
		    && label.endsWith("\"")) {
		label = label.substring(1, label.length() - 1);
	    }
	    if (labelsSet.contains(label)) {
		throw new IOException("Duplicate label '" + fields[columnIndex]
			+ "' at columns " + (columnIndex + 1) + " and "
			+ (labels.indexOf(fields[columnIndex]) + 1) + ".");
	    }

	    boolean useThisColumn = isStatusColumn
		    || (allowedAttributes == null);
	    if (!useThisColumn) {
		// we are only keeping some columns so confirm keeping this one
		if (allowedAttributesAreIndices) {
		    useThisColumn = allowedAttributes.contains(columnIndex);
		} else {
		    useThisColumn = allowedAttributes.contains(label);
		}
	    }
	    if (useThisColumn) {
		labels.add(label);
		labelsSet.add(label);
		levels.add(templateLevelList);
	    } else {
		disallowedColumnIndices.add(columnIndex);
	    }
	} // end column index loop
	labelsSet.clear();
	labelsSet = null;
	if (labels.isEmpty()) {
	    throw new IOException("No columns in data set!");
	}
	final int statusColIndex = labels.size() - 1;
	while (((line = lnr.readLine()) != null)
		&& ((endPattern == null) || !endPattern.matcher(line).matches())) {
	    line = line.trim();
	    if (line.length() == 0) {
		continue; // sometimes files have an extra carriage return at
			  // the bottom. Even if an extra carriage return in
			  // middle of file, be forgiving
	    }
	    fields = line.split(delimiter);
	    if (fields.length != headerRowNumberOfColumns) {
		throw new IOException("Line " + lnr.getLineNumber()
			+ ": Expected " + headerRowNumberOfColumns
			+ " columns, found " + fields.length + ".");
	    }
	    final byte[] levelIndices = new byte[labels.size()];
	    final RowData newRow = new RowData(levelIndices, null, null);
	    newRowData.add(newRow);
	    int colIndex = 0;
	    for (int fieldIndex = 0; fieldIndex < fields.length; ++fieldIndex) {
		String cellValue = fields[fieldIndex].trim();
		if ((disallowedColumnIndices != null)
			&& disallowedColumnIndices.contains(fieldIndex)) {
		    // skip this column
		    continue;
		}
		if ((colIndex == statusColIndex) && (cellValue.length() == 0)) {
		    throw new IOException(
			    "Line "
				    + lnr.getLineNumber()
				    + ": The last column, which represents class, cannot be empty.");
		}
		if (colIndex == statusColIndex) {
		    if (Main.isExperimental) {
			final String[] statusAndWeight = cellValue.split(":");
			if (statusAndWeight.length == 2) {
			    newRow.rowWeight = Float
				    .valueOf(statusAndWeight[1]);
			    ++rowsWithWeights;
			    if (rowsWithWeights != newRowData.size()) {
				throw new RuntimeException(
					"Line "
						+ lnr.getLineNumber()
						+ ": The status value for row contained a weight but some previous rows did not. Status column value: "
						+ cellValue);
			    }
			    cellValue = statusAndWeight[0];
			}
		    } // end if experimental
		} else {
		    // support for missing data is still experimental because of
		    // the
		    // issue about how fitness should be adjusted for
		    // unclassifiable data
		    if (Main.isExperimental && cellValue.equals(missing)) {
			// kludgy optimization -- use the actual string object
			// of missing so
			// that we can use object comparison == instead of call
			// to String.equal method
			cellValue = missing;
			missingCount++;
		    } else
		    /* not missing */{
			notMissingCount++;
		    }
		} // end if not status column
		boolean isContinuousDataColumn = (colIndex == statusColIndex)
			&& newDataHasContinuousEndpoints;
		if (!isContinuousDataColumn) {
		    final List<String> discreteValues = levels.get(colIndex);
		    byte levelIndex = (byte) discreteValues.indexOf(cellValue);
		    if (levelIndex < 0) {
			// need to figure out if we have discrete endpoints or
			// continuous endpoints
			// if there are more than two types of values in the
			// last column then it must be continuous
			if ((colIndex == statusColIndex)
				&& (discreteValues.size() == 2)) {
			    // We may have continuous endpoints -- need to check
			    // that the first two types are parsable as numbers
			    final double[] continuousEndpoints = new double[newRowData
				    .size()];
			    for (int index = 0; index < discreteValues.size(); ++index) {
				final String endpointString = discreteValues
					.get(index);
				try {
				    continuousEndpoints[index] = Double
					    .valueOf(endpointString);
				} catch (final NumberFormatException numberFormatException) {
				    throw new IOException(
					    "Line "
						    + lnr.getLineNumber()
						    + ": The last column must have either two different classes for discrete data OR only numbers for continuous outcome. The current row's value is '"
						    + cellValue
						    + "' but the earlier values are not all numbers: "
						    + discreteValues.toString());
				}
			    } // end for loop over existing status column
			      // endpoints
			      // change the strings associated with 0 and 1 for
			      // this status column
			    discreteValues.set(0, Dataset.BELOW_AVERAGE_CLASS); // below
										// average
			    discreteValues.set(1,
				    Dataset.ABOVE_AVERAGE_OR_EQUAL_CLASS); // average
									   // and
									   // above
			    // Since we just figured out that we have continuous
			    // data
			    // we must fix up the rows already read in so far to
			    // store continuous data
			    newDataHasContinuousEndpoints = true;
			    isContinuousDataColumn = true;
			    for (int newRowIndex = 0; newRowIndex < newRowData
				    .size(); ++newRowIndex) {
				final RowData rowDatum = newRowData
					.get(newRowIndex);
				final int rowLevelIndex = rowDatum.rowLevelIndices[statusColIndex];
				rowDatum.continuousEndpoint = continuousEndpoints[rowLevelIndex];
				// set the discrete status column to an invalid
				// value to highlight errors.
				rowDatum.rowLevelIndices[statusColIndex] = Model.INVALID_STATUS;
			    } // end newRow loop
			} // end if checking to see if have continuous endpoints
			if (!isContinuousDataColumn) {
			    List<String> newDiscreteValues = new ArrayList<String>(
				    discreteValues);
			    newDiscreteValues.add(cellValue);
			    levelIndex = (byte) (newDiscreteValues.size() - 1);
			    if (levelIndex == (Model.INVALID_STATUS)) {
				throw new IOException(
					"Line "
						+ lnr.getLineNumber()
						+ ": Column "
						+ (colIndex + 1)
						+ " '"
						+ labels.get(colIndex)
						+ "' has more than 250 different values! MDR requires attribute columns to be categorical data. The first ten values are: "
						+ newDiscreteValues.subList(0,
							10));
			    }
			    final int sameLevelsListIndex = levels
				    .indexOf(newDiscreteValues);
			    if (sameLevelsListIndex != -1) {
				// if a list with these values already exists,
				// use it instead of newly created one
				newDiscreteValues = levels
					.get(sameLevelsListIndex);
			    }
			    levels.set(colIndex, newDiscreteValues);
			} // end if dealing with discrete data
		    } // end if cellValue is a new one for this column
		    if (!isContinuousDataColumn) {
			levelIndices[colIndex] = levelIndex;
		    } // end if still dealing with discrete data
		} // end if dealing with discrete data
		if (isContinuousDataColumn) {
		    levelIndices[colIndex] = Model.INVALID_STATUS;
		    try {
			final double newRowContinuousEndpoint = Double
				.valueOf(cellValue);
			newRow.continuousEndpoint = newRowContinuousEndpoint;
		    } catch (final NumberFormatException numberFormatException) {
			throw new IOException(
				"Line "
					+ lnr.getLineNumber()
					+ ": The dataset status column appears to be continuous data but the current row's value is '"
					+ cellValue
					+ "' which is not a number.");
		    }
		} // end if continuousDataColumn
		++colIndex;
	    } // for fields[] loop
	    if (progressUpdater != null) {
		progressUpdater.run();
	    }
	} // end while lines
	  // now actually store data as indices into levels for each attribute
	  // column
	cols = labels.size();
	rows = newRowData.size();
	rowData = new RowData[newRowData.size()];
	newRowData.toArray(rowData);
	if (newDataHasContinuousEndpoints) {
	    affectedStatus = Model.INVALID_STATUS;
	    unaffectedStatus = Model.INVALID_STATUS;
	    statusCounts = null;
	} else { // if discrete endpoints
	    final List<String> statuses = levels.get(statusColIndex);
	    if (statuses.size() != 2) {
		throw new IOException(
			"After having completely read file, there should be exactly two different values for the last (class/status) column '"
				+ labels.get(statusColIndex)
				+ "'. There were "
				+ statuses.size()
				+ " different values found. The values found were: "
				+ statuses.toString());
	    }
	    affectedStatus = (byte) statuses.indexOf("1");
	    unaffectedStatus = (byte) statuses.indexOf("0");
	    if ((affectedStatus < 0) || (unaffectedStatus < 0)) {
		// if the class variables are something other than 0 or 1
		// then the first one alphabetically is affected and the
		// second unaffected.
		// this is arbitrary but works with the common pairs
		// 'case/control' and 'affected/unaffected'
		final int comparisonResult = statuses.get(0).compareTo(
			statuses.get(1));
		if (comparisonResult < 1) {
		    affectedStatus = 0;
		    unaffectedStatus = 1;
		} else {
		    affectedStatus = 1;
		    unaffectedStatus = 0;
		}
	    }
	    calculateStatusCounts();
	} // end if status column is discrete
	if (missingCount > 0) {
	    final float missingPercentage = (missingCount * 100)
		    / (missingCount + notMissingCount);
	    final String warningMessage = "Warning: there are " + missingCount
		    + " out of " + notMissingCount + " or " + missingPercentage
		    + "% data values with missing data.";
	    System.out.println(warningMessage);
	    Dataset.datasetLoadingWarningMessages.add(warningMessage);
	}

	return line; // return the last line
    }

    /**
     * 
     * @param lnr
     * @param allowedAttributes
     *            can be set attribute names or zero based indices. Should be
     *            all of one or the other =- not mixed.
     * @throws IOException
     */
    public void read(final LineNumberReader lnr,
	    final Set<? extends Object> allowedAttributes) throws IOException {
	read(lnr, (Pattern) null, (SwingInvoker) null, allowedAttributes);
    }

    /**
     * 
     * @param r
     * @param progressUpdater
     * @param allowedAttributes
     *            can be set attribute names or zero based indices. Should be
     *            all of one or the other =- not mixed.
     * @throws IOException
     */
    public void read(final LineNumberReader r,
	    final SwingInvoker progressUpdater,
	    final Set<? extends Object> allowedAttributes) throws IOException {
	read(r, (Pattern) null, progressUpdater, allowedAttributes);
    }

    public void removeColumn(final int col) {
	assert ((col >= 0) && (col < (cols - 1)));
	final List<String> newLabels = new ArrayList<String>(labels.size() - 1);
	final List<List<String>> newLevels = new ArrayList<List<String>>(
		levels.size() - 1);
	for (int i = 0; i < cols; ++i) {
	    if (i != col) {
		newLabels.add(labels.get(i));
		newLevels.add(levels.get(i));
	    }
	}
	for (final RowData rowDatum : rowData) {
	    rowDatum.removeColumn(col);
	}
	labels = newLabels;
	levels = newLevels;
	cols = cols - 1;
    }

    public void setDatasetHasBeenPermuted() {
	datasetHasBeenPermuted = true;
    }

    public void setDatasetHasBeenPermuted(final boolean datasetHasBeenPermuted) {
	this.datasetHasBeenPermuted = datasetHasBeenPermuted;
    }

    public void setMatchedPairsOrTriplets(final boolean matchedPairsOrTriplets) {
	this.matchedPairsOrTriplets = matchedPairsOrTriplets;
	checkPairedIsSupportable();
    }

    @Override
    public String toString() {
	final StringBuilder sb = new StringBuilder(
		(datasetHasBeenPermuted ? "WARNING - DATASET HAS BEEN PERMUTED!!!\n"
			: "")
			+ "Dataset rows: "
			+ rows
			+ " cols: "
			+ cols
			+ " hasContinuousEndpoints: "
			+ hasContinuousEndpoints()
			+ " final column '"
			+ getStatusColumnName()
			+ "' has "
			+ getAffectedStatusCount()
			+ " affected '"
			+ getAffectedValuesString()
			+ "' and "
			+ getUnaffectedStatusCount()
			+ " unaffected '"
			+ getUnaffectedValuesString() + "'");
	return sb.toString();
    }

    public void write(final PrintWriter w) {
	assert !datasetHasBeenPermuted;
	w.println(Utility.join(labels, Dataset.sDelim));
	final int statusColIndex = cols - 1;
	for (int r = 0; r < rows; ++r) {
	    for (int c = 0; c < cols; ++c) {
		if (c != 0) {
		    w.print(Dataset.sDelim);
		}
		int levelIndex = rowData[r].rowLevelIndices[c];
		// check for negative value because byte are not unsigned
		// (dammit!)
		if (levelIndex < 0) {
		    levelIndex += 256; // convert to positive integer
		}
		if ((c == statusColIndex) && hasContinuousEndpoints()) {
		    w.print(rowData[r].continuousEndpoint);
		} else {
		    w.print(levels.get(c).get(levelIndex));
		}
	    }
	    w.println();
	}
	w.flush();
    }

    public void write(final PrintWriter w,
	    final int[] attributeIndicesInAscendingOrder) {
	assert !datasetHasBeenPermuted;
	// first print header row
	for (final int c : attributeIndicesInAscendingOrder) {
	    w.print(labels.get(c));
	    w.print(Dataset.sDelim);
	}
	w.println(getStatusColumnName());
	// next print out data rows
	for (int r = 0; r < rows; ++r) {
	    for (final int c : attributeIndicesInAscendingOrder) {
		int levelIndex = rowData[r].rowLevelIndices[c];
		// check for negative value because byte are not unsigned
		// (dammit!)
		if (levelIndex < 0) {
		    levelIndex += 256; // convert to positive integer
		}
		w.print(levels.get(c).get(levelIndex));
		w.print(Dataset.sDelim);
	    }
	    // print the status value at end of each row
	    w.println(rowData[r].getStatusColumnValue(levels));
	} // end row loop
	w.flush();
    }

    public class DatasetTableModel extends AbstractTableModel {
	private static final long serialVersionUID = 1L;

	@Override
	public Class<?> getColumnClass(final int columnIndex) {
	    return String.class;
	}

	@Override
	public int getColumnCount() {
	    return getCols();
	}

	@Override
	public String getColumnName(final int column) {
	    return getLabels().get(column);
	}

	@Override
	public int getRowCount() {
	    return getRows();
	}

	@Override
	public Object getValueAt(final int rowIndex, final int columnIndex) {
	    final String datum = getDatum(rowIndex, columnIndex);
	    if (datum == getMissing()) {
		return Main.missingRepresentation;
	    } else {
		return datum;
	    }
	}

	@Override
	public boolean isCellEditable(final int row, final int col) {
	    return false;
	}
    } // end local class DatasetTableModel

    static class Genotype implements Comparable<Genotype> {
	final AttributeCombination attributeCombination;
	final byte[] rowSlice;
	final float numAffected;
	final float numUnaffected;
	private double fishersQuickAndDirty = Double.NaN;
	private double fishersExact = Double.NaN;
	private final Dataset data;
	private final byte predictedStatus;
	private ConfusionMatrix confusionMatrix = null;
	final static edu.northwestern.at.utils.math.matrix.Matrix matrix = MatrixFactory
		.createMatrix(2, 2);

	public Genotype(final Dataset pData,
		final AttributeCombination pAttributeCombination,
		final byte pPredictedStatus, final byte[] pRowSlice,
		final float pNumAffected, final float pNumUnaffected) {
	    data = pData;
	    attributeCombination = pAttributeCombination;
	    predictedStatus = pPredictedStatus;
	    rowSlice = Arrays.copyOf(pRowSlice, pRowSlice.length);
	    numAffected = pNumAffected;
	    numUnaffected = pNumUnaffected;
	}

	@Override
	public int compareTo(final Genotype o) {
	    int compareResult = 0;
	    if (!super.equals(o)) {
		compareResult = Double
			.compare(
				getRequestedSortValue(GenotypeQualityMetric.MAJORITY_RATIO_TIMES_TOTAL),
				o.getRequestedSortValue(GenotypeQualityMetric.MAJORITY_RATIO_TIMES_TOTAL));
		if (compareResult == 0) {
		    // reverse sort since more samples is better
		    compareResult = -(data.getRows() - o.data.getRows());
		    if (compareResult == 0) {
			// reverse sort since more samples is better
			// compareResult = -Float.compare(getTotal(),
			// o.getTotal());
			compareResult = -Float
				.compare(getDelta(), o.getDelta());
			if (compareResult == 0) {
			    compareResult = attributeCombination
				    .compareTo(o.attributeCombination);
			    if (compareResult == 0) {
				compareResult = rowSlice.length
					- o.rowSlice.length;
				if (compareResult == 0) {
				    for (int index = 0; (index < rowSlice.length)
					    && (compareResult == 0); ++index) {
					compareResult = rowSlice[index]
						- o.rowSlice[index];
				    }
				    if (compareResult == 0) {
					// the genotypes are not the same object
					// but describe the same thing so are
					// functionally equal
					// System.out
					// .println(Thread.currentThread().getName()
					// +
					// ": Genotype compareTo hit two apparently equal genotypes:\n"
					// + toString() + o.toString());
					// compareResult = hashCode() -
					// o.hashCode();
				    }
				}
			    }
			}
		    }
		}
	    }
	    return compareResult;
	} // end compareTo

	// do not override equals because not sure how to override hashcode in
	// this case
	// I think it is allowable for results of compareTo == 0 to be the same
	// as equals() but
	// it will make a sorted set act different than a regualr set since
	// sortedSet uses compareTo and Set uses equals
	// @Override
	// public boolean equals(final Object aThat) {
	// boolean result = super.equals(aThat);
	// if (result) {
	// result = compareTo((Genotype) aThat) == 0;
	// }
	// return result;
	// }
	private float getDelta() {
	    return Math.abs(numAffected - numUnaffected);
	}

	private double getFisherExact() {
	    if (Double.isNaN(fishersExact)) {
		Genotype.matrix.set(1, 1, data.getAffectedStatusCount()
			- numAffected);
		Genotype.matrix.set(1, 2, data.getUnaffectedStatusCount()
			- numUnaffected);
		Genotype.matrix.set(2, 1, numUnaffected);
		Genotype.matrix.set(2, 2, numAffected);
		// double vector with three entries. [0] = two-sided Fisher's
		// exact test. [1] = left-tail Fisher's exact test. [2] =
		// right-tail
		// Fisher's exact test.
		final double[] fisherExactTestResults = ContingencyTable
			.fishersExactTest(Genotype.matrix);
		fishersExact = fisherExactTestResults[0];
	    }
	    return fishersExact;
	}

	private double getFisherExactQuickAndDirty() {
	    if (Double.isNaN(fishersQuickAndDirty)) {
		Genotype.matrix.set(1, 1, numAffected);
		Genotype.matrix.set(1, 2, numUnaffected);
		Genotype.matrix.set(2, 1, numUnaffected);
		Genotype.matrix.set(2, 2, numAffected);
		// double vector with three entries. [0] = two-sided Fisher's
		// exact test. [1] = left-tail Fisher's exact test. [2] =
		// right-tail
		// Fisher's exact test.
		final double[] fisherExactTestResults = ContingencyTable
			.fishersExactTest(Genotype.matrix);
		fishersQuickAndDirty = fisherExactTestResults[0];
	    }
	    return fishersQuickAndDirty;
	}

	private double getHeritability() {
	    final double total = (numAffected + numUnaffected);
	    final double average = total / 2.0;
	    final double differenceSquared = (float) Math.pow(numAffected
		    - average, 2);
	    return differenceSquared / total;
	}

	private float getMajorityRatio() {
	    return Math.max(numAffected, numUnaffected) / getTotal();
	}

	private double getRequestedSortValue(
		final GenotypeQualityMetric genotypeQualityMetric) {
	    double qualityMetric = Double.NaN;
	    switch (genotypeQualityMetric) {
	    case FISHERS_EXACT:
		qualityMetric = getFisherExact();
		break;
	    case FISHERS_QUICK_AND_DIRTY:
		qualityMetric = getFisherExactQuickAndDirty();
		break;
	    case HERITABILITY:
		qualityMetric = getHeritability();
		break;
	    case MAJORITY_RATIO:
		qualityMetric = -getMajorityRatio();
		break;
	    case MAJORITY_RATIO_TIMES_TOTAL:
		qualityMetric = -getMajorityRatio() * getTotal();
		break;
	    case MAJORITY_RATIO_TIMES_DELTA:
		qualityMetric = -getMajorityRatio() * getDelta();
		break;
	    case DELTA:
		qualityMetric = -getDelta();
		break;
	    default:
		throw new RuntimeException("Unhandled GenotypeQualityMetric: "
			+ genotypeQualityMetric);
	    }
	    return qualityMetric;
	}

	private float getTotal() {
	    return numAffected + numUnaffected;
	}

	public void predict(final byte status, final float rowWeight) {
	    if (confusionMatrix == null) {
		confusionMatrix = new ConfusionMatrix(data.getLevels().get(
			data.getCols() - 1), data.getAffectedStatus());
	    }
	    confusionMatrix.add(status, predictedStatus, rowWeight);
	}

	public void resetConfusionMatrix() {
	    confusionMatrix = null;
	}

	@Override
	public String toString() {
	    final StringBuilder sb = new StringBuilder();
	    sb.append("Fisher=" + Double.toString(fishersQuickAndDirty) + ' ');
	    for (int comboIndex = 0; comboIndex < rowSlice.length; ++comboIndex) {
		final int attributeIndex = attributeCombination
			.getAttributeIndices()[comboIndex];
		if (comboIndex > 0) {
		    sb.append(',');
		}
		final int levelIndex = rowSlice[comboIndex];
		sb.append(data.getLabels().get(attributeIndex) + "=");
		sb.append(data.getLevels().get(attributeIndex).get(levelIndex));
	    }
	    sb.append(" majorityRatio="
		    + Main.decimalUpToFourPrecision.format(getMajorityRatio()));
	    sb.append(" delta="
		    + Main.decimalUpToFourPrecision.format(getDelta()));
	    sb.append(" numAffected="
		    + Main.decimalUpToFourPrecision.format(numAffected));
	    sb.append(" numUnaffected="
		    + Main.decimalUpToFourPrecision.format(numUnaffected));
	    sb.append(" predicted status: " + predictedStatus);
	    if (confusionMatrix != null) {
		sb.append(" Conf.: " + confusionMatrix.toString());
	    }
	    return "\n" + sb.toString();
	}

	/**
	 * The value used to sort Genotype. Smaller is better since sort used
	 * for ranking is Ascending.
	 * 
	 * @return
	 */
	enum GenotypeQualityMetric {
	    FISHERS_EXACT, FISHERS_QUICK_AND_DIRTY, MAJORITY_RATIO, MAJORITY_RATIO_TIMES_TOTAL, MAJORITY_RATIO_TIMES_DELTA, DELTA, HERITABILITY
	}
    } // end private class

    public static class GenotypeFilterType {
	public static GenotypeFilterType[] genotypeFilterTypes = new GenotypeFilterType[] {
		new GenotypeFilterType(null, Double.NaN),
		new GenotypeFilterType(GenotypeQualityMetric.FISHERS_EXACT,
			0.10),
		new GenotypeFilterType(GenotypeQualityMetric.FISHERS_EXACT,
			0.05),
		new GenotypeFilterType(GenotypeQualityMetric.FISHERS_EXACT,
			0.03),
		new GenotypeFilterType(GenotypeQualityMetric.FISHERS_EXACT,
			0.01),
		new GenotypeFilterType(
			GenotypeQualityMetric.FISHERS_QUICK_AND_DIRTY, 0.10),
		new GenotypeFilterType(
			GenotypeQualityMetric.FISHERS_QUICK_AND_DIRTY, 0.05),
		new GenotypeFilterType(
			GenotypeQualityMetric.FISHERS_QUICK_AND_DIRTY, 0.03),
		new GenotypeFilterType(
			GenotypeQualityMetric.FISHERS_QUICK_AND_DIRTY, 0.01), };
	GenotypeQualityMetric genotypeQualityMetric;
	Double filterLevel;

	public GenotypeFilterType(
		final GenotypeQualityMetric pGenotypeQualityMetric,
		final Double pFilterLevel) {
	    genotypeQualityMetric = pGenotypeQualityMetric;
	    filterLevel = pFilterLevel;
	}

	public boolean passFilter(final Genotype genotype) {
	    boolean result = false;
	    if (genotypeQualityMetric == null) {
		result = true;
	    } else {
		switch (genotypeQualityMetric) {
		case FISHERS_EXACT:
		    result = genotype.getFisherExact() <= filterLevel;
		    break;
		case FISHERS_QUICK_AND_DIRTY:
		    result = genotype.getFisherExactQuickAndDirty() <= filterLevel;
		    break;
		case DELTA:
		case MAJORITY_RATIO:
		case MAJORITY_RATIO_TIMES_DELTA:
		case MAJORITY_RATIO_TIMES_TOTAL:
		default:
		    throw new RuntimeException(
			    "GenotypeQualityMetric type not handled for passFilter: "
				    + genotypeQualityMetric);
		}
	    }
	    return result;
	}

	@Override
	public String toString() {
	    final StringBuilder sb = new StringBuilder();
	    if (genotypeQualityMetric == null) {
		sb.append("NONE");
	    } else {
		sb.append(genotypeQualityMetric);
		sb.append("<=");
		sb.append(filterLevel);
	    }
	    return sb.toString();
	}
    } // end static class GenotypeFilterType

    enum MdrByGenotypeVotingMethod {
	FIRST_MATCH_PREDICTS, SUM_OF_ALL_MATCHES, WEIGHTED_SUM_FISHER_FOR_ALL_MATCHES, WEIGHTED_SUM_OF_ACCURACY_FOR_ALL_MATCHES, WEIGHTED_SUM_OF_MAJORITY_RATIO_FOR_ALL_MATCHES, FIRST_MATCH_PREDICTS_WEIGHT_INVERSE_FISHERS, FIRST_MATCH_PREDICTS_WEIGHT_ACCURACY, FIRST_MATCH_PREDICTS_WEIGHT_MAJORITY_RATIO
    }

    public static class MutableFloat {
	float myFloat;

	public MutableFloat(final float initialValue) {
	    myFloat = initialValue;
	}

	public void add(final float deltaValue) {
	    myFloat += deltaValue;
	}

	@Override
	public String toString() {
	    return Float.toString(myFloat);
	}
    }

    /**
     * We want to be able to reproduce any permutation result. To do this we
     * need to permute the data to the same state it was in when it was
     * analyzed.
     */
    public class PermutationSupport {
	public static final int PERMUTATION_DEFAULT_START_INDEX = 0 /* permutationStartIndex */;
	private final RowData[] affectedRows;
	private final RowData[] unaffectedRows;
	private final boolean useExplicitTestOfInteraction;
	private final Random randomNumberGenerator;

	/**
	 * 
	 * @param permutationRandomSeed
	 * @param useExplicitTestOfInteraction
	 * @param permutationStartIndex
	 *            This is used to make distributed permutation across
	 *            machines give same answer as on one machine. When I
	 *            permute 1000 times ideally it would be nice to get the
	 *            identical answer regardless of whether I did it on one
	 *            machine or 1000 machines. For the 1000 machine case,
	 *            passing this value to each instance running a permutation
	 *            will make it so that the this parameter is used to permute
	 *            the dataset as many times as needed to put it into the
	 *            same condition as if it were being run on a single
	 *            machine.
	 */
	public PermutationSupport(final long permutationRandomSeed,
		final boolean useExplicitTestOfInteraction) {
	    this(permutationRandomSeed, useExplicitTestOfInteraction,
		    PermutationSupport.PERMUTATION_DEFAULT_START_INDEX);
	}

	public PermutationSupport(final long permutationRandomSeed,
		final boolean useExplicitTestOfInteraction,
		final int permutationStartIndex) {
	    this.useExplicitTestOfInteraction = useExplicitTestOfInteraction;
	    if (useExplicitTestOfInteraction) {
		if (matchedPairsOrTriplets) {
		    throw new RuntimeException(
			    "Permutations not implemented for matched data and useExplicitTestOfInteraction. Not sure if it makes sense.");
		}
		final byte[] dichotomousEndpoints = getDichotomousEndpoints();
		final TreeMap<Byte, List<Integer>> instByClass = Dataset
			.mapRowIndicesByClass(dichotomousEndpoints);
		final List<Integer> affectedRowIndices;
		final List<Integer> unaffectedRowIndices;
		if (hasContinuousEndpoints()) {
		    affectedRowIndices = instByClass
			    .get(Dataset.CONTINUOUS_ENDPOINT_AFFECTED_STATUS);
		    unaffectedRowIndices = instByClass
			    .get(Dataset.CONTINUOUS_ENDPOINT_UNAFFECTED_STATUS);
		} else {
		    affectedRowIndices = instByClass.get(affectedStatus);
		    unaffectedRowIndices = instByClass.get(unaffectedStatus);
		}
		if ((affectedRowIndices.size() + unaffectedRowIndices.size()) != rows) {
		    throw new RuntimeException(
			    "PermutationSupport constructor with useExplicitTestOfInteraction did not get expected total of affected and unaffected rows! "
				    + " # affected("
				    + affectedRowIndices.size()
				    + ") + # unaffected("
				    + unaffectedRowIndices.size()
				    + ") != # rows(" + rows + ")");
		}
		affectedRows = new RowData[affectedRowIndices.size()];
		unaffectedRows = new RowData[unaffectedRowIndices.size()];
		int affectedRowsAdded = 0;
		int unaffectedRowsAdded = 0;
		for (final Integer rowIndex : affectedRowIndices) {
		    affectedRows[affectedRowsAdded++] = rowData[rowIndex];
		}
		for (final Integer rowIndex : unaffectedRowIndices) {
		    unaffectedRows[unaffectedRowsAdded++] = rowData[rowIndex];
		}
	    } else {
		// not used if not explicit test of interaction
		affectedRows = unaffectedRows = null;
	    }
	    randomNumberGenerator = new Random(permutationRandomSeed);
	    assert permutationStartIndex >= PermutationSupport.PERMUTATION_DEFAULT_START_INDEX;
	    final int numberToAdvance = permutationStartIndex;
	    int advancementCtr;
	    for (advancementCtr = 0; advancementCtr < numberToAdvance; ++advancementCtr) {
		permuteData();
	    }
	    assert advancementCtr == numberToAdvance;
	} // end constructor

	public void permuteData() {
	    if (matchedPairsOrTriplets) {
		permutePairedOrTripletData(randomNumberGenerator);
	    } else {
		permuteUnmatchedData(randomNumberGenerator);
	    }
	    setDatasetHasBeenPermuted();
	} // end permuteStatuses

	/*
	 * Code derived from Sun Collections.shuffle implementation This
	 * implementation traverses the list backwards, from the last element up
	 * to the second, repeatedly swapping a randomly selected element into
	 * the "current position". Elements are randomly selected from the
	 * portion of the list that runs from the first element to the current
	 * position, inclusive.<p>
	 */
	private void permuteDataColumn(final Random rnd,
		final RowData[] rowData, final int columnIndexToBePermuted) {
	    for (int i = rowData.length; i > 1; i--) {
		final int indexToSwap = rnd.nextInt(i);
		final RowData row1 = rowData[indexToSwap];
		final RowData row2 = rowData[i - 1];
		row1.swapColumn(row2, columnIndexToBePermuted);
	    } // end for
	} // end permuteDataColumn

	/**
	 * Shuffle the class values of all rows based on the original value.
	 * 
	 * @param rnd
	 *            Random number generator to use for the shuffle
	 */
	private void permutePairedOrTripletData(final Random rnd) {
	    int patternSize;
	    switch (rowRepeatPattern) {
	    case PAIRED:
		patternSize = 2;
		break;
	    case ONE_ONE_ONE:
	    case ONE_TWO:
	    case TWO_ONE:
		patternSize = 3;
		break;
	    default:
		throw new RuntimeException(
			"Dataset.pairedPartition() unhandled rowRepeatPattern: "
				+ rowRepeatPattern);
	    }
	    for (int rowIndex = 0; rowIndex < (rows - (patternSize - 1)); rowIndex += patternSize) {
		/*
		 * Code derived from Sun Collections.shuffle implementation This
		 * implementation traverses the list backwards, from the last
		 * element up to the second, repeatedly swapping a randomly
		 * selected element into the "current position". Elements are
		 * randomly selected from the portion of the list that runs from
		 * the first element to the current position, inclusive.<p>
		 */
		for (int patternPosition = patternSize; patternPosition > 1; patternPosition--) {
		    final int swapIndex1 = rowIndex
			    + rnd.nextInt(patternPosition); // paired = 0 or 1,
							    // triplets = 0, 1
							    // or 2
		    final int swapIndex2 = rowIndex + (patternPosition - 1); // paired
									     // =
									     // 1,
									     // triplets
									     // =
									     // 1
									     // or
									     // 2
		    if (swapIndex1 != swapIndex2) {
			rowData[swapIndex1].swapEndpoints(rowData[swapIndex2]);
		    }
		} // end for
	    } // end row loop
	} // end permutePairedData()

	private void permuteUnmatchedData(final Random rnd) {
	    final int statusColIndex = cols - 1;
	    if (useExplicitTestOfInteraction) {
		// rather than permuting statuses across all data
		// permute the attributes within each class
		// This will preserve main affects while breaking epistatic
		// affects.
		for (int colIndex = 0; colIndex < statusColIndex; ++colIndex) {
		    permuteDataColumn(rnd, affectedRows, colIndex);
		    permuteDataColumn(rnd, unaffectedRows, colIndex);
		} // end columns
	    } else {
		permuteDataColumn(rnd, rowData, statusColIndex);
	    }
	} // end permuteStatuses

    } // end local class

    enum ROW_REPEAT_PATTERN {
	// TWO_ONE is like 001 or 110
	// ONE_TWO is like 011 or 100
	// ONE_ONE_ONE is like 010 or 101
	NONE, PAIRED, TWO_ONE, ONE_TWO, ONE_ONE_ONE;
    }

    public static class RowData {
	byte[] rowLevelIndices;
	Float rowWeight;
	Double continuousEndpoint;

	public RowData(final byte[] pRowLevelIndices, final Float pRowWeight,
		final Double pContinuousEndpoint) {
	    rowLevelIndices = pRowLevelIndices;
	    rowWeight = pRowWeight;
	    continuousEndpoint = pContinuousEndpoint;
	}

	/**
	 * get the original data value at the column -- not the byte index but
	 * the one from the data file
	 * 
	 * @param columnIndex
	 * @param levels
	 * @return
	 */
	public String getDatum(final int columnIndex,
		final List<List<String>> levels) {
	    String returnVal;
	    if ((columnIndex == (rowLevelIndices.length - 1))
		    && (continuousEndpoint != null)) {
		returnVal = continuousEndpoint.toString();
	    } else {
		returnVal = levels.get(columnIndex).get(
			rowLevelIndices[columnIndex]);
	    }
	    return returnVal;
	}

	public double getEndpoint() {
	    return (continuousEndpoint != null) ? continuousEndpoint
		    : rowLevelIndices[rowLevelIndices.length - 1];
	}

	public float getRowWeight() {
	    float rowWeightToReturn;
	    if (rowWeight == null) {
		rowWeightToReturn = 1.0f;
	    } else {
		rowWeightToReturn = rowWeight;
	    }
	    return rowWeightToReturn;
	}

	public byte getStatus() {
	    return rowLevelIndices[rowLevelIndices.length - 1];
	}

	public String getStatusColumnValue(final List<List<String>> levels) {
	    return getDatum(rowLevelIndices.length - 1, levels);
	}

	public void insertColumn(final int columnIndex, final byte value) {
	    if ((columnIndex < 0) || (columnIndex > (rowLevelIndices.length))) {
		throw new RuntimeException(
			"RowData.insertColumn("
				+ columnIndex
				+ ") called with illegal column index. Num attribute columns ="
				+ (rowLevelIndices.length - 1));
	    }
	    final byte[] newRowLevelIndices = new byte[rowLevelIndices.length + 1];
	    // copy section of array before columnIndex
	    System.arraycopy(rowLevelIndices, 0, newRowLevelIndices, 0,
		    columnIndex);
	    // store passed in value into new location
	    newRowLevelIndices[columnIndex] = value;
	    // copy section of array after columnIndex
	    System.arraycopy(rowLevelIndices, columnIndex, newRowLevelIndices,
		    columnIndex + 1, (newRowLevelIndices.length - 1)
			    - columnIndex);
	    rowLevelIndices = newRowLevelIndices;
	}

	public RowData makeFilteredCopy(final int[] attributes) {
	    final byte[] filteredRowLevelIndices = new byte[attributes.length + 1];
	    for (int c = 0; c < attributes.length; ++c) {
		filteredRowLevelIndices[c] = rowLevelIndices[attributes[c]];
	    }
	    filteredRowLevelIndices[attributes.length] = getStatus();
	    final RowData filteredCopy = new RowData(filteredRowLevelIndices,
		    rowWeight, continuousEndpoint);
	    return filteredCopy;
	}

	public void removeColumn(final int columnIndex) {
	    if ((columnIndex < 0)
		    || (columnIndex > (rowLevelIndices.length - 1))) {
		throw new RuntimeException(
			"RowData.removeColumn("
				+ columnIndex
				+ ") called with illegal column index. Num attribute columns ="
				+ (rowLevelIndices.length - 1));
	    }
	    final byte[] newRowLevelIndices = new byte[rowLevelIndices.length - 1];
	    // copy section of array before columnIndex
	    System.arraycopy(rowLevelIndices, 0, newRowLevelIndices, 0,
		    columnIndex);
	    // copy section of array after columnIndex
	    System.arraycopy(rowLevelIndices, columnIndex + 1,
		    newRowLevelIndices, columnIndex, newRowLevelIndices.length
			    - columnIndex);
	    rowLevelIndices = newRowLevelIndices;
	}

	public void setStatus(final byte status) {
	    rowLevelIndices[rowLevelIndices.length - 1] = status;
	}

	public void swapColumn(final RowData row2,
		final int columnIndexToBePermuted) {
	    final byte cellValue = rowLevelIndices[columnIndexToBePermuted];
	    rowLevelIndices[columnIndexToBePermuted] = row2.rowLevelIndices[columnIndexToBePermuted];
	    row2.rowLevelIndices[columnIndexToBePermuted] = cellValue;
	    // if swapping status column and have continuous endpoint swap that
	    if ((continuousEndpoint != null)
		    && (columnIndexToBePermuted == (rowLevelIndices.length - 1))) {
		final Double swapContinuousEndpoint = continuousEndpoint;
		continuousEndpoint = row2.continuousEndpoint;
		row2.continuousEndpoint = swapContinuousEndpoint;
	    }
	} // end swapColumn

	public void swapEndpoints(final RowData row2) {
	    swapColumn(row2, rowLevelIndices.length - 1);
	}

	@Override
	public String toString() {
	    return (((rowWeight != null) ? ("rowWeight: " + rowWeight) : "")
		    + " endpoint: " + getEndpoint()
		    + " rowLevelIndices.length=" + rowLevelIndices.length);
	}
    } // end static RowData

} // end Dataset class
