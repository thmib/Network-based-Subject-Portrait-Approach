package org.epistasis.mdr.analysis;

import org.epistasis.exceptions.IncompleteBuildException;
import org.epistasis.mdr.AmbiguousCellStatus;
import org.epistasis.mdr.AnalysisFileManager;
import org.epistasis.mdr.enums.FitnessCriteriaOrder;
import org.epistasis.mdr.newengine.Dataset;

public class FixedRandomAnalysisThread extends RandomAnalysisThread {

    private final long maxEval;

    private FixedRandomAnalysisThread(final Dataset data,
	    final FitnessCriteriaOrder topModelsFitnessCriteriaOrder,
	    final FitnessCriteriaOrder bestModelFitnessCriteriaOrder,
	    final int numCrossValidationIntervals,
	    final AmbiguousCellStatus tiePriorityList, final long seed,
	    final Runnable onEndModel, final Runnable onEndLevel,
	    final Runnable onEndAnalysis, final boolean parallel,
	    final int topModelsLandscapeSize,
	    final boolean computeAllModelsLandscape, final int minAttr,
	    final int maxAttr, final long maxEval) {
	super(data, topModelsFitnessCriteriaOrder,
		bestModelFitnessCriteriaOrder, numCrossValidationIntervals,
		tiePriorityList, seed, onEndModel, onEndLevel, onEndAnalysis,
		parallel, topModelsLandscapeSize, computeAllModelsLandscape,
		minAttr, maxAttr);
	this.maxEval = maxEval;
	for (int nAttr = minAttr; nAttr <= maxAttr; ++nAttr) {
	    addProducer(new RandomProducer(new FixedRandomCombinationGenerator(
		    data.getLabels(), nAttr, seed, maxEval), getIntervals()));
	}
    }

    @Override
    public void saveAnalysis(final AnalysisFileManager analysisFileManager) {
	analysisFileManager.putCfg(AnalysisFileManager.cfgWrapper,
		AnalysisFileManager.cfgValRandom);
	analysisFileManager.putCfg(AnalysisFileManager.cfgEvaluations,
		String.valueOf(maxEval));
    }

    public static class FixedRandomAnalysisThreadBuilder extends
	    RandomAnalysisThreadBuilder<FixedRandomAnalysisThread> {

	private long maxEval = -1;

	public FixedRandomAnalysisThreadBuilder(final Dataset data,
		final int numCrossValidationIntervals, final long seed) {
	    super(data, numCrossValidationIntervals, seed);
	}

	@Override
	public FixedRandomAnalysisThread build() {
	    if ((minAttr == -1) || (maxAttr == -1) || (maxEval == -1)
		    || (maxAttr == -1)) {
		throw new IncompleteBuildException(
			"Random (fixed) field not set.");
	    }
	    return new FixedRandomAnalysisThread(data,
		    topModelsFitnessCriteriaOrder,
		    bestModelFitnessCriteriaOrder, numCrossValidationIntervals,
		    tiePriorityList, seed, onEndModel, onEndLevel,
		    onEndAnalysis, parallel, topModelsLandscapeSize,
		    computeAllModelsLandscape, minAttr, maxAttr, maxEval);
	}

	@Override
	public FixedRandomAnalysisThreadBuilder setMaxAttr(final int maxAttr) {
	    this.maxAttr = maxAttr;
	    return this;
	}

	public FixedRandomAnalysisThreadBuilder setMaxEval(final long maxEval) {
	    this.maxEval = maxEval;
	    return this;
	}
    }
}
