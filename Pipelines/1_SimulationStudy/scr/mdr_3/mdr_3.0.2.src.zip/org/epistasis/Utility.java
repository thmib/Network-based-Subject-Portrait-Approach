package org.epistasis;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.math.BigInteger;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.NumberFormat;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;

import javax.swing.SwingUtilities;

/**
 * Several utility functions for epistasis.org programs.
 */
public final class Utility {
    public static final String NEWLINE = System.getProperty("line.separator");
    private static BigInteger[] preComputedFactorials;
    static {
	Utility.preComputedFactorials = new BigInteger[500];
	Utility.preComputedFactorials[0] = BigInteger.ONE;
	Utility.fillInPrecomputedFactorials(1);
    }

    public static String chrdup(final char c, final int count) {
	if (count < 0) {
	    return "";
	}
	final char[] a = new char[count];
	Arrays.fill(a, c);
	return String.valueOf(a);
    }

    /**
     * Compute the number of combinations possible when choosing r from n.
     * 
     * @param n
     *            The total number of items
     * @param r
     *            The number of items to choose
     * @return Number of possible combinations
     */
    public static BigInteger combinations(final long n, long r) {
	BigInteger numberOfCombinations;
	if (r == 1) {
	    numberOfCombinations = BigInteger.valueOf(n);
	} else {
	    if ((r * 2) > n) {
		r = n - r;
	    }
	    numberOfCombinations = BigInteger.ONE;
	    BigInteger nr = BigInteger.valueOf(n - r);
	    for (long i = n; i > r; i--) {
		numberOfCombinations = numberOfCombinations.multiply(BigInteger
			.valueOf(i));
		while ((nr.compareTo(BigInteger.ONE) > 0)
			&& numberOfCombinations.mod(nr).equals(BigInteger.ZERO)) {
		    numberOfCombinations = numberOfCombinations.divide(nr);
		    nr = nr.subtract(BigInteger.ONE);
		}
	    }
	    while (nr.compareTo(BigInteger.ONE) > 0) {
		numberOfCombinations = numberOfCombinations.divide(nr);
		nr = nr.subtract(BigInteger.ONE);
	    }
	}
	return numberOfCombinations;
    }

    public static int compareFloatsHandlingNan(final float floatOne,
	    final float floatTwo) {
	int compareResult;
	final boolean floatOneIsNan = Float.isNaN(floatOne);
	final boolean floatTwoIsNan = Float.isNaN(floatTwo);
	if (floatOneIsNan) {
	    if (floatTwoIsNan) {
		compareResult = 0; // if both Nan then equal
	    } else {
		// other is bigger than Nan
		compareResult = -1;
	    }
	} else if (floatTwoIsNan) {
	    compareResult = 1;
	} else {
	    compareResult = Float.compare(floatOne, floatTwo);
	}
	return compareResult;
    }

    /**
     * Used to make an Ascending sort based on lower indices. if indexes left
     * most index < equivalent index in indexes2 then will return with a
     * negative number
     * 
     * @param indexes
     * @param indexes2
     * @return
     */
    public static int compareIndexArrays(final int indexes[],
	    final int indexes2[]) {
	int compareResult = 0;
	// an object is always equal to itself
	if (indexes != indexes2) {
	    compareResult = indexes.length - indexes2.length;
	    if (compareResult == 0) {
		for (int comboIndex = 0; (comboIndex < indexes.length)
			&& (compareResult == 0); ++comboIndex) {
		    final int index1 = indexes[comboIndex];
		    final int index2 = indexes2[comboIndex];
		    if (comboIndex > 0) {
			// enforce rule that attribute indices must be in
			// ascending
			// order
			assert indexes[comboIndex - 1] < index1;
			assert indexes2[comboIndex - 1] < index2;
		    }
		    compareResult = index1 - index2;
		} // end for comboIndex
	    } // end if compareResult == 0
	} // end if not the same object

	return compareResult;
    }

    public static <E extends Comparable<E>> int compareRanges(
	    final Iterator<E> i, final Iterator<E> j) {
	while (i.hasNext() && j.hasNext()) {
	    final E a = i.next();
	    final E b = j.next();
	    final int ret = a.compareTo(b);
	    if (ret != 0) {
		return ret;
	    }
	}
	if (i.hasNext()) {
	    return 1;
	}
	if (j.hasNext()) {
	    return -1;
	}
	return 0;
    }

    public static float computeChiSquared(final double[][] table) {
	final int rows = table.length;
	final int cols = rows > 0 ? table[0].length : 0;
	final double[] rtotal = new double[rows];
	final double[] ctotal = new double[cols];
	double total = 0;
	for (int i = 0; i < rows; i++) {
	    for (int j = 0; j < cols; j++) {
		rtotal[i] += table[i][j];
		ctotal[j] += table[i][j];
	    }
	    total += rtotal[i];
	}
	float chisq = 0;
	for (int i = 0; i < rows; ++i) {
	    for (int j = 0; j < cols; ++j) {
		final double expected = (ctotal[j] * rtotal[i]) / total;
		final double diff = table[i][j] - expected;
		chisq += (diff * diff) / expected;
	    }
	}
	return chisq;
    }

    public static float computeChiSquared(final float[][] table) {
	final int rows = table.length;
	final int cols = rows > 0 ? table[0].length : 0;
	final double[] rtotal = new double[rows];
	final double[] ctotal = new double[cols];
	double total = 0;
	for (int i = 0; i < rows; i++) {
	    for (int j = 0; j < cols; j++) {
		rtotal[i] += table[i][j];
		ctotal[j] += table[i][j];
	    }
	    total += rtotal[i];
	}
	float chisq = 0;
	for (int i = 0; i < rows; ++i) {
	    for (int j = 0; j < cols; ++j) {
		final double expected = (ctotal[j] * rtotal[i]) / total;
		final double diff = table[i][j] - expected;
		chisq += (diff * diff) / expected;
	    }
	}
	return chisq;
    }

    /**
     * Returns value of kappa statistic if class is nominal. This was adapted
     * from Weka 3.4.4.
     * 
     * @param confusion
     *            A square matrix of floats with actual classes as the row
     *            indices and predicted classes as the column indices.
     * @return the value of the kappa statistic
     */
    public static float computeKappaStatistic(final float[][] confusion) {
	final float[] sumRows = new float[confusion.length];
	final float[] sumColumns = new float[confusion.length];
	float sumOfWeights = 0;
	float kappaStatistic;
	for (int i = 0; i < confusion.length; i++) {
	    for (int j = 0; j < confusion.length; j++) {
		sumRows[i] += confusion[i][j];
		sumColumns[j] += confusion[i][j];
		sumOfWeights += confusion[i][j];
	    }
	}
	float correct = 0, chanceAgreement = 0;
	for (int i = 0; i < confusion.length; i++) {
	    chanceAgreement += (sumRows[i] * sumColumns[i]);
	    correct += confusion[i][i];
	}
	chanceAgreement /= (sumOfWeights * sumOfWeights);
	correct /= sumOfWeights;
	if (chanceAgreement < 1) {
	    kappaStatistic = (correct - chanceAgreement)
		    / (1 - chanceAgreement);
	} else {
	    kappaStatistic = 1;
	}
	return kappaStatistic;
    }

    /**
     * Capitalizes all words in a {@link String}.
     * 
     * @param s
     *            The String to capitalize
     * @return An interned {@link String} where all characters following spaces
     *         and the first character have been replaced by the character with
     *         {@link Character#toUpperCase(char)} called on it.
     */
    public static String ensureCaps(final String s) {
	if (s.length() == 0) {
	    return "";
	}
	final char[] c = s.toCharArray();
	c[0] = Character.toUpperCase(c[0]);
	int idx = 0;
	while (((idx = s.indexOf(' ', idx + 1) + 1) != 0) && (idx < s.length())) {
	    c[idx] = Character.toUpperCase(c[idx]);
	}
	return new String(c).intern();
    }

    /**
     * Compute the factorial of a long integer.
     * 
     * @param n
     *            Number of which to compute the factorial
     * @return Factorial of the parameter
     */
    public static BigInteger factorial(final BigInteger n) {
	return Utility.product(BigInteger.valueOf(2), n);
    }

    public static BigInteger factorial(final int i) {
	if (i >= Utility.preComputedFactorials.length) {
	    final int oldLength = Utility.preComputedFactorials.length;
	    final int newLength = Math.max(i, oldLength + 100);
	    final BigInteger[] newPreComputedFactorials = new BigInteger[newLength];
	    System.arraycopy(Utility.preComputedFactorials, 0,
		    newPreComputedFactorials, 0,
		    Utility.preComputedFactorials.length);
	    Utility.preComputedFactorials = newPreComputedFactorials;
	    Utility.fillInPrecomputedFactorials(oldLength);
	}
	return Utility.preComputedFactorials[i];
	// BigInteger factorial = BigInteger.ONE;
	// while (i > 0) {
	// factorial = factorial.multiply(new BigInteger("" + i));
	// i--;
	// }
	// return factorial;
    }

    /**
     * Compute the factorial of a long integer.
     * 
     * @param n
     *            Number of which to compute the factorial
     * @return Factorial of the parameter
     */
    public static long factorial(final long n) {
	return Utility.product(2, n);
    }

    private static void fillInPrecomputedFactorials(final int firstNewValueIndex) {
	BigInteger previousValue = Utility.preComputedFactorials[firstNewValueIndex - 1];
	BigInteger nextValue;
	for (long index = firstNewValueIndex; index < Utility.preComputedFactorials.length; ++index) {
	    nextValue = previousValue.multiply(BigInteger.valueOf(index));
	    Utility.preComputedFactorials[(int) index] = nextValue;
	    previousValue = nextValue;
	}
    }

    /**
     * Returns the stack traces of all current Threads
     */
    public static String getAllStackTraces() {
	try {
	    final Map<Thread, StackTraceElement[]> map = Thread
		    .getAllStackTraces();
	    final List<Map.Entry<Thread, StackTraceElement[]>> sorted = new ArrayList<Map.Entry<Thread, StackTraceElement[]>>(
		    map.entrySet());
	    Collections.sort(sorted,
		    new Comparator<Map.Entry<Thread, StackTraceElement[]>>() {
			@Override
			public int compare(
				final Map.Entry<Thread, StackTraceElement[]> a,
				final Map.Entry<Thread, StackTraceElement[]> b) {
			    return a.getKey().getName()
				    .compareTo(b.getKey().getName());
			}
		    });
	    final StringBuffer buffer = new StringBuffer();
	    for (final Map.Entry<Thread, StackTraceElement[]> entry : sorted) {
		final Thread key = entry.getKey();
		final StackTraceElement[] value = entry.getValue();
		buffer.append(key.getName()).append("\n");
		for (final StackTraceElement element : value) {
		    buffer.append("    ").append(element).append("\n");
		}
		buffer.append("\n");
	    }
	    // Remove the last '\n'
	    if (buffer.length() > 0) {
		buffer.setLength(buffer.length() - 1);
	    }
	    return buffer.toString();
	} catch (final Exception err) {
	    final StringWriter sw = new StringWriter();
	    final PrintWriter pw = new PrintWriter(sw);
	    pw.println("An error occured during getting the StackTraces of all active Threads");
	    err.printStackTrace(pw);
	    pw.flush();
	    return sw.toString();
	}
    } // end getAllStackTraces

    public static String getLocalDirName(final Class<?> classOfInterest) {
	String localDirName;
	// Use that name to get a URL to the directory we are executing in
	final java.net.URL myURL = classOfInterest.getResource(classOfInterest
		.getSimpleName() + ".class"); // Open a URL to the our .class
					      // file
	// Clean up the URL and make a String with absolute pathname
	localDirName = myURL.getPath(); // Strip path to URL object out
	final int jarMarkerIndex = localDirName.lastIndexOf(".jar!/");
	if (jarMarkerIndex != -1) {
	    localDirName = localDirName.substring(0, jarMarkerIndex); // clean
								      // off
	    // everything
	    // from '.jar!/'
	    // on
	} else {
	    // kludge to get correct directory in development
	    final int buildDirIndex = localDirName.lastIndexOf("/build/");
	    if (buildDirIndex != -1) {
		localDirName = localDirName.substring(0, buildDirIndex
			+ "/build/".length());
	    }
	}
	if (localDirName.startsWith("file:")) {
	    localDirName = localDirName.substring(5); // knock off 'file:'
	}
	localDirName = localDirName.replaceAll("%20", " "); // change %20 chars
							    // to
	// spaces
	localDirName = localDirName.substring(0, localDirName.lastIndexOf("/")); // clean
	// off
	// the
	// filename
	return localDirName;
    }

    public static String getLocalFileOrURL(final String filePathOrURL)
	    throws IOException, MalformedURLException {
	String localFilename;
	if (filePathOrURL.contains("//")) {
	    final File localCopyOfFile = File.createTempFile(
		    "MDR_remote_file_copy", ".tmp");
	    localCopyOfFile.deleteOnExit();
	    String line;
	    final String lineSeparator = System.getProperty("line.separator");
	    final BufferedReader r = new BufferedReader(new InputStreamReader(
		    new URL(filePathOrURL).openStream()));
	    final BufferedWriter w = new BufferedWriter(new FileWriter(
		    localCopyOfFile));
	    while ((line = r.readLine()) != null) {
		w.write(line);
		w.write(lineSeparator);
	    } // end while lines
	    w.close();
	    localFilename = localCopyOfFile.getCanonicalPath();
	} // if a URL
	else {
	    localFilename = filePathOrURL;
	}
	return localFilename;
    }

    public static <T> T getResultFromSwing(final Callable<T> callable)
	    throws Exception {
	T resultObject = null;
	if (SwingUtilities.isEventDispatchThread()) {
	    resultObject = callable.call();
	} else {
	    final FutureTask<T> future = new FutureTask<T>(callable);
	    SwingUtilities.invokeLater(future);
	    resultObject = future.get();
	}
	return resultObject;
    }

    public static <E> String join(final Iterable<? extends E> iterable,
	    final CharSequence delim) {
	final StringBuffer b = new StringBuffer();
	boolean skip = true;
	for (final E e : iterable) {
	    if (skip) {
		skip = false;
	    } else {
		b.append(delim);
	    }
	    b.append(e);
	}
	return b.toString();
    }

    public static String join(final List<? extends Number> numberList,
	    final char delimiter, final NumberFormat numberFormat) {
	final StringBuilder sb = new StringBuilder();
	boolean skip = true;
	for (final Number number : numberList) {
	    if (skip) {
		skip = false;
	    } else {
		sb.append(delimiter);
	    }
	    sb.append(numberFormat.format(number));
	}
	return sb.toString();
    }

    /**
     * join items in a collection into a delimited String
     * 
     * @param delimiter
     *            delimiter
     * @param strings
     *            list of Strings to join
     * @return collection items in a single string, joined on d
     */
    public static String join(final Object[] strings, final char delimiter) {
	if ((strings == null) || (strings.length == 0)) {
	    return "";
	}
	final StringBuilder sb = new StringBuilder();
	sb.append(strings[0].toString());
	for (int i = 1; i < strings.length; i++) {
	    sb.append(delimiter + strings[i].toString());
	}
	return sb.toString();
    }

    public static Properties loadPropertiesFile(final String propertyFilePath)
	    throws IOException {
	final Properties props = new Properties();
	final String localDirName = Utility.getLocalDirName(Utility.class);
	final String fullPathToFile = localDirName + '/' + propertyFilePath;
	InputStream propFileStream = null;
	try {
	    propFileStream = new FileInputStream(fullPathToFile);
	} catch (final FileNotFoundException ex) {
	    propFileStream = Utility.class.getClassLoader()
		    .getResourceAsStream(propertyFilePath);
	} finally {
	    if (propFileStream != null) {
		props.load(propFileStream);
		propFileStream.close();
	    }
	} // end finally
	if (props.isEmpty()) {
	    System.err.println("Utility.loadPropertiesFile(" + propertyFilePath
		    + ") did not load any properties.");
	}
	propFileStream.close(); // not needed but get rid of erroneous Eclipse
				// warning
	return props;
    } // end loadPropertiesFile

    public static void logException(final Exception ex) {
	System.err.println("Caught exception: " + ex.getMessage() + "\n"
		+ Utility.stackTraceToString(ex.getStackTrace(), 0));
    }

    public static <E extends Comparable<E>> List<E> lowestN(final List<E> list,
	    final int n) {
	return Utility.lowestN(list, n, null);
    }

    public static <E extends Comparable<E>> List<E> lowestN(final List<E> list,
	    final int n, final Comparator<E> c) {
	if (list.size() <= n) {
	    return new ArrayList<E>(list);
	}
	final List<E> lowest = new ArrayList<E>(n);
	int maxindex = 0;
	for (final E o : list) {
	    if (lowest.size() < n) {
		lowest.add(o);
		if (lowest.size() == n) {
		    maxindex = Utility.maxIndex(lowest, c);
		} else {
		    maxindex++;
		}
		continue;
	    }
	    final E max = lowest.get(maxindex);
	    if (c == null) {
		if (o.compareTo(max) < 0) {
		    lowest.set(maxindex, o);
		    maxindex = Utility.maxIndex(lowest, c);
		}
	    } else {
		if (c.compare(o, max) < 0) {
		    // indices[maxindex] = i;
		    lowest.set(maxindex, o);
		    maxindex = Utility.maxIndex(lowest, c);
		}
	    }
	}
	return lowest;
    }

    public static <E extends Comparable<E>> int maxIndex(final List<E> list) {
	return Utility.maxIndex(list, null);
    }

    public static <E extends Comparable<E>> int maxIndex(final List<E> list,
	    final Comparator<E> c) {
	int maxIndex = -1;
	E maxObj = null;
	int i = 0;
	for (final E o : list) {
	    if (maxObj == null) {
		maxIndex = i;
		maxObj = o;
		i++;
		continue;
	    }
	    if (c == null) {
		if (o.compareTo(maxObj) > 0) {
		    maxIndex = i;
		    maxObj = o;
		}
	    } else {
		if (c.compare(o, maxObj) > 0) {
		    maxIndex = i;
		    maxObj = o;
		}
	    }
	    ++i;
	}
	return maxIndex;
    }

    public static int[] mergeTwoSortedArrays(final int[] a, final int[] b) {

	final int[] answer = new int[a.length + b.length];
	int i = 0, j = 0, k = 0;
	while ((i < a.length) && (j < b.length)) {
	    if (a[i] < b[j]) {
		answer[k++] = a[i++];
	    } else {
		answer[k++] = b[j++];
	    }
	}

	while (i < a.length) {
	    answer[k++] = a[i++];
	}

	while (j < b.length) {
	    answer[k++] = b[j++];
	}
	return answer;
    }

    public static String padLeft(final String s, final int len) {
	final StringBuffer b = new StringBuffer(len);
	b.append(Utility.chrdup(' ', len - s.length()));
	b.append(s);
	return b.toString();
    }

    public static String padRight(final String s, final int len) {
	final StringBuffer b = new StringBuffer(len);
	b.append(s);
	b.append(Utility.chrdup(' ', len - s.length()));
	return b.toString();
    }

    public static double pchisq(final double chisq, final int df) {
	if (chisq == 0) {
	    return 1;
	}
	return 1 - APStat.gammad(chisq / 2.0, df / 2.0);
    }

    /**
     * Compute the power mean of an array of doubles for a given power (p). Many
     * means are special cases of the power mean: Harmonic Mean => p = -1,
     * Geometric Mean => p = 0, Arithmetic Mean => p = 1, Root-Mean-Square => p
     * = 2.
     * 
     * @param p
     *            Power of the mean
     * @param x
     *            Array of doubles for which to compute the power mean
     * @return Power mean of input values
     */
    public static double powerMean(final double p, final double[] x) {
	double sum = 0;
	for (final double element : x) {
	    sum += Math.pow(element, p);
	}
	return Math.pow(sum / x.length, 1.0 / p);
    }

    /**
     * Compute the product of all integers in the range [min,max].
     * 
     * @param min
     *            First number to include in product
     * @param max
     *            Last number to include in product
     * @return Product of all integers in range.
     */
    public static BigInteger product(final BigInteger min, final BigInteger max) {
	BigInteger ret = BigInteger.ONE;
	for (BigInteger i = min; i.compareTo(max) <= 0; i = i
		.add(BigInteger.ONE)) {
	    ret = ret.multiply(i);
	}
	return ret;
    }

    /**
     * Compute the product of all integers in the range [min,max].
     * 
     * @param min
     *            First number to include in product
     * @param max
     *            Last number to include in product
     * @return Product of all integers in range.
     */
    public static long product(final long min, final long max) {
	long ret = 1;
	for (long i = min; i <= max; ++i) {
	    ret *= i;
	}
	return ret;
    }

    public static String propertiesToString(final Properties properties) {
	final StringWriter sw = new StringWriter();
	final PrintWriter pw = new PrintWriter(sw);
	properties.list(pw);
	return sw.toString();
    }

    /**
     * @param end
     *            exclusive
     * @return list of integers from 0 to end
     */
    public static List<Integer> range(final int end) {
	return new AbstractList<Integer>() {
	    @Override
	    public Integer get(final int index) {
		return index;
	    }

	    @Override
	    public int size() {
		return end;
	    }
	};
    }

    /**
     * @param begin
     *            inclusive
     * @param end
     *            exclusive
     * @return list of integers from begin to end
     */
    public static List<Integer> range(final int begin, final int end) {
	return new AbstractList<Integer>() {
	    @Override
	    public Integer get(final int index) {
		return begin + index;
	    }

	    @Override
	    public int size() {
		return end - begin;
	    }
	};
    }

    /**
     * Reallocates an array with a new size, and copies the contents of the old
     * array to the new array.
     * 
     * @param oldArray
     *            the old array, to be reallocated.
     * @param newSize
     *            the new array size.
     * @return A new array with the same contents.
     */
    public static long[] resizeArray(final long[] oldArray, final int newSize) {
	final int oldSize = oldArray.length;
	final long[] newArray = new long[newSize];
	final int preserveLength = Math.min(oldSize, newSize);
	if (preserveLength > 0) {
	    System.arraycopy(oldArray, 0, newArray, 0, preserveLength);
	}
	return newArray;
    }

    public static String stackTraceToString() {
	return Utility.stackTraceToString(Thread.currentThread()
		.getStackTrace(), 2);
    }

    public static String stackTraceToString(
	    final StackTraceElement[] stackTrace, int numberOfFramesToSkip) {
	final StringBuilder sb = new StringBuilder();
	for (final StackTraceElement stackTraceElement : stackTrace) {
	    if (numberOfFramesToSkip > 0) {
		--numberOfFramesToSkip;
	    } else {
		if (sb.length() > 0) {
		    sb.append("\n");
		}
		sb.append(stackTraceElement);
	    }
	}
	return sb.toString();
    }

    /**
     * if all strings can be parsed as integers then an integer array is return
     * else null
     * 
     * @param possibleIntegersArray
     * @return
     */
    public static int[] stringArrayToIntegerArray(
	    final String[] possibleIntegersArray) {
	int[] integerArray = new int[possibleIntegersArray.length];
	for (int index = 0; index < integerArray.length; ++index) {
	    try {
		integerArray[index] = Integer
			.parseInt(possibleIntegersArray[index]);
	    } catch (final NumberFormatException ex) {
		integerArray = null;
		break;
	    }
	}
	return integerArray;
    }

    public static String throwableStackTraceToString(final Throwable aThrowable)
	    throws IOException {
	final ByteArrayOutputStream baos = new ByteArrayOutputStream();
	final PrintWriter printWriter = new PrintWriter(baos);
	aThrowable.printStackTrace(printWriter);
	baos.flush();
	final String resultString = baos.toString();
	baos.close();
	return resultString;
    }

    /**
     * * found in jscience.org experimental package org.jscience.util
     * Antelmann.com Java Framework by Holger Antelmann Copyright (c) 2005
     * Holger Antelmann <info@antelmann.com> For details, see also
     * http://www.antelmann.com/developer/
     * --------------------------------------------------------- takes
     * milliseconds and converts them into a short String. The format is
     * 
     * <pre>
     * h:mm:ss
     * </pre>
     * 
     * .
     */
    public static String timeAsStringShort(final long milliSecs) {
	final int hours = Math.abs((int) milliSecs / 3600000);
	final int minutes = Math.abs((int) (milliSecs % 3600000) / 60000);
	final int seconds = Math.abs((int) (milliSecs % 60000) / 1000);
	String s = hours + ":";
	s += ((minutes < 10) ? ("0" + minutes) : String.valueOf(minutes));
	s += ":";
	s += ((seconds < 10) ? ("0" + seconds) : String.valueOf(seconds));
	s = s.substring(0, s.length() - 1).replaceAll("^[^1-9]+", "")
		+ s.substring(s.length() - 1); // remove all leading zeros and
					       // colons
	if (milliSecs < 0) {
	    s = "-" + s;
	}
	return s;
    }

    static final public String truncate(final String target, final int maxSize) {
	return (target.length() > maxSize ? target.substring(0, maxSize)
		: target);
    }

    /**
     * Prevent the Utility class from being instantiated.
     */
    private Utility() {
	throw new IllegalStateException("Do not instantiate this class.");
    }
}
