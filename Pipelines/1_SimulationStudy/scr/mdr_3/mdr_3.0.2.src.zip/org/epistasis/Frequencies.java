package org.epistasis;

import java.util.Arrays;

import org.epistasis.mdr.Main;

/**
 * This code derived from eatomica.util.HistogramDiscrete from
 * http://rheneas.eng.buffalo.edu/wiki/Source Frequencies class capable of
 * keeping track of how many times each discrete value was passed in, similar to
 * what one would expect from a histogram with very small bin width. Two
 * incoming values are judged to be the same if they are within some tolerance,
 * which is specified at construction. The returned histogram is then the (raw)
 * probability with which each value was seen.
 * 
 * @author Andrew Schultz
 */
public class Frequencies {
    protected long totalCount;
    protected double tolerance;
    protected double[] xValues;
    protected long[] counts;
    private final static ColumnFormat fmt = new ColumnFormat(Arrays.asList(20,
	    20, 20), true /* useTabs */);

    public static String getDetailedTableHeader(final String prefix) {
	final StringBuilder sb = new StringBuilder();
	sb.append(Frequencies.fmt.format(Arrays.asList(prefix + "_bin_value",
		prefix + "_count", prefix + "_percentage")));
	return sb.toString();
    }

    public static String getSummaryTableHeader(final String prefix) {
	final StringBuilder sb = new StringBuilder();
	sb.append(prefix);
	sb.append("_min\t");
	sb.append(prefix);
	sb.append("_lowerRangeBoundary\t");
	sb.append(prefix);
	sb.append("_median\t");
	sb.append(prefix);
	sb.append("_upperRangeBoundary\t");
	sb.append(prefix);
	sb.append("_max\t");
	sb.append(prefix);
	sb.append("_ratioOfTopRelativeToMiddleRange\t");
	sb.append(prefix);
	sb.append("_averageOfTopRange\t");
	return sb.toString();
    }

    public Frequencies(final double tolerance) {
	this.tolerance = tolerance;
	xValues = new double[0];
	counts = new long[0];
    }

    public void addValue(final double x) {
	int bin;
	if (counts.length == 0) {
	    counts = new long[1];
	    xValues = new double[1];
	    bin = 0;
	    xValues[bin] = x;
	} else {
	    int maxBin = counts.length - 1;
	    int minBin = 0;
	    bin = (minBin + maxBin) / 2;
	    double diff = x - xValues[bin];
	    if (Double.isNaN(diff) && !Double.isNaN(x)) {
		diff = 0;
	    }
	    while (Math.abs(diff) > tolerance) {
		if (diff > 0) {
		    if (bin == maxBin) {
			final long[] newCounts = new long[counts.length + 1];
			System.arraycopy(counts, 0, newCounts, 0, maxBin + 1);
			if (maxBin < (counts.length - 1)) {
			    System.arraycopy(counts, maxBin + 1, newCounts,
				    maxBin + 2, counts.length - 1 - maxBin);
			}
			counts = newCounts;
			final double[] newXValues = new double[xValues.length + 1];
			System.arraycopy(xValues, 0, newXValues, 0, maxBin + 1);
			if (maxBin < (xValues.length - 1)) {
			    System.arraycopy(xValues, maxBin + 1, newXValues,
				    maxBin + 2, xValues.length - 1 - maxBin);
			}
			xValues = newXValues;
			bin++;
			xValues[bin] = x;
			break;
		    }
		    minBin = bin + 1;
		    bin = (minBin + maxBin) / 2;
		    diff = x - xValues[bin];
		} else {
		    if (bin == minBin) {
			final long[] newCounts = new long[counts.length + 1];
			if (minBin > 0) {
			    System.arraycopy(counts, 0, newCounts, 0, minBin);
			}
			System.arraycopy(counts, minBin, newCounts, minBin + 1,
				counts.length - minBin);
			counts = newCounts;
			final double[] newXValues = new double[xValues.length + 1];
			if (minBin > 0) {
			    System.arraycopy(xValues, 0, newXValues, 0, minBin);
			}
			System.arraycopy(xValues, minBin, newXValues,
				minBin + 1, xValues.length - minBin);
			xValues = newXValues;
			xValues[bin] = x;
			break;
		    }
		    maxBin = bin - 1;
		    bin = (minBin + maxBin) / 2;
		    diff = x - xValues[bin];
		}
	    }
	}
	counts[bin]++;
	totalCount++;
    }

    private void appendDetailedTableRow(final StringBuilder sb,
	    final double binValue, final double binFrequency,
	    final long binValueCount) {
	sb.append(Frequencies.fmt.format(Arrays.asList(
		Main.decimalUpToFourPrecision.format(binValue),
		String.valueOf(binValueCount),
		Main.decimalUpToFourPrecision.format(binFrequency * 100) + '%')));
	sb.append('\n');
    }

    public double getAverage() {
	double total = 0;
	for (int index = 0; index < xValues.length; ++index) {
	    total += xValues[index] * counts[index];
	}
	return total / totalCount;
    }

    public long[] getCounts() {
	return counts;
    }

    /*
     * @param fillInMissingValues -- Normally values are only printed out if
     * they have a non-zero count. For some distribution statistics (such as R
     * function fgev in library EVD) it is better to have an entry for every
     * interval, even if zero
     */
    public String getDetailedTableContent(final boolean fillInMissingValues) {
	final double[] frequencies = getFrequencies();
	final StringBuilder sb = new StringBuilder();
	double lastSeenvalue = getMinimumXRange();
	final double epsilon = tolerance / 100.0;
	for (int index = 0; index < xValues.length; ++index) {
	    final double currentValue = xValues[index];
	    final double currentValueFrequency = frequencies[index];
	    final long currentValueCount = counts[index];
	    if (fillInMissingValues) {
		for (double binValue = (lastSeenvalue + tolerance); (binValue + epsilon) < currentValue; binValue += tolerance) {
		    appendDetailedTableRow(sb, binValue, 0.0, 0);
		}
	    }
	    appendDetailedTableRow(sb, currentValue, currentValueFrequency,
		    currentValueCount);
	    lastSeenvalue = currentValue;
	}
	return (sb.toString());
    }

    /**
     * Numbers between 0 and 1 representing fraction of the total in each bin.
     * Can also be thought of as percentages divided by 100.
     * 
     * @return
     */
    public double[] getFrequencies() {
	final double[] histogram = new double[counts.length];
	for (int i = 0; i < counts.length; i++) {
	    histogram[i] = ((double) counts[i]) / totalCount;
	}
	return histogram;
    }

    /**
     * A common test to detect outliers is to determine the interquartile range
     * and then set a threshold of the value of Q3 + 1.5*IQR -- anything more
     * than that value is an outlier. In this case we are asking what multiple
     * of the IQR the maximum value is.
     * 
     * @return
     */
    public double getIQRMultipleOfMaximum() {
	return getRatioOfTopRelativeToMiddle(0.25);
    }

    public double getMaximumXRange() {
	double maximumXRange;
	if (xValues.length == 0) {
	    maximumXRange = Double.NaN;
	} else {
	    maximumXRange = xValues[xValues.length - 1];
	}
	return maximumXRange;
    }

    public double getMedian() {
	return getPercentileInclusive(0.50);
    }

    public double getMinimumXRange() {
	double minimumXRange;
	if (xValues.length == 0) {
	    minimumXRange = Double.NaN;
	} else {
	    minimumXRange = xValues[0];
	}
	return minimumXRange;
    }

    public int getNBins() {
	return counts.length;
    }

    /**
     * Returns the k-th percentile of values in a range. You can use this
     * function to establish a threshold of acceptance. For example, you can
     * decide to examine candidates who score above the 90th percentile. This
     * will interpolate when the value for the specified percentile lies between
     * two values in the array
     * 
     * @param requestedPercentile
     * @return
     */
    public double getPercentileInclusive(final double requestedPercentile) {
	final double countAtPercentile = totalCount * requestedPercentile;
	final long lowerCount = (long) Math.floor(countAtPercentile);
	final long higherCount = (long) Math.ceil(countAtPercentile);
	long countSoFar = 0;
	int index;
	for (index = 0; (index < xValues.length); ++index) {
	    countSoFar += counts[index];
	    if (countSoFar >= lowerCount) {
		break;
	    }
	}
	double percentileValue = xValues[index];
	if ((lowerCount != higherCount) && (countSoFar == lowerCount)) {
	    percentileValue = (percentileValue + xValues[index + 1]) / 2.0;
	}
	return percentileValue;
    }

    /*
     * similar to getIQRMultipleOfMaximum but instead of hard-coding 25 percent
     * as the boundary, it can be passed in
     */
    public double getRatioOfTopRelativeToMiddle(final double topPercentile) {
	final double lowerLimit = getPercentileInclusive(topPercentile);
	final double upperLimit = getPercentileInclusive(1.0 - topPercentile);
	final double maximum = xValues[xValues.length - 1];
	final double rangeBetween = upperLimit - lowerLimit;
	final double multiple = (maximum - upperLimit) / rangeBetween;
	return multiple;
    }

    /**
     * If percentInset passed in is is 0.25 then values for 0% (minimum value),
     * 25%(lower boundary), 50%(median), 75% (upper boundary), 100% (maximum).
     * lastly the average value for the topmost 25% is calculated
     * 
     * @param percentInset
     * @return
     */
    public String getSummaryTableContent(final double percentInset) {
	final StringBuilder sb = new StringBuilder();
	sb.append(Main.decimalUpToFourPrecision.format(getMinimumXRange()));
	sb.append("\t");
	sb.append(Main.decimalUpToFourPrecision
		.format(getPercentileInclusive(percentInset)));
	sb.append("\t");
	sb.append(Main.decimalUpToFourPrecision.format(getMedian()));
	sb.append("\t");
	sb.append(Main.decimalUpToFourPrecision
		.format(getPercentileInclusive(1.0 - percentInset)));
	sb.append("\t");
	sb.append(Main.decimalUpToFourPrecision.format(getMaximumXRange()));
	sb.append("\t");
	sb.append(Main.decimalUpToFourPrecision
		.format(getRatioOfTopRelativeToMiddle(percentInset)));
	sb.append("\t");
	sb.append(Main.decimalUpToFourPrecision.format(new UpperSubset(this,
		percentInset).getAverage()));
	sb.append("\t");
	return sb.toString();
    }

    public double getTolerance() {
	return tolerance;
    }

    public long getTotalCount() {
	return totalCount;
    }

    public double[] getXValues() {
	return xValues;
    }

    public void reset() {
	xValues = new double[0];
	counts = new long[0];
	totalCount = 0;
    }

    /**
     * Create subset of the top portion of a passed in Frencies object
     * 
     * @author pandrews
     */
    public static class UpperSubset extends Frequencies {
	public UpperSubset(final Frequencies superset,
		final double topPercentile) {
	    super(superset.tolerance);
	    initSubset(superset, topPercentile);
	}

	private void initSubset(final Frequencies superset,
		final double topPercentile) {
	    final double countAtPercentile = superset.totalCount
		    * (1.0 - topPercentile);
	    final long firstValueToTake = (long) Math.floor(countAtPercentile);
	    long countSoFar = 0;
	    int index;
	    for (index = 0; index < superset.xValues.length; ++index) {
		countSoFar += superset.counts[index];
		if (countSoFar > firstValueToTake) {
		    break;
		}
	    }
	    xValues = new double[superset.xValues.length - index];
	    counts = new long[xValues.length];
	    System.arraycopy(superset.counts, index, counts, 0, counts.length);
	    System.arraycopy(superset.xValues, index, xValues, 0,
		    xValues.length);
	    counts[0] -= firstValueToTake - countSoFar;
	    totalCount = 0;
	    for (final long binCount : counts) {
		totalCount += binCount;
	    }
	}

	public enum SUBSET {
	    TOP_QUARTILE, TOP_TEN_PERCENT;
	}
    } // end static class UpperSubset
}
