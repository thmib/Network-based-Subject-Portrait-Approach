package org.epistasis.gui;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JRootPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;

public class CmdMaximizeActionListener implements ActionListener {
    private JComponent enclosingComponent;
    private final JButton cmdMaximize;
    private Container oldContentPane = null;
    private Container originalParent;
    private int originalTabIndex;
    private String originalTabName;
    private boolean originalSplitIsOnLeft;

    public CmdMaximizeActionListener(final JComponent enclosingComponent,
	    final JButton cmdMaximize) {
	this.enclosingComponent = enclosingComponent;
	this.cmdMaximize = cmdMaximize;
    }

    @Override
    public void actionPerformed(final ActionEvent arg0) {
	final JRootPane rootPane = enclosingComponent.getRootPane();
	final Container contentPane = rootPane.getContentPane();
	if (contentPane != enclosingComponent) {
	    originalParent = enclosingComponent.getParent();
	    if (originalParent instanceof OrderedTabbedPane) {
		final OrderedTabbedPane tabbedPane = (OrderedTabbedPane) originalParent;
		tabbedPane.setOrderedTabVisible(enclosingComponent, false);
	    } else if (originalParent instanceof JTabbedPane) {
		final JTabbedPane tabbedPane = (JTabbedPane) originalParent;
		originalTabIndex = tabbedPane
			.indexOfComponent(enclosingComponent);
		originalTabName = tabbedPane.getTitleAt(originalTabIndex);
	    } else if (originalParent instanceof JSplitPane) {
		final JSplitPane splitpane = (JSplitPane) originalParent;
		originalSplitIsOnLeft = splitpane.getLeftComponent() == enclosingComponent;
	    } else {
		System.out.println("Dang: enclosingComponent= "
			+ enclosingComponent.getClass().getCanonicalName()
			+ " originalParent= "
			+ originalParent.getClass().getCanonicalName());
	    }
	    oldContentPane = contentPane;
	    rootPane.setContentPane(enclosingComponent);
	    cmdMaximize.setText("Restore");
	} else {
	    rootPane.setContentPane(oldContentPane);
	    oldContentPane = null;
	    cmdMaximize.setText("Maximize");
	    if (originalParent instanceof OrderedTabbedPane) {
		final OrderedTabbedPane tabbedPane = (OrderedTabbedPane) originalParent;
		tabbedPane.setOrderedTabVisible(enclosingComponent, true);
		tabbedPane.setSelectedComponent(enclosingComponent);
	    } else if (originalParent instanceof JTabbedPane) {
		final JTabbedPane tabbedPane = (JTabbedPane) originalParent;
		tabbedPane.insertTab(originalTabName, null, enclosingComponent,
			null, originalTabIndex);
		tabbedPane.setSelectedComponent(enclosingComponent);
	    } else if (originalParent instanceof JSplitPane) {
		final JSplitPane splitpane = (JSplitPane) originalParent;
		if (originalSplitIsOnLeft) {
		    splitpane.setLeftComponent(enclosingComponent);
		} else {
		    splitpane.setRightComponent(enclosingComponent);
		}
	    } else {
		System.out.println("During Restore : enclosingComponent= "
			+ enclosingComponent.getClass().getCanonicalName()
			+ " originalParent= "
			+ originalParent.getClass().getCanonicalName());
	    }
	}
	enclosingComponent.invalidate();
	enclosingComponent.setSize(enclosingComponent.getSize()); // force a
								  // resize
								  // event
	// enclosingComponent.validate();
	// enclosingComponent.repaint();
    } // end actionPerformed

    public void setEnclosingComponent(final JComponent newEnclosingComponent) {
	if (!(newEnclosingComponent.getParent() instanceof JTabbedPane)) {
	    throw new IllegalArgumentException(
		    "CmdMaximizeActionListener.setEnclosingComponent() was passed a component which is not contained within a JTabbedPane");
	}
	enclosingComponent = newEnclosingComponent;
    }
} // end class CmdMaximizeActionListener
