package org.epistasis.exceptions;

public class IncompleteBuildException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public IncompleteBuildException() {
	super();
    }

    public IncompleteBuildException(final String message) {
	super(message);
    }

    public IncompleteBuildException(final String message, final Throwable cause) {
	super(message, cause);
    }

    public IncompleteBuildException(final Throwable cause) {
	super(cause);
    }

}
